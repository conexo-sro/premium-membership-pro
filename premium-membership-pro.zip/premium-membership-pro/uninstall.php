<?php
/**
 * Uninstall Premium Membership Pro
 * 
 * This file runs when the plugin is deleted (not deactivated).
 * It removes all plugin data from the database.
 */

// If uninstall not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Check if user wants to keep data
$keep_data = get_option('pmp_keep_data_on_uninstall', false);

if ($keep_data) {
    // User wants to keep data - skip deletion
    return;
}

global $wpdb;

/**
 * Delete all plugin tables
 */
function pmp_delete_tables() {
    global $wpdb;
    
    $tables = array(
        $wpdb->prefix . 'pmp_memberships',
        $wpdb->prefix . 'pmp_transactions',
        $wpdb->prefix . 'pmp_access_logs',
    );
    
    foreach ($tables as $table) {
        $wpdb->query("DROP TABLE IF EXISTS {$table}");
    }
}

/**
 * Delete all plugin options
 */
function pmp_delete_options() {
    global $wpdb;
    
    // Delete all options starting with 'pmp_'
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'pmp_%'");
    
    // Delete specific options
    $options = array(
        'pmp_version',
        'pmp_db_version',
        'pmp_currency',
        'pmp_currency_position',
        'pmp_enable_stripe',
        'pmp_stripe_public_key',
        'pmp_stripe_secret_key',
        'pmp_enable_paypal',
        'pmp_paypal_client_id',
        'pmp_paypal_secret',
        'pmp_enable_bank_transfer',
        'pmp_bank_account_number',
        'pmp_bank_iban',
        'pmp_enable_elementor',
        'pmp_keep_data_on_uninstall',
    );
    
    foreach ($options as $option) {
        delete_option($option);
    }
}

/**
 * Delete all plugin post types and their meta
 */
function pmp_delete_post_types() {
    global $wpdb;
    
    $post_types = array(
        'pmp_membership',
        'pmp_product',
        'pmp_coupon',
    );
    
    foreach ($post_types as $post_type) {
        // Get all posts of this type
        $posts = get_posts(array(
            'post_type' => $post_type,
            'numberposts' => -1,
            'post_status' => 'any',
        ));
        
        // Delete each post and its meta
        foreach ($posts as $post) {
            // Delete post meta
            $wpdb->delete(
                $wpdb->postmeta,
                array('post_id' => $post->ID),
                array('%d')
            );
            
            // Delete post
            wp_delete_post($post->ID, true);
        }
    }
}

/**
 * Delete all user meta added by plugin
 */
function pmp_delete_user_meta() {
    global $wpdb;
    
    // Delete all user meta starting with 'pmp_'
    $wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE 'pmp_%'");
    
    // Delete specific user meta
    $meta_keys = array(
        '_pmp_membership_id',
        '_pmp_membership_level',
        '_pmp_membership_status',
        '_pmp_membership_start',
        '_pmp_membership_end',
    );
    
    foreach ($meta_keys as $meta_key) {
        delete_metadata('user', 0, $meta_key, '', true);
    }
}

/**
 * Remove custom capabilities from all roles
 */
function pmp_remove_capabilities() {
    global $wp_roles;
    
    if (!class_exists('WP_Roles')) {
        return;
    }
    
    if (!isset($wp_roles)) {
        $wp_roles = new WP_Roles();
    }
    
    $capabilities = array(
        'pmp_view_dashboard',
        'pmp_manage_levels',
        'pmp_edit_level',
        'pmp_delete_level',
        'pmp_manage_members',
        'pmp_edit_member',
        'pmp_delete_member',
        'pmp_view_transactions',
        'pmp_manage_transactions',
        'pmp_view_reports',
        'pmp_export_data',
        'pmp_manage_products',
        'pmp_edit_product',
        'pmp_delete_product',
        'pmp_manage_coupons',
        'pmp_edit_coupon',
        'pmp_delete_coupon',
        'pmp_manage_emails',
        'pmp_send_emails',
        'pmp_manage_protection',
        'pmp_view_logs',
        'pmp_manage_settings',
        'pmp_manage_roles',
    );
    
    foreach ($wp_roles->roles as $role_name => $role_info) {
        $role = get_role($role_name);
        if ($role) {
            foreach ($capabilities as $cap) {
                $role->remove_cap($cap);
            }
        }
    }
    
    // Remove custom role
    remove_role('membership_manager');
}

/**
 * Delete plugin uploads folder
 */
function pmp_delete_uploads() {
    $upload_dir = wp_upload_dir();
    $pmp_uploads = $upload_dir['basedir'] . '/pmp-uploads';
    
    if (is_dir($pmp_uploads)) {
        pmp_delete_directory($pmp_uploads);
    }
}

/**
 * Recursively delete directory
 */
function pmp_delete_directory($dir) {
    if (!is_dir($dir)) {
        return;
    }
    
    $files = array_diff(scandir($dir), array('.', '..'));
    
    foreach ($files as $file) {
        $path = $dir . '/' . $file;
        is_dir($path) ? pmp_delete_directory($path) : unlink($path);
    }
    
    return rmdir($dir);
}

/**
 * Clear all transients
 */
function pmp_delete_transients() {
    global $wpdb;
    
    // Delete all transients starting with 'pmp_'
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_pmp_%'");
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_pmp_%'");
}

/**
 * Execute cleanup
 */
pmp_delete_tables();
pmp_delete_options();
pmp_delete_post_types();
pmp_delete_user_meta();
pmp_remove_capabilities();
pmp_delete_uploads();
pmp_delete_transients();

// Clear any cached data
wp_cache_flush();
