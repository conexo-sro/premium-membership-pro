<?php
/**
 * MANUAL DATABASE SETUP
 * Premium Membership Pro - Manuální vytvoření databázových tabulek
 * 
 * POUŽITÍ:
 * 1. Nahraj tento soubor přes FTP do složky pluginu: /wp-content/plugins/premium-membership-pro/
 * 2. Otevři v browseru: https://tvuj-web.cz/wp-content/plugins/premium-membership-pro/create-tables-manual.php
 * 3. Tabulky se vytvoří
 * 4. SMAŽ tento soubor po dokončení!
 */

// Security check
if (!isset($_GET['confirm']) || $_GET['confirm'] !== 'yes') {
    die('Pro vytvoření tabulek přidej ?confirm=yes na konec URL<br>Příklad: create-tables-manual.php?confirm=yes');
}

// Load WordPress
require_once('../../../wp-load.php');

// Check permissions
if (!current_user_can('activate_plugins')) {
    wp_die('Nemáš oprávnění spustit tento skript. Musíš být přihlášen jako administrátor.');
}

global $wpdb;
$charset_collate = $wpdb->get_charset_collate();

echo '<h1>Premium Membership Pro - Vytváření tabulek</h1>';
echo '<pre>';

require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

$tables_created = array();
$tables_failed = array();

// 1. MEMBERSHIPS TABLE
echo "\n1. Vytvářím tabulku: {$wpdb->prefix}pmp_memberships\n";
$table_memberships = $wpdb->prefix . 'pmp_memberships';
$sql_memberships = "CREATE TABLE $table_memberships (
    id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    user_id bigint(20) unsigned NOT NULL,
    level_id bigint(20) unsigned NOT NULL,
    status varchar(50) NOT NULL DEFAULT 'active',
    start_date datetime NOT NULL,
    end_date datetime DEFAULT NULL,
    trial_end_date datetime DEFAULT NULL,
    payment_gateway varchar(50) DEFAULT NULL,
    subscription_id varchar(255) DEFAULT NULL,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    PRIMARY KEY  (id),
    KEY user_id (user_id),
    KEY level_id (level_id),
    KEY status (status)
) $charset_collate;";

dbDelta($sql_memberships);

if ($wpdb->get_var("SHOW TABLES LIKE '$table_memberships'") == $table_memberships) {
    echo "✅ Tabulka $table_memberships vytvořena!\n";
    $tables_created[] = $table_memberships;
} else {
    echo "❌ CHYBA: Nepodařilo se vytvořit $table_memberships\n";
    echo "SQL Chyba: " . $wpdb->last_error . "\n";
    $tables_failed[] = $table_memberships;
}

// 2. TRANSACTIONS TABLE
echo "\n2. Vytvářím tabulku: {$wpdb->prefix}pmp_transactions\n";
$table_transactions = $wpdb->prefix . 'pmp_transactions';
$sql_transactions = "CREATE TABLE $table_transactions (
    id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    user_id bigint(20) unsigned NOT NULL,
    membership_id bigint(20) unsigned DEFAULT NULL,
    amount decimal(10,2) NOT NULL,
    currency varchar(10) NOT NULL DEFAULT 'CZK',
    status varchar(50) NOT NULL DEFAULT 'pending',
    payment_gateway varchar(50) NOT NULL,
    transaction_id varchar(255) DEFAULT NULL,
    invoice_number varchar(100) DEFAULT NULL,
    description text,
    created_at datetime NOT NULL,
    updated_at datetime NOT NULL,
    PRIMARY KEY  (id),
    KEY user_id (user_id),
    KEY membership_id (membership_id),
    KEY status (status)
) $charset_collate;";

dbDelta($sql_transactions);

if ($wpdb->get_var("SHOW TABLES LIKE '$table_transactions'") == $table_transactions) {
    echo "✅ Tabulka $table_transactions vytvořena!\n";
    $tables_created[] = $table_transactions;
} else {
    echo "❌ CHYBA: Nepodařilo se vytvořit $table_transactions\n";
    echo "SQL Chyba: " . $wpdb->last_error . "\n";
    $tables_failed[] = $table_transactions;
}

// 3. ACCESS LOGS TABLE
echo "\n3. Vytvářím tabulku: {$wpdb->prefix}pmp_access_logs\n";
$table_logs = $wpdb->prefix . 'pmp_access_logs';
$sql_logs = "CREATE TABLE $table_logs (
    id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    user_id bigint(20) unsigned NOT NULL,
    post_id bigint(20) unsigned NOT NULL,
    membership_level_id bigint(20) unsigned NOT NULL,
    access_type varchar(50) NOT NULL,
    ip_address varchar(45) DEFAULT NULL,
    user_agent text,
    accessed_at datetime NOT NULL,
    PRIMARY KEY  (id),
    KEY user_id (user_id),
    KEY post_id (post_id),
    KEY accessed_at (accessed_at)
) $charset_collate;";

dbDelta($sql_logs);

if ($wpdb->get_var("SHOW TABLES LIKE '$table_logs'") == $table_logs) {
    echo "✅ Tabulka $table_logs vytvořena!\n";
    $tables_created[] = $table_logs;
} else {
    echo "❌ CHYBA: Nepodařilo se vytvořit $table_logs\n";
    echo "SQL Chyba: " . $wpdb->last_error . "\n";
    $tables_failed[] = $table_logs;
}

// 4. EMAIL LOGS TABLE
echo "\n4. Vytvářím tabulku: {$wpdb->prefix}pmp_email_logs\n";
$table_emails = $wpdb->prefix . 'pmp_email_logs';
$sql_emails = "CREATE TABLE $table_emails (
    id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    user_id bigint(20) unsigned NOT NULL,
    email_type varchar(100) NOT NULL,
    subject varchar(255) NOT NULL,
    status varchar(50) NOT NULL DEFAULT 'sent',
    sent_at datetime NOT NULL,
    PRIMARY KEY  (id),
    KEY user_id (user_id),
    KEY email_type (email_type)
) $charset_collate;";

dbDelta($sql_emails);

if ($wpdb->get_var("SHOW TABLES LIKE '$table_emails'") == $table_emails) {
    echo "✅ Tabulka $table_emails vytvořena!\n";
    $tables_created[] = $table_emails;
} else {
    echo "❌ CHYBA: Nepodařilo se vytvořit $table_emails\n";
    echo "SQL Chyba: " . $wpdb->last_error . "\n";
    $tables_failed[] = $table_emails;
}

// SUMMARY
echo "\n" . str_repeat('=', 60) . "\n";
echo "SOUHRN:\n";
echo str_repeat('=', 60) . "\n\n";

if (count($tables_created) > 0) {
    echo "✅ Vytvořeno tabulek: " . count($tables_created) . "\n";
    foreach ($tables_created as $table) {
        echo "   - $table\n";
    }
}

if (count($tables_failed) > 0) {
    echo "\n❌ Selhalo vytvoření: " . count($tables_failed) . "\n";
    foreach ($tables_failed as $table) {
        echo "   - $table\n";
    }
    echo "\nKONTROLA:\n";
    echo "1. Zkontroluj databázová oprávnění\n";
    echo "2. Zkontroluj MySQL verzi (minimálně 5.7)\n";
    echo "3. Zkontroluj dostupné místo v databázi\n";
}

// Store version
if (count($tables_created) == 4) {
    update_option('pmp_db_version', '1.8.0');
    echo "\n✅ Databázová verze uložena: 1.8.0\n";
}

echo "\n" . str_repeat('=', 60) . "\n";
echo "HOTOVO!\n";
echo str_repeat('=', 60) . "\n\n";

echo "DALŠÍ KROKY:\n";
echo "1. Zkontroluj že všechny 4 tabulky jsou vytvořené (✅)\n";
echo "2. Jdi do WordPress Admin\n";
echo "3. Deaktivuj a znovu aktivuj plugin Premium Membership Pro\n";
echo "4. DŮLEŽITÉ: SMAŽ tento soubor create-tables-manual.php!\n";

echo '</pre>';

echo '<hr>';
echo '<h2>Kontrola tabulek v databázi:</h2>';
echo '<table border="1" cellpadding="10" style="border-collapse: collapse;">';
echo '<tr><th>Tabulka</th><th>Status</th><th>Počet sloupců</th></tr>';

$tables = array(
    $wpdb->prefix . 'pmp_memberships',
    $wpdb->prefix . 'pmp_transactions',
    $wpdb->prefix . 'pmp_access_logs',
    $wpdb->prefix . 'pmp_email_logs'
);

foreach ($tables as $table) {
    $exists = $wpdb->get_var("SHOW TABLES LIKE '$table'") == $table;
    $columns = $exists ? $wpdb->get_results("SHOW COLUMNS FROM $table") : array();
    
    echo '<tr>';
    echo '<td><strong>' . $table . '</strong></td>';
    echo '<td style="color: ' . ($exists ? 'green' : 'red') . '">' . ($exists ? '✅ Existuje' : '❌ Neexistuje') . '</td>';
    echo '<td>' . count($columns) . '</td>';
    echo '</tr>';
}

echo '</table>';
