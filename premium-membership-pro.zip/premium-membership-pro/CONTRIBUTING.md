# Contributing to Premium Membership Pro

Děkujeme za váš zájem přispět do Premium Membership Pro! 🎉

## Jak přispět

### Hlášení chyb (Bug Reports)

Pokud najdete chybu, vytvořte prosím issue s následujícími informacemi:

- **Popis chyby**: Jasný a stručný popis problému
- **Kroky k reprodukci**: Jak problém vyvolat
- **Očekávané chování**: Co by se mělo stát
- **Skutečné chování**: Co se ve skutečnosti děje
- **Screenshots**: Pokud je to relevantní
- **Prostředí**:
  - WordPress verze
  - PHP verze
  - Téma
  - Další pluginy

### Návrhy funkcí (Feature Requests)

Máte nápad na vylepšení? Skvělé! Vytvořte issue s:

- **Popis funkce**: Co by nová funkce měla dělat
- **Use case**: Proč je to užitečné
- **Alternativy**: Jaké jiné řešení jste zvažovali
- **Dodatečné informace**: Mockupy, příklady z jiných pluginů, atd.

### Pull Requests

1. **Forkněte** repository
2. **Vytvořte branch** pro vaši funkci (`git checkout -b feature/AmazingFeature`)
3. **Commitujte změny** (`git commit -m 'Add some AmazingFeature'`)
4. **Pushněte** do branche (`git push origin feature/AmazingFeature`)
5. **Otevřete Pull Request**

### Coding Standards

- Používejte **WordPress Coding Standards**
- Komentujte kód v **angličtině**
- Uživatelská rozhraní a texty v **češtině**
- Přidejte **PHPDoc** komentáře k funkcím
- Testujte na **nejnovější verzi WordPressu**

### Commit Messages

Používejte jasné commit messages:

```
feat: Přidání nové funkce XYZ
fix: Oprava chyby v platební bráně
docs: Aktualizace dokumentace
style: Formátování kódu
refactor: Refaktoring třídy ABC
test: Přidání testů
chore: Aktualizace dependencies
```

### Testování

Před odesláním PR:

- ✅ Otestujte na čisté instalaci WordPressu
- ✅ Zkontrolujte kompatibilitu s populárními tématy
- ✅ Ověřte responzivitu na mobilech
- ✅ Zkontrolujte konzoli na chyby
- ✅ Otestujte s vypnutým cache

## Kodex chování

- Buďte přátelští a respektující
- Přijímejte konstruktivní kritiku
- Zaměřte se na to, co je nejlepší pro komunitu
- Ukažte empatii k ostatním členům komunity

## Otázky?

Máte otázky? Kontaktujte nás:

- 📧 Email: support@example.com
- 💬 Discussions: GitHub Discussions
- 📖 Dokumentace: README.md

Děkujeme za vaši pomoc při vylepšování Premium Membership Pro! 🚀
