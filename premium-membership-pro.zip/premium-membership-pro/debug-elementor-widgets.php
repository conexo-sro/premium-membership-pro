<?php
/**
 * ELEMENTOR WIDGETS DEBUG
 * 
 * Tento soubor pomáhá zjistit, proč se widgety nezobrazují
 * 
 * POUŽITÍ:
 * Přidejte do functions.php:
 * 
 * include_once WP_PLUGIN_DIR . '/premium-membership-pro/debug-elementor-widgets.php';
 */

if (!defined('ABSPATH')) {
    exit;
}

// Add admin notice with debug info
add_action('admin_notices', function() {
    if (!current_user_can('manage_options')) {
        return;
    }
    
    // Only show on Elementor editor or widgets page
    $screen = get_current_screen();
    if (!$screen || !in_array($screen->id, array('toplevel_page_elementor', 'edit-elementor_library'))) {
        return;
    }
    
    ?>
    <div class="notice notice-info" style="padding: 15px; background: #fff; border-left: 4px solid #2271b1;">
        <h3>🔍 PMP Elementor Widgets Debug</h3>
        
        <h4>Elementor Status:</h4>
        <ul style="font-family: monospace; font-size: 12px;">
            <li>Elementor installed: <?php echo defined('ELEMENTOR_VERSION') ? '✅ YES (' . ELEMENTOR_VERSION . ')' : '❌ NO'; ?></li>
            <li>Elementor loaded: <?php echo did_action('elementor/loaded') ? '✅ YES' : '❌ NO'; ?></li>
            <li>Elementor active: <?php echo class_exists('\Elementor\Plugin') ? '✅ YES' : '❌ NO'; ?></li>
        </ul>
        
        <h4>PMP Integration:</h4>
        <ul style="font-family: monospace; font-size: 12px;">
            <li>PMP_Elementor class: <?php echo class_exists('PMP_Elementor') ? '✅ EXISTS' : '❌ NOT FOUND'; ?></li>
            <li>Integration enabled: <?php echo get_option('pmp_enable_elementor', '1') === '1' ? '✅ YES' : '❌ NO'; ?></li>
            <?php if (class_exists('PMP_Elementor')): ?>
                <li>Integration ready: <?php echo PMP_Elementor::is_integration_ready() ? '✅ YES' : '❌ NO'; ?></li>
            <?php endif; ?>
        </ul>
        
        <h4>Widget Files:</h4>
        <ul style="font-family: monospace; font-size: 12px;">
            <?php
            $widget_files = array(
                'base-widget.php',
                'membership-levels.php',
                'login-form.php',
                'registration-form.php',
                'account-page.php',
                'member-content.php',
                'pricing-table.php',
                'membership-status.php',
            );
            
            foreach ($widget_files as $file) {
                $path = WP_PLUGIN_DIR . '/premium-membership-pro/elementor/widgets/' . $file;
                $exists = file_exists($path);
                echo '<li>' . $file . ': ' . ($exists ? '✅ EXISTS' : '❌ NOT FOUND') . '</li>';
            }
            ?>
        </ul>
        
        <h4>Widget Classes:</h4>
        <ul style="font-family: monospace; font-size: 12px;">
            <li>PMP_Elementor_Base_Widget: <?php echo class_exists('PMP_Elementor_Base_Widget') ? '✅ LOADED' : '❌ NOT LOADED'; ?></li>
            <li>PMP_Elementor_Membership_Levels_Widget: <?php echo class_exists('PMP_Elementor_Membership_Levels_Widget') ? '✅ LOADED' : '❌ NOT LOADED'; ?></li>
            <li>PMP_Elementor_Login_Form_Widget: <?php echo class_exists('PMP_Elementor_Login_Form_Widget') ? '✅ LOADED' : '❌ NOT LOADED'; ?></li>
            <li>PMP_Elementor_Registration_Form_Widget: <?php echo class_exists('PMP_Elementor_Registration_Form_Widget') ? '✅ LOADED' : '❌ NOT LOADED'; ?></li>
            <li>PMP_Elementor_Account_Page_Widget: <?php echo class_exists('PMP_Elementor_Account_Page_Widget') ? '✅ LOADED' : '❌ NOT LOADED'; ?></li>
            <li>PMP_Elementor_Member_Content_Widget: <?php echo class_exists('PMP_Elementor_Member_Content_Widget') ? '✅ LOADED' : '❌ NOT LOADED'; ?></li>
            <li>PMP_Elementor_Pricing_Table_Widget: <?php echo class_exists('PMP_Elementor_Pricing_Table_Widget') ? '✅ LOADED' : '❌ NOT LOADED'; ?></li>
            <li>PMP_Elementor_Membership_Status_Widget: <?php echo class_exists('PMP_Elementor_Membership_Status_Widget') ? '✅ LOADED' : '❌ NOT LOADED'; ?></li>
        </ul>
        
        <h4>Registered Widgets:</h4>
        <?php
        if (class_exists('\Elementor\Plugin') && \Elementor\Plugin::instance()->widgets_manager) {
            $widgets_manager = \Elementor\Plugin::instance()->widgets_manager;
            $all_widgets = $widgets_manager->get_widget_types();
            
            $pmp_widgets = array_filter($all_widgets, function($widget_name) {
                return strpos($widget_name, 'pmp-') === 0;
            }, ARRAY_FILTER_USE_KEY);
            
            if (!empty($pmp_widgets)) {
                echo '<ul style="font-family: monospace; font-size: 12px; color: green;">';
                foreach ($pmp_widgets as $widget_name => $widget_obj) {
                    echo '<li>✅ ' . $widget_name . ' (' . $widget_obj->get_title() . ')</li>';
                }
                echo '</ul>';
            } else {
                echo '<p style="color: red; font-weight: bold;">❌ NO PMP WIDGETS REGISTERED!</p>';
            }
        } else {
            echo '<p style="color: red;">❌ Cannot access widgets manager</p>';
        }
        ?>
        
        <h4>Hooks Registered:</h4>
        <ul style="font-family: monospace; font-size: 12px;">
            <?php
            global $wp_filter;
            
            $hooks_to_check = array(
                'elementor/widgets/register',
                'elementor/widgets/widgets_registered',
                'elementor/elements/categories_registered',
            );
            
            foreach ($hooks_to_check as $hook) {
                $has_callbacks = isset($wp_filter[$hook]) && !empty($wp_filter[$hook]->callbacks);
                echo '<li>' . $hook . ': ' . ($has_callbacks ? '✅ HAS CALLBACKS' : '❌ NO CALLBACKS') . '</li>';
                
                if ($has_callbacks && isset($wp_filter[$hook]->callbacks)) {
                    foreach ($wp_filter[$hook]->callbacks as $priority => $callbacks) {
                        foreach ($callbacks as $callback) {
                            if (is_array($callback['function'])) {
                                $class = is_object($callback['function'][0]) ? get_class($callback['function'][0]) : $callback['function'][0];
                                $method = $callback['function'][1];
                                echo '<li style="margin-left: 20px;">→ ' . $class . '::' . $method . ' (priority: ' . $priority . ')</li>';
                            }
                        }
                    }
                }
            }
            ?>
        </ul>
        
        <h4>Widget Categories:</h4>
        <?php
        if (class_exists('\Elementor\Plugin') && \Elementor\Plugin::instance()->elements_manager) {
            $elements_manager = \Elementor\Plugin::instance()->elements_manager;
            $categories = $elements_manager->get_categories();
            
            if (isset($categories['pmp-elements'])) {
                echo '<p style="color: green;">✅ Category "pmp-elements" is registered</p>';
            } else {
                echo '<p style="color: red;">❌ Category "pmp-elements" NOT registered!</p>';
                echo '<p>Available categories:</p>';
                echo '<ul style="font-family: monospace; font-size: 12px;">';
                foreach ($categories as $key => $category) {
                    echo '<li>' . $key . ' (' . $category['title'] . ')</li>';
                }
                echo '</ul>';
            }
        }
        ?>
        
        <h4>Recommended Actions:</h4>
        <?php
        $issues = array();
        
        if (!defined('ELEMENTOR_VERSION')) {
            $issues[] = '❌ Install Elementor plugin';
        }
        if (!did_action('elementor/loaded')) {
            $issues[] = '❌ Activate Elementor plugin';
        }
        if (get_option('pmp_enable_elementor', '1') !== '1') {
            $issues[] = '❌ Enable Elementor integration in PMP settings';
        }
        if (!class_exists('PMP_Elementor_Base_Widget')) {
            $issues[] = '❌ Base widget class not loaded - check file permissions';
        }
        
        if (empty($issues)) {
            echo '<p style="color: green; font-weight: bold;">✅ All checks passed! Widgets should be visible.</p>';
            echo '<p>If widgets still not visible, try:</p>';
            echo '<ul>';
            echo '<li>1. Deactivate and reactivate PMP plugin</li>';
            echo '<li>2. Clear Elementor cache (Tools → Regenerate CSS)</li>';
            echo '<li>3. Hard refresh browser (Ctrl+Shift+R)</li>';
            echo '</ul>';
        } else {
            echo '<ul style="color: red; font-weight: bold;">';
            foreach ($issues as $issue) {
                echo '<li>' . $issue . '</li>';
            }
            echo '</ul>';
        }
        ?>
        
        <p style="margin-top: 15px;">
            <button onclick="this.parentElement.parentElement.style.display='none'" style="padding: 5px 15px; cursor: pointer;">
                Close Debug Panel
            </button>
        </p>
    </div>
    
    <script>
    console.log('🔍 PMP Elementor Widgets Debug');
    console.log('Elementor version:', '<?php echo defined('ELEMENTOR_VERSION') ? ELEMENTOR_VERSION : 'NOT INSTALLED'; ?>');
    console.log('Elementor loaded:', <?php echo did_action('elementor/loaded') ? 'true' : 'false'; ?>);
    console.log('PMP integration ready:', <?php echo class_exists('PMP_Elementor') && PMP_Elementor::is_integration_ready() ? 'true' : 'false'; ?>);
    </script>
    <?php
});
