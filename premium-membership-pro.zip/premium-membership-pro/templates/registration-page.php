<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrace - Premium Membership</title>
    <link rel="stylesheet" href="<?php echo PMP_PLUGIN_URL; ?>assets/css/frontend.css">
</head>
<body class="pmp-page-wrapper">
    <div class="pmp-login-page">
        <div class="pmp-login-container">
            <div class="pmp-login-card">
                <div class="pmp-login-header">
                    <div class="pmp-login-logo">
                        <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M20 5L35 12.5V27.5L20 35L5 27.5V12.5L20 5Z" stroke="white" stroke-width="2" fill="none"/>
                            <circle cx="20" cy="20" r="6" fill="white"/>
                        </svg>
                    </div>
                    <h1 class="pmp-login-title">Začněte dnes</h1>
                    <p class="pmp-login-subtitle">Vytvořte si účet a získejte přístup k prémiový obsahu</p>
                </div>

                <?php if (isset($_GET['error'])): ?>
                    <div class="pmp-error-message">
                        <?php 
                        switch($_GET['error']) {
                            case 'username_exists':
                                echo '❌ Toto uživatelské jméno již existuje';
                                break;
                            case 'email_exists':
                                echo '❌ Tento email je již zaregistrován';
                                break;
                            case 'empty':
                                echo '⚠️ Prosím vyplňte všechna pole';
                                break;
                            default:
                                echo '❌ Došlo k chybě při registraci';
                        }
                        ?>
                    </div>
                <?php endif; ?>

                <form class="pmp-login-form" method="post" action="<?php echo esc_url(site_url('wp-login.php?action=register', 'login_post')); ?>">
                    <div class="pmp-form-group">
                        <label class="pmp-form-label" for="user_login">
                            Uživatelské jméno
                        </label>
                        <input 
                            type="text" 
                            name="user_login" 
                            id="user_login" 
                            class="pmp-form-input" 
                            placeholder="vase_jmeno"
                            required
                            autocomplete="username"
                        >
                    </div>

                    <div class="pmp-form-group">
                        <label class="pmp-form-label" for="user_email">
                            Email
                        </label>
                        <input 
                            type="email" 
                            name="user_email" 
                            id="user_email" 
                            class="pmp-form-input" 
                            placeholder="vas@email.cz"
                            required
                            autocomplete="email"
                        >
                    </div>

                    <div class="pmp-form-group">
                        <label class="pmp-form-label" for="user_pass">
                            Heslo
                        </label>
                        <input 
                            type="password" 
                            name="user_pass" 
                            id="user_pass" 
                            class="pmp-form-input" 
                            placeholder="••••••••"
                            required
                            autocomplete="new-password"
                            minlength="8"
                        >
                        <small style="color: var(--text-secondary); font-size: 12px; display: block; margin-top: 5px;">
                            Minimálně 8 znaků
                        </small>
                    </div>

                    <div class="pmp-form-checkbox">
                        <input 
                            type="checkbox" 
                            name="agree_terms" 
                            id="agree_terms" 
                            required
                        >
                        <label for="agree_terms">
                            Souhlasím s <a href="#" style="color: #667eea; text-decoration: none;">podmínkami použití</a>
                        </label>
                    </div>

                    <input type="hidden" name="redirect_to" value="<?php echo esc_url($atts['redirect'] ? $atts['redirect'] : home_url('/prihlaseni?registered=true')); ?>">

                    <button type="submit" class="pmp-submit-button">
                        Vytvořit účet
                    </button>
                </form>

                <div class="pmp-form-footer">
                    <div class="pmp-form-links" style="justify-content: center;">
                        <span style="color: var(--text-secondary); font-size: 14px;">
                            Už máte účet?
                        </span>
                        <a href="<?php echo wp_login_url(); ?>" class="pmp-form-link">
                            Přihlásit se
                        </a>
                    </div>

                    <div class="pmp-social-login">
                        <div class="pmp-social-divider">
                            nebo se zaregistrujte přes
                        </div>
                        <div class="pmp-social-buttons">
                            <a href="#" class="pmp-social-button" onclick="alert('Google registrace - implementujte OAuth'); return false;">
                                <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                                    <path d="M19.6 10.23c0-.82-.1-1.42-.25-2.05H10v3.72h5.5c-.15.96-.74 2.31-2.04 3.22v2.45h3.16c1.89-1.73 2.98-4.3 2.98-7.34z"/>
                                    <path d="M13.46 15.13c-.83.59-1.96 1-3.46 1-2.64 0-4.88-1.74-5.68-4.15H1.07v2.52C2.72 17.75 6.09 20 10 20c2.7 0 4.96-.89 6.62-2.42l-3.16-2.45z"/>
                                    <path d="M3.99 10c0-.69.12-1.35.32-1.97V5.51H1.07A9.973 9.973 0 000 10c0 1.61.39 3.14 1.07 4.49l3.24-2.52c-.2-.62-.32-1.28-.32-1.97z"/>
                                    <path d="M10 3.88c1.88 0 3.13.81 3.85 1.48l2.84-2.76C14.96.99 12.7 0 10 0 6.09 0 2.72 2.25 1.07 5.51l3.24 2.52C5.12 5.62 7.36 3.88 10 3.88z"/>
                                </svg>
                                Google
                            </a>
                            <a href="#" class="pmp-social-button" onclick="alert('Facebook registrace - implementujte OAuth'); return false;">
                                <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                                    <path d="M20 10c0-5.523-4.477-10-10-10S0 4.477 0 10c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V10h2.54V7.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V10h2.773l-.443 2.89h-2.33v6.988C16.343 19.128 20 14.991 20 10z"/>
                                </svg>
                                Facebook
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Decorative Elements -->
            <svg class="pmp-decorative-circle" style="position: absolute; top: -100px; right: -100px; opacity: 0.1; width: 300px; height: 300px; pointer-events: none;" viewBox="0 0 200 200">
                <polygon points="100,20 180,60 180,140 100,180 20,140 20,60" fill="none" stroke="url(#gradient3)" stroke-width="2">
                    <animateTransform
                        attributeName="transform"
                        type="rotate"
                        from="0 100 100"
                        to="360 100 100"
                        dur="30s"
                        repeatCount="indefinite"/>
                </polygon>
                <defs>
                    <linearGradient id="gradient3" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" style="stop-color:#4facfe;stop-opacity:1" />
                        <stop offset="100%" style="stop-color:#00f2fe;stop-opacity:1" />
                    </linearGradient>
                </defs>
            </svg>
        </div>
    </div>

    <script>
    // Add floating particles effect
    function createParticle() {
        const particle = document.createElement('div');
        const colors = ['rgba(102, 126, 234, 0.6)', 'rgba(245, 87, 108, 0.6)', 'rgba(79, 172, 254, 0.6)'];
        
        particle.style.cssText = `
            position: fixed;
            width: ${3 + Math.random() * 4}px;
            height: ${3 + Math.random() * 4}px;
            background: ${colors[Math.floor(Math.random() * colors.length)]};
            border-radius: 50%;
            pointer-events: none;
            z-index: 0;
        `;
        
        particle.style.left = Math.random() * window.innerWidth + 'px';
        particle.style.top = window.innerHeight + 'px';
        
        document.body.appendChild(particle);
        
        const duration = 10000 + Math.random() * 10000;
        const distance = 100 + Math.random() * 300;
        
        particle.animate([
            { transform: `translateY(0) translateX(0)`, opacity: 0 },
            { transform: `translateY(-${distance}px) translateX(${Math.random() * 100 - 50}px)`, opacity: 1, offset: 0.1 },
            { transform: `translateY(-${window.innerHeight + 100}px) translateX(${Math.random() * 100 - 50}px)`, opacity: 0 }
        ], {
            duration: duration,
            easing: 'linear'
        }).onfinish = () => particle.remove();
    }

    // Create particles periodically
    setInterval(createParticle, 500);

    // Password strength indicator
    const passwordInput = document.getElementById('user_pass');
    const strengthDiv = document.createElement('div');
    strengthDiv.style.cssText = `
        margin-top: 10px;
        padding: 8px 12px;
        border-radius: 8px;
        font-size: 12px;
        font-weight: 600;
        text-align: center;
        display: none;
    `;
    passwordInput.parentElement.appendChild(strengthDiv);

    passwordInput.addEventListener('input', function() {
        const password = this.value;
        if (password.length === 0) {
            strengthDiv.style.display = 'none';
            return;
        }
        
        strengthDiv.style.display = 'block';
        
        let strength = 0;
        if (password.length >= 8) strength++;
        if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength++;
        if (password.match(/[0-9]/)) strength++;
        if (password.match(/[^a-zA-Z0-9]/)) strength++;
        
        if (strength <= 1) {
            strengthDiv.textContent = '⚠️ Slabé heslo';
            strengthDiv.style.background = 'rgba(255, 107, 107, 0.2)';
            strengthDiv.style.color = '#ff6b6b';
        } else if (strength === 2) {
            strengthDiv.textContent = '🔶 Střední heslo';
            strengthDiv.style.background = 'rgba(255, 217, 61, 0.2)';
            strengthDiv.style.color = '#ffd93d';
        } else {
            strengthDiv.textContent = '✓ Silné heslo';
            strengthDiv.style.background = 'rgba(56, 239, 125, 0.2)';
            strengthDiv.style.color = '#38ef7d';
        }
    });

    // Add input focus effects
    document.querySelectorAll('.pmp-form-input').forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.style.transform = 'translateX(5px)';
        });
        
        input.addEventListener('blur', function() {
            this.parentElement.style.transform = 'translateX(0)';
        });
    });

    // Form submission effect
    document.querySelector('.pmp-login-form').addEventListener('submit', function(e) {
        const password = document.getElementById('user_pass').value;
        if (password.length < 8) {
            e.preventDefault();
            alert('Heslo musí mít alespoň 8 znaků');
            return false;
        }
        
        const button = this.querySelector('.pmp-submit-button');
        button.classList.add('pmp-loading');
        button.textContent = 'Vytvářím účet...';
    });
    </script>
</body>
</html>
