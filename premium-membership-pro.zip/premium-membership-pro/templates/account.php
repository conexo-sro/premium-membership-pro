<div class="pmp-account-page">
    <h2><?php _e('Můj účet', 'premium-membership-pro'); ?></h2>
    
    <?php if ($membership): 
        $level = get_post($membership->level_id);
    ?>
        <div class="pmp-current-membership">
            <h3><?php _e('Aktivní členství', 'premium-membership-pro'); ?></h3>
            <div class="pmp-membership-details">
                <p><strong><?php _e('Úroveň:', 'premium-membership-pro'); ?></strong> <?php echo esc_html($level->post_title); ?></p>
                <p><strong><?php _e('Status:', 'premium-membership-pro'); ?></strong> <span class="pmp-status-<?php echo esc_attr($membership->status); ?>"><?php echo esc_html($membership->status); ?></span></p>
                <p><strong><?php _e('Začátek:', 'premium-membership-pro'); ?></strong> <?php echo date_i18n(get_option('date_format'), strtotime($membership->start_date)); ?></p>
                <?php if ($membership->end_date): ?>
                    <p><strong><?php _e('Konec:', 'premium-membership-pro'); ?></strong> <?php echo date_i18n(get_option('date_format'), strtotime($membership->end_date)); ?></p>
                <?php endif; ?>
                
                <?php if ($membership->trial_end_date && strtotime($membership->trial_end_date) > time()): ?>
                    <p class="pmp-trial-notice">
                        <em><?php printf(__('Zkušební období do: %s', 'premium-membership-pro'), date_i18n(get_option('date_format'), strtotime($membership->trial_end_date))); ?></em>
                    </p>
                <?php endif; ?>
            </div>
            
            <div class="pmp-membership-actions">
                <a href="#" class="button pmp-cancel-membership" data-subscription-id="<?php echo $membership->id; ?>">
                    <?php _e('Zrušit členství', 'premium-membership-pro'); ?>
                </a>
                <a href="<?php echo get_permalink(get_option('pmp_pricing_page')); ?>" class="button">
                    <?php _e('Změnit plán', 'premium-membership-pro'); ?>
                </a>
            </div>
        </div>
    <?php else: ?>
        <div class="pmp-no-membership">
            <p><?php _e('Nemáte aktivní členství.', 'premium-membership-pro'); ?></p>
            <a href="<?php echo get_permalink(get_option('pmp_pricing_page')); ?>" class="button button-primary">
                <?php _e('Zobrazit členské plány', 'premium-membership-pro'); ?>
            </a>
        </div>
    <?php endif; ?>
    
    <?php if (!empty($transactions)): ?>
        <div class="pmp-transactions">
            <h3><?php _e('Historie transakcí', 'premium-membership-pro'); ?></h3>
            <table class="pmp-transactions-table">
                <thead>
                    <tr>
                        <th><?php _e('Faktura', 'premium-membership-pro'); ?></th>
                        <th><?php _e('Částka', 'premium-membership-pro'); ?></th>
                        <th><?php _e('Status', 'premium-membership-pro'); ?></th>
                        <th><?php _e('Datum', 'premium-membership-pro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($transactions as $transaction): ?>
                        <tr>
                            <td><?php echo esc_html($transaction->invoice_number); ?></td>
                            <td><?php echo pmp_format_price($transaction->amount); ?></td>
                            <td><span class="pmp-status-<?php echo esc_attr($transaction->status); ?>"><?php echo esc_html($transaction->status); ?></span></td>
                            <td><?php echo date_i18n(get_option('date_format'), strtotime($transaction->created_at)); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
    
    <div class="pmp-user-info">
        <h3><?php _e('Informace o účtu', 'premium-membership-pro'); ?></h3>
        <?php
        $user = wp_get_current_user();
        ?>
        <p><strong><?php _e('Email:', 'premium-membership-pro'); ?></strong> <?php echo esc_html($user->user_email); ?></p>
        <p><strong><?php _e('Jméno:', 'premium-membership-pro'); ?></strong> <?php echo esc_html($user->display_name); ?></p>
        <p><a href="<?php echo get_edit_profile_url(); ?>"><?php _e('Upravit profil', 'premium-membership-pro'); ?></a></p>
    </div>
</div>
