<div class="pmp-membership-levels <?php echo esc_attr('pmp-layout-' . $atts['layout']); ?>">
    <?php foreach ($levels as $level): ?>
        <div class="pmp-level-card">
            <div class="pmp-level-header">
                <h3 class="pmp-level-title"><?php echo esc_html($level['name']); ?></h3>
                <?php if (has_post_thumbnail($level['id'])): ?>
                    <div class="pmp-level-image">
                        <?php echo get_the_post_thumbnail($level['id'], 'medium'); ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="pmp-level-price">
                <span class="pmp-price-amount"><?php echo pmp_format_price($level['price']); ?></span>
                <?php if ($level['billing_type'] === 'recurring'): ?>
                    <span class="pmp-price-period">
                        / <?php 
                        echo $level['period_count'] . ' ';
                        echo $level['period'] === 'month' ? __('měsíc', 'premium-membership-pro') : 
                             ($level['period'] === 'year' ? __('rok', 'premium-membership-pro') : 
                             ($level['period'] === 'week' ? __('týden', 'premium-membership-pro') : 
                             __('den', 'premium-membership-pro')));
                        ?>
                    </span>
                <?php endif; ?>
            </div>
            
            <div class="pmp-level-description">
                <?php echo wpautop($level['description']); ?>
            </div>
            
            <?php if ($level['trial_enabled']): ?>
                <div class="pmp-level-trial">
                    <strong><?php printf(__('%d dní zkušebně zdarma', 'premium-membership-pro'), $level['trial_days']); ?></strong>
                </div>
            <?php endif; ?>
            
            <div class="pmp-level-action">
                <?php if (is_user_logged_in()): 
                    $user_membership = pmp_get_user_membership();
                    if ($user_membership && $user_membership->level_id == $level['id']):
                ?>
                    <span class="pmp-current-level"><?php _e('Vaše aktuální úroveň', 'premium-membership-pro'); ?></span>
                <?php else: ?>
                    <a href="#" class="button pmp-select-level" data-level-id="<?php echo $level['id']; ?>">
                        <?php _e('Vybrat tento plán', 'premium-membership-pro'); ?>
                    </a>
                <?php endif; ?>
                <?php else: ?>
                    <a href="<?php echo wp_login_url(get_permalink()); ?>" class="button pmp-login-button">
                        <?php _e('Přihlásit se', 'premium-membership-pro'); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>
</div>
