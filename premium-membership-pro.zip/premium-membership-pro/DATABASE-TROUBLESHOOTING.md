# Řešení Problémů s Databázovými Tabulkami

## Problém: Chybové hlášky o neexistujících tabulkách

Pokud po aktivaci pluginu vidíš chybové hlášky typu:
```
Table 'database.wp_pmp_memberships' doesn't exist
Table 'database.wp_pmp_transactions' doesn't exist
```

## Rychlé Řešení (Metoda 1) - Automatická oprava

### Krok 1: Deaktivovat a Aktivovat plugin

```
WordPress Admin
→ Pluginy
→ Premium Membership Pro
→ Deaktivovat
→ Aktivovat
```

Po aktivaci by se tabulky měly vytvořit automaticky.

### Krok 2: Zkontrolovat

Jdi do phpMyAdmin a zkontroluj, zda existují tyto tabulky:
- `wp_pmp_memberships`
- `wp_pmp_transactions`
- `wp_pmp_access_logs`
- `wp_pmp_email_logs`

---

## Manuální Řešení (Metoda 2) - Pokud automatická oprava nefunguje

### Použití Manuálního Skriptu

#### Krok 1: Nahrát skript

```
1. Najdi soubor: create-tables-manual.php
   (v ZIP archivu pluginu)

2. Nahraj přes FTP do:
   /wp-content/plugins/premium-membership-pro/

3. Nastav práva: 644
```

#### Krok 2: Spustit skript

```
Otevři v browseru:
https://tvuj-web.cz/wp-content/plugins/premium-membership-pro/create-tables-manual.php?confirm=yes

DŮLEŽITÉ: Musíš být přihlášený jako administrátor!
```

#### Krok 3: Zkontrolovat výsledek

Skript ti ukáže:
```
✅ Vytvořeno tabulek: 4
   - wp_pmp_memberships
   - wp_pmp_transactions
   - wp_pmp_access_logs
   - wp_pmp_email_logs

HOTOVO!
```

#### Krok 4: Smazat skript

```
⚠️ DŮLEŽITÉ: Po dokončení SMAŽ soubor create-tables-manual.php!
Důvod: Bezpečnost - skript vytváří databázové tabulky
```

---

## Manuální Řešení (Metoda 3) - Přes phpMyAdmin

### SQL Příkazy

Pokud potřebuješ vytvořit tabulky ručně přes phpMyAdmin:

#### 1. Tabulka: pmp_memberships

```sql
CREATE TABLE `wp_pmp_memberships` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `level_id` bigint(20) unsigned NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'active',
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `trial_end_date` datetime DEFAULT NULL,
  `payment_gateway` varchar(50) DEFAULT NULL,
  `subscription_id` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `level_id` (`level_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

#### 2. Tabulka: pmp_transactions

```sql
CREATE TABLE `wp_pmp_transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `membership_id` bigint(20) unsigned DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(10) NOT NULL DEFAULT 'CZK',
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `payment_gateway` varchar(50) NOT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `invoice_number` varchar(100) DEFAULT NULL,
  `description` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `membership_id` (`membership_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

#### 3. Tabulka: pmp_access_logs

```sql
CREATE TABLE `wp_pmp_access_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `membership_level_id` bigint(20) unsigned NOT NULL,
  `access_type` varchar(50) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `accessed_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `post_id` (`post_id`),
  KEY `accessed_at` (`accessed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

#### 4. Tabulka: pmp_email_logs

```sql
CREATE TABLE `wp_pmp_email_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `email_type` varchar(100) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'sent',
  `sent_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `email_type` (`email_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

**POZNÁMKA:** Pokud tvůj prefix není `wp_`, nahraď `wp_` svým prefixem!

---

## Časté Příčiny Problému

### 1. Nedostatečná Oprávnění

**Problém:**
```
Uživatel databáze nemá oprávnění CREATE TABLE
```

**Řešení:**
```
1. Jdi do cPanel → MySQL Databases
2. Zkontroluj oprávnění databázového uživatele
3. Měl by mít: ALL PRIVILEGES
```

### 2. Stará MySQL Verze

**Problém:**
```
MySQL verze < 5.7
```

**Řešení:**
```
1. Upgraduj MySQL na 5.7+ nebo MariaDB 10.3+
2. Kontaktuj hosting support
```

### 3. Nedostatek Místa v Databázi

**Problém:**
```
Database quota exceeded
```

**Řešení:**
```
1. Zkontroluj využití databáze v cPanel
2. Rozšiř limit nebo vyčisti staré data
```

### 4. Plugin Aktivován Před Nahráním Souborů

**Problém:**
```
Plugin se aktivoval dřív než se nahráli všechny soubory
```

**Řešení:**
```
1. Deaktivuj plugin
2. Smaž složku pluginu
3. Nahraj znovu celý ZIP
4. Aktivuj
```

---

## Kontrola Po Vytvoření Tabulek

### Metoda 1: phpMyAdmin

```
1. Přihlaš se do phpMyAdmin
2. Vyber svou databázi
3. Měl bys vidět 4 nové tabulky:
   ✅ wp_pmp_memberships
   ✅ wp_pmp_transactions
   ✅ wp_pmp_access_logs
   ✅ wp_pmp_email_logs
```

### Metoda 2: WordPress Plugin

```
Pluginy → Premium Membership Pro → Settings → System Info
→ Měl by ukázat stav databáze
```

---

## Debug Logging

Pokud chceš vidět podrobné informace o vytváření tabulek:

### Zapnout Debug Mode

```php
// wp-config.php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
```

### Zkontrolovat Log

```
Cesta: /wp-content/debug.log

Hledej řádky:
PMP: Database tables created successfully
PMP: wp_pmp_memberships - EXISTS
PMP: wp_pmp_transactions - EXISTS
PMP: wp_pmp_access_logs - EXISTS
PMP: wp_pmp_email_logs - EXISTS
```

---

## Pokud Nic Nepomáhá

### Kontaktuj Support

```
Email: info@conexo.cz
Web: conexo.cz

Pošli:
1. Verzi WordPress
2. Verzi PHP
3. Verzi MySQL/MariaDB
4. Obsah debug.log (posledních 100 řádků)
5. Screenshot chybové hlášky
6. Hosting provider
```

---

## Preventivní Opatření

### Před Instalací Zkontroluj:

```
✅ PHP 8.0+
✅ WordPress 6.4+
✅ MySQL 5.7+ nebo MariaDB 10.3+
✅ Databázová oprávnění: ALL PRIVILEGES
✅ Dostupné místo v databázi
✅ Aktivní spojení s databází
```

---

## Shrnutí

### Nejrychlejší Metoda:

```
1. Deaktivovat plugin
2. Aktivovat plugin znovu
3. ✅ Hotovo (tabulky vytvořeny)
```

### Pokud Nefunguje:

```
1. Použít create-tables-manual.php
2. Otevřít v browseru s ?confirm=yes
3. Zkontrolovat výsledek
4. Smazat skript
5. ✅ Hotovo
```

### Poslední Možnost:

```
1. Otevřít phpMyAdmin
2. Spustit SQL příkazy ručně
3. Vytvořit všechny 4 tabulky
4. ✅ Hotovo
```

---

**CONEXO s.r.o.** | Litoměřice, CZ  
conexo.cz | info@conexo.cz

**Verze:** 1.8.0  
**Vydáno:** 10. prosince 2024
