<?php
/**
 * Elementor Pricing Table Widget
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Elementor_Pricing_Table_Widget extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'pmp-pricing-table';
    }
    
    public function get_title() {
        return __('Cenová tabulka', 'premium-membership-pro');
    }
    
    public function get_icon() {
        return 'eicon-price-table';
    }
    
    public function get_categories() {
        return array('pmp-elements');
    }
    
    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            array(
                'label' => __('Obsah', 'premium-membership-pro'),
            )
        );
        
        $this->add_control(
            'membership_level',
            array(
                'label' => __('Úroveň členství', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => PMP_Elementor::get_membership_levels_for_control(),
            )
        );
        
        $this->add_control(
            'featured',
            array(
                'label' => __('Zvýrazněná', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'no',
            )
        );
        
        $this->add_control(
            'ribbon_text',
            array(
                'label' => __('Text stuhy', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Nejoblíbenější', 'premium-membership-pro'),
                'condition' => array(
                    'featured' => 'yes',
                ),
            )
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        if (empty($settings['membership_level'])) {
            echo '<p>' . __('Vyberte úroveň členství.', 'premium-membership-pro') . '</p>';
            return;
        }
        
        $level = get_post($settings['membership_level']);
        if (!$level) {
            return;
        }
        
        $price = get_post_meta($level->ID, '_pmp_price', true);
        $period = get_post_meta($level->ID, '_pmp_period', true);
        $features = get_post_meta($level->ID, '_pmp_features', true);
        
        $featured_class = $settings['featured'] === 'yes' ? ' pmp-featured' : '';
        
        ?>
        <div class="pmp-pricing-table<?php echo $featured_class; ?>">
            <?php if ($settings['featured'] === 'yes'): ?>
                <div class="pmp-ribbon"><?php echo esc_html($settings['ribbon_text']); ?></div>
            <?php endif; ?>
            
            <h3 class="pmp-pricing-title"><?php echo esc_html($level->post_title); ?></h3>
            
            <div class="pmp-pricing-price">
                <span class="pmp-price-amount"><?php 
                    if (function_exists('pmp_format_price')) {
                        echo pmp_format_price($price);
                    } else {
                        echo esc_html($price) . ' Kč';
                    }
                ?></span>
                <?php if ($period): ?>
                    <span class="pmp-price-period">/ <?php echo esc_html($period); ?></span>
                <?php endif; ?>
            </div>
            
            <?php if ($features): ?>
                <ul class="pmp-pricing-features">
                    <?php foreach (explode("\n", $features) as $feature): ?>
                        <li><?php echo esc_html($feature); ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
            
            <a href="<?php echo esc_url(add_query_arg('level', $level->ID, home_url('/registrace/'))); ?>" 
               class="pmp-pricing-button">
                <?php _e('Získat členství', 'premium-membership-pro'); ?>
            </a>
        </div>
        <?php
    }
}
