<?php
/**
 * Elementor Login Form Widget
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Elementor_Login_Form_Widget extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'pmp-login-form';
    }
    
    public function get_title() {
        return __('Přihlašovací formulář', 'premium-membership-pro');
    }
    
    public function get_icon() {
        return 'eicon-lock-user';
    }
    
    public function get_categories() {
        return array('pmp-elements');
    }
    
    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            array(
                'label' => __('Obsah', 'premium-membership-pro'),
            )
        );
        
        $this->add_control(
            'show_labels',
            array(
                'label' => __('Zobrazit popisky', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
            )
        );
        
        $this->add_control(
            'show_remember',
            array(
                'label' => __('Zapamatovat si mě', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => 'yes',
            )
        );
        
        $this->add_control(
            'redirect_url',
            array(
                'label' => __('URL přesměrování po přihlášení', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => home_url('/muj-ucet/'),
            )
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        if (is_user_logged_in()) {
            echo '<p>' . __('Již jste přihlášeni.', 'premium-membership-pro') . '</p>';
            return;
        }
        
        echo do_shortcode('[pmp_login_form]');
    }
}
