<?php
/**
 * Elementor Registration Form Widget
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Elementor_Registration_Form_Widget extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'pmp-registration-form';
    }
    
    public function get_title() {
        return __('Registrační formulář', 'premium-membership-pro');
    }
    
    public function get_icon() {
        return 'eicon-form-horizontal';
    }
    
    public function get_categories() {
        return array('pmp-elements');
    }
    
    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            array(
                'label' => __('Obsah', 'premium-membership-pro'),
            )
        );
        
        $this->add_control(
            'default_level',
            array(
                'label' => __('Výchozí úroveň', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => PMP_Elementor::get_membership_levels_for_control(),
            )
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        if (is_user_logged_in()) {
            echo '<p>' . __('Již jste registrováni.', 'premium-membership-pro') . '</p>';
            return;
        }
        
        echo do_shortcode('[pmp_registration_form]');
    }
}
