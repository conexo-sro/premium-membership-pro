<?php
/**
 * Elementor Membership Levels Widget
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Elementor_Membership_Levels_Widget extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'pmp-membership-levels';
    }
    
    public function get_title() {
        return __('Úrovně členství', 'premium-membership-pro');
    }
    
    public function get_icon() {
        return 'eicon-price-table';
    }
    
    public function get_categories() {
        return array('pmp-elements');
    }
    
    public function get_keywords() {
        return array('membership', 'levels', 'pricing', 'členství', 'úrovně');
    }
    
    protected function register_controls() {
        
        // Content section
        $this->start_controls_section(
            'content_section',
            array(
                'label' => __('Obsah', 'premium-membership-pro'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );
        
        $this->add_control(
            'show_title',
            array(
                'label' => __('Zobrazit nadpis', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Ano', 'premium-membership-pro'),
                'label_off' => __('Ne', 'premium-membership-pro'),
                'return_value' => 'yes',
                'default' => 'yes',
            )
        );
        
        $this->add_control(
            'title_text',
            array(
                'label' => __('Text nadpisu', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Vyberte si členství', 'premium-membership-pro'),
                'condition' => array(
                    'show_title' => 'yes',
                ),
            )
        );
        
        $this->add_control(
            'columns',
            array(
                'label' => __('Počet sloupců', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '3',
                'options' => array(
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ),
            )
        );
        
        $this->add_control(
            'show_description',
            array(
                'label' => __('Zobrazit popis', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Ano', 'premium-membership-pro'),
                'label_off' => __('Ne', 'premium-membership-pro'),
                'return_value' => 'yes',
                'default' => 'yes',
            )
        );
        
        $this->add_control(
            'button_text',
            array(
                'label' => __('Text tlačítka', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Získat členství', 'premium-membership-pro'),
            )
        );
        
        $this->end_controls_section();
        
        // Style section
        $this->start_controls_section(
            'style_section',
            array(
                'label' => __('Styl', 'premium-membership-pro'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            )
        );
        
        $this->add_control(
            'card_background',
            array(
                'label' => __('Pozadí karty', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => array(
                    '{{WRAPPER}} .pmp-level-card' => 'background-color: {{VALUE}}',
                ),
            )
        );
        
        $this->add_control(
            'title_color',
            array(
                'label' => __('Barva nadpisu', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#1d2327',
                'selectors' => array(
                    '{{WRAPPER}} .pmp-level-title' => 'color: {{VALUE}}',
                ),
            )
        );
        
        $this->add_control(
            'price_color',
            array(
                'label' => __('Barva ceny', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#2271b1',
                'selectors' => array(
                    '{{WRAPPER}} .pmp-level-price' => 'color: {{VALUE}}',
                ),
            )
        );
        
        $this->add_control(
            'button_background',
            array(
                'label' => __('Pozadí tlačítka', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#2271b1',
                'selectors' => array(
                    '{{WRAPPER}} .pmp-level-button' => 'background-color: {{VALUE}}',
                ),
            )
        );
        
        $this->add_control(
            'button_text_color',
            array(
                'label' => __('Barva textu tlačítka', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => array(
                    '{{WRAPPER}} .pmp-level-button' => 'color: {{VALUE}}',
                ),
            )
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        // Get membership levels
        $levels = get_posts(array(
            'post_type' => 'pmp_membership',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'orderby' => 'menu_order',
            'order' => 'ASC'
        ));
        
        if (empty($levels)) {
            echo '<p>' . __('Žádné úrovně členství nebyly nalezeny.', 'premium-membership-pro') . '</p>';
            return;
        }
        
        ?>
        <div class="pmp-elementor-membership-levels">
            <?php if ($settings['show_title'] === 'yes'): ?>
                <h2 class="pmp-levels-title"><?php echo esc_html($settings['title_text']); ?></h2>
            <?php endif; ?>
            
            <div class="pmp-levels-grid pmp-columns-<?php echo esc_attr($settings['columns']); ?>">
                <?php foreach ($levels as $level): 
                    $price = get_post_meta($level->ID, '_pmp_price', true);
                    $period = get_post_meta($level->ID, '_pmp_period', true);
                    $description = get_post_meta($level->ID, '_pmp_description', true);
                    ?>
                    
                    <div class="pmp-level-card">
                        <h3 class="pmp-level-title"><?php echo esc_html($level->post_title); ?></h3>
                        
                        <div class="pmp-level-price">
                            <?php 
                            if (function_exists('pmp_format_price')) {
                                echo pmp_format_price($price);
                            } else {
                                echo esc_html($price) . ' Kč';
                            }
                            ?>
                            <?php if ($period): ?>
                                <span class="pmp-level-period">/ <?php echo esc_html($period); ?></span>
                            <?php endif; ?>
                        </div>
                        
                        <?php if ($settings['show_description'] === 'yes' && $description): ?>
                            <div class="pmp-level-description">
                                <?php echo wp_kses_post($description); ?>
                            </div>
                        <?php endif; ?>
                        
                        <a href="<?php echo esc_url(add_query_arg('level', $level->ID, home_url('/registrace/'))); ?>" 
                           class="pmp-level-button">
                            <?php echo esc_html($settings['button_text']); ?>
                        </a>
                    </div>
                    
                <?php endforeach; ?>
            </div>
        </div>
        
        <style>
        .pmp-elementor-membership-levels {
            padding: 20px 0;
        }
        .pmp-levels-title {
            text-align: center;
            margin-bottom: 40px;
            font-size: 2em;
        }
        .pmp-levels-grid {
            display: grid;
            gap: 30px;
        }
        .pmp-levels-grid.pmp-columns-1 {
            grid-template-columns: 1fr;
        }
        .pmp-levels-grid.pmp-columns-2 {
            grid-template-columns: repeat(2, 1fr);
        }
        .pmp-levels-grid.pmp-columns-3 {
            grid-template-columns: repeat(3, 1fr);
        }
        .pmp-levels-grid.pmp-columns-4 {
            grid-template-columns: repeat(4, 1fr);
        }
        .pmp-level-card {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 30px;
            text-align: center;
            transition: all 0.3s;
        }
        .pmp-level-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .pmp-level-title {
            font-size: 1.5em;
            margin-bottom: 20px;
        }
        .pmp-level-price {
            font-size: 2.5em;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .pmp-level-period {
            font-size: 0.5em;
            opacity: 0.7;
        }
        .pmp-level-description {
            margin-bottom: 30px;
            opacity: 0.8;
        }
        .pmp-level-button {
            display: inline-block;
            padding: 15px 40px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
        }
        .pmp-level-button:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        @media (max-width: 768px) {
            .pmp-levels-grid {
                grid-template-columns: 1fr !important;
            }
        }
        </style>
        <?php
    }
}
