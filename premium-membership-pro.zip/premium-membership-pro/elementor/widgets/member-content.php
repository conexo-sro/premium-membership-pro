<?php
/**
 * Elementor Member Content Widget
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Elementor_Member_Content_Widget extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'pmp-member-content';
    }
    
    public function get_title() {
        return __('Obsah pro členy', 'premium-membership-pro');
    }
    
    public function get_icon() {
        return 'eicon-lock';
    }
    
    public function get_categories() {
        return array('pmp-elements');
    }
    
    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            array(
                'label' => __('Obsah', 'premium-membership-pro'),
            )
        );
        
        $this->add_control(
            'required_level',
            array(
                'label' => __('Požadovaná úroveň', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => PMP_Elementor::get_membership_levels_for_control(),
            )
        );
        
        $this->add_control(
            'content',
            array(
                'label' => __('Obsah', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'default' => __('Tento obsah je viditelný pouze pro členy.', 'premium-membership-pro'),
            )
        );
        
        $this->add_control(
            'denied_message',
            array(
                'label' => __('Zpráva při zamítnutí', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('K zobrazení tohoto obsahu potřebujete členství.', 'premium-membership-pro'),
            )
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        // Check if user has required membership
        if (!is_user_logged_in()) {
            echo '<div class="pmp-denied-message">' . esc_html($settings['denied_message']) . '</div>';
            return;
        }
        
        if (!empty($settings['required_level'])) {
            // Check if PMP_User_Management class exists
            if (!class_exists('PMP_User_Management')) {
                echo '<div class="pmp-denied-message">' . esc_html($settings['denied_message']) . '</div>';
                return;
            }
            
            $user_membership = PMP_User_Management::get_user_membership(get_current_user_id());
            
            if (!$user_membership || $user_membership->level_id != $settings['required_level']) {
                echo '<div class="pmp-denied-message">' . esc_html($settings['denied_message']) . '</div>';
                return;
            }
        }
        
        echo '<div class="pmp-member-content">' . wp_kses_post($settings['content']) . '</div>';
    }
}
