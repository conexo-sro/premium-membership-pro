<?php
/**
 * Elementor Membership Status Widget
 * Displays current user's membership status and information
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Elementor_Membership_Status_Widget extends PMP_Elementor_Base_Widget {
    
    /**
     * Get widget name
     */
    public function get_name() {
        return 'pmp-membership-status';
    }
    
    /**
     * Get widget title
     */
    public function get_title() {
        return __('Stav členství', 'premium-membership-pro');
    }
    
    /**
     * Get widget icon
     */
    public function get_icon() {
        return 'eicon-user-circle-o';
    }
    
    /**
     * Register widget controls
     */
    protected function register_controls() {
        
        // Content Section
        $this->start_controls_section(
            'content_section',
            array(
                'label' => __('Obsah', 'premium-membership-pro'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );
        
        $this->add_control(
            'show_avatar',
            array(
                'label' => __('Zobrazit avatar', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Ano', 'premium-membership-pro'),
                'label_off' => __('Ne', 'premium-membership-pro'),
                'default' => 'yes',
            )
        );
        
        $this->add_control(
            'show_name',
            array(
                'label' => __('Zobrazit jméno', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Ano', 'premium-membership-pro'),
                'label_off' => __('Ne', 'premium-membership-pro'),
                'default' => 'yes',
            )
        );
        
        $this->add_control(
            'show_level',
            array(
                'label' => __('Zobrazit úroveň', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Ano', 'premium-membership-pro'),
                'label_off' => __('Ne', 'premium-membership-pro'),
                'default' => 'yes',
            )
        );
        
        $this->add_control(
            'show_expiry',
            array(
                'label' => __('Zobrazit expirace', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Ano', 'premium-membership-pro'),
                'label_off' => __('Ne', 'premium-membership-pro'),
                'default' => 'yes',
            )
        );
        
        $this->add_control(
            'show_upgrade_button',
            array(
                'label' => __('Zobrazit tlačítko upgrade', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Ano', 'premium-membership-pro'),
                'label_off' => __('Ne', 'premium-membership-pro'),
                'default' => 'yes',
            )
        );
        
        $this->add_control(
            'upgrade_button_text',
            array(
                'label' => __('Text tlačítka upgrade', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Upgrade členství', 'premium-membership-pro'),
                'condition' => array(
                    'show_upgrade_button' => 'yes',
                ),
            )
        );
        
        $this->add_control(
            'logged_out_message',
            array(
                'label' => __('Zpráva pro nepřihlášené', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Pro zobrazení stavu členství se prosím přihlaste.', 'premium-membership-pro'),
                'rows' => 3,
            )
        );
        
        $this->end_controls_section();
        
        // Style Section
        $this->start_controls_section(
            'style_section',
            array(
                'label' => __('Styl', 'premium-membership-pro'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            )
        );
        
        $this->add_control(
            'layout',
            array(
                'label' => __('Layout', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'card',
                'options' => array(
                    'card' => __('Karta', 'premium-membership-pro'),
                    'inline' => __('Řádek', 'premium-membership-pro'),
                    'compact' => __('Kompaktní', 'premium-membership-pro'),
                ),
            )
        );
        
        $this->add_control(
            'card_background',
            array(
                'label' => __('Pozadí karty', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => array(
                    '{{WRAPPER}} .pmp-membership-status-card' => 'background-color: {{VALUE}};',
                ),
            )
        );
        
        $this->add_control(
            'text_color',
            array(
                'label' => __('Barva textu', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#2d3748',
                'selectors' => array(
                    '{{WRAPPER}} .pmp-membership-status-card' => 'color: {{VALUE}};',
                ),
            )
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'card_border',
                'selector' => '{{WRAPPER}} .pmp-membership-status-card',
            )
        );
        
        $this->add_control(
            'card_border_radius',
            array(
                'label' => __('Zaoblení rohů', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array('px', '%'),
                'default' => array(
                    'top' => '8',
                    'right' => '8',
                    'bottom' => '8',
                    'left' => '8',
                    'unit' => 'px',
                ),
                'selectors' => array(
                    '{{WRAPPER}} .pmp-membership-status-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        
        $this->add_control(
            'card_padding',
            array(
                'label' => __('Vnitřní odsazení', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array('px', '%'),
                'default' => array(
                    'top' => '30',
                    'right' => '30',
                    'bottom' => '30',
                    'left' => '30',
                    'unit' => 'px',
                ),
                'selectors' => array(
                    '{{WRAPPER}} .pmp-membership-status-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'card_shadow',
                'selector' => '{{WRAPPER}} .pmp-membership-status-card',
            )
        );
        
        $this->end_controls_section();
        
        // Button Style
        $this->start_controls_section(
            'button_style_section',
            array(
                'label' => __('Styl tlačítka', 'premium-membership-pro'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_upgrade_button' => 'yes',
                ),
            )
        );
        
        $this->add_control(
            'button_background',
            array(
                'label' => __('Pozadí tlačítka', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#667eea',
                'selectors' => array(
                    '{{WRAPPER}} .pmp-upgrade-button' => 'background-color: {{VALUE}};',
                ),
            )
        );
        
        $this->add_control(
            'button_text_color',
            array(
                'label' => __('Barva textu tlačítka', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => array(
                    '{{WRAPPER}} .pmp-upgrade-button' => 'color: {{VALUE}};',
                ),
            )
        );
        
        $this->end_controls_section();
    }
    
    /**
     * Render widget output
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        // Check if user is logged in
        if (!is_user_logged_in()) {
            echo '<div class="pmp-membership-status-logged-out">';
            echo '<p>' . esc_html($settings['logged_out_message']) . '</p>';
            echo '</div>';
            return;
        }
        
        $user = wp_get_current_user();
        $user_id = $user->ID;
        
        // Get user's active membership
        global $wpdb;
        $membership = $wpdb->get_row($wpdb->prepare(
            "SELECT m.*, p.post_title as level_name
             FROM {$wpdb->prefix}pmp_memberships m
             LEFT JOIN {$wpdb->posts} p ON m.level_id = p.ID
             WHERE m.user_id = %d 
             AND m.status = 'active'
             AND (m.expires_at IS NULL OR m.expires_at > NOW())
             ORDER BY m.created_at DESC
             LIMIT 1",
            $user_id
        ));
        
        $layout_class = 'pmp-layout-' . $settings['layout'];
        
        ?>
        <div class="pmp-membership-status-widget <?php echo esc_attr($layout_class); ?>">
            <div class="pmp-membership-status-card">
                
                <?php if ($settings['show_avatar'] === 'yes'): ?>
                    <div class="pmp-status-avatar">
                        <?php echo get_avatar($user_id, 80); ?>
                    </div>
                <?php endif; ?>
                
                <div class="pmp-status-content">
                    
                    <?php if ($settings['show_name'] === 'yes'): ?>
                        <h3 class="pmp-status-name"><?php echo esc_html($user->display_name); ?></h3>
                    <?php endif; ?>
                    
                    <?php if ($settings['show_level'] === 'yes'): ?>
                        <div class="pmp-status-level">
                            <?php if ($membership): ?>
                                <span class="pmp-level-badge">
                                    <?php echo esc_html($membership->level_name); ?>
                                </span>
                            <?php else: ?>
                                <span class="pmp-no-membership">
                                    <?php _e('Žádné aktivní členství', 'premium-membership-pro'); ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($settings['show_expiry'] === 'yes' && $membership && $membership->expires_at): ?>
                        <div class="pmp-status-expiry">
                            <span class="pmp-expiry-label"><?php _e('Vyprší:', 'premium-membership-pro'); ?></span>
                            <span class="pmp-expiry-date">
                                <?php 
                                $expires = new DateTime($membership->expires_at);
                                echo $expires->format('d.m.Y');
                                
                                $now = new DateTime();
                                $diff = $now->diff($expires);
                                
                                if ($diff->days <= 7 && $diff->invert === 0) {
                                    echo ' <span class="pmp-expiry-warning">(' . sprintf(__('zbývá %d dní', 'premium-membership-pro'), $diff->days) . ')</span>';
                                }
                                ?>
                            </span>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($settings['show_upgrade_button'] === 'yes'): ?>
                        <div class="pmp-status-actions">
                            <a href="<?php echo esc_url(get_permalink(get_option('pmp_upgrade_page_id'))); ?>" class="pmp-upgrade-button">
                                <?php echo esc_html($settings['upgrade_button_text']); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                    
                </div>
                
            </div>
        </div>
        
        <style>
        .pmp-membership-status-widget {
            width: 100%;
        }
        
        .pmp-membership-status-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .pmp-layout-card .pmp-membership-status-card {
            text-align: center;
        }
        
        .pmp-layout-inline .pmp-membership-status-card {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .pmp-layout-compact .pmp-membership-status-card {
            padding: 15px;
        }
        
        .pmp-status-avatar {
            margin-bottom: 15px;
        }
        
        .pmp-layout-inline .pmp-status-avatar {
            margin-bottom: 0;
        }
        
        .pmp-status-avatar img {
            border-radius: 50%;
            border: 3px solid #667eea;
        }
        
        .pmp-status-name {
            font-size: 24px;
            font-weight: 700;
            margin: 0 0 10px;
            color: #2d3748;
        }
        
        .pmp-layout-compact .pmp-status-name {
            font-size: 18px;
        }
        
        .pmp-status-level {
            margin: 15px 0;
        }
        
        .pmp-level-badge {
            display: inline-block;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
        }
        
        .pmp-no-membership {
            color: #a0aec0;
            font-style: italic;
        }
        
        .pmp-status-expiry {
            margin: 10px 0;
            font-size: 14px;
            color: #718096;
        }
        
        .pmp-expiry-label {
            font-weight: 600;
        }
        
        .pmp-expiry-warning {
            color: #e53e3e;
            font-weight: 600;
        }
        
        .pmp-status-actions {
            margin-top: 20px;
        }
        
        .pmp-upgrade-button {
            display: inline-block;
            background: #667eea;
            color: white;
            padding: 12px 30px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .pmp-upgrade-button:hover {
            background: #5a67d8;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
        
        .pmp-membership-status-logged-out {
            padding: 30px;
            background: #f7fafc;
            border: 2px dashed #cbd5e0;
            border-radius: 8px;
            text-align: center;
            color: #4a5568;
        }
        </style>
        <?php
    }
}
