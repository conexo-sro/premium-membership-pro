<?php
/**
 * Elementor Account Page Widget
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Elementor_Account_Page_Widget extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'pmp-account-page';
    }
    
    public function get_title() {
        return __('Můj účet', 'premium-membership-pro');
    }
    
    public function get_icon() {
        return 'eicon-my-account';
    }
    
    public function get_categories() {
        return array('pmp-elements');
    }
    
    protected function register_controls() {}
    
    protected function render() {
        if (!is_user_logged_in()) {
            echo '<p>' . __('Pro zobrazení účtu se musíte přihlásit.', 'premium-membership-pro') . '</p>';
            return;
        }
        
        echo do_shortcode('[pmp_account]');
    }
}
