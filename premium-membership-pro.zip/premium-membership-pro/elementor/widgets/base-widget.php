<?php
/**
 * Base Elementor Widget with safety checks
 */

if (!defined('ABSPATH')) {
    exit;
}

// Base widget will be loaded after Elementor is confirmed active
// So we can safely extend Elementor\Widget_Base

abstract class PMP_Elementor_Base_Widget extends \Elementor\Widget_Base {
    
    /**
     * Get widget categories
     */
    public function get_categories() {
        return array('pmp-elements');
    }
    
    /**
     * Safe render wrapper
     */
    protected function safe_render($callback) {
        try {
            if (is_callable($callback)) {
                call_user_func($callback);
            }
        } catch (Exception $e) {
            if (WP_DEBUG) {
                echo '<div class="pmp-error">Error: ' . esc_html($e->getMessage()) . '</div>';
            }
        }
    }
    
    /**
     * Check if PMP is fully loaded
     */
    protected function is_pmp_ready() {
        return defined('PMP_VERSION') && 
               post_type_exists('pmp_membership');
    }
}
