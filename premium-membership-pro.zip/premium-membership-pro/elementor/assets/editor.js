/**
 * Elementor Editor Scripts
 */

(function($) {
    'use strict';
    
    $(window).on('elementor:init', function() {
        
        // Add PMP icon to category
        elementor.hooks.addFilter('elementor/editor/localize/strings', function(strings) {
            strings.categories.pmp = {
                title: 'Premium Membership Pro',
                icon: 'eicon-lock-user'
            };
            return strings;
        });
        
        // Update widget preview on change
        elementor.hooks.addAction('panel/open_editor/widget', function(panel, model, view) {
            var widgetType = model.get('widgetType');
            
            if (widgetType.indexOf('pmp-') === 0) {
                console.log('PMP Widget loaded:', widgetType);
            }
        });
    });
    
})(jQuery);
