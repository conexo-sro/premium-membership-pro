# 🔍 Řešení problémů s Meta Boxy

## Problém: Meta boxy nejsou viditelné v editoru

Pokud nevidíte meta boxy "🔒 Ochrana obsahu - Členství" v editoru příspěvků/stránek, zkuste následující:

### 1. Zkontrolujte "Možnosti obrazovky"

V pravém horním rohu editoru klikněte na **"Možnosti obrazovky"** (Screen Options):

```
┌─────────────────────────────────┐
│ [Možnosti obrazovky ▼]          │
└─────────────────────────────────┘
```

Zkontrolujte, jestli je zaškrtnuté:
- ☑ **Ochrana obsahu - Členství**
- ☑ **Přidělení členství** (pokud je dostupné)
- ☑ **Uzamknutí obsahu** (pokud je dostupné)

### 2. Zkontrolujte Gutenberg vs Classic Editor

**Pokud používáte Gutenberg (Block Editor):**
- Meta boxy by měly být viditelné v pravém sidebaru
- Pokud ne, klikněte na ikonu ⚙️ (nastavení) v pravém horním rohu

**Pokud používáte Classic Editor:**
- Meta boxy by měly být přímo ve stránce
- Zkuste scroll dolů

### 3. Reload stránky

Někdy pomůže jednoduché:
```
Ctrl + F5 (Windows)
Cmd + Shift + R (Mac)
```

### 4. Zkontrolujte, jestli je plugin aktivní

```
WordPress Admin → Pluginy → Premium Membership Pro

Status: ✅ Aktivní
```

### 5. Debug Mode

Přidejte do `wp-config.php`:

```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
```

Pak zkontrolujte `/wp-content/debug.log` pro chyby.

### 6. Použijte Debug Script

Nahrajte soubor `debug-metaboxes.php` z pluginu jako aktivní plugin nebo přidejte jeho obsah do `functions.php` vašeho motivu.

Zobrazí se vám diagnostická informace v editoru.

### 7. Zkontrolujte oprávnění

Uživatel musí mít práva:
- `edit_posts` (pro příspěvky)
- `edit_pages` (pro stránky)

### 8. Zkuste jiný post type

Vytvořte nový příspěvek nebo stránku a zkontrolujte, jestli se tam meta boxy zobrazí.

### 9. Deaktivujte ostatní pluginy

Někdy jiný plugin může způsobovat konflikty:

1. Deaktivujte všechny pluginy kromě PMP
2. Zkontrolujte, jestli se meta boxy zobrazí
3. Aktivujte pluginy jeden po druhém

### 10. Zkontrolujte JavaScript konzoli

V prohlížeči:
```
F12 → Console
```

Hledejte červené chyby.

## Manuální test

Otevřete WordPress konzoli (wp-cli nebo Plugin Console) a spusťte:

```php
// Zkontrolovat, jestli třída existuje
var_dump(class_exists('PMP_Meta_Boxes'));

// Zkontrolovat registrované meta boxy
global $wp_meta_boxes;
print_r($wp_meta_boxes['post']);
```

## Kde hledat meta boxy

### V Gutenbergu:

```
┌─────────────────────────────────┐
│  [Název příspěvku]              │
├─────────────────────────────────┤
│                                 │
│  [Obsah článku...]              │
│                                 │
└─────────────────────────────────┘

                    Pravý sidebar →
                    ┌────────────────┐
                    │ Post            │
                    │ Block           │
                    ├────────────────┤
                    │ 🔒 Ochrana     │  ← TADY!
                    │    obsahu      │
                    ├────────────────┤
                    │ 👥 Přidělení   │  ← TADY!
                    │    členství    │
                    ├────────────────┤
                    │ 🔒 Uzamknutí   │  ← TADY!
                    │    obsahu      │
                    └────────────────┘
```

### V Classic Editoru:

```
┌─────────────────────────────────┐
│  [Název příspěvku]              │
├─────────────────────────────────┤
│  [Obsah...]                     │
└─────────────────────────────────┘

┌─────────────────────────────────┐
│ 🔒 Ochrana obsahu - Členství    │  ← TADY!
├─────────────────────────────────┤
│ ☑ Chránit tento obsah           │
└─────────────────────────────────┘

┌─────────────────────────────────┐
│ 👥 Přidělení členství            │  ← TADY!
├─────────────────────────────────┤
│ [Přidělit členství...]          │
└─────────────────────────────────┘
```

## Stále nefunguje?

Kontaktujte podporu:
- 📧 info@conexo.cz
- 💬 GitHub Issues: github.com/conexo-sro/premium-membership-pro

Uveďte:
- Verzi WordPress
- Verzi PHP
- Seznam aktivních pluginů
- Screenshot editoru
- Obsah debug.log
