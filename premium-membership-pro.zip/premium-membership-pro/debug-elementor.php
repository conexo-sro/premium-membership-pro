<?php
/**
 * ELEMENTOR DEBUG HELPER - NEAKTIVNÍ
 * 
 * Tento soubor pomáhá diagnostikovat Elementor integraci.
 * Ve výchozím stavu je NEAKTIVNÍ a nebude se načítat.
 * 
 * === JAK POUŽÍT ===
 * 
 * VARIANTA A - Do functions.php:
 * 
 * Přidejte do functions.php vašeho motivu:
 * 
 * if (file_exists(WP_PLUGIN_DIR . '/premium-membership-pro/debug-elementor-active.php')) {
 *     include_once WP_PLUGIN_DIR . '/premium-membership-pro/debug-elementor-active.php';
 * }
 * 
 * VARIANTA B - Jako plugin:
 * 
 * 1. Zkopírujte tento soubor jako: debug-elementor-plugin.php
 * 2. Na začátek přidejte:
 * 
 * <?php
 * Plugin Name: PMP Elementor Debug
 * Description: Debug tool for PMP Elementor integration
 * Version: 1.0
 * Author: CONEXO s.r.o.
 * 
 * 3. Aktivujte v seznamu pluginů
 * 
 * === CO DEBUG ZOBRAZÍ ===
 * 
 * V Elementor editoru uvidíte panel s info:
 * - Post ID, Type, Status
 * - Načtené třídy (PMP_Meta_Boxes, PMP_Elementor)
 * - Elementor status
 * - Registrované hooks
 * - Meta values (_pmp_enable_protection, atd.)
 * - Debug log v konzoli
 * 
 * === KÓD PRO AKTIVACI ===
 * 
 * Zkopírujte následující kód do functions.php nebo do nového plugin souboru:
 */

// === DEBUG KÓD (zkopírujte odtud) ===

/*

add_action('admin_notices', function() {
    // Only in Elementor editor
    if (!isset($_GET['action']) || $_GET['action'] !== 'elementor') {
        return;
    }
    
    $post_id = isset($_GET['post']) ? intval($_GET['post']) : 0;
    if (!$post_id) {
        return;
    }
    
    ?>
    <div class="notice notice-info" style="position: fixed; top: 32px; right: 20px; z-index: 99999; max-width: 400px; background: white; border-left: 4px solid #2271b1; box-shadow: 0 2px 8px rgba(0,0,0,0.15); max-height: 80vh; overflow-y: auto;">
        <h3 style="margin: 10px 0;">🔍 PMP Elementor Debug</h3>
        
        <h4>Post Info:</h4>
        <ul style="font-size: 12px; font-family: monospace;">
            <li>Post ID: <?php echo $post_id; ?></li>
            <li>Post Type: <?php echo get_post_type($post_id); ?></li>
            <li>Post Status: <?php echo get_post_status($post_id); ?></li>
        </ul>
        
        <h4>Classes Loaded:</h4>
        <ul style="font-size: 12px;">
            <li>PMP_Meta_Boxes: <?php echo class_exists('PMP_Meta_Boxes') ? '✅ YES' : '❌ NO'; ?></li>
            <li>PMP_Elementor: <?php echo class_exists('PMP_Elementor') ? '✅ YES' : '❌ NO'; ?></li>
            <li>Elementor\Plugin: <?php echo class_exists('Elementor\Plugin') ? '✅ YES' : '❌ NO'; ?></li>
        </ul>
        
        <h4>Elementor Status:</h4>
        <ul style="font-size: 12px;">
            <li>Elementor loaded: <?php echo did_action('elementor/loaded') ? '✅ YES' : '❌ NO'; ?></li>
            <li>PMP Elementor enabled: <?php echo get_option('pmp_enable_elementor', '1') === '1' ? '✅ YES' : '❌ NO'; ?></li>
        </ul>
        
        <h4>Meta Values:</h4>
        <ul style="font-size: 12px; font-family: monospace;">
            <li>_pmp_enable_protection: <?php echo get_post_meta($post_id, '_pmp_enable_protection', true) ?: 'not set'; ?></li>
            <li>_pmp_required_levels: <?php 
                $levels = get_post_meta($post_id, '_pmp_required_levels', true);
                echo $levels ? implode(', ', $levels) : 'not set';
            ?></li>
            <li>_pmp_content_locked: <?php echo get_post_meta($post_id, '_pmp_content_locked', true) ?: 'not set'; ?></li>
        </ul>
        
        <p style="font-size: 11px; color: #666; margin: 10px 0;">
            Check /wp-content/debug.log for detailed logs
        </p>
        
        <button onclick="this.parentElement.style.display='none'" style="margin: 10px 0; padding: 5px 10px; cursor: pointer;">
            Close Debug Panel
        </button>
    </div>
    
    <script>
    console.log('🔍 PMP Elementor Debug Info:', {
        post_id: <?php echo $post_id; ?>,
        post_type: '<?php echo get_post_type($post_id); ?>',
        pmp_meta_boxes_exists: <?php echo class_exists('PMP_Meta_Boxes') ? 'true' : 'false'; ?>,
        pmp_elementor_exists: <?php echo class_exists('PMP_Elementor') ? 'true' : 'false'; ?>,
        elementor_loaded: <?php echo did_action('elementor/loaded') ? 'true' : 'false'; ?>
    });
    </script>
    <?php
});

// Log when Elementor document controls hook fires
add_action('elementor/documents/register_controls', function($document) {
    $post_id = $document->get_main_id();
    $post = get_post($post_id);
    
    error_log('PMP DEBUG: elementor/documents/register_controls fired');
    error_log('PMP DEBUG: Post ID: ' . $post_id);
    error_log('PMP DEBUG: Post Type: ' . ($post ? $post->post_type : 'none'));
    error_log('PMP DEBUG: PMP_Meta_Boxes exists: ' . (class_exists('PMP_Meta_Boxes') ? 'yes' : 'no'));
    
    if (class_exists('PMP_Meta_Boxes') && method_exists('PMP_Meta_Boxes', 'add_elementor_controls')) {
        error_log('PMP DEBUG: add_elementor_controls method EXISTS');
    } else {
        error_log('PMP DEBUG: add_elementor_controls method DOES NOT EXIST');
    }
}, 5);

*/

// === KONEC DEBUG KÓDU ===

// Tento soubor sám o sobě nic nedělá - je jen dokumentační
// Pro aktivaci zkopírujte výše uvedený kód
