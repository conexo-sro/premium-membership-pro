/**
 * Uninstall Dialog JavaScript
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        // Intercept delete link
        interceptDeleteLink();
        
        // Handle modal interactions
        handleModalInteractions();
        
        // Handle option selection
        handleOptionSelection();
    });
    
    /**
     * Intercept delete link for our plugin
     */
    function interceptDeleteLink() {
        var pluginSlug = pmpUninstall.plugin;
        var $deleteLink = $('tr[data-plugin="' + pluginSlug + '"] .delete a');
        
        if (!$deleteLink.length) {
            return;
        }
        
        // Store original href
        var originalHref = $deleteLink.attr('href');
        
        // Replace with modal trigger
        $deleteLink.on('click', function(e) {
            e.preventDefault();
            
            // Show modal
            $('#pmp-uninstall-modal').fadeIn(300);
            $('body').addClass('pmp-modal-open');
            
            // Store original href for later
            $('#pmp-uninstall-modal').data('delete-url', originalHref);
        });
    }
    
    /**
     * Handle modal interactions
     */
    function handleModalInteractions() {
        var $modal = $('#pmp-uninstall-modal');
        
        // Close button
        $('.pmp-modal-close, .pmp-modal-cancel').on('click', function() {
            closeModal();
        });
        
        // Overlay click
        $('.pmp-modal-overlay').on('click', function() {
            closeModal();
        });
        
        // ESC key
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape' && $modal.is(':visible')) {
                closeModal();
            }
        });
        
        // Confirm uninstall
        $('.pmp-confirm-uninstall').on('click', function() {
            var $button = $(this);
            
            if ($button.prop('disabled')) {
                return;
            }
            
            var option = $('input[name="pmp_uninstall_option"]:checked').val();
            var deleteUrl = $modal.data('delete-url');
            
            // Show loading
            $modal.find('.pmp-modal-content').addClass('pmp-loading');
            $button.prop('disabled', true);
            
            // Save option
            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: {
                    action: 'pmp_save_uninstall_option',
                    option: option,
                    nonce: pmpUninstall.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Redirect to delete URL
                        window.location.href = deleteUrl;
                    } else {
                        alert('Chyba při ukládání nastavení.');
                        $modal.find('.pmp-modal-content').removeClass('pmp-loading');
                        $button.prop('disabled', false);
                    }
                },
                error: function() {
                    alert('Chyba při komunikaci se serverem.');
                    $modal.find('.pmp-modal-content').removeClass('pmp-loading');
                    $button.prop('disabled', false);
                }
            });
        });
    }
    
    /**
     * Handle option selection
     */
    function handleOptionSelection() {
        $('input[name="pmp_uninstall_option"]').on('change', function() {
            // Update card selection
            $('.pmp-option-card').removeClass('pmp-selected');
            $(this).closest('.pmp-option-card').addClass('pmp-selected');
            
            // Enable confirm button
            $('.pmp-confirm-uninstall').prop('disabled', false);
            
            // Update button text based on selection
            var option = $(this).val();
            var buttonText = option === 'delete' 
                ? 'Smazat plugin a všechna data' 
                : 'Smazat plugin, zachovat data';
            
            $('.pmp-confirm-uninstall').text(buttonText);
        });
        
        // Click on card = select radio
        $('.pmp-option-card').on('click', function(e) {
            if (e.target.type !== 'radio') {
                $(this).find('input[type="radio"]').prop('checked', true).trigger('change');
            }
        });
    }
    
    /**
     * Close modal
     */
    function closeModal() {
        $('#pmp-uninstall-modal').fadeOut(300);
        $('body').removeClass('pmp-modal-open');
    }
    
})(jQuery);

// Prevent body scroll when modal is open
jQuery(document).ready(function($) {
    $(document).on('pmp-modal-open', function() {
        $('body').css('overflow', 'hidden');
    });
    
    $(document).on('pmp-modal-close', function() {
        $('body').css('overflow', '');
    });
});
