/* Premium Membership Pro - Frontend JavaScript */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        
        // Initialize page animations
        initPageAnimations();
        
        // Select membership level
        $('.pmp-select-level').on('click', function(e) {
            e.preventDefault();
            
            var levelId = $(this).data('level-id');
            var $card = $(this).closest('.pmp-level-card');
            
            // Add selection animation
            $card.css('transform', 'scale(1.05)');
            setTimeout(function() {
                $card.css('transform', '');
            }, 200);
            
            // Show payment modal or redirect to checkout
            pmpShowCheckout(levelId);
        });
        
        // Cancel membership with confirmation
        $('.pmp-cancel-membership').on('click', function(e) {
            e.preventDefault();
            
            var subscriptionId = $(this).data('subscription-id');
            var $button = $(this);
            
            // Custom styled confirmation
            pmpConfirm(
                'Opravdu chcete zrušit své členství?',
                'Tuto akci nelze vrátit zpět. Ztratíte přístup ke všemu prémiový obsahu.',
                function() {
                    $button.prop('disabled', true).addClass('pmp-loading').text('Ruším...');
                    
                    $.ajax({
                        url: pmpData.ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'pmp_cancel_subscription',
                            nonce: pmpData.nonce,
                            subscription_id: subscriptionId
                        },
                        success: function(response) {
                            if (response.success) {
                                pmpAlert('✓ Členství zrušeno', 'success');
                                setTimeout(function() {
                                    location.reload();
                                }, 1500);
                            } else {
                                pmpAlert(response.data.message || pmpData.strings.error, 'error');
                                $button.prop('disabled', false).removeClass('pmp-loading').text('Zrušit členství');
                            }
                        },
                        error: function() {
                            pmpAlert(pmpData.strings.error, 'error');
                            $button.prop('disabled', false).removeClass('pmp-loading').text('Zrušit členství');
                        }
                    });
                }
            );
        });
        
        // Process payment
        $('#pmp-payment-form').on('submit', function(e) {
            e.preventDefault();
            
            var formData = $(this).serialize();
            var $submitButton = $(this).find('button[type="submit"]');
            var originalText = $submitButton.text();
            
            $submitButton.prop('disabled', true).addClass('pmp-loading').text('Zpracovávám...');
            
            $.ajax({
                url: pmpData.ajaxurl,
                type: 'POST',
                data: formData + '&action=pmp_process_payment&nonce=' + pmpData.nonce,
                success: function(response) {
                    if (response.success) {
                        pmpAlert('✓ Platba byla úspěšná!', 'success');
                        
                        setTimeout(function() {
                            if (response.data.redirect) {
                                window.location.href = response.data.redirect;
                            } else {
                                location.reload();
                            }
                        }, 1500);
                    } else {
                        pmpAlert(response.data.message || pmpData.strings.error, 'error');
                        $submitButton.prop('disabled', false).removeClass('pmp-loading').text(originalText);
                    }
                },
                error: function() {
                    pmpAlert(pmpData.strings.error, 'error');
                    $submitButton.prop('disabled', false).removeClass('pmp-loading').text(originalText);
                }
            });
        });
        
        // Smooth scroll to elements
        $('a[href^="#"]').on('click', function(e) {
            var target = $(this.getAttribute('href'));
            if(target.length) {
                e.preventDefault();
                $('html, body').stop().animate({
                    scrollTop: target.offset().top - 100
                }, 800, 'easeInOutCubic');
            }
        });
        
        // Add parallax effect to cards
        if (window.innerWidth > 768) {
            $('.pmp-level-card').on('mousemove', function(e) {
                var $card = $(this);
                var rect = this.getBoundingClientRect();
                var x = e.clientX - rect.left;
                var y = e.clientY - rect.top;
                
                var centerX = rect.width / 2;
                var centerY = rect.height / 2;
                
                var rotateX = (y - centerY) / 20;
                var rotateY = (centerX - x) / 20;
                
                $card.css({
                    'transform': `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(10px)`
                });
            });
            
            $('.pmp-level-card').on('mouseleave', function() {
                $(this).css({
                    'transform': ''
                });
            });
        }
        
    });
    
    // Initialize page animations
    function initPageAnimations() {
        // Animate elements on scroll
        var observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        var observer = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('pmp-animated');
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);
        
        // Observe all cards
        $('.pmp-level-card, .pmp-current-membership, .pmp-transactions, .pmp-user-info').each(function() {
            observer.observe(this);
        });
        
        // Add animation styles
        var style = document.createElement('style');
        style.textContent = `
            .pmp-level-card, 
            .pmp-current-membership, 
            .pmp-transactions, 
            .pmp-user-info {
                opacity: 0;
                transform: translateY(30px);
                transition: opacity 0.6s ease, transform 0.6s ease;
            }
            .pmp-level-card.pmp-animated,
            .pmp-current-membership.pmp-animated,
            .pmp-transactions.pmp-animated,
            .pmp-user-info.pmp-animated {
                opacity: 1;
                transform: translateY(0);
            }
        `;
        document.head.appendChild(style);
    }
    
    // Show checkout modal
    function pmpShowCheckout(levelId) {
        // Create overlay
        var $overlay = $('<div class="pmp-modal-overlay"></div>');
        var $modal = $(`
            <div class="pmp-checkout-modal">
                <div class="pmp-modal-content">
                    <button class="pmp-modal-close">&times;</button>
                    <h3>Vyberte způsob platby</h3>
                    <form id="pmp-checkout-form">
                        <input type="hidden" name="level_id" value="${levelId}">
                        
                        <div class="pmp-payment-methods">
                            <label class="pmp-payment-option">
                                <input type="radio" name="gateway" value="stripe" checked>
                                <div class="pmp-payment-card">
                                    <strong>Kreditní karta</strong>
                                    <small>Visa, Mastercard, American Express</small>
                                </div>
                            </label>
                            
                            <label class="pmp-payment-option">
                                <input type="radio" name="gateway" value="paypal">
                                <div class="pmp-payment-card">
                                    <strong>PayPal</strong>
                                    <small>Platba přes PayPal účet</small>
                                </div>
                            </label>
                            
                            <label class="pmp-payment-option">
                                <input type="radio" name="gateway" value="bank_transfer">
                                <div class="pmp-payment-card">
                                    <strong>Bankovní převod</strong>
                                    <small>Pokyny budou zaslány emailem</small>
                                </div>
                            </label>
                        </div>
                        
                        <div class="pmp-coupon-field">
                            <input type="text" name="coupon" placeholder="Máte slevový kód?">
                        </div>
                        
                        <button type="submit" class="pmp-submit-button">Pokračovat k platbě</button>
                    </form>
                </div>
            </div>
        `);
        
        // Add modal styles
        var modalStyles = `
            <style>
                .pmp-modal-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: rgba(10, 14, 39, 0.9);
                    backdrop-filter: blur(10px);
                    z-index: 9999;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    animation: fadeIn 0.3s ease;
                }
                .pmp-checkout-modal {
                    width: 90%;
                    max-width: 500px;
                    animation: slideUp 0.4s ease;
                }
                .pmp-modal-content {
                    background: var(--card-bg);
                    border: 2px solid var(--border-color);
                    border-radius: 24px;
                    padding: 40px;
                    position: relative;
                }
                .pmp-modal-close {
                    position: absolute;
                    top: 20px;
                    right: 20px;
                    background: none;
                    border: none;
                    color: var(--text-primary);
                    font-size: 30px;
                    cursor: pointer;
                    width: 40px;
                    height: 40px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    border-radius: 50%;
                    transition: all 0.3s ease;
                }
                .pmp-modal-close:hover {
                    background: rgba(255, 107, 107, 0.2);
                    transform: rotate(90deg);
                }
                .pmp-payment-methods {
                    display: grid;
                    gap: 15px;
                    margin: 30px 0;
                }
                .pmp-payment-option {
                    cursor: pointer;
                    display: block;
                }
                .pmp-payment-option input[type="radio"] {
                    display: none;
                }
                .pmp-payment-card {
                    padding: 20px;
                    border: 2px solid var(--border-color);
                    border-radius: 16px;
                    transition: all 0.3s ease;
                    background: rgba(102, 126, 234, 0.05);
                }
                .pmp-payment-option input:checked + .pmp-payment-card {
                    border-color: #667eea;
                    background: rgba(102, 126, 234, 0.15);
                    box-shadow: 0 10px 30px rgba(102, 126, 234, 0.2);
                }
                .pmp-payment-card strong {
                    display: block;
                    margin-bottom: 5px;
                }
                .pmp-payment-card small {
                    color: var(--text-secondary);
                }
                .pmp-coupon-field {
                    margin: 20px 0;
                }
                .pmp-coupon-field input {
                    width: 100%;
                    padding: 16px 20px;
                    background: rgba(102, 126, 234, 0.05);
                    border: 2px solid var(--border-color);
                    border-radius: 12px;
                    color: var(--text-primary);
                    font-size: 16px;
                }
                @keyframes fadeIn {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
                @keyframes slideUp {
                    from { transform: translateY(30px); opacity: 0; }
                    to { transform: translateY(0); opacity: 1; }
                }
            </style>
        `;
        $('head').append(modalStyles);
        
        $('body').append($overlay.append($modal));
        
        // Close modal
        $overlay.on('click', function(e) {
            if (e.target === this) {
                $(this).fadeOut(300, function() { $(this).remove(); });
            }
        });
        
        $('.pmp-modal-close').on('click', function() {
            $overlay.fadeOut(300, function() { $(this).remove(); });
        });
        
        // Handle checkout form
        $('#pmp-checkout-form').on('submit', function(e) {
            e.preventDefault();
            var formData = $(this).serialize();
            
            $.ajax({
                url: pmpData.ajaxurl,
                type: 'POST',
                data: formData + '&action=pmp_process_payment&nonce=' + pmpData.nonce,
                success: function(response) {
                    if (response.success) {
                        pmpAlert('✓ Objednávka vytvořena!', 'success');
                        setTimeout(function() {
                            if (response.data.redirect) {
                                window.location.href = response.data.redirect;
                            }
                        }, 1500);
                    } else {
                        pmpAlert(response.data.message || 'Došlo k chybě', 'error');
                    }
                }
            });
        });
    }
    
    // Custom confirm dialog
    function pmpConfirm(title, message, callback) {
        var $dialog = $(`
            <div class="pmp-modal-overlay">
                <div class="pmp-confirm-dialog">
                    <h3>${title}</h3>
                    <p>${message}</p>
                    <div class="pmp-dialog-buttons">
                        <button class="pmp-button-cancel">Zrušit</button>
                        <button class="pmp-button-confirm">Potvrdit</button>
                    </div>
                </div>
            </div>
        `);
        
        $('body').append($dialog);
        
        $dialog.find('.pmp-button-confirm').on('click', function() {
            $dialog.fadeOut(200, function() { $(this).remove(); });
            callback();
        });
        
        $dialog.find('.pmp-button-cancel').on('click', function() {
            $dialog.fadeOut(200, function() { $(this).remove(); });
        });
    }
    
    // Custom alert
    function pmpAlert(message, type) {
        var icon = type === 'success' ? '✓' : '❌';
        var $alert = $(`
            <div class="pmp-alert pmp-alert-${type}">
                ${icon} ${message}
            </div>
        `);
        
        var styles = `
            <style>
                .pmp-alert {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    padding: 20px 30px;
                    border-radius: 16px;
                    font-weight: 600;
                    z-index: 10000;
                    animation: alertSlideIn 0.4s ease;
                    box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
                }
                .pmp-alert-success {
                    background: linear-gradient(135deg, rgba(17, 153, 142, 0.95) 0%, rgba(56, 239, 125, 0.95) 100%);
                    color: white;
                }
                .pmp-alert-error {
                    background: linear-gradient(135deg, rgba(255, 107, 107, 0.95) 0%, rgba(238, 90, 111, 0.95) 100%);
                    color: white;
                }
                @keyframes alertSlideIn {
                    from { transform: translateX(400px); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
            </style>
        `;
        
        if (!$('.pmp-alert-styles').length) {
            $('head').append($(styles).addClass('pmp-alert-styles'));
        }
        
        $('body').append($alert);
        
        setTimeout(function() {
            $alert.fadeOut(400, function() { $(this).remove(); });
        }, 3000);
    }
    
})(jQuery);

