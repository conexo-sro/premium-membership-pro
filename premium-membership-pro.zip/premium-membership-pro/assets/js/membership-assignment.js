/**
 * Membership Assignment JavaScript
 */

(function($) {
    'use strict';
    
    var selectedUser = null;
    
    $(document).ready(function() {
        
        // Open assignment modal
        handleModalOpen();
        
        // User search
        handleUserSearch();
        
        // Level selection
        handleLevelSelection();
        
        // Duration selection
        handleDurationSelection();
        
        // Confirm assignment
        handleAssignmentConfirm();
    });
    
    /**
     * Handle modal open
     */
    function handleModalOpen() {
        $(document).on('click', '.pmp-open-assignment-modal, .pmp-editor-assignment-button, .pmp-admin-bar-assignment', function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var postId = $button.data('post-id') || pmpAssignment.post_id;
            
            // Show loading
            $button.prop('disabled', true).addClass('pmp-loading');
            
            // Get modal content
            $.ajax({
                url: pmpAssignment.ajaxurl,
                method: 'POST',
                data: {
                    action: 'pmp_get_assignment_modal',
                    post_id: postId,
                    nonce: pmpAssignment.nonce
                },
                success: function(response) {
                    if (response.success) {
                        showModal(response.data.html);
                    } else {
                        alert(response.data.message || 'Chyba při načítání modalu.');
                    }
                    
                    $button.prop('disabled', false).removeClass('pmp-loading');
                },
                error: function() {
                    alert('Chyba při komunikaci se serverem.');
                    $button.prop('disabled', false).removeClass('pmp-loading');
                }
            });
        });
    }
    
    /**
     * Show modal
     */
    function showModal(content) {
        // Remove existing modal
        $('.pmp-assignment-modal').remove();
        
        // Create modal
        var $modal = $('<div class="pmp-assignment-modal">' +
            '<div class="pmp-assignment-modal-overlay"></div>' +
            '<div class="pmp-assignment-modal-content">' + content + '</div>' +
        '</div>');
        
        $('body').append($modal);
        $modal.fadeIn(300);
        
        // Close handlers
        $modal.find('.pmp-modal-cancel, .pmp-assignment-modal-overlay').on('click', function() {
            closeModal();
        });
        
        // ESC key
        $(document).on('keydown.pmpModal', function(e) {
            if (e.key === 'Escape') {
                closeModal();
            }
        });
    }
    
    /**
     * Close modal
     */
    function closeModal() {
        $('.pmp-assignment-modal').fadeOut(300, function() {
            $(this).remove();
        });
        $(document).off('keydown.pmpModal');
        selectedUser = null;
    }
    
    /**
     * Handle user search
     */
    function handleUserSearch() {
        var searchTimeout;
        
        $(document).on('keyup', '.pmp-user-search-input', function() {
            var $input = $(this);
            var search = $input.val();
            
            clearTimeout(searchTimeout);
            
            if (search.length < 2) {
                $('.pmp-user-search-results').empty();
                return;
            }
            
            searchTimeout = setTimeout(function() {
                searchUsers(search);
            }, 300);
        });
        
        // Select user
        $(document).on('click', '.pmp-user-result', function() {
            var $result = $(this);
            
            selectedUser = {
                id: $result.data('user-id'),
                name: $result.data('user-name'),
                email: $result.data('user-email'),
                avatar: $result.find('.pmp-user-result-avatar img').attr('src')
            };
            
            showSelectedUser();
            
            // Clear search
            $('.pmp-user-search-input').val('');
            $('.pmp-user-search-results').empty();
            
            // Enable confirm if level is selected
            checkFormCompletion();
        });
        
        // Remove user
        $(document).on('click', '.pmp-remove-user', function() {
            selectedUser = null;
            $('.pmp-selected-user').hide();
            $('.pmp-confirm-assignment').prop('disabled', true);
        });
    }
    
    /**
     * Search users via AJAX
     */
    function searchUsers(search) {
        $.ajax({
            url: pmpAssignment.ajaxurl,
            method: 'POST',
            data: {
                action: 'pmp_search_users',
                search: search,
                nonce: pmpAssignment.nonce
            },
            success: function(response) {
                if (response.success) {
                    displayUserResults(response.data.users);
                }
            }
        });
    }
    
    /**
     * Display user search results
     */
    function displayUserResults(users) {
        var $results = $('.pmp-user-search-results');
        $results.empty();
        
        if (users.length === 0) {
            $results.html('<p class="pmp-no-results">' + pmpAssignment.strings.no_results + '</p>');
            return;
        }
        
        users.forEach(function(user) {
            var $result = $('<div class="pmp-user-result" data-user-id="' + user.id + '" data-user-name="' + user.name + '" data-user-email="' + user.email + '">' +
                '<div class="pmp-user-result-avatar"><img src="' + user.avatar + '" alt=""></div>' +
                '<div class="pmp-user-result-info">' +
                    '<span class="pmp-user-result-name">' + user.name + '</span>' +
                    '<span class="pmp-user-result-email">' + user.email + '</span>' +
                '</div>' +
            '</div>');
            
            $results.append($result);
        });
    }
    
    /**
     * Show selected user
     */
    function showSelectedUser() {
        if (!selectedUser) {
            return;
        }
        
        $('.pmp-selected-user .pmp-user-avatar').html('<img src="' + selectedUser.avatar + '" alt="">');
        $('.pmp-selected-user .pmp-user-name').text(selectedUser.name);
        $('.pmp-selected-user .pmp-user-email').text(selectedUser.email);
        $('.pmp-selected-user').show();
    }
    
    /**
     * Handle level selection
     */
    function handleLevelSelection() {
        $(document).on('change', 'input[name="pmp_level"]', function() {
            checkFormCompletion();
        });
    }
    
    /**
     * Handle duration selection
     */
    function handleDurationSelection() {
        $(document).on('change', 'input[name="pmp_duration"]', function() {
            var value = $(this).val();
            
            if (value === 'custom') {
                $('.pmp-custom-date').slideDown(300);
            } else {
                $('.pmp-custom-date').slideUp(300);
            }
        });
    }
    
    /**
     * Check if form is complete
     */
    function checkFormCompletion() {
        var hasUser = selectedUser !== null;
        var hasLevel = $('input[name="pmp_level"]:checked').length > 0;
        
        if (hasUser && hasLevel) {
            $('.pmp-confirm-assignment').prop('disabled', false);
        } else {
            $('.pmp-confirm-assignment').prop('disabled', true);
        }
    }
    
    /**
     * Handle assignment confirm
     */
    function handleAssignmentConfirm() {
        $(document).on('click', '.pmp-confirm-assignment', function() {
            var $button = $(this);
            
            if ($button.prop('disabled')) {
                return;
            }
            
            var levelId = $('input[name="pmp_level"]:checked').val();
            var duration = $('input[name="pmp_duration"]:checked').val();
            var customDate = $('#pmp_custom_date').val();
            var note = $('#pmp_assignment_note').val();
            var sendEmail = $('#pmp_send_email').is(':checked');
            var postId = pmpAssignment.post_id;
            
            // Validate
            if (!selectedUser || !levelId) {
                alert('Vyberte uživatele a úroveň.');
                return;
            }
            
            if (duration === 'custom' && !customDate) {
                alert('Zadejte vlastní datum.');
                return;
            }
            
            // Show loading
            $button.prop('disabled', true);
            $('.pmp-assignment-modal-content').addClass('pmp-assignment-loading');
            
            // Assign membership
            $.ajax({
                url: pmpAssignment.ajaxurl,
                method: 'POST',
                data: {
                    action: 'pmp_assign_membership',
                    user_id: selectedUser.id,
                    level_id: levelId,
                    duration: duration,
                    custom_date: customDate,
                    note: note,
                    send_email: sendEmail,
                    post_id: postId,
                    nonce: pmpAssignment.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Show success
                        showSuccessMessage(response.data.message);
                        
                        // Close modal after 2 seconds
                        setTimeout(function() {
                            closeModal();
                            
                            // Reload page to show updated stats
                            if ($('#pmp_membership_assignment').length) {
                                location.reload();
                            }
                        }, 2000);
                    } else {
                        alert(response.data.message || 'Chyba při přidělování.');
                        $button.prop('disabled', false);
                        $('.pmp-assignment-modal-content').removeClass('pmp-assignment-loading');
                    }
                },
                error: function() {
                    alert('Chyba při komunikaci se serverem.');
                    $button.prop('disabled', false);
                    $('.pmp-assignment-modal-content').removeClass('pmp-assignment-loading');
                }
            });
        });
    }
    
    /**
     * Show success message
     */
    function showSuccessMessage(message) {
        var $message = $('<div class="pmp-success-overlay">' +
            '<div class="pmp-success-content">' +
                '<div class="pmp-success-icon">✅</div>' +
                '<h3>' + pmpAssignment.strings.assign_success + '</h3>' +
                '<p>' + message + '</p>' +
            '</div>' +
        '</div>');
        
        $('.pmp-assignment-modal-content').append($message);
        $message.fadeIn(300);
    }
    
})(jQuery);

// Success overlay CSS
jQuery(document).ready(function($) {
    var css = '<style>' +
        '.pmp-success-overlay {' +
            'position: absolute;' +
            'top: 0;' +
            'left: 0;' +
            'width: 100%;' +
            'height: 100%;' +
            'background: rgba(255, 255, 255, 0.95);' +
            'display: flex;' +
            'align-items: center;' +
            'justify-content: center;' +
            'z-index: 10;' +
        '}' +
        '.pmp-success-content {' +
            'text-align: center;' +
            'padding: 40px;' +
        '}' +
        '.pmp-success-icon {' +
            'font-size: 64px;' +
            'margin-bottom: 20px;' +
        '}' +
        '.pmp-success-content h3 {' +
            'font-size: 24px;' +
            'color: #22543d;' +
            'margin: 0 0 10px 0;' +
        '}' +
        '.pmp-success-content p {' +
            'font-size: 16px;' +
            'color: #2f855a;' +
            'margin: 0;' +
        '}' +
    '</style>';
    
    $('head').append(css);
});
