/**
 * Auth Pages JavaScript
 * Interactive features for login and registration
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        
        // Form validation
        $('.pmp-auth-form').on('submit', function(e) {
            var form = $(this);
            var button = form.find('button[type="submit"]');
            
            // Disable button and show loading
            button.addClass('pmp-loading').prop('disabled', true);
            
            // Password match validation for registration
            if (form.find('#pmp_password_confirm').length) {
                var password = form.find('#pmp_password').val();
                var confirm = form.find('#pmp_password_confirm').val();
                
                if (password !== confirm) {
                    e.preventDefault();
                    alert('Hesla se neshodují!');
                    button.removeClass('pmp-loading').prop('disabled', false);
                    return false;
                }
            }
        });
        
        // Password strength indicator for registration
        if ($('#pmp_password').length && $('.pmp-register-page').length) {
            var $password = $('#pmp_password');
            var $strength = $('<div class="pmp-password-strength"></div>');
            var $strengthBar = $('<div class="pmp-strength-bar"></div>');
            var $strengthText = $('<div class="pmp-strength-text"></div>');
            
            $strength.append($strengthBar).append($strengthText);
            $password.parent().append($strength);
            
            $password.on('input', function() {
                var password = $(this).val();
                var strength = calculatePasswordStrength(password);
                
                $strengthBar.removeClass('weak medium strong').addClass(strength.class);
                $strengthText.text(strength.text);
                
                if (password.length === 0) {
                    $strength.hide();
                } else {
                    $strength.show();
                }
            });
            
            // Hide initially
            $strength.hide();
        }
        
        // Show/hide password toggle
        $('.pmp-form-group').each(function() {
            var $group = $(this);
            var $input = $group.find('input[type="password"]');
            
            if ($input.length) {
                var $toggle = $('<button type="button" class="pmp-password-toggle" aria-label="Toggle password visibility"></button>');
                $toggle.html('<svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/><path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/></svg>');
                
                $input.after($toggle);
                
                $toggle.on('click', function() {
                    var type = $input.attr('type') === 'password' ? 'text' : 'password';
                    $input.attr('type', type);
                    
                    if (type === 'text') {
                        $toggle.addClass('active');
                        $toggle.html('<svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M3.707 2.293a1 1 0 00-1.414 1.414l14 14a1 1 0 001.414-1.414l-1.473-1.473A10.014 10.014 0 0019.542 10C18.268 5.943 14.478 3 10 3a9.958 9.958 0 00-4.512 1.074l-1.78-1.781zm4.261 4.26l1.514 1.515a2.003 2.003 0 012.45 2.45l1.514 1.514a4 4 0 00-5.478-5.478z" clip-rule="evenodd"/><path d="M12.454 16.697L9.75 13.992a4 4 0 01-3.742-3.741L2.335 6.578A9.98 9.98 0 00.458 10c1.274 4.057 5.065 7 9.542 7 .847 0 1.669-.105 2.454-.303z"/></svg>');
                    } else {
                        $toggle.removeClass('active');
                        $toggle.html('<svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/><path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/></svg>');
                    }
                });
            }
        });
        
        // Auto-dismiss messages after 5 seconds
        $('.pmp-message').each(function() {
            var $message = $(this);
            setTimeout(function() {
                $message.fadeOut(400, function() {
                    $(this).remove();
                });
            }, 5000);
        });
        
        // Parallax effect for background shapes
        if ($('.pmp-bg-shapes').length) {
            $(document).on('mousemove', function(e) {
                var x = e.pageX / $(window).width();
                var y = e.pageY / $(window).height();
                
                $('.pmp-shape').each(function(index) {
                    var speed = (index + 1) * 10;
                    var moveX = (x - 0.5) * speed;
                    var moveY = (y - 0.5) * speed;
                    
                    $(this).css({
                        'transform': 'translate(' + moveX + 'px, ' + moveY + 'px)'
                    });
                });
            });
        }
        
        // Smooth scroll for anchor links
        $('a[href^="#"]').on('click', function(e) {
            var target = $(this.hash);
            if (target.length) {
                e.preventDefault();
                $('html, body').animate({
                    scrollTop: target.offset().top - 100
                }, 600);
            }
        });
        
        // Username validation
        $('#pmp_username').on('input', function() {
            var username = $(this).val();
            var regex = /^[a-zA-Z0-9_-]+$/;
            
            if (username.length > 0 && !regex.test(username)) {
                $(this).addClass('invalid');
            } else {
                $(this).removeClass('invalid');
            }
        });
        
        // Email validation
        $('#pmp_email').on('blur', function() {
            var email = $(this).val();
            var regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            
            if (email.length > 0 && !regex.test(email)) {
                $(this).addClass('invalid');
            } else {
                $(this).removeClass('invalid');
            }
        });
    });
    
    /**
     * Calculate password strength
     */
    function calculatePasswordStrength(password) {
        var strength = 0;
        
        if (password.length >= 8) strength++;
        if (password.length >= 12) strength++;
        if (/[a-z]/.test(password)) strength++;
        if (/[A-Z]/.test(password)) strength++;
        if (/[0-9]/.test(password)) strength++;
        if (/[^a-zA-Z0-9]/.test(password)) strength++;
        
        if (strength <= 2) {
            return { class: 'weak', text: 'Slabé heslo' };
        } else if (strength <= 4) {
            return { class: 'medium', text: 'Střední heslo' };
        } else {
            return { class: 'strong', text: 'Silné heslo' };
        }
    }
    
})(jQuery);
