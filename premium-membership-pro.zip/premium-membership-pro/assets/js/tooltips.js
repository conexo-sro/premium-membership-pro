/**
 * Tooltips JavaScript
 * Interactive help system
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        
        // Initialize tooltips
        initTooltips();
        
        // Add help icons to form fields
        addHelpIcons();
        
        // Keyboard shortcuts for help
        initKeyboardShortcuts();
    });
    
    /**
     * Initialize tooltip system
     */
    function initTooltips() {
        // Close tooltip on ESC
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape') {
                closeTooltips();
            }
        });
        
        // Close tooltip on click outside
        $(document).on('click', function(e) {
            if (!$(e.target).closest('.pmp-tooltip-icon, .pmp-tooltip-popup').length) {
                closeTooltips();
            }
        });
        
        // Tooltip click handler
        $(document).on('click', '.pmp-tooltip-icon', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            var $icon = $(this);
            var title = $icon.data('tooltip-title');
            var content = $icon.data('tooltip-content');
            
            showTooltip($icon, title, content);
        });
        
        // Hover preview (optional)
        var hoverTimeout;
        $(document).on('mouseenter', '.pmp-tooltip-icon', function() {
            var $icon = $(this);
            hoverTimeout = setTimeout(function() {
                var title = $icon.data('tooltip-title');
                var content = $icon.data('tooltip-content');
                showTooltip($icon, title, content);
            }, 800);
        });
        
        $(document).on('mouseleave', '.pmp-tooltip-icon', function() {
            clearTimeout(hoverTimeout);
        });
    }
    
    /**
     * Show tooltip
     */
    function showTooltip($icon, title, content) {
        // Remove existing tooltips
        closeTooltips();
        
        // Create tooltip
        var $tooltip = $('<div class="pmp-tooltip-popup">' +
            '<div class="pmp-tooltip-title">' + title + '</div>' +
            '<div class="pmp-tooltip-content">' + content + '</div>' +
        '</div>');
        
        $('body').append($tooltip);
        
        // Position tooltip
        positionTooltip($icon, $tooltip);
        
        // Auto-hide after 8 seconds
        setTimeout(function() {
            $tooltip.fadeOut(300, function() {
                $(this).remove();
            });
        }, 8000);
    }
    
    /**
     * Position tooltip relative to icon
     */
    function positionTooltip($icon, $tooltip) {
        var iconOffset = $icon.offset();
        var iconWidth = $icon.outerWidth();
        var iconHeight = $icon.outerHeight();
        var tooltipWidth = $tooltip.outerWidth();
        var tooltipHeight = $tooltip.outerHeight();
        var windowWidth = $(window).width();
        var windowHeight = $(window).height();
        var scrollTop = $(window).scrollTop();
        
        var top, left;
        
        // Try to position above icon
        top = iconOffset.top - tooltipHeight - 15;
        
        // If doesn't fit above, position below
        if (top < scrollTop) {
            top = iconOffset.top + iconHeight + 15;
            $tooltip.addClass('pmp-tooltip-below');
        }
        
        // Center horizontally
        left = iconOffset.left - (tooltipWidth / 2) + (iconWidth / 2);
        
        // Make sure it fits in viewport
        if (left < 10) {
            left = 10;
        } else if (left + tooltipWidth > windowWidth - 10) {
            left = windowWidth - tooltipWidth - 10;
        }
        
        $tooltip.css({
            top: top,
            left: left
        });
    }
    
    /**
     * Close all tooltips
     */
    function closeTooltips() {
        $('.pmp-tooltip-popup').fadeOut(200, function() {
            $(this).remove();
        });
    }
    
    /**
     * Add help icons to form fields
     */
    function addHelpIcons() {
        // Admin settings page
        if ($('.pmp-settings-page').length) {
            addSettingsHelp();
        }
        
        // Membership levels
        if ($('#pmp_membership_meta_box').length) {
            addLevelHelp();
        }
    }
    
    /**
     * Add help to settings page
     */
    function addSettingsHelp() {
        var settingsHelp = {
            'pmp_login_page': {
                title: 'Přihlašovací stránka',
                content: 'Vyberte stránku s [pmp_login] shortcodem. Tato stránka se použije pro přihlášení členů.'
            },
            'pmp_register_page': {
                title: 'Registrační stránka',
                content: 'Vyberte stránku s [pmp_register] shortcodem. Zde se budou registrovat noví členové.'
            },
            'pmp_account_page': {
                title: 'Účet stránka',
                content: 'Dashboard pro přihlášené členy. Zobrazí jejich členství, transakce a nastavení.'
            },
            'pmp_currency': {
                title: 'Měna',
                content: 'Měna pro zobrazení cen. Ovlivní formátování částek na celém webu.'
            },
            'pmp_default_protection': {
                title: 'Výchozí ochrana',
                content: 'Co se stane když ne-člen přistoupí na chráněný obsah? Preview = ukáže začátek, Redirect = přesměruje na přihlášení.'
            }
        };
        
        $.each(settingsHelp, function(field, data) {
            var $field = $('#' + field);
            if ($field.length) {
                var $icon = $('<span class="pmp-tooltip-icon" data-tooltip-title="' + data.title + '" data-tooltip-content="' + data.content + '">?</span>');
                $field.closest('tr').find('th').append($icon);
            }
        });
    }
    
    /**
     * Add help to membership level
     */
    function addLevelHelp() {
        var levelHelp = {
            '_pmp_price': {
                title: 'Cena',
                content: 'Cena za tento membership. Zadejte číslo bez měny (např. 199).'
            },
            '_pmp_interval': {
                title: 'Interval platby',
                content: 'Jak často se bude platit? Měsíc = měsíční předplatné, Rok = roční, Jednorázově = jen jednou.'
            },
            '_pmp_trial_days': {
                title: 'Zkušební dny',
                content: 'Počet dní zdarma na začátku. Např. 14 = 14 dní zdarma, pak začne účtování.'
            }
        };
        
        $.each(levelHelp, function(field, data) {
            var $field = $('input[name="' + field + '"], select[name="' + field + '"]');
            if ($field.length) {
                var $label = $('label[for="' + field.replace('_', '') + '"]');
                if ($label.length) {
                    var $icon = $('<span class="pmp-tooltip-icon" data-tooltip-title="' + data.title + '" data-tooltip-content="' + data.content + '">?</span>');
                    $label.append($icon);
                }
            }
        });
    }
    
    /**
     * Keyboard shortcuts
     */
    function initKeyboardShortcuts() {
        // Ctrl+H or Cmd+H = Toggle help panel
        $(document).on('keydown', function(e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'h') {
                e.preventDefault();
                $('#contextual-help-link').trigger('click');
            }
        });
        
        // F1 = Open help
        $(document).on('keydown', function(e) {
            if (e.key === 'F1') {
                e.preventDefault();
                $('#contextual-help-link').trigger('click');
            }
        });
    }
    
    /**
     * Show help notification (one-time)
     */
    function showHelpNotification() {
        if (localStorage.getItem('pmp_help_shown')) {
            return;
        }
        
        var $notice = $('<div class="notice notice-info is-dismissible pmp-help-notice">' +
            '<p><strong>💡 Tip:</strong> Stiskněte <kbd>F1</kbd> nebo <kbd>Ctrl+H</kbd> pro zobrazení nápovědy kdykoli.</p>' +
        '</div>');
        
        $('.wrap h1').after($notice);
        
        // Mark as shown
        localStorage.setItem('pmp_help_shown', '1');
        
        // Auto-dismiss after 10 seconds
        setTimeout(function() {
            $notice.fadeOut(400, function() {
                $(this).remove();
            });
        }, 10000);
    }
    
    // Show help notification on first visit
    if ($('.membership-pro_page').length) {
        setTimeout(showHelpNotification, 2000);
    }
    
})(jQuery);
