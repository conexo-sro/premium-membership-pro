/**
 * Content Lock JavaScript
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        
        // Toggle lock status visibility
        toggleLockVisibility();
        
        // Handle lock toggle in meta box
        handleMetaBoxToggle();
        
        // Handle quick unlock button
        handleQuickUnlock();
        
        // Handle row action lock toggle
        handleRowActionToggle();
        
        // Handle admin bar toggle
        handleAdminBarToggle();
        
        // Handle bulk action notices
        handleBulkNotices();
    });
    
    /**
     * Toggle lock status visibility
     */
    function toggleLockVisibility() {
        $('#pmp_content_locked').on('change', function() {
            var isChecked = $(this).is(':checked');
            
            if (isChecked) {
                $('.pmp-lock-status').slideDown(300);
                $('.pmp-unlock-status').slideUp(300);
            } else {
                $('.pmp-lock-status').slideUp(300);
                $('.pmp-unlock-status').slideDown(300);
            }
        });
    }
    
    /**
     * Handle meta box toggle
     */
    function handleMetaBoxToggle() {
        $('#pmp_content_locked').on('change', function() {
            var $checkbox = $(this);
            var postId = $checkbox.data('post-id');
            var isChecked = $checkbox.is(':checked');
            
            // Visual feedback
            if (isChecked) {
                showLockNotice('Změny se uloží při publikování.', 'info');
            }
        });
    }
    
    /**
     * Handle quick unlock button
     */
    function handleQuickUnlock() {
        $('.pmp-force-unlock').on('click', function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var postId = $button.data('post-id');
            
            if (!confirm('Opravdu chcete okamžitě odemknout tento obsah?')) {
                return;
            }
            
            // Disable button
            $button.prop('disabled', true).addClass('pmp-lock-loading');
            
            // Toggle via AJAX
            toggleLockAjax(postId, function(success, data) {
                if (success) {
                    // Uncheck checkbox
                    $('#pmp_content_locked').prop('checked', false).trigger('change');
                    
                    // Remove quick unlock button
                    $('.pmp-quick-actions').slideUp(300);
                    
                    // Show success notice
                    showLockNotice(data.message, 'success');
                } else {
                    $button.prop('disabled', false).removeClass('pmp-lock-loading');
                    showLockNotice(data.message || 'Chyba při odemykání.', 'error');
                }
            });
        });
    }
    
    /**
     * Handle row action lock toggle
     */
    function handleRowActionToggle() {
        $(document).on('click', '.pmp-row-lock-toggle', function(e) {
            e.preventDefault();
            
            var $link = $(this);
            var postId = $link.data('post-id');
            var action = $link.data('action');
            var nonce = $link.data('nonce');
            var $row = $link.closest('tr');
            
            // Add loading state
            $row.addClass('pmp-lock-loading');
            
            // Toggle via AJAX
            $.ajax({
                url: pmpLock.ajaxurl,
                method: 'POST',
                data: {
                    action: 'pmp_toggle_lock',
                    post_id: postId,
                    nonce: nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Update badge
                        var $badge = $row.find('.pmp-lock-badge');
                        var $icon = $badge.find('.dashicons');
                        
                        if (response.data.locked) {
                            $badge.removeClass('pmp-unlocked').addClass('pmp-locked');
                            $icon.removeClass('dashicons-unlock').addClass('dashicons-lock');
                            $link.text('🔓 Odemknout').data('action', 'unlock');
                        } else {
                            $badge.removeClass('pmp-locked').addClass('pmp-unlocked');
                            $icon.removeClass('dashicons-lock').addClass('dashicons-unlock');
                            $link.text('🔒 Uzamknout').data('action', 'lock');
                        }
                        
                        // Show notice
                        showAdminNotice(response.data.message, 'success');
                    } else {
                        showAdminNotice(response.data.message || 'Chyba', 'error');
                    }
                    
                    $row.removeClass('pmp-lock-loading');
                },
                error: function() {
                    showAdminNotice('Chyba při komunikaci se serverem.', 'error');
                    $row.removeClass('pmp-lock-loading');
                }
            });
        });
    }
    
    /**
     * Handle admin bar toggle
     */
    function handleAdminBarToggle() {
        $(document).on('click', '.pmp-toggle-lock-link', function(e) {
            e.preventDefault();
            
            var $link = $(this);
            var postId = $link.data('post-id');
            var nonce = $link.data('nonce');
            
            // Toggle via AJAX
            $.ajax({
                url: pmpLock.ajaxurl,
                method: 'POST',
                data: {
                    action: 'pmp_toggle_lock',
                    post_id: postId,
                    nonce: nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Reload page to update admin bar
                        location.reload();
                    } else {
                        alert(response.data.message || 'Chyba');
                    }
                },
                error: function() {
                    alert('Chyba při komunikaci se serverem.');
                }
            });
        });
    }
    
    /**
     * Handle bulk action notices
     */
    function handleBulkNotices() {
        var urlParams = new URLSearchParams(window.location.search);
        var locked = urlParams.get('pmp_locked');
        var unlocked = urlParams.get('pmp_unlocked');
        
        if (locked) {
            showAdminNotice('Uzamknuto: ' + locked + ' položek', 'success');
        }
        
        if (unlocked) {
            showAdminNotice('Odemknuto: ' + unlocked + ' položek', 'success');
        }
    }
    
    /**
     * Toggle lock via AJAX
     */
    function toggleLockAjax(postId, callback) {
        $.ajax({
            url: pmpLock.ajaxurl,
            method: 'POST',
            data: {
                action: 'pmp_toggle_lock',
                post_id: postId,
                nonce: $('#pmp_lock_nonce').val()
            },
            success: function(response) {
                if (response.success) {
                    callback(true, response.data);
                } else {
                    callback(false, response.data);
                }
            },
            error: function() {
                callback(false, {message: 'Chyba při komunikaci se serverem.'});
            }
        });
    }
    
    /**
     * Show lock notice in meta box
     */
    function showLockNotice(message, type) {
        var $notice = $('<div class="pmp-meta-notice pmp-notice-' + type + '">' + message + '</div>');
        
        $('.pmp-lock-meta-box').prepend($notice);
        
        setTimeout(function() {
            $notice.fadeOut(300, function() {
                $(this).remove();
            });
        }, 3000);
    }
    
    /**
     * Show admin notice
     */
    function showAdminNotice(message, type) {
        var className = type === 'success' ? 'notice-success' : 'notice-error';
        var $notice = $(
            '<div class="notice ' + className + ' is-dismissible pmp-lock-notice">' +
                '<p>' + message + '</p>' +
                '<button type="button" class="notice-dismiss"></button>' +
            '</div>'
        );
        
        $('.wrap h1').after($notice);
        
        // Make dismissible work
        $notice.find('.notice-dismiss').on('click', function() {
            $notice.fadeOut(300, function() {
                $(this).remove();
            });
        });
        
        // Auto-dismiss after 5 seconds
        setTimeout(function() {
            $notice.fadeOut(300, function() {
                $(this).remove();
            });
        }, 5000);
    }
    
})(jQuery);

// CSS for meta notice
jQuery(document).ready(function($) {
    var css = '<style>' +
        '.pmp-meta-notice {' +
            'padding: 10px 15px;' +
            'border-radius: 4px;' +
            'margin-bottom: 15px;' +
            'animation: slideDown 0.3s ease;' +
        '}' +
        '.pmp-notice-info {' +
            'background: #e7f3ff;' +
            'border-left: 4px solid #2196F3;' +
            'color: #0d47a1;' +
        '}' +
        '.pmp-notice-success {' +
            'background: #e8f5e9;' +
            'border-left: 4px solid #4caf50;' +
            'color: #1b5e20;' +
        '}' +
        '.pmp-notice-error {' +
            'background: #ffebee;' +
            'border-left: 4px solid #f44336;' +
            'color: #b71c1c;' +
        '}' +
        '@keyframes slideDown {' +
            'from { opacity: 0; transform: translateY(-10px); }' +
            'to { opacity: 1; transform: translateY(0); }' +
        '}' +
    '</style>';
    
    $('head').append(css);
});
