/* Premium Membership Pro - Admin JavaScript */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        
        // Toggle recurring fields based on billing type
        $('#pmp_billing_type').on('change', function() {
            if ($(this).val() === 'recurring') {
                $('.recurring-field').show();
            } else {
                $('.recurring-field').hide();
            }
        }).trigger('change');
        
        // Toggle trial fields
        $('#pmp_trial_enabled').on('change', function() {
            if ($(this).is(':checked')) {
                $('#pmp_trial_days').closest('tr').find('input[type="number"]').show();
            } else {
                $('#pmp_trial_days').closest('tr').find('input[type="number"]').hide();
            }
        }).trigger('change');
        
        // Toggle access limit fields
        $('#pmp_limit_access').on('change', function() {
            if ($(this).is(':checked')) {
                $('#pmp_max_content').show();
            } else {
                $('#pmp_max_content').hide();
            }
        }).trigger('change');
        
        // Toggle access type fields
        $('#pmp_access_type').on('change', function() {
            var type = $(this).val();
            $('.access-categories, .access-posts').hide();
            
            if (type === 'categories' || type === 'mixed') {
                $('.access-categories').show();
            }
            if (type === 'posts' || type === 'mixed') {
                $('.access-posts').show();
            }
        }).trigger('change');
        
        // Content protection toggle
        $('input[name="pmp_protected"]').on('change', function() {
            if ($(this).is(':checked')) {
                $('#pmp-protection-options').slideDown();
            } else {
                $('#pmp-protection-options').slideUp();
            }
        });
        
        // Confirm actions
        $('.pmp-delete-action').on('click', function(e) {
            if (!confirm('Opravdu chcete tuto akci provést? Tato akce je nevratná.')) {
                e.preventDefault();
            }
        });
        
        // Date picker
        if ($.fn.datepicker) {
            $('.pmp-datepicker').datepicker({
                dateFormat: 'yy-mm-dd',
                changeMonth: true,
                changeYear: true
            });
        }
        
        // Tooltips
        if ($.fn.tooltip) {
            $('.pmp-tooltip').tooltip();
        }
        
        // Charts initialization (placeholder for future implementation)
        if (typeof Chart !== 'undefined') {
            initializeCharts();
        }
        
    });
    
    function initializeCharts() {
        // Placeholder for chart initialization
        // You would implement Chart.js charts here
        console.log('Charts initialized');
    }
    
})(jQuery);
