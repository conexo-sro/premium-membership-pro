/**
 * Post Level Column JavaScript
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        
        // Handle bulk edit save
        handleBulkEditSave();
        
        // Store level IDs in rows for quick edit
        storeLevelIds();
    });
    
    /**
     * Handle bulk edit save
     */
    function handleBulkEditSave() {
        $('#bulk_edit').on('click', function() {
            
            var $bulk_row = $('#bulk-edit');
            var action = $bulk_row.find('select[name="pmp_bulk_action"]').val();
            
            if (!action) {
                return;
            }
            
            var levels = [];
            $bulk_row.find('input[name="pmp_bulk_levels[]"]:checked').each(function() {
                levels.push($(this).val());
            });
            
            // Get selected post IDs
            var post_ids = [];
            $bulk_row.find('#bulk-titles').children().each(function() {
                post_ids.push($(this).attr('id').replace(/^(ttle)/i, ''));
            });
            
            if (post_ids.length === 0) {
                return;
            }
            
            // Save via AJAX
            $.ajax({
                url: pmpLevelColumn.ajaxurl,
                method: 'POST',
                data: {
                    action: 'pmp_save_bulk_edit_level',
                    post_ids: post_ids,
                    pmp_bulk_action: action,
                    pmp_bulk_levels: levels,
                    _ajax_nonce: pmpLevelColumn.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Show notice
                        showNotice(response.data.message, 'success');
                        
                        // Reload after short delay
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        showNotice(response.data.message || 'Chyba při ukládání.', 'error');
                    }
                },
                error: function() {
                    showNotice('Chyba při komunikaci se serverem.', 'error');
                }
            });
        });
    }
    
    /**
     * Store level IDs in rows
     */
    function storeLevelIds() {
        $('.pmp-levels-badges').each(function() {
            var $badges = $(this);
            var level_ids = [];
            
            $badges.find('.pmp-level-badge').each(function() {
                var badge_text = $(this).text();
                // This is a simplified approach - in production you'd want to store IDs properly
                level_ids.push(badge_text);
            });
            
            if (level_ids.length > 0) {
                $badges.closest('tr').attr('data-level-ids', level_ids.join(','));
            }
        });
    }
    
    /**
     * Show admin notice
     */
    function showNotice(message, type) {
        var className = type === 'success' ? 'notice-success' : 'notice-error';
        var $notice = $(
            '<div class="notice ' + className + ' is-dismissible">' +
                '<p>' + message + '</p>' +
                '<button type="button" class="notice-dismiss"></button>' +
            '</div>'
        );
        
        $('.wrap h1').first().after($notice);
        
        $notice.find('.notice-dismiss').on('click', function() {
            $notice.fadeOut(300, function() {
                $(this).remove();
            });
        });
        
        setTimeout(function() {
            $notice.fadeOut(300, function() {
                $(this).remove();
            });
        }, 5000);
    }
    
    // ============================================
    // INLINE EDITOR
    // ============================================
    
    var currentEditor = null;
    
    // Open inline editor
    $(document).on('click', '.pmp-level-display, .pmp-edit-icon', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        var $wrapper = $(this).closest('.pmp-level-column-wrapper');
        var $editor = $wrapper.find('.pmp-level-editor');
        
        // Close any open editors
        if (currentEditor && currentEditor[0] !== $wrapper[0]) {
            currentEditor.removeClass('editing').find('.pmp-level-editor').hide();
        }
        
        // Toggle this editor
        if ($wrapper.hasClass('editing')) {
            $wrapper.removeClass('editing');
            $editor.hide();
            currentEditor = null;
        } else {
            $wrapper.addClass('editing');
            $editor.show();
            currentEditor = $wrapper;
        }
    });
    
    // Toggle protection checkbox
    $(document).on('change', '.pmp-protection-checkbox', function() {
        var $editor = $(this).closest('.pmp-level-editor');
        var $levels = $editor.find('.pmp-editor-levels');
        
        if ($(this).is(':checked')) {
            $levels.slideDown(200);
        } else {
            $levels.slideUp(200);
        }
    });
    
    // Auto-enable protection when level is selected
    $(document).on('change', '.pmp-level-checkbox', function() {
        if ($(this).is(':checked')) {
            var $editor = $(this).closest('.pmp-level-editor');
            var $protectionCheckbox = $editor.find('.pmp-protection-checkbox');
            
            if (!$protectionCheckbox.is(':checked')) {
                $protectionCheckbox.prop('checked', true).trigger('change');
            }
        }
    });
    
    // Save inline edit
    $(document).on('click', '.pmp-save-inline', function(e) {
        e.preventDefault();
        
        var $button = $(this);
        var $wrapper = $button.closest('.pmp-level-column-wrapper');
        var $editor = $wrapper.find('.pmp-level-editor');
        var postId = $wrapper.data('post-id');
        
        var enableProtection = $editor.find('.pmp-protection-checkbox').is(':checked');
        var selectedLevels = [];
        
        // CRITICAL: ALWAYS collect selected levels, regardless of checkbox
        $editor.find('.pmp-level-checkbox:checked').each(function() {
            selectedLevels.push($(this).val());
        });
        
        // If levels are selected, auto-enable protection
        if (selectedLevels.length > 0) {
            enableProtection = true;
        }
        
        // Disable button
        $button.addClass('loading').prop('disabled', true).text('Ukládám...');
        
        // AJAX save
        $.ajax({
            url: pmpLevelColumn.ajaxurl,
            type: 'POST',
            data: {
                action: 'pmp_save_inline_level',
                nonce: pmpLevelColumn.inline_nonce,
                post_id: postId,
                enable_protection: enableProtection,
                selected_levels: selectedLevels
            },
            success: function(response) {
                if (response.success) {
                    // Show success message FIRST
                    showNotice(response.data.message, 'success');
                    
                    // Update display
                    $wrapper.find('.pmp-level-display').html(response.data.display_html);
                    
                    // Close editor
                    $wrapper.removeClass('editing');
                    $editor.hide();
                    currentEditor = null;
                } else {
                    showNotice(response.data.message || 'Došlo k chybě při ukládání.', 'error');
                }
            },
            error: function() {
                showNotice('Došlo k chybě při ukládání. Zkuste to prosím znovu.', 'error');
            },
            complete: function() {
                $button.removeClass('loading').prop('disabled', false).text('Uložit');
            }
        });
    });
    
    // Cancel inline edit
    $(document).on('click', '.pmp-cancel-inline', function(e) {
        e.preventDefault();
        
        var $wrapper = $(this).closest('.pmp-level-column-wrapper');
        var $editor = $wrapper.find('.pmp-level-editor');
        
        $wrapper.removeClass('editing');
        $editor.hide();
        currentEditor = null;
    });
    
    // Close editor when clicking outside
    $(document).on('click', function(e) {
        if (currentEditor && 
            !$(e.target).closest('.pmp-level-column-wrapper').length) {
            currentEditor.removeClass('editing').find('.pmp-level-editor').hide();
            currentEditor = null;
        }
    });
    
    // Prevent editor close when clicking inside it
    $(document).on('click', '.pmp-level-editor', function(e) {
        e.stopPropagation();
    });
    
})(jQuery);
