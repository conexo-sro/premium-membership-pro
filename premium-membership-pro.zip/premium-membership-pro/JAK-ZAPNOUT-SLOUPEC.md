# 🎯 JAK ZAPNOUT SLOUPEC "ÚROVEŇ" V SEZNAMU PŘÍSPĚVKŮ

## ⚠️ DŮLEŽITÉ: Sloupec už existuje, jen ho musíš zapnout!

---

## 📋 Krok za krokem návod

### KROK 1: Otevřít "Možnosti obrazovky"

```
Jdi na: Příspěvky → Všechny příspěvky
```

```
V PRAVÉM HORNÍM ROHU najdi tlačítko:
┌──────────────────────────┐
│ [Možnosti obrazovky ▼]   │
└──────────────────────────┘
```

**POZICE:**
- Pravý horní roh stránky
- Vedle tlačítka "Nápověda"
- Nad seznamem příspěvků

---

### KROK 2: Kliknout na "Možnosti obrazovky"

```
Klikni na tlačítko → Rozbalí se panel
```

**ROZBALENÝ PANEL:**

```
┌────────────────────────────────────────┐
│ Možnosti obrazovky                     │
├────────────────────────────────────────┤
│ Sloupce:                               │
│                                        │
│ ☑ Autor                                │
│ ☑ Kategorie                            │
│ ☑ Štítky                               │
│ ☑ Komentáře                            │
│ ☑ Datum                                │
│ ☐ Úroveň              ← TENTO!!!       │
│ ☑ Skupiny obsahu                       │
│                                        │
│ Počet položek na stránku: [20]         │
└────────────────────────────────────────┘
```

---

### KROK 3: Zaškrtnout "Úroveň"

```
Najdi v seznamu: ☐ Úroveň
                  ↓
Klikni na checkbox
                  ↓
              ☑ Úroveň ✅
```

**NÁZEV SLOUPCE:**
- 🛡️ **Úroveň**
- Nebo: **🛡️ Úroveň členství**

---

### KROK 4: Panel se zavře, sloupec se objeví!

```
Panel se automaticky zavře
    ↓
Sloupec "Úroveň" se OKAMŽITĚ zobrazí
    ↓
✅ HOTOVO!
```

---

## 🎨 JAK BUDE VYPADAT SEZNAM

### PŘED (bez sloupce):

```
┌────┬───────────────┬────────┬──────────────┬─────────┐
│ ☑  │ Název         │ Autor  │ Rubriky      │ Datum   │
├────┼───────────────┼────────┼──────────────┼─────────┤
│ ☑  │ Test článek   │ admin  │ Nezařazené   │ 9.12.   │
└────┴───────────────┴────────┴──────────────┴─────────┘
```

### PO (se sloupcem):

```
┌────┬───────────────┬──────────────┬────────┬──────────────┬─────────┐
│ ☑  │ Název         │ 🛡️ Úroveň    │ Autor  │ Rubriky      │ Datum   │
├────┼───────────────┼──────────────┼────────┼──────────────┼─────────┤
│ ☑  │ Test článek   │ [Premium] 🖊 │ admin  │ Nezařazené   │ 9.12.   │
├────┼───────────────┼──────────────┼────────┼──────────────┼─────────┤
│ ☑  │ VIP obsah     │ [VIP] 🖊     │ admin  │ Nezařazené   │ 9.12.   │
├────┼───────────────┼──────────────┼────────┼──────────────┼─────────┤
│ ☑  │ Veřejný       │ 🔓 Veřejný 🖊│ admin  │ Nezařazené   │ 9.12.   │
└────┴───────────────┴──────────────┴────────┴──────────────┴─────────┘
              ↑ NOVÝ SLOUPEC!
```

---

## 🖱️ JAK POUŽÍVAT SLOUPEC

### 1. KLIKNOUT na badge nebo ikonu 🖊

```
Klikni na:
├─ [Premium] badge
├─ 🔓 Veřejný badge
└─ 🖊 Ikona tužky
```

### 2. OTEVŘE SE inline editor

```
┌─────────────────────────────────┐
│ ☑ Chránit obsah                 │
│                                 │
│ Vyber úrovně:                   │
│ ☐ Basic                         │
│ ☑ Premium                       │
│ ☐ VIP                           │
│                                 │
│ [Uložit] [Zrušit]               │
└─────────────────────────────────┘
```

### 3. ZMĚNIT úrovně

```
Zaškrtni/odškrtni úrovně
    ↓
Klikni "Uložit"
    ↓
✅ Badge se automaticky aktualizuje!
```

---

## 🔍 POKUD SLOUPEC NENÍ V "MOŽNOSTI OBRAZOVKY"

### Možná příčina 1: Plugin není aktivní

```
Zkontroluj:
Pluginy → Instalované pluginy
Premium Membership Pro: ☑ Aktivní
```

### Možná příčina 2: Cache problém

```
Řešení:
1. Hard refresh (Ctrl + Shift + R)
2. Vymazat browser cache
3. Deaktivovat + aktivovat plugin
```

### Možná příčina 3: Konflikt s jiným pluginem

```
Zkontroluj:
1. Deaktivuj ostatní membership pluginy
2. Deaktivuj column manager pluginy
3. Zkus jeden po druhém
```

---

## 📱 SCREENSHOTY POZIC

### Pozice tlačítka "Možnosti obrazovky":

```
WordPress Header
├─ Logo (vlevo)
├─ Menu (uprostřed)
└─ Možnosti obrazovky + Nápověda (VPRAVO NAHOŘE!) ← TADY!
    ↓
┌──────────────────────┬────────────┐
│ Možnosti obrazovky ▼ │ Nápověda ⓘ │
└──────────────────────┴────────────┘
```

### Rozbalený panel:

```
┌────────────────────────────────────┐
│ × Možnosti obrazovky            [X]│ ← Křížek pro zavření
├────────────────────────────────────┤
│                                    │
│ Sloupce:                           │
│ ─────────────────────              │
│ ☑ Autor                            │
│ ☑ Kategorie                        │
│ ☑ Štítky                           │
│ ☑ Komentáře                        │
│ ☑ Datum                            │
│ ☐ Úroveň ← ZAŠKRTNI!               │
│ ☑ Skupiny obsahu                   │
│                                    │
│ Počet položek na stránku:          │
│ [20 ▼]                             │
│                                    │
│ [Použít]                           │
└────────────────────────────────────┘
```

---

## 🎯 TYPY ZOBRAZENÍ VE SLOUPCI

### 1. Veřejný obsah

```
🔓 Veřejný 🖊
├─ Icon: Odemčený zámek
├─ Text: "Veřejný"
├─ Barva: Zelená
└─ Kliknutelné
```

### 2. Jakékoli členství

```
👥 Jakékoli 🖊
├─ Icon: Skupina lidí
├─ Text: "Jakékoli"
├─ Barva: Modrá
└─ = Chráněno, ale žádná úroveň nevybrána
```

### 3. Konkrétní úroveň

```
[Premium] 🖊
├─ Badge: Fialový gradient
├─ Text: Název úrovně
├─ Rounded corners
└─ Kliknutelné
```

### 4. Více úrovní

```
[Basic] [Premium] +2 🖊
├─ První 2 úrovně: Badge
├─ +2: Počet zbylých
└─ Tooltip: Všechny úrovně při hoveru
```

---

## 💡 TIPY

### Tip 1: Přetažení sloupců

```
Můžeš přetáhnout sloupec "Úroveň" na jinou pozici:
├─ Chyť záhlaví sloupce
├─ Drž a táhni
└─ Pusť na nové pozici
```

### Tip 2: Řazení

```
Klikni na záhlaví "Úroveň":
├─ 1x: Vzestupně (Veřejné → Chráněné)
└─ 2x: Sestupně (Chráněné → Veřejné)
```

### Tip 3: Filtrování

```
Nad seznamem příspěvků:
[Všechny úrovně ▼]
├─ Všechny
├─ Veřejné
├─ Chráněné
├─ Basic
├─ Premium
└─ VIP
```

---

## ⚠️ DŮLEŽITÉ POZNÁMKY

### 1. Sloupec se ukládá pro každého uživatele

```
Pokud zapneš sloupec:
├─ Uloží se pro TVŮJ účet
├─ Jiní uživatelé ho nevidí
└─ Každý si musí zapnout sám
```

### 2. Sloupec se pamatuje

```
Když zavřeš panel:
├─ Sloupec zůstane viditelný
├─ I po odhlášení
└─ I po restartu browseru
```

### 3. Funguje pro příspěvky i stránky

```
Sloupec se objeví na:
├─ Příspěvky → Všechny příspěvky
└─ Stránky → Všechny stránky
```

---

## 🔧 DEBUG

### Pokud sloupec NENÍ v "Možnosti obrazovky"

**Zkontroluj v kódu:**

```php
// functions.php nebo debug
add_action('admin_head', function() {
    global $wp_list_table;
    if ($wp_list_table) {
        $columns = $wp_list_table->get_columns();
        echo '<pre>';
        print_r($columns);
        echo '</pre>';
    }
});
```

**Očekávaný výstup:**

```
Array (
    [cb] => <input type="checkbox">
    [title] => Název
    [pmp_levels] => Úroveň    ← TOTO MUSÍ BÝT!
    [author] => Autor
    [categories] => Rubriky
    ...
)
```

---

## 📋 CHECKLIST

**Zkontroluj:**

- ☐ Plugin Premium Membership Pro aktivní
- ☐ Verze 1.7.0 nebo vyšší
- ☐ Jsi na stránce "Všechny příspěvky"
- ☐ Klikl jsi na "Možnosti obrazovky"
- ☐ Vidíš "Úroveň" v seznamu sloupců
- ☐ Zaškrtl jsi checkbox
- ☐ Panel se zavřel
- ☐ Sloupec se objevil
- ☐ Můžeš kliknout na badges
- ☐ Inline editor funguje

---

## 🆘 POMOC

**Pokud sloupec stále není viditelný:**

1. ✅ Screenshot "Možnosti obrazovky" panelu
2. ✅ Screenshot seznamu příspěvků
3. ✅ Zkontroluj debug.log
4. ✅ Kontaktuj podporu s info:
   - Verze WordPress
   - Verze PHP
   - Verze pluginu
   - Seznam aktivních pluginů

**Kontakt:**
- 📧 info@conexo.cz
- 💬 GitHub Issues

---

**JE TO JEDNODUCHÉ!**

```
Možnosti obrazovky
    ↓
☑ Úroveň
    ↓
✅ HOTOVO!
```

**Plugin Premium Membership Pro v1.7.0+**  
**CONEXO s.r.o.** | conexo.cz
