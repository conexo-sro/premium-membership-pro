<?php
/**
 * DEBUG INFO
 * 
 * Tento soubor pomáhá diagnostikovat problémy s meta boxy
 */

// Přidej do functions.php nebo aktivuj jako plugin pro test:

add_action('admin_notices', function() {
    $screen = get_current_screen();
    
    if (!$screen || !in_array($screen->post_type, ['post', 'page'])) {
        return;
    }
    
    echo '<div class="notice notice-info">';
    echo '<h3>🔍 PMP Debug Info</h3>';
    echo '<p><strong>Current Screen:</strong> ' . $screen->id . '</p>';
    echo '<p><strong>Post Type:</strong> ' . $screen->post_type . '</p>';
    
    // Check if PMP classes exist
    echo '<h4>Classes loaded:</h4>';
    echo '<ul>';
    echo '<li>PMP_Meta_Boxes: ' . (class_exists('PMP_Meta_Boxes') ? '✅ YES' : '❌ NO') . '</li>';
    echo '<li>PMP_Content_Lock: ' . (class_exists('PMP_Content_Lock') ? '✅ YES' : '❌ NO') . '</li>';
    echo '<li>PMP_Membership_Assignment: ' . (class_exists('PMP_Membership_Assignment') ? '✅ YES' : '❌ NO') . '</li>';
    echo '<li>PMP_Post_Level_Column: ' . (class_exists('PMP_Post_Level_Column') ? '✅ YES' : '❌ NO') . '</li>';
    echo '</ul>';
    
    // Check if hooks are registered
    echo '<h4>Hooks registered:</h4>';
    global $wp_filter;
    echo '<ul>';
    
    if (isset($wp_filter['add_meta_boxes'])) {
        echo '<li>add_meta_boxes hook: ✅ EXISTS (' . count($wp_filter['add_meta_boxes']->callbacks) . ' callbacks)</li>';
        
        // List all callbacks
        foreach ($wp_filter['add_meta_boxes']->callbacks as $priority => $callbacks) {
            foreach ($callbacks as $callback) {
                if (is_array($callback['function'])) {
                    $class = is_string($callback['function'][0]) ? $callback['function'][0] : get_class($callback['function'][0]);
                    $method = $callback['function'][1];
                    echo '<li style="margin-left: 20px;">Priority ' . $priority . ': ' . $class . '::' . $method . '</li>';
                }
            }
        }
    } else {
        echo '<li>add_meta_boxes hook: ❌ NOT FOUND</li>';
    }
    echo '</ul>';
    
    // Check meta boxes
    global $wp_meta_boxes;
    echo '<h4>Registered meta boxes for ' . $screen->post_type . ':</h4>';
    
    if (isset($wp_meta_boxes[$screen->post_type])) {
        echo '<pre style="background: #f5f5f5; padding: 10px; overflow: auto; max-height: 300px;">';
        print_r($wp_meta_boxes[$screen->post_type]);
        echo '</pre>';
    } else {
        echo '<p>❌ No meta boxes found for ' . $screen->post_type . '</p>';
    }
    
    echo '</div>';
});
