# Deployment Guide - Premium Membership Pro

Návod jak připravit a nasadit plugin na GitHub.

## 🚀 Příprava pro GitHub

### 1. Inicializace Git repository

```bash
cd premium-membership-pro
git init
git add .
git commit -m "Initial commit - Premium Membership Pro v1.1.0"
```

### 2. Vytvoření GitHub repository

1. Jděte na https://github.com/new
2. Název: `premium-membership-pro`
3. Popis: `Kompletní WordPress plugin pro správu členství a prémiový obsah`
4. Public/Private: Vyberte podle preference
5. Klikněte "Create repository"

### 3. Push na GitHub

```bash
git remote add origin https://github.com/VASE_JMENO/premium-membership-pro.git
git branch -M main
git push -u origin main
```

## 📦 Vytvoření Release

### 1. Aktualizace verze

Před vytvořením release zkontrolujte verze v:
- `premium-membership-pro.php` (Plugin Version)
- `package.json` (version)
- `composer.json` (pokud používáte)
- `CHANGELOG.md` (přidejte změny)

### 2. Git Tag

```bash
git tag -a v1.1.0 -m "Release v1.1.0 - Rozostřené náhledy článků"
git push origin v1.1.0
```

### 3. GitHub Release

1. Jděte na: `https://github.com/VASE_JMENO/premium-membership-pro/releases/new`
2. Vyberte tag: `v1.1.0`
3. Název release: `v1.1.0 - Profesionální náhledy`
4. Popis: Zkopírujte z CHANGELOG.md
5. Nahrát ZIP soubor pluginu
6. Klikněte "Publish release"

### 4. Automatické vytvoření ZIP

Použijte GitHub Actions nebo manuálně:

```bash
npm run zip
# nebo
zip -r premium-membership-pro-v1.1.0.zip . \
  -x '*.git*' \
  -x '*node_modules/*' \
  -x '*.DS_Store' \
  -x '*package*.json' \
  -x '*composer.*'
```

## 🌳 Správa větví

### Main branch
- Stabilní produkční verze
- Pouze hotové features
- Všechny commity musí být otestované

### Develop branch

```bash
git checkout -b develop
git push origin develop
```

- Vývojová verze
- Nové features se vyvíjejí zde
- Testování před merge do main

### Feature branches

```bash
git checkout -b feature/nova-funkce
# ... práce ...
git commit -m "feat: Přidána nová funkce"
git push origin feature/nova-funkce
# Otevřít Pull Request na develop
```

## 📝 Konvence pojmenování

### Branches
- `main` - produkční verze
- `develop` - vývojová verze
- `feature/nazev` - nové funkce
- `fix/nazev` - opravy chyb
- `hotfix/nazev` - urgentní opravy
- `docs/nazev` - dokumentace

### Commits
```
feat: Nová funkce
fix: Oprava chyby
docs: Dokumentace
style: Formátování
refactor: Refaktoring
test: Testy
chore: Údržba
```

### Tags
- `v1.0.0` - Major release
- `v1.1.0` - Minor release (nové funkce)
- `v1.1.1` - Patch release (bugfixy)

## 🔄 Workflow pro novou verzi

### 1. Vývoj
```bash
git checkout develop
git checkout -b feature/nova-funkce
# ... práce ...
git commit -m "feat: Přidána funkce X"
git push origin feature/nova-funkce
# Pull Request do develop
```

### 2. Testování
```bash
git checkout develop
# Testování, bugfixy...
```

### 3. Release
```bash
# Aktualizace CHANGELOG.md
git checkout main
git merge develop
git tag -a v1.2.0 -m "Release v1.2.0"
git push origin main
git push origin v1.2.0
```

### 4. Publish na GitHub
1. Vytvořte release z tagu
2. Napište release notes
3. Nahrajte ZIP soubor
4. Publikujte

## 🏷️ Verzování (Semantic Versioning)

```
v1.2.3
│ │ │
│ │ └─ PATCH - Opravy chyb (kompatibilní)
│ └─── MINOR - Nové funkce (kompatibilní)
└───── MAJOR - Breaking changes (nekompatibilní)
```

### Kdy zvýšit verzi:

**MAJOR (1.0.0 → 2.0.0)**
- Nekompatibilní změny API
- Odstranění funkcí
- Změny v databázi

**MINOR (1.0.0 → 1.1.0)**
- Nové funkce
- Vylepšení
- Zpětně kompatibilní

**PATCH (1.0.0 → 1.0.1)**
- Bugfixy
- Bezpečnostní záplaty
- Drobné úpravy

## 📊 GitHub Pages (volitelné)

Pro dokumentaci můžete použít GitHub Pages:

```bash
# Vytvořit gh-pages branch
git checkout --orphan gh-pages
git rm -rf .
echo "<h1>Premium Membership Pro</h1>" > index.html
git add index.html
git commit -m "Initial GitHub Pages"
git push origin gh-pages
```

Pak v Settings → Pages → Source → gh-pages

## 🔒 Zabezpečení

### Secrets v GitHub

Pro CI/CD přidejte secrets:
1. Settings → Secrets → Actions
2. Přidat: `WORDPRESS_USERNAME`, `WORDPRESS_PASSWORD`

### .gitignore

Ujistěte se, že `.gitignore` obsahuje:
```
node_modules/
vendor/
*.log
.DS_Store
.env
composer.lock
package-lock.json
```

## ✅ Checklist před release

- [ ] Aktualizována verze v `premium-membership-pro.php`
- [ ] Aktualizován `CHANGELOG.md`
- [ ] Aktualizován `README.md`
- [ ] Otestováno na čisté instalaci WP
- [ ] Zkontrolována kompatibilita s PHP 7.4+
- [ ] Zkontrolována kompatibilita s WP 5.0+
- [ ] Všechny testy prošly
- [ ] Dokumentace je aktuální
- [ ] ZIP soubor je vytvořen
- [ ] Git tag je vytvořen
- [ ] GitHub release je publikován

## 🎉 Po publikování

1. Oznámit na sociálních sítích
2. Aktualizovat WordPress.org (pokud tam je)
3. Informovat uživatele emailem
4. Přidat do changelog na webu
5. Aktualizovat dokumentaci

## 📞 Další zdroje

- [GitHub Flow](https://guides.github.com/introduction/flow/)
- [Semantic Versioning](https://semver.org/)
- [Keep a Changelog](https://keepachangelog.com/)
- [Git Branching Model](https://nvie.com/posts/a-successful-git-branching-model/)
