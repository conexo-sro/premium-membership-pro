<?php
/**
 * User Management Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_User_Management {
    
    public static function init() {
        add_action('show_user_profile', array(__CLASS__, 'add_user_membership_fields'));
        add_action('edit_user_profile', array(__CLASS__, 'add_user_membership_fields'));
        add_action('personal_options_update', array(__CLASS__, 'save_user_membership_fields'));
        add_action('edit_user_profile_update', array(__CLASS__, 'save_user_membership_fields'));
        
        // CRITICAL: Automatically assign membership to new users
        add_action('user_register', array(__CLASS__, 'auto_assign_membership_to_new_user'), 10, 1);
    }
    
    /**
     * Automatically assign default membership to new users
     * Runs when a new user registers
     */
    public static function auto_assign_membership_to_new_user($user_id) {
        global $wpdb;
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("=== PMP AUTO-ASSIGN MEMBERSHIP ===");
            error_log("PMP: New user registered: user_id={$user_id}");
        }
        
        // Get default membership level (first active level, or create one if none exists)
        $default_level = $wpdb->get_row(
            "SELECT * FROM {$wpdb->prefix}pmp_membership_levels 
            WHERE status = 'active' 
            ORDER BY sort_order ASC, id ASC 
            LIMIT 1"
        );
        
        if (!$default_level) {
            // No levels exist - create a default "Registered" level
            $wpdb->insert(
                $wpdb->prefix . 'pmp_membership_levels',
                array(
                    'name' => 'Registrovaný',
                    'description' => 'Výchozí úroveň pro nové uživatele',
                    'price' => 0.00,
                    'billing_period' => 'lifetime',
                    'trial_period' => 0,
                    'status' => 'active',
                    'sort_order' => 0
                ),
                array('%s', '%s', '%f', '%s', '%d', '%s', '%d')
            );
            
            $default_level_id = $wpdb->insert_id;
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP: Created default level 'Registrovaný' with ID={$default_level_id}");
            }
        } else {
            $default_level_id = $default_level->id;
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP: Using existing default level: {$default_level->name} (ID={$default_level_id})");
            }
        }
        
        // Check if user already has a membership (shouldn't happen, but just in case)
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}pmp_memberships WHERE user_id = %d",
            $user_id
        ));
        
        if ($existing) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP: User already has membership - skipping");
            }
            return;
        }
        
        // Insert new membership
        $result = $wpdb->insert(
            $wpdb->prefix . 'pmp_memberships',
            array(
                'user_id' => $user_id,
                'level_id' => $default_level_id,
                'status' => 'active',
                'start_date' => current_time('mysql'),
                'created_at' => current_time('mysql')
            ),
            array('%d', '%d', '%s', '%s', '%s')
        );
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            if ($result) {
                error_log("PMP: ✅ SUCCESS - Membership assigned (membership_id={$wpdb->insert_id})");
                
                // Verify
                $verify = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM {$wpdb->prefix}pmp_memberships WHERE user_id = %d",
                    $user_id
                ));
                error_log("PMP: Verification: " . var_export($verify, true));
            } else {
                error_log("PMP: ❌ FAILED - Could not insert membership");
                if ($wpdb->last_error) {
                    error_log("PMP: SQL ERROR: " . $wpdb->last_error);
                }
            }
            error_log("=== PMP AUTO-ASSIGN END ===");
        }
    }
    
    public static function get_user_membership($user_id) {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}pmp_memberships 
            WHERE user_id = %d 
            AND status = 'active' 
            ORDER BY created_at DESC 
            LIMIT 1",
            $user_id
        ));
    }
    
    public static function user_has_active_membership($user_id) {
        $membership = self::get_user_membership($user_id);
        return !empty($membership);
    }
    
    public static function get_membership_status($user_id) {
        $membership = self::get_user_membership($user_id);
        
        if (!$membership) {
            return 'none';
        }
        
        // Check if in trial period
        if ($membership->trial_end_date && strtotime($membership->trial_end_date) > time()) {
            return 'trial';
        }
        
        return $membership->status;
    }
    
    public static function add_user_membership_fields($user) {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        $membership = self::get_user_membership($user->ID);
        $all_memberships = PMP_Subscriptions::get_user_subscriptions($user->ID);
        ?>
        <h2><?php _e('Členství Premium Membership Pro', 'premium-membership-pro'); ?></h2>
        
        <table class="form-table">
            <tr>
                <th><?php _e('Aktuální členství', 'premium-membership-pro'); ?></th>
                <td>
                    <?php if ($membership): 
                        $level = get_post($membership->level_id);
                        ?>
                        <p>
                            <strong><?php echo esc_html($level->post_title); ?></strong><br>
                            Status: <span class="pmp-status-<?php echo esc_attr($membership->status); ?>"><?php echo esc_html($membership->status); ?></span><br>
                            Od: <?php echo date_i18n(get_option('date_format'), strtotime($membership->start_date)); ?><br>
                            <?php if ($membership->end_date): ?>
                                Do: <?php echo date_i18n(get_option('date_format'), strtotime($membership->end_date)); ?><br>
                            <?php endif; ?>
                            <?php if ($membership->trial_end_date && strtotime($membership->trial_end_date) > time()): ?>
                                <em>Zkušební období do: <?php echo date_i18n(get_option('date_format'), strtotime($membership->trial_end_date)); ?></em><br>
                            <?php endif; ?>
                        </p>
                        <p>
                            <a href="#" class="button pmp-cancel-membership" data-subscription-id="<?php echo $membership->id; ?>"><?php _e('Zrušit členství', 'premium-membership-pro'); ?></a>
                        </p>
                    <?php else: ?>
                        <p><?php _e('Žádné aktivní členství', 'premium-membership-pro'); ?></p>
                    <?php endif; ?>
                </td>
            </tr>
            
            <?php if (!empty($all_memberships)): ?>
            <tr>
                <th><?php _e('Historie členství', 'premium-membership-pro'); ?></th>
                <td>
                    <table class="widefat">
                        <thead>
                            <tr>
                                <th><?php _e('Úroveň', 'premium-membership-pro'); ?></th>
                                <th><?php _e('Status', 'premium-membership-pro'); ?></th>
                                <th><?php _e('Období', 'premium-membership-pro'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($all_memberships as $sub): 
                                $level = get_post($sub->level_id);
                                ?>
                                <tr>
                                    <td><?php echo esc_html($level->post_title); ?></td>
                                    <td><span class="pmp-status-<?php echo esc_attr($sub->status); ?>"><?php echo esc_html($sub->status); ?></span></td>
                                    <td>
                                        <?php echo date_i18n(get_option('date_format'), strtotime($sub->start_date)); ?>
                                        <?php if ($sub->end_date): ?>
                                            - <?php echo date_i18n(get_option('date_format'), strtotime($sub->end_date)); ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </td>
            </tr>
            <?php endif; ?>
            
            <tr>
                <th><label for="pmp_assign_membership"><?php _e('Přiřadit nové členství', 'premium-membership-pro'); ?></label></th>
                <td>
                    <select name="pmp_assign_membership" id="pmp_assign_membership">
                        <option value=""><?php _e('-- Vyberte úroveň --', 'premium-membership-pro'); ?></option>
                        <?php
                        $levels = PMP_Membership_Levels::get_all_levels();
                        foreach ($levels as $level) {
                            echo '<option value="' . $level['id'] . '">' . esc_html($level['name']) . '</option>';
                        }
                        ?>
                    </select>
                    <p class="description"><?php _e('Manuálně přiřaďte členství tomuto uživateli', 'premium-membership-pro'); ?></p>
                </td>
            </tr>
        </table>
        <?php
    }
    
    public static function save_user_membership_fields($user_id) {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        if (isset($_POST['pmp_assign_membership']) && !empty($_POST['pmp_assign_membership'])) {
            $level_id = intval($_POST['pmp_assign_membership']);
            
            // Cancel any existing active membership
            $current = self::get_user_membership($user_id);
            if ($current) {
                PMP_Subscriptions::cancel_subscription($current->id, 'Manual assignment by admin');
            }
            
            // Create new subscription
            PMP_Subscriptions::create_subscription($user_id, $level_id, array(
                'gateway' => 'manual',
                'subscription_id' => 'manual_' . time(),
            ));
        }
    }
    
    public static function get_user_access_count($user_id, $period = 'month') {
        global $wpdb;
        
        $date_format = '%Y-%m';
        if ($period === 'day') {
            $date_format = '%Y-%m-%d';
        } elseif ($period === 'year') {
            $date_format = '%Y';
        }
        
        return $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT post_id) 
            FROM {$wpdb->prefix}pmp_access_logs 
            WHERE user_id = %d 
            AND DATE_FORMAT(accessed_at, %s) = DATE_FORMAT(NOW(), %s)
            AND access_type = 'granted'",
            $user_id,
            $date_format,
            $date_format
        ));
    }
    
    public static function can_access_more_content($user_id) {
        $membership = self::get_user_membership($user_id);
        if (!$membership) {
            return false;
        }
        
        $limit_access = get_post_meta($membership->level_id, '_pmp_limit_access', true);
        if (!$limit_access) {
            return true;
        }
        
        $max_content = intval(get_post_meta($membership->level_id, '_pmp_max_content', true));
        if ($max_content === 0) {
            return true;
        }
        
        $current_count = self::get_user_access_count($user_id, 'month');
        
        return $current_count < $max_content;
    }
}
