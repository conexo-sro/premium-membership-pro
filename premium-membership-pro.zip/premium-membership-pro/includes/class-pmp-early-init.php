<?php
/**
 * Early initialization - MUST run before any posts are created
 * Forces _pmp_protected to be set on ALL posts
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Early_Init {
    
    /**
     * Initialize early hooks
     * This runs on 'plugins_loaded' with priority 1 (very early)
     */
    public static function init() {
        // CRITICAL: Hook into wp_insert_post_data to modify post data BEFORE it's saved
        add_filter('wp_insert_post_data', array(__CLASS__, 'force_protection_on_insert'), 99999, 2);
        
        // CRITICAL: Hook into AJAX handler for inline editor
        add_action('wp_ajax_pmp_save_inline_level', array(__CLASS__, 'intercept_inline_save'), 1);
        
        // CRITICAL: After ANY post is inserted, force check
        add_action('wp_insert_post', array(__CLASS__, 'force_check_after_insert'), 99999, 3);
        
        // CRITICAL: After ANY meta is updated, check if it's _pmp_required_levels
        add_action('updated_post_meta', array(__CLASS__, 'force_check_after_meta_update'), 99999, 4);
        add_action('added_post_meta', array(__CLASS__, 'force_check_after_meta_update'), 99999, 4);
    }
    
    /**
     * Force protection metadata when post is inserted
     */
    public static function force_protection_on_insert($data, $postarr) {
        // Only for posts and pages
        if (!in_array($data['post_type'], array('post', 'page'))) {
            return $data;
        }
        
        // Get post ID if updating
        $post_id = isset($postarr['ID']) ? $postarr['ID'] : 0;
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("=== PMP EARLY INIT: wp_insert_post_data ===");
            error_log("PMP: Post ID: {$post_id}");
            error_log("PMP: Post type: {$data['post_type']}");
            error_log("PMP: Post status: {$data['post_status']}");
        }
        
        return $data;
    }
    
    /**
     * Force check and fix _pmp_protected immediately after post is inserted
     */
    public static function force_check_after_insert($post_id, $post, $update) {
        // Only for posts and pages
        if (!in_array($post->post_type, array('post', 'page'))) {
            return;
        }
        
        // Skip autosave and revisions
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        if (wp_is_post_revision($post_id)) {
            return;
        }
        
        global $wpdb;
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("=== PMP EARLY INIT: wp_insert_post (priority 99999) ===");
            error_log("PMP: Post ID: {$post_id}");
            error_log("PMP: Is update: " . ($update ? 'YES' : 'NO'));
        }
        
        // Check current value
        $current = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_pmp_protected'",
            $post_id
        ));
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("PMP: Current _pmp_protected: " . var_export($current, true));
        }
        
        // If empty, force set to '1'
        if ($current === null || $current === '') {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP: FORCING _pmp_protected = '1' via direct SQL");
            }
            
            // Use REPLACE INTO for guaranteed insert
            $replace_sql = "REPLACE INTO {$wpdb->postmeta} (post_id, meta_key, meta_value) VALUES ({$post_id}, '_pmp_protected', '1')";
            $result = $wpdb->query($replace_sql);
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP: REPLACE result: {$result}");
                if ($wpdb->last_error) {
                    error_log("PMP: SQL ERROR: {$wpdb->last_error}");
                }
                
                // Verify
                $verify = $wpdb->get_var($wpdb->prepare(
                    "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_pmp_protected'",
                    $post_id
                ));
                error_log("PMP: Verification: " . var_export($verify, true));
            }
        }
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("=== PMP EARLY INIT END ===");
        }
    }
    
    /**
     * When _pmp_required_levels is updated, ensure _pmp_protected is also set
     */
    public static function force_check_after_meta_update($meta_id, $post_id, $meta_key, $meta_value) {
        // Only care about _pmp_required_levels
        if ($meta_key !== '_pmp_required_levels') {
            return;
        }
        
        global $wpdb;
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("=== PMP EARLY INIT: Meta updated ===");
            error_log("PMP: Post ID: {$post_id}");
            error_log("PMP: Meta key: {$meta_key}");
        }
        
        // Check _pmp_protected
        $current = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_pmp_protected'",
            $post_id
        ));
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("PMP: Current _pmp_protected: " . var_export($current, true));
        }
        
        // If _pmp_required_levels is set but _pmp_protected is empty, fix it!
        if (!empty($meta_value) && ($current === null || $current === '')) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP: _pmp_required_levels is set but _pmp_protected is empty - FORCING FIX!");
            }
            
            // Force set
            $replace_sql = "REPLACE INTO {$wpdb->postmeta} (post_id, meta_key, meta_value) VALUES ({$post_id}, '_pmp_protected', '1')";
            $result = $wpdb->query($replace_sql);
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP: REPLACE result: {$result}");
                
                $verify = $wpdb->get_var($wpdb->prepare(
                    "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_pmp_protected'",
                    $post_id
                ));
                error_log("PMP: Verification: " . var_export($verify, true));
            }
        }
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("=== PMP EARLY INIT META END ===");
        }
    }
    
    /**
     * Intercept inline save AJAX to ensure immediate processing
     */
    public static function intercept_inline_save() {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("=== PMP EARLY INIT: Intercepting inline save ===");
            error_log("PMP: POST data: " . print_r($_POST, true));
        }
        
        // Don't actually handle it here, just log and let the regular handler work
        // But register the post ID for checking
        if (isset($_POST['post_id'])) {
            $post_id = intval($_POST['post_id']);
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP: Will check post {$post_id} after inline save");
            }
        }
    }
}
