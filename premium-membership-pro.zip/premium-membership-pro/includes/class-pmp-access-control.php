<?php
/**
 * Access Control Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Access_Control {
    
    public static function init() {
        add_action('template_redirect', array(__CLASS__, 'check_content_access'));
        add_filter('the_content', array(__CLASS__, 'filter_protected_content'));
        add_action('add_meta_boxes', array(__CLASS__, 'add_protection_meta_box'));
        add_action('save_post', array(__CLASS__, 'save_protection_meta'));
    }
    
    public static function check_content_access() {
        if (!is_singular()) {
            return;
        }
        
        global $post;
        
        if (!self::user_can_access($post->ID)) {
            $redirect_url = get_option('pmp_login_redirect', wp_login_url());
            wp_redirect($redirect_url);
            exit;
        }
    }
    
    public static function user_can_access($post_id, $user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        // Admin can access everything
        if (current_user_can('manage_options')) {
            return true;
        }
        
        // Check if content is protected
        $is_protected = get_post_meta($post_id, '_pmp_protected', true);
        if (!$is_protected) {
            return true;
        }
        
        // Check if user is logged in
        if (!$user_id) {
            return false;
        }
        
        // Get required membership levels
        $required_levels = get_post_meta($post_id, '_pmp_required_levels', true);
        if (empty($required_levels)) {
            return true;
        }
        
        // Get user's active membership
        $user_membership = PMP_User_Management::get_user_membership($user_id);
        if (!$user_membership) {
            return false;
        }
        
        // Check if user's membership level is in required levels
        if (in_array($user_membership->level_id, (array)$required_levels)) {
            // Additional check: verify access through groups/categories
            if (self::check_group_access($post_id, $user_membership->level_id)) {
                self::log_access($user_id, $post_id, $user_membership->level_id, 'granted');
                return true;
            }
        }
        
        // Log denied access
        self::log_access($user_id, $post_id, $user_membership->level_id, 'denied');
        return false;
    }
    
    private static function check_group_access($post_id, $level_id) {
        $access_type = get_post_meta($level_id, '_pmp_access_type', true);
        
        // If access type is 'all', always allow
        if ($access_type === 'all' || empty($access_type)) {
            return true;
        }
        
        // Check content groups
        if ($access_type === 'groups' || $access_type === 'mixed') {
            $allowed_groups = get_post_meta($level_id, '_pmp_allowed_groups', true);
            if (!empty($allowed_groups)) {
                $post_groups = wp_get_post_terms($post_id, 'pmp_content_group', array('fields' => 'ids'));
                if (!empty($post_groups)) {
                    $has_access = !empty(array_intersect($allowed_groups, $post_groups));
                    if ($has_access) {
                        return true;
                    }
                    // If only checking groups and no match, deny
                    if ($access_type === 'groups') {
                        return false;
                    }
                }
            }
        }
        
        // Check categories
        if ($access_type === 'categories' || $access_type === 'mixed') {
            $allowed_categories = get_post_meta($level_id, '_pmp_allowed_categories', true);
            if (!empty($allowed_categories)) {
                $post_categories = wp_get_post_categories($post_id);
                if (!empty($post_categories)) {
                    $has_access = !empty(array_intersect($allowed_categories, $post_categories));
                    if ($has_access) {
                        return true;
                    }
                    // If only checking categories and no match, deny
                    if ($access_type === 'categories') {
                        return false;
                    }
                }
            }
        }
        
        // For mixed type, if we got here and nothing matched, deny
        if ($access_type === 'mixed' || $access_type === 'groups' || $access_type === 'categories') {
            return false;
        }
        
        // Default allow
        return true;
    }
    
    public static function filter_protected_content($content) {
        if (!is_singular() || !in_the_loop() || !is_main_query()) {
            return $content;
        }
        
        global $post;
        
        $is_protected = get_post_meta($post->ID, '_pmp_protected', true);
        if (!$is_protected) {
            return $content;
        }
        
        if (self::user_can_access($post->ID)) {
            return $content;
        }
        
        // Get preview settings
        $preview_type = get_post_meta($post->ID, '_pmp_preview_type', true) ?: 'blur';
        $preview_length = get_post_meta($post->ID, '_pmp_preview_length', true) ?: '30';
        
        // Generate preview content based on type
        if ($preview_type === 'blur') {
            return self::generate_blurred_preview($content, $post->ID, $preview_length);
        } elseif ($preview_type === 'teaser') {
            return self::generate_teaser_preview($content, $post->ID, $preview_length);
        } else {
            return self::generate_locked_preview($post->ID);
        }
    }
    
    private static function generate_blurred_preview($content, $post_id, $preview_percentage) {
        $required_levels = get_post_meta($post_id, '_pmp_required_levels', true);
        $levels_list = self::get_levels_list($required_levels);
        
        // Split content into paragraphs
        $paragraphs = array_filter(explode('</p>', $content));
        $total_paragraphs = count($paragraphs);
        $preview_paragraphs = max(1, round($total_paragraphs * ($preview_percentage / 100)));
        
        // Free content
        $free_content = '';
        for ($i = 0; $i < $preview_paragraphs && $i < $total_paragraphs; $i++) {
            $free_content .= $paragraphs[$i] . '</p>';
        }
        
        // Blurred content
        $blurred_content = '';
        for ($i = $preview_paragraphs; $i < $total_paragraphs; $i++) {
            $blurred_content .= $paragraphs[$i] . '</p>';
        }
        
        $output = '<div class="pmp-protected-content pmp-blur-preview">';
        $output .= '<div class="pmp-free-content">' . $free_content . '</div>';
        
        if (!empty($blurred_content)) {
            $output .= '<div class="pmp-blurred-wrapper">';
            $output .= '<div class="pmp-blurred-content">' . $blurred_content . '</div>';
            $output .= '<div class="pmp-blur-overlay">';
            $output .= '<div class="pmp-unlock-message">';
            $output .= '<div class="pmp-lock-icon">🔒</div>';
            $output .= '<h3>' . __('Odemkněte zbytek článku', 'premium-membership-pro') . '</h3>';
            $output .= '<p>' . __('Pro pokračování ve čtení si aktivujte členství:', 'premium-membership-pro') . '</p>';
            
            if ($levels_list) {
                $output .= '<div class="pmp-pricing-options">' . $levels_list . '</div>';
            }
            
            if (is_user_logged_in()) {
                $pricing_page = get_option('pmp_pricing_page');
                if ($pricing_page) {
                    $output .= '<a href="' . get_permalink($pricing_page) . '" class="pmp-unlock-button">' . __('Vybrat členství', 'premium-membership-pro') . '</a>';
                }
            } else {
                $output .= '<a href="' . wp_login_url(get_permalink()) . '" class="pmp-unlock-button pmp-primary">' . __('Přihlásit se', 'premium-membership-pro') . '</a>';
                $output .= '<a href="' . wp_registration_url() . '" class="pmp-unlock-button pmp-secondary">' . __('Registrovat se', 'premium-membership-pro') . '</a>';
            }
            
            $output .= '</div></div></div>';
        }
        
        $output .= '</div>';
        
        return $output;
    }
    
    private static function generate_teaser_preview($content, $post_id, $word_count) {
        $required_levels = get_post_meta($post_id, '_pmp_required_levels', true);
        $levels_list = self::get_levels_list($required_levels);
        
        // Custom teaser or auto-generated
        $teaser_content = get_post_meta($post_id, '_pmp_teaser_content', true);
        if (empty($teaser_content)) {
            $teaser_content = wp_trim_words($content, intval($word_count));
        }
        
        $output = '<div class="pmp-protected-content pmp-teaser-preview">';
        $output .= '<div class="pmp-teaser-content">' . wpautop($teaser_content) . '</div>';
        $output .= '<div class="pmp-teaser-fade"></div>';
        $output .= '<div class="pmp-access-message">';
        $output .= '<div class="pmp-lock-icon">🔒</div>';
        $output .= '<h3>' . __('Pokračujte ve čtení s členstvím', 'premium-membership-pro') . '</h3>';
        $output .= '<p>' . __('Získejte neomezený přístup k tomuto a dalšímu prémiovému obsahu:', 'premium-membership-pro') . '</p>';
        
        if ($levels_list) {
            $output .= '<div class="pmp-pricing-options">' . $levels_list . '</div>';
        }
        
        if (is_user_logged_in()) {
            $pricing_page = get_option('pmp_pricing_page');
            if ($pricing_page) {
                $output .= '<a href="' . get_permalink($pricing_page) . '" class="button pmp-upgrade-button">' . __('Upgradovat členství', 'premium-membership-pro') . '</a>';
            }
        } else {
            $output .= '<a href="' . wp_login_url(get_permalink()) . '" class="button pmp-login-button">' . __('Přihlásit se', 'premium-membership-pro') . '</a>';
            $output .= ' <a href="' . wp_registration_url() . '" class="button pmp-register-button">' . __('Registrovat se', 'premium-membership-pro') . '</a>';
        }
        
        $output .= '</div></div>';
        
        return $output;
    }
    
    private static function generate_locked_preview($post_id) {
        $required_levels = get_post_meta($post_id, '_pmp_required_levels', true);
        $levels_list = self::get_levels_list($required_levels);
        
        $output = '<div class="pmp-protected-content pmp-locked-preview">';
        $output .= '<div class="pmp-lock-container">';
        $output .= '<div class="pmp-lock-icon-large">🔒</div>';
        $output .= '<h2>' . __('Tento obsah je uzamčen', 'premium-membership-pro') . '</h2>';
        $output .= '<p>' . __('Pro zobrazení tohoto obsahu potřebujete aktivní členství:', 'premium-membership-pro') . '</p>';
        
        if ($levels_list) {
            $output .= '<div class="pmp-pricing-options">' . $levels_list . '</div>';
        }
        
        if (is_user_logged_in()) {
            $pricing_page = get_option('pmp_pricing_page');
            if ($pricing_page) {
                $output .= '<a href="' . get_permalink($pricing_page) . '" class="button pmp-upgrade-button">' . __('Získat přístup', 'premium-membership-pro') . '</a>';
            }
        } else {
            $output .= '<a href="' . wp_login_url(get_permalink()) . '" class="button pmp-login-button">' . __('Přihlásit se', 'premium-membership-pro') . '</a>';
            $output .= ' <a href="' . wp_registration_url() . '" class="button pmp-register-button">' . __('Vytvořit účet', 'premium-membership-pro') . '</a>';
        }
        
        $output .= '</div></div>';
        
        return $output;
    }
    
    private static function get_levels_list($required_levels) {
        if (empty($required_levels)) {
            return '';
        }
        
        $output = '<div class="pmp-required-levels-grid">';
        
        foreach ($required_levels as $level_id) {
            $level = get_post($level_id);
            if ($level) {
                $price = get_post_meta($level_id, '_pmp_price', true);
                $billing_type = get_post_meta($level_id, '_pmp_billing_type', true);
                $period = get_post_meta($level_id, '_pmp_period', true);
                
                $output .= '<div class="pmp-level-option">';
                $output .= '<div class="pmp-level-name">' . esc_html($level->post_title) . '</div>';
                $output .= '<div class="pmp-level-price">' . pmp_format_price($price);
                
                if ($billing_type === 'recurring') {
                    $output .= '<span class="pmp-period">/' . esc_html($period) . '</span>';
                }
                
                $output .= '</div></div>';
            }
        }
        
        $output .= '</div>';
        
        return $output;
    }
    
    public static function add_protection_meta_box() {
        $post_types = get_post_types(array('public' => true), 'names');
        
        foreach ($post_types as $post_type) {
            add_meta_box(
                'pmp_content_protection',
                __('Ochrana obsahu', 'premium-membership-pro'),
                array(__CLASS__, 'render_protection_meta_box'),
                $post_type,
                'side',
                'high'
            );
        }
    }
    
    public static function render_protection_meta_box($post) {
        wp_nonce_field('pmp_protection_meta', 'pmp_protection_nonce');
        
        $is_protected = get_post_meta($post->ID, '_pmp_protected', true);
        $required_levels = get_post_meta($post->ID, '_pmp_required_levels', true) ?: array();
        $preview_type = get_post_meta($post->ID, '_pmp_preview_type', true) ?: 'blur';
        $preview_length = get_post_meta($post->ID, '_pmp_preview_length', true) ?: '30';
        $teaser_content = get_post_meta($post->ID, '_pmp_teaser_content', true);
        
        ?>
        <p>
            <label>
                <input type="checkbox" name="pmp_protected" value="1" <?php checked($is_protected, '1'); ?>>
                <strong><?php _e('Chránit tento obsah', 'premium-membership-pro'); ?></strong>
            </label>
        </p>
        
        <div id="pmp-protection-options" style="<?php echo $is_protected ? '' : 'display:none;'; ?>">
            <p><strong><?php _e('Požadované úrovně členství:', 'premium-membership-pro'); ?></strong></p>
            <?php
            $levels = PMP_Membership_Levels::get_all_levels();
            foreach ($levels as $level) {
                $checked = in_array($level['id'], $required_levels);
                echo '<label style="display: block; margin: 5px 0;">';
                echo '<input type="checkbox" name="pmp_required_levels[]" value="' . $level['id'] . '" ' . checked($checked, true, false) . '>';
                echo ' ' . esc_html($level['name']);
                echo '</label>';
            }
            ?>
            
            <hr style="margin: 20px 0;">
            
            <p><strong><?php _e('Typ náhledu pro nečleny:', 'premium-membership-pro'); ?></strong></p>
            <p>
                <label style="display: block; margin: 10px 0;">
                    <input type="radio" name="pmp_preview_type" value="blur" <?php checked($preview_type, 'blur'); ?>>
                    <strong><?php _e('Rozostřený obsah', 'premium-membership-pro'); ?></strong> - 
                    <span class="description"><?php _e('Zobrazí část obsahu čitelně, zbytek rozostřený s overlay', 'premium-membership-pro'); ?></span>
                </label>
                <label style="display: block; margin: 10px 0;">
                    <input type="radio" name="pmp_preview_type" value="teaser" <?php checked($preview_type, 'teaser'); ?>>
                    <strong><?php _e('Textový náhled', 'premium-membership-pro'); ?></strong> - 
                    <span class="description"><?php _e('Zobrazí jen začátek textu s fade efektem', 'premium-membership-pro'); ?></span>
                </label>
                <label style="display: block; margin: 10px 0;">
                    <input type="radio" name="pmp_preview_type" value="locked" <?php checked($preview_type, 'locked'); ?>>
                    <strong><?php _e('Úplně uzamčeno', 'premium-membership-pro'); ?></strong> - 
                    <span class="description"><?php _e('Nezobrazí žádný obsah, jen ikonu zámku', 'premium-membership-pro'); ?></span>
                </label>
            </p>
            
            <div id="pmp-preview-length-options" style="margin-top: 15px;">
                <p>
                    <label for="pmp_preview_length">
                        <strong><?php _e('Kolik obsahu zobrazit zdarma:', 'premium-membership-pro'); ?></strong>
                    </label>
                    <select name="pmp_preview_length" id="pmp_preview_length" style="width: 100%;">
                        <option value="10" <?php selected($preview_length, '10'); ?>><?php _e('10% - Velmi málo (1-2 odstavce)', 'premium-membership-pro'); ?></option>
                        <option value="20" <?php selected($preview_length, '20'); ?>><?php _e('20% - Málo', 'premium-membership-pro'); ?></option>
                        <option value="30" <?php selected($preview_length, '30'); ?>><?php _e('30% - Střední (doporučeno)', 'premium-membership-pro'); ?></option>
                        <option value="40" <?php selected($preview_length, '40'); ?>><?php _e('40% - Více', 'premium-membership-pro'); ?></option>
                        <option value="50" <?php selected($preview_length, '50'); ?>><?php _e('50% - Polovina článku', 'premium-membership-pro'); ?></option>
                        <option value="75" <?php selected($preview_length, '75'); ?>><?php _e('75% - Téměř celý článek', 'premium-membership-pro'); ?></option>
                    </select>
                    <small class="description" style="display: block; margin-top: 5px;">
                        <?php _e('Pro "Textový náhled" - počet slov, pro "Rozostřený obsah" - procento odstavců', 'premium-membership-pro'); ?>
                    </small>
                </p>
            </div>
            
            <p style="margin-top: 15px;">
                <label for="pmp_teaser_content"><strong><?php _e('Vlastní náhledový text (volitelné):', 'premium-membership-pro'); ?></strong></label>
                <textarea name="pmp_teaser_content" id="pmp_teaser_content" rows="4" style="width: 100%;"><?php echo esc_textarea($teaser_content); ?></textarea>
                <small class="description"><?php _e('Použije se místo automatického výtahu (pouze pro "Textový náhled")', 'premium-membership-pro'); ?></small>
            </p>
            
            <div class="pmp-preview-examples" style="margin-top: 20px; padding: 15px; background: #f0f0f1; border-radius: 5px;">
                <p style="margin: 0 0 10px 0;"><strong><?php _e('Ukázky náhledů:', 'premium-membership-pro'); ?></strong></p>
                <ul style="margin: 0; padding-left: 20px; font-size: 12px; line-height: 1.8;">
                    <li><strong>Rozostřený:</strong> Ideální pro dlouhé články - uživatel vidí strukturu, ale musí se přihlásit</li>
                    <li><strong>Textový:</strong> Pro novinky a blogy - zobrazí úvod a nalákne čtenáře</li>
                    <li><strong>Uzamčeno:</strong> Pro exkluzivní obsah - žádný náhled, maximální tajemno</li>
                </ul>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            $('input[name="pmp_protected"]').change(function() {
                if ($(this).is(':checked')) {
                    $('#pmp-protection-options').slideDown();
                } else {
                    $('#pmp-protection-options').slideUp();
                }
            });
            
            $('input[name="pmp_preview_type"]').change(function() {
                if ($(this).val() === 'locked') {
                    $('#pmp-preview-length-options').hide();
                } else {
                    $('#pmp-preview-length-options').show();
                }
            }).trigger('change');
        });
        </script>
        
        <style>
        #pmp-protection-options label {
            cursor: pointer;
        }
        #pmp-protection-options input[type="radio"]:checked + strong {
            color: #2271b1;
        }
        .pmp-preview-examples ul li {
            color: #555;
        }
        </style>
        <?php
    }
    
    public static function save_protection_meta($post_id) {
        if (!isset($_POST['pmp_protection_nonce']) || 
            !wp_verify_nonce($_POST['pmp_protection_nonce'], 'pmp_protection_meta')) {
            return;
        }
        
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        if (isset($_POST['pmp_protected'])) {
            update_post_meta($post_id, '_pmp_protected', '1');
        } else {
            delete_post_meta($post_id, '_pmp_protected');
        }
        
        if (isset($_POST['pmp_required_levels'])) {
            update_post_meta($post_id, '_pmp_required_levels', array_map('intval', $_POST['pmp_required_levels']));
        } else {
            delete_post_meta($post_id, '_pmp_required_levels');
        }
        
        if (isset($_POST['pmp_preview_type'])) {
            update_post_meta($post_id, '_pmp_preview_type', sanitize_text_field($_POST['pmp_preview_type']));
        }
        
        if (isset($_POST['pmp_preview_length'])) {
            update_post_meta($post_id, '_pmp_preview_length', sanitize_text_field($_POST['pmp_preview_length']));
        }
        
        if (isset($_POST['pmp_teaser_content'])) {
            update_post_meta($post_id, '_pmp_teaser_content', wp_kses_post($_POST['pmp_teaser_content']));
        }
    }
    
    public static function log_access($user_id, $post_id, $level_id, $access_type) {
        global $wpdb;
        
        $wpdb->insert(
            $wpdb->prefix . 'pmp_access_logs',
            array(
                'user_id' => $user_id,
                'post_id' => $post_id,
                'membership_level_id' => $level_id,
                'access_type' => $access_type,
                'ip_address' => $_SERVER['REMOTE_ADDR'],
                'user_agent' => $_SERVER['HTTP_USER_AGENT'],
                'accessed_at' => current_time('mysql'),
            ),
            array('%d', '%d', '%d', '%s', '%s', '%s', '%s')
        );
    }
}
