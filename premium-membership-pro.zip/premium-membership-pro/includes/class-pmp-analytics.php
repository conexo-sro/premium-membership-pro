<?php
/**
 * Analytics Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Analytics {
    
    public static function init() {
        // Analytics hooks
    }
    
    public static function get_total_members() {
        global $wpdb;
        
        return $wpdb->get_var(
            "SELECT COUNT(DISTINCT user_id) 
            FROM {$wpdb->prefix}pmp_memberships 
            WHERE status = 'active'"
        );
    }
    
    public static function get_total_revenue($period = 'all') {
        global $wpdb;
        
        $where = "WHERE status = 'completed'";
        
        if ($period === 'month') {
            $where .= " AND MONTH(created_at) = MONTH(NOW()) AND YEAR(created_at) = YEAR(NOW())";
        } elseif ($period === 'year') {
            $where .= " AND YEAR(created_at) = YEAR(NOW())";
        }
        
        return $wpdb->get_var(
            "SELECT COALESCE(SUM(amount), 0) 
            FROM {$wpdb->prefix}pmp_transactions 
            {$where}"
        );
    }
    
    public static function get_members_by_level() {
        global $wpdb;
        
        $results = $wpdb->get_results(
            "SELECT level_id, COUNT(*) as count 
            FROM {$wpdb->prefix}pmp_memberships 
            WHERE status = 'active' 
            GROUP BY level_id"
        );
        
        $data = array();
        foreach ($results as $row) {
            $level = get_post($row->level_id);
            if ($level) {
                $data[$level->post_title] = $row->count;
            }
        }
        
        return $data;
    }
    
    public static function get_new_members($days = 30) {
        global $wpdb;
        
        return $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) 
            FROM {$wpdb->prefix}pmp_memberships 
            WHERE status = 'active' 
            AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
    }
    
    public static function get_cancelled_members($days = 30) {
        global $wpdb;
        
        return $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) 
            FROM {$wpdb->prefix}pmp_memberships 
            WHERE status = 'cancelled' 
            AND updated_at >= DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
    }
    
    public static function get_churn_rate($period = 'month') {
        $total = self::get_total_members();
        if ($total == 0) {
            return 0;
        }
        
        $days = $period === 'year' ? 365 : 30;
        $cancelled = self::get_cancelled_members($days);
        
        return round(($cancelled / $total) * 100, 2);
    }
    
    public static function get_popular_content($limit = 10) {
        global $wpdb;
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT post_id, COUNT(*) as views 
            FROM {$wpdb->prefix}pmp_access_logs 
            WHERE access_type = 'granted' 
            AND accessed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY post_id 
            ORDER BY views DESC 
            LIMIT %d",
            $limit
        ));
    }
    
    public static function get_revenue_chart_data($period = 'year') {
        global $wpdb;
        
        if ($period === 'year') {
            $results = $wpdb->get_results(
                "SELECT DATE_FORMAT(created_at, '%Y-%m') as period, SUM(amount) as total 
                FROM {$wpdb->prefix}pmp_transactions 
                WHERE status = 'completed' 
                AND created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
                GROUP BY DATE_FORMAT(created_at, '%Y-%m')
                ORDER BY period ASC"
            );
        } else {
            $results = $wpdb->get_results(
                "SELECT DATE_FORMAT(created_at, '%Y-%m-%d') as period, SUM(amount) as total 
                FROM {$wpdb->prefix}pmp_transactions 
                WHERE status = 'completed' 
                AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                GROUP BY DATE_FORMAT(created_at, '%Y-%m-%d')
                ORDER BY period ASC"
            );
        }
        
        $data = array();
        foreach ($results as $row) {
            $data[] = array(
                'period' => $row->period,
                'total' => floatval($row->total),
            );
        }
        
        return $data;
    }
}
