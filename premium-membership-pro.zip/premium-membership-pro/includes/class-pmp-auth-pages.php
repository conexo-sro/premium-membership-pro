<?php
/**
 * Login and Registration Pages
 * Beautiful, customizable login and registration pages with bubble design
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Auth_Pages {
    
    public static function init() {
        // Register pages on activation
        register_activation_hook(PMP_PLUGIN_FILE, array(__CLASS__, 'create_pages'));
        
        // Shortcodes
        add_shortcode('pmp_login', array(__CLASS__, 'login_shortcode'));
        add_shortcode('pmp_register', array(__CLASS__, 'register_shortcode'));
        
        // Process forms
        add_action('template_redirect', array(__CLASS__, 'process_login'));
        add_action('template_redirect', array(__CLASS__, 'process_registration'));
        
        // Enqueue styles
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue_scripts'));
        
        // Add settings
        add_action('admin_init', array(__CLASS__, 'register_settings'));
    }
    
    /**
     * Create login and registration pages
     */
    public static function create_pages() {
        // Check if pages already exist
        $login_page = get_option('pmp_login_page_id');
        $register_page = get_option('pmp_register_page_id');
        
        if (!$login_page || !get_post($login_page)) {
            // Create login page
            $login_id = wp_insert_post(array(
                'post_title' => __('Přihlášení', 'premium-membership-pro'),
                'post_content' => '[pmp_login]',
                'post_status' => 'publish',
                'post_type' => 'page',
                'post_author' => 1,
                'comment_status' => 'closed',
            ));
            update_option('pmp_login_page_id', $login_id);
        }
        
        if (!$register_page || !get_post($register_page)) {
            // Create registration page
            $register_id = wp_insert_post(array(
                'post_title' => __('Registrace', 'premium-membership-pro'),
                'post_content' => '[pmp_register]',
                'post_status' => 'publish',
                'post_type' => 'page',
                'post_author' => 1,
                'comment_status' => 'closed',
            ));
            update_option('pmp_register_page_id', $register_id);
        }
    }
    
    /**
     * Register settings
     */
    public static function register_settings() {
        register_setting('pmp_auth_pages', 'pmp_login_bg_image');
        register_setting('pmp_auth_pages', 'pmp_login_bg_color');
        register_setting('pmp_auth_pages', 'pmp_login_bg_gradient');
        register_setting('pmp_auth_pages', 'pmp_login_bubble_color');
        register_setting('pmp_auth_pages', 'pmp_login_bubble_blur');
        register_setting('pmp_auth_pages', 'pmp_register_bg_image');
        register_setting('pmp_auth_pages', 'pmp_register_bg_color');
        register_setting('pmp_auth_pages', 'pmp_register_bg_gradient');
    }
    
    /**
     * Enqueue scripts and styles
     */
    public static function enqueue_scripts() {
        if (is_page(get_option('pmp_login_page_id')) || is_page(get_option('pmp_register_page_id'))) {
            wp_enqueue_style('pmp-auth-pages', PMP_PLUGIN_URL . 'assets/css/auth-pages.css', array(), PMP_VERSION);
            wp_enqueue_script('pmp-auth-pages', PMP_PLUGIN_URL . 'assets/js/auth-pages.js', array('jquery'), PMP_VERSION, true);
        }
    }
    
    /**
     * Login shortcode
     */
    public static function login_shortcode($atts) {
        if (is_user_logged_in()) {
            return '<p>' . sprintf(__('Již jste přihlášeni. <a href="%s">Přejít na účet</a>', 'premium-membership-pro'), get_permalink(get_option('pmp_account_page_id'))) . '</p>';
        }
        
        $atts = shortcode_atts(array(
            'redirect' => '',
            'show_register_link' => 'yes',
        ), $atts);
        
        $redirect = !empty($atts['redirect']) ? $atts['redirect'] : get_permalink(get_option('pmp_account_page_id'));
        
        // Get background settings
        $bg_image = get_option('pmp_login_bg_image');
        $bg_color = get_option('pmp_login_bg_color', '#667eea');
        $bg_gradient = get_option('pmp_login_bg_gradient', 'yes');
        $bubble_color = get_option('pmp_login_bubble_color', 'rgba(255, 255, 255, 0.95)');
        $bubble_blur = get_option('pmp_login_bubble_blur', '20');
        
        $background_style = '';
        if ($bg_image) {
            $background_style = "background-image: url('{$bg_image}');";
        } elseif ($bg_gradient === 'yes') {
            $background_style = "background: linear-gradient(135deg, {$bg_color} 0%, #764ba2 100%);";
        } else {
            $background_style = "background-color: {$bg_color};";
        }
        
        ob_start();
        ?>
        <div class="pmp-auth-container pmp-login-page" style="<?php echo esc_attr($background_style); ?>">
            <!-- Animated background elements -->
            <div class="pmp-bg-shapes">
                <div class="pmp-shape pmp-shape-1"></div>
                <div class="pmp-shape pmp-shape-2"></div>
                <div class="pmp-shape pmp-shape-3"></div>
            </div>
            
            <div class="pmp-auth-bubble" style="background-color: <?php echo esc_attr($bubble_color); ?>; backdrop-filter: blur(<?php echo esc_attr($bubble_blur); ?>px);">
                <div class="pmp-auth-header">
                    <h1><?php _e('Přihlášení', 'premium-membership-pro'); ?></h1>
                    <p><?php _e('Vítejte zpět! Přihlaste se ke svému účtu.', 'premium-membership-pro'); ?></p>
                </div>
                
                <?php if (isset($_GET['registered'])): ?>
                    <div class="pmp-message pmp-success">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                        </svg>
                        <?php _e('Registrace úspěšná! Nyní se můžete přihlásit.', 'premium-membership-pro'); ?>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_GET['login']) && $_GET['login'] === 'failed'): ?>
                    <div class="pmp-message pmp-error">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
                        </svg>
                        <?php _e('Nesprávné přihlašovací údaje.', 'premium-membership-pro'); ?>
                    </div>
                <?php endif; ?>
                
                <form method="post" action="" class="pmp-auth-form">
                    <?php wp_nonce_field('pmp_login', 'pmp_login_nonce'); ?>
                    <input type="hidden" name="pmp_action" value="login">
                    <input type="hidden" name="redirect_to" value="<?php echo esc_url($redirect); ?>">
                    
                    <div class="pmp-form-group">
                        <label for="pmp_username">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"/>
                            </svg>
                            <?php _e('Email nebo uživatelské jméno', 'premium-membership-pro'); ?>
                        </label>
                        <input type="text" id="pmp_username" name="username" required>
                    </div>
                    
                    <div class="pmp-form-group">
                        <label for="pmp_password">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd"/>
                            </svg>
                            <?php _e('Heslo', 'premium-membership-pro'); ?>
                        </label>
                        <input type="password" id="pmp_password" name="password" required>
                    </div>
                    
                    <div class="pmp-form-row">
                        <label class="pmp-checkbox">
                            <input type="checkbox" name="remember" value="1">
                            <span><?php _e('Zapamatovat si mě', 'premium-membership-pro'); ?></span>
                        </label>
                        <a href="<?php echo wp_lostpassword_url(); ?>" class="pmp-forgot-link">
                            <?php _e('Zapomněli jste heslo?', 'premium-membership-pro'); ?>
                        </a>
                    </div>
                    
                    <button type="submit" class="pmp-btn pmp-btn-primary">
                        <?php _e('Přihlásit se', 'premium-membership-pro'); ?>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clip-rule="evenodd"/>
                        </svg>
                    </button>
                </form>
                
                <?php if ($atts['show_register_link'] === 'yes'): ?>
                    <div class="pmp-auth-footer">
                        <p>
                            <?php _e('Ještě nemáte účet?', 'premium-membership-pro'); ?>
                            <a href="<?php echo get_permalink(get_option('pmp_register_page_id')); ?>">
                                <?php _e('Zaregistrujte se', 'premium-membership-pro'); ?>
                            </a>
                        </p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Registration shortcode
     */
    public static function register_shortcode($atts) {
        if (is_user_logged_in()) {
            return '<p>' . sprintf(__('Již jste přihlášeni. <a href="%s">Přejít na účet</a>', 'premium-membership-pro'), get_permalink(get_option('pmp_account_page_id'))) . '</p>';
        }
        
        $atts = shortcode_atts(array(
            'show_login_link' => 'yes',
        ), $atts);
        
        // Get background settings
        $bg_image = get_option('pmp_register_bg_image');
        $bg_color = get_option('pmp_register_bg_color', '#f093fb');
        $bg_gradient = get_option('pmp_register_bg_gradient', 'yes');
        
        $background_style = '';
        if ($bg_image) {
            $background_style = "background-image: url('{$bg_image}');";
        } elseif ($bg_gradient === 'yes') {
            $background_style = "background: linear-gradient(135deg, {$bg_color} 0%, #f5576c 100%);";
        } else {
            $background_style = "background-color: {$bg_color};";
        }
        
        ob_start();
        ?>
        <div class="pmp-auth-container pmp-register-page" style="<?php echo esc_attr($background_style); ?>">
            <!-- Animated background elements -->
            <div class="pmp-bg-shapes">
                <div class="pmp-shape pmp-shape-1"></div>
                <div class="pmp-shape pmp-shape-2"></div>
                <div class="pmp-shape pmp-shape-3"></div>
                <div class="pmp-shape pmp-shape-4"></div>
            </div>
            
            <div class="pmp-auth-bubble">
                <div class="pmp-auth-header">
                    <h1><?php _e('Registrace', 'premium-membership-pro'); ?></h1>
                    <p><?php _e('Vytvořte si účet a získejte přístup k exkluzivnímu obsahu.', 'premium-membership-pro'); ?></p>
                </div>
                
                <?php if (isset($_GET['error'])): ?>
                    <div class="pmp-message pmp-error">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
                        </svg>
                        <?php echo esc_html(urldecode($_GET['error'])); ?>
                    </div>
                <?php endif; ?>
                
                <form method="post" action="" class="pmp-auth-form">
                    <?php wp_nonce_field('pmp_register', 'pmp_register_nonce'); ?>
                    <input type="hidden" name="pmp_action" value="register">
                    
                    <div class="pmp-form-row pmp-form-row-2">
                        <div class="pmp-form-group">
                            <label for="pmp_first_name">
                                <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"/>
                                </svg>
                                <?php _e('Jméno', 'premium-membership-pro'); ?>
                            </label>
                            <input type="text" id="pmp_first_name" name="first_name" required>
                        </div>
                        
                        <div class="pmp-form-group">
                            <label for="pmp_last_name">
                                <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"/>
                                </svg>
                                <?php _e('Příjmení', 'premium-membership-pro'); ?>
                            </label>
                            <input type="text" id="pmp_last_name" name="last_name" required>
                        </div>
                    </div>
                    
                    <div class="pmp-form-group">
                        <label for="pmp_email">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                                <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"/>
                                <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"/>
                            </svg>
                            <?php _e('Email', 'premium-membership-pro'); ?>
                        </label>
                        <input type="email" id="pmp_email" name="email" required>
                    </div>
                    
                    <div class="pmp-form-group">
                        <label for="pmp_username">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-6-3a2 2 0 11-4 0 2 2 0 014 0zm-2 4a5 5 0 00-4.546 2.916A5.986 5.986 0 0010 16a5.986 5.986 0 004.546-2.084A5 5 0 0010 11z" clip-rule="evenodd"/>
                            </svg>
                            <?php _e('Uživatelské jméno', 'premium-membership-pro'); ?>
                        </label>
                        <input type="text" id="pmp_username" name="username" required>
                        <small><?php _e('Pouze písmena, čísla, pomlčky a podtržítka', 'premium-membership-pro'); ?></small>
                    </div>
                    
                    <div class="pmp-form-group">
                        <label for="pmp_password">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd"/>
                            </svg>
                            <?php _e('Heslo', 'premium-membership-pro'); ?>
                        </label>
                        <input type="password" id="pmp_password" name="password" required minlength="8">
                        <small><?php _e('Minimálně 8 znaků', 'premium-membership-pro'); ?></small>
                    </div>
                    
                    <div class="pmp-form-group">
                        <label for="pmp_password_confirm">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                            </svg>
                            <?php _e('Potvrdit heslo', 'premium-membership-pro'); ?>
                        </label>
                        <input type="password" id="pmp_password_confirm" name="password_confirm" required minlength="8">
                    </div>
                    
                    <div class="pmp-form-group">
                        <label class="pmp-checkbox">
                            <input type="checkbox" name="terms" value="1" required>
                            <span>
                                <?php _e('Souhlasím s', 'premium-membership-pro'); ?> 
                                <a href="<?php echo get_privacy_policy_url(); ?>" target="_blank">
                                    <?php _e('podmínkami použití', 'premium-membership-pro'); ?>
                                </a>
                            </span>
                        </label>
                    </div>
                    
                    <button type="submit" class="pmp-btn pmp-btn-primary">
                        <?php _e('Vytvořit účet', 'premium-membership-pro'); ?>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                            <path d="M8 9a3 3 0 100-6 3 3 0 000 6zM8 11a6 6 0 016 6H2a6 6 0 016-6zM16 7a1 1 0 10-2 0v1h-1a1 1 0 100 2h1v1a1 1 0 102 0v-1h1a1 1 0 100-2h-1V7z"/>
                        </svg>
                    </button>
                </form>
                
                <?php if ($atts['show_login_link'] === 'yes'): ?>
                    <div class="pmp-auth-footer">
                        <p>
                            <?php _e('Již máte účet?', 'premium-membership-pro'); ?>
                            <a href="<?php echo get_permalink(get_option('pmp_login_page_id')); ?>">
                                <?php _e('Přihlaste se', 'premium-membership-pro'); ?>
                            </a>
                        </p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Process login
     */
    public static function process_login() {
        if (!isset($_POST['pmp_action']) || $_POST['pmp_action'] !== 'login') {
            return;
        }
        
        if (!isset($_POST['pmp_login_nonce']) || !wp_verify_nonce($_POST['pmp_login_nonce'], 'pmp_login')) {
            return;
        }
        
        $username = sanitize_text_field($_POST['username']);
        $password = $_POST['password'];
        $remember = isset($_POST['remember']);
        $redirect = isset($_POST['redirect_to']) ? esc_url_raw($_POST['redirect_to']) : home_url();
        
        $creds = array(
            'user_login' => $username,
            'user_password' => $password,
            'remember' => $remember,
        );
        
        $user = wp_signon($creds, is_ssl());
        
        if (is_wp_error($user)) {
            wp_redirect(add_query_arg('login', 'failed', get_permalink(get_option('pmp_login_page_id'))));
            exit;
        }
        
        wp_redirect($redirect);
        exit;
    }
    
    /**
     * Process registration
     */
    public static function process_registration() {
        if (!isset($_POST['pmp_action']) || $_POST['pmp_action'] !== 'register') {
            return;
        }
        
        if (!isset($_POST['pmp_register_nonce']) || !wp_verify_nonce($_POST['pmp_register_nonce'], 'pmp_register')) {
            return;
        }
        
        $first_name = sanitize_text_field($_POST['first_name']);
        $last_name = sanitize_text_field($_POST['last_name']);
        $email = sanitize_email($_POST['email']);
        $username = sanitize_user($_POST['username']);
        $password = $_POST['password'];
        $password_confirm = $_POST['password_confirm'];
        
        // Validation
        if ($password !== $password_confirm) {
            wp_redirect(add_query_arg('error', urlencode(__('Hesla se neshodují', 'premium-membership-pro')), get_permalink(get_option('pmp_register_page_id'))));
            exit;
        }
        
        if (username_exists($username)) {
            wp_redirect(add_query_arg('error', urlencode(__('Uživatelské jméno již existuje', 'premium-membership-pro')), get_permalink(get_option('pmp_register_page_id'))));
            exit;
        }
        
        if (email_exists($email)) {
            wp_redirect(add_query_arg('error', urlencode(__('Email již existuje', 'premium-membership-pro')), get_permalink(get_option('pmp_register_page_id'))));
            exit;
        }
        
        // Create user
        $user_id = wp_create_user($username, $password, $email);
        
        if (is_wp_error($user_id)) {
            wp_redirect(add_query_arg('error', urlencode($user_id->get_error_message()), get_permalink(get_option('pmp_register_page_id'))));
            exit;
        }
        
        // Update user meta
        wp_update_user(array(
            'ID' => $user_id,
            'first_name' => $first_name,
            'last_name' => $last_name,
        ));
        
        // Send notification email
        wp_new_user_notification($user_id, null, 'both');
        
        // Redirect to login
        wp_redirect(add_query_arg('registered', '1', get_permalink(get_option('pmp_login_page_id'))));
        exit;
    }
}
