<?php
/**
 * Post Level Column
 * Add membership level column to posts/pages list
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Post_Level_Column {
    
    public static function init() {
        // Add level column to posts and pages - use specific hooks with HIGH priority
        add_filter('manage_post_posts_columns', array(__CLASS__, 'add_level_column'), 999);
        add_filter('manage_page_posts_columns', array(__CLASS__, 'add_level_column'), 999);
        
        // Also add generic hooks as fallback
        add_filter('manage_posts_columns', array(__CLASS__, 'add_level_column'), 999);
        add_filter('manage_pages_columns', array(__CLASS__, 'add_level_column'), 999);
        
        // Display level column content
        add_action('manage_posts_custom_column', array(__CLASS__, 'display_level_column'), 10, 2);
        add_action('manage_pages_custom_column', array(__CLASS__, 'display_level_column'), 10, 2);
        
        // Make column sortable
        add_filter('manage_edit-post_sortable_columns', array(__CLASS__, 'make_level_column_sortable'));
        add_filter('manage_edit-page_sortable_columns', array(__CLASS__, 'make_level_column_sortable'));
        
        // Handle sorting
        add_action('pre_get_posts', array(__CLASS__, 'handle_level_column_sorting'));
        
        // Add quick edit field
        add_action('quick_edit_custom_box', array(__CLASS__, 'quick_edit_level'), 10, 2);
        add_action('admin_footer-edit.php', array(__CLASS__, 'quick_edit_script'));
        
        // Save quick edit
        add_action('save_post', array(__CLASS__, 'save_quick_edit_level'), 10, 2);
        
        // Add bulk edit field
        add_action('bulk_edit_custom_box', array(__CLASS__, 'bulk_edit_level'), 10, 2);
        add_action('wp_ajax_pmp_save_bulk_edit_level', array(__CLASS__, 'save_bulk_edit_level'));
        
        // Inline edit AJAX
        add_action('wp_ajax_pmp_save_inline_level', array(__CLASS__, 'save_inline_level'));
        
        // Add filter dropdown
        add_action('restrict_manage_posts', array(__CLASS__, 'add_level_filter'));
        add_filter('parse_query', array(__CLASS__, 'filter_by_level'));
        
        // Debug log
        if (WP_DEBUG) {
            error_log('PMP: Post Level Column initialized on admin_init');
        }
        
        // Enqueue scripts
        add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_scripts'));
    }
    
    /**
     * Add level column
     */
    public static function add_level_column($columns) {
        // Debug log
        if (WP_DEBUG) {
            error_log('PMP: add_level_column called with columns: ' . print_r(array_keys($columns), true));
        }
        
        $new_columns = array();
        
        foreach ($columns as $key => $title) {
            $new_columns[$key] = $title;
            
            // Add level column after title
            if ($key === 'title') {
                $new_columns['pmp_levels'] = '<span class="dashicons dashicons-shield" title="' . esc_attr__('Úrovně členství', 'premium-membership-pro') . '"></span> ' . __('Úroveň', 'premium-membership-pro');
            }
        }
        
        // Debug log result
        if (WP_DEBUG) {
            error_log('PMP: add_level_column returning columns: ' . print_r(array_keys($new_columns), true));
        }
        
        return $new_columns;
    }
    
    /**
     * Display level column content
     */
    public static function display_level_column($column, $post_id) {
        if ($column !== 'pmp_levels') {
            return;
        }
        
        $required_levels = get_post_meta($post_id, '_pmp_required_levels', true);
        $is_protected = get_post_meta($post_id, '_pmp_protected', true);
        
        // Get all available levels for editor
        $all_levels = get_posts(array(
            'post_type' => 'pmp_membership',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'orderby' => 'title',
            'order' => 'ASC',
        ));
        
        // Container with inline edit
        echo '<div class="pmp-level-column-wrapper" data-post-id="' . esc_attr($post_id) . '">';
        
        // Display current state
        echo '<div class="pmp-level-display">';
        
        if (!$is_protected) {
            echo '<span class="pmp-level-none" title="' . esc_attr__('Klikněte pro úpravu', 'premium-membership-pro') . '">';
            echo '<span class="dashicons dashicons-unlock"></span> ';
            echo '<span class="pmp-level-text">' . __('Veřejný', 'premium-membership-pro') . '</span>';
            echo '</span>';
        } elseif (empty($required_levels) || !is_array($required_levels)) {
            echo '<span class="pmp-level-any" title="' . esc_attr__('Klikněte pro úpravu', 'premium-membership-pro') . '">';
            echo '<span class="dashicons dashicons-groups"></span> ';
            echo '<span class="pmp-level-text">' . __('Jakékoli', 'premium-membership-pro') . '</span>';
            echo '</span>';
        } else {
            // Get level names
            $level_names = array();
            foreach ($required_levels as $level_id) {
                $level = get_post($level_id);
                if ($level) {
                    $level_names[] = $level->post_title;
                }
            }
            
            if (empty($level_names)) {
                echo '<span class="pmp-level-error" title="' . esc_attr__('Klikněte pro úpravu', 'premium-membership-pro') . '">';
                echo '<span class="dashicons dashicons-warning"></span> ';
                echo '<span class="pmp-level-text">' . __('Chyba', 'premium-membership-pro') . '</span>';
                echo '</span>';
            } else {
                // Display levels
                $count = count($level_names);
                $display_names = array_slice($level_names, 0, 2);
                $tooltip = __('Klikněte pro úpravu: ', 'premium-membership-pro') . implode(', ', $level_names);
                
                echo '<div class="pmp-levels-badges" title="' . esc_attr($tooltip) . '">';
                
                foreach ($display_names as $name) {
                    echo '<span class="pmp-level-badge">' . esc_html($name) . '</span>';
                }
                
                if ($count > 2) {
                    echo '<span class="pmp-level-more">+' . ($count - 2) . '</span>';
                }
                
                echo '</div>';
            }
        }
        
        // Edit icon
        echo '<span class="dashicons dashicons-edit pmp-edit-icon" title="' . esc_attr__('Upravit úrovně', 'premium-membership-pro') . '"></span>';
        
        echo '</div>'; // .pmp-level-display
        
        // Inline editor (hidden by default)
        echo '<div class="pmp-level-editor" style="display: none;">';
        
        echo '<div class="pmp-editor-content">';
        
        // Protection checkbox
        echo '<label class="pmp-editor-protection">';
        echo '<input type="checkbox" class="pmp-protection-checkbox" ' . checked($is_protected, true, false) . '> ';
        echo __('Chránit obsah', 'premium-membership-pro');
        echo '</label>';
        
        // Levels checkboxes
        echo '<div class="pmp-editor-levels" ' . ($is_protected ? '' : 'style="display:none;"') . '>';
        
        if (!empty($all_levels)) {
            foreach ($all_levels as $level) {
                $checked = $is_protected && is_array($required_levels) && in_array($level->ID, $required_levels);
                echo '<label class="pmp-editor-level-item">';
                echo '<input type="checkbox" class="pmp-level-checkbox" value="' . esc_attr($level->ID) . '" ' . checked($checked, true, false) . '> ';
                echo esc_html($level->post_title);
                echo '</label>';
            }
        } else {
            echo '<p class="pmp-no-levels">' . __('Žádné úrovně členství nejsou k dispozici.', 'premium-membership-pro') . '</p>';
        }
        
        echo '</div>'; // .pmp-editor-levels
        
        // Buttons
        echo '<div class="pmp-editor-buttons">';
        echo '<button type="button" class="button button-primary button-small pmp-save-inline">' . __('Uložit', 'premium-membership-pro') . '</button> ';
        echo '<button type="button" class="button button-small pmp-cancel-inline">' . __('Zrušit', 'premium-membership-pro') . '</button>';
        echo '</div>';
        
        echo '</div>'; // .pmp-editor-content
        
        echo '</div>'; // .pmp-level-editor
        
        echo '</div>'; // .pmp-level-column-wrapper
    }
    
    /**
     * Make column sortable
     */
    public static function make_level_column_sortable($columns) {
        $columns['pmp_levels'] = 'pmp_levels';
        return $columns;
    }
    
    /**
     * Handle sorting
     */
    public static function handle_level_column_sorting($query) {
        if (!is_admin() || !$query->is_main_query()) {
            return;
        }
        
        $orderby = $query->get('orderby');
        
        if ($orderby === 'pmp_levels') {
            $query->set('meta_key', '_pmp_enable_protection');
            $query->set('orderby', 'meta_value');
        }
    }
    
    /**
     * Quick edit field
     */
    public static function quick_edit_level($column_name, $post_type) {
        if ($column_name !== 'pmp_levels') {
            return;
        }
        
        // Get all levels
        $levels = get_posts(array(
            'post_type' => 'pmp_membership',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'orderby' => 'title',
            'order' => 'ASC',
        ));
        
        ?>
        <fieldset class="inline-edit-col-right inline-edit-pmp-levels">
            <div class="inline-edit-col">
                <label>
                    <span class="title"><?php _e('Ochrana obsahu', 'premium-membership-pro'); ?></span>
                </label>
                <div class="pmp-quick-edit-protection">
                    <label>
                        <input type="checkbox" name="pmp_enable_protection" value="1">
                        <?php _e('Povolit ochranu', 'premium-membership-pro'); ?>
                    </label>
                </div>
                
                <div class="pmp-quick-edit-levels" style="display: none;">
                    <label>
                        <span class="title"><?php _e('Požadované úrovně', 'premium-membership-pro'); ?></span>
                    </label>
                    <?php if (!empty($levels)): ?>
                        <div class="pmp-levels-checkboxes">
                            <?php foreach ($levels as $level): ?>
                                <label>
                                    <input type="checkbox" 
                                           name="pmp_required_levels[]" 
                                           value="<?php echo $level->ID; ?>">
                                    <?php echo esc_html($level->post_title); ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="description">
                            <?php _e('Nejsou k dispozici žádné úrovně.', 'premium-membership-pro'); ?>
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </fieldset>
        <?php
    }
    
    /**
     * Quick edit script
     */
    public static function quick_edit_script() {
        global $current_screen;
        
        if (!in_array($current_screen->post_type, array('post', 'page'))) {
            return;
        }
        
        ?>
        <script type="text/javascript">
        (function($) {
            var $wp_inline_edit = inlineEditPost.edit;
            
            inlineEditPost.edit = function(id) {
                $wp_inline_edit.apply(this, arguments);
                
                var post_id = 0;
                if (typeof(id) == 'object') {
                    post_id = parseInt(this.getId(id));
                }
                
                if (post_id > 0) {
                    var $row = $('#post-' + post_id);
                    var $edit_row = $('#edit-' + post_id);
                    
                    // Get current values
                    var $levels_cell = $row.find('.pmp-levels-badges');
                    var has_protection = $levels_cell.length > 0;
                    
                    // Set protection checkbox
                    $edit_row.find('input[name="pmp_enable_protection"]').prop('checked', has_protection);
                    
                    if (has_protection) {
                        $edit_row.find('.pmp-quick-edit-levels').show();
                        
                        // Get level IDs from data attribute
                        var level_ids = $row.data('level-ids');
                        if (level_ids) {
                            var ids = level_ids.split(',');
                            ids.forEach(function(level_id) {
                                $edit_row.find('input[name="pmp_required_levels[]"][value="' + level_id + '"]').prop('checked', true);
                            });
                        }
                    }
                }
            };
            
            // Toggle levels visibility
            $(document).on('change', 'input[name="pmp_enable_protection"]', function() {
                var $checkbox = $(this);
                var $levels = $checkbox.closest('.inline-edit-col').find('.pmp-quick-edit-levels');
                
                if ($checkbox.is(':checked')) {
                    $levels.slideDown(200);
                } else {
                    $levels.slideUp(200);
                }
            });
        })(jQuery);
        </script>
        
        <style>
        .pmp-quick-edit-protection {
            margin: 10px 0;
        }
        
        .pmp-quick-edit-levels {
            margin-top: 10px;
        }
        
        .pmp-levels-checkboxes {
            max-height: 200px;
            overflow-y: auto;
            border: 1px solid #ddd;
            padding: 10px;
            background: #f9f9f9;
        }
        
        .pmp-levels-checkboxes label {
            display: block;
            margin: 5px 0;
        }
        </style>
        <?php
    }
    
    /**
     * Save quick edit
     */
    public static function save_quick_edit_level($post_id, $post) {
        // Check if this is a quick edit save
        if (!isset($_POST['_inline_edit'])) {
            return;
        }
        
        // Check nonce
        if (!wp_verify_nonce($_POST['_inline_edit'], 'inlineeditnonce')) {
            return;
        }
        
        // Check autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        // Check permissions
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Save protection status
        $enable_protection = isset($_POST['pmp_enable_protection']) ? '1' : '0';
        update_post_meta($post_id, '_pmp_enable_protection', $enable_protection);
        
        // Save required levels
        if ($enable_protection === '1' && isset($_POST['pmp_required_levels'])) {
            $levels = array_map('intval', $_POST['pmp_required_levels']);
            update_post_meta($post_id, '_pmp_required_levels', $levels);
        } else {
            delete_post_meta($post_id, '_pmp_required_levels');
        }
    }
    
    /**
     * Bulk edit field
     */
    public static function bulk_edit_level($column_name, $post_type) {
        if ($column_name !== 'pmp_levels') {
            return;
        }
        
        // Get all levels
        $levels = get_posts(array(
            'post_type' => 'pmp_membership',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'orderby' => 'title',
            'order' => 'ASC',
        ));
        
        ?>
        <fieldset class="inline-edit-col-right inline-edit-pmp-levels-bulk">
            <div class="inline-edit-col">
                <label>
                    <span class="title"><?php _e('Úrovně členství', 'premium-membership-pro'); ?></span>
                </label>
                
                <div class="pmp-bulk-edit-action">
                    <select name="pmp_bulk_action">
                        <option value=""><?php _e('— Beze změny —', 'premium-membership-pro'); ?></option>
                        <option value="set_levels"><?php _e('Nastavit úrovně', 'premium-membership-pro'); ?></option>
                        <option value="add_levels"><?php _e('Přidat úrovně', 'premium-membership-pro'); ?></option>
                        <option value="remove_protection"><?php _e('Odstranit ochranu', 'premium-membership-pro'); ?></option>
                    </select>
                </div>
                
                <div class="pmp-bulk-edit-levels" style="display: none;">
                    <?php if (!empty($levels)): ?>
                        <div class="pmp-levels-checkboxes">
                            <?php foreach ($levels as $level): ?>
                                <label>
                                    <input type="checkbox" 
                                           name="pmp_bulk_levels[]" 
                                           value="<?php echo $level->ID; ?>">
                                    <?php echo esc_html($level->post_title); ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="description">
                            <?php _e('Nejsou k dispozici žádné úrovně.', 'premium-membership-pro'); ?>
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </fieldset>
        
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('select[name="pmp_bulk_action"]').on('change', function() {
                var value = $(this).val();
                var $levels = $(this).closest('.inline-edit-col').find('.pmp-bulk-edit-levels');
                
                if (value === 'set_levels' || value === 'add_levels') {
                    $levels.slideDown(200);
                } else {
                    $levels.slideUp(200);
                }
            });
        });
        </script>
        <?php
    }
    
    /**
     * Save bulk edit
     */
    public static function save_bulk_edit_level() {
        check_ajax_referer('bulk-posts');
        
        $post_ids = isset($_POST['post_ids']) ? array_map('intval', $_POST['post_ids']) : array();
        $action = isset($_POST['pmp_bulk_action']) ? sanitize_text_field($_POST['pmp_bulk_action']) : '';
        $levels = isset($_POST['pmp_bulk_levels']) ? array_map('intval', $_POST['pmp_bulk_levels']) : array();
        
        if (empty($post_ids) || empty($action)) {
            wp_send_json_error(array('message' => __('Chybí data.', 'premium-membership-pro')));
        }
        
        $updated = 0;
        
        foreach ($post_ids as $post_id) {
            if (!current_user_can('edit_post', $post_id)) {
                continue;
            }
            
            switch ($action) {
                case 'set_levels':
                    update_post_meta($post_id, '_pmp_enable_protection', '1');
                    update_post_meta($post_id, '_pmp_required_levels', $levels);
                    $updated++;
                    break;
                    
                case 'add_levels':
                    $existing_levels = get_post_meta($post_id, '_pmp_required_levels', true);
                    $existing_levels = is_array($existing_levels) ? $existing_levels : array();
                    $new_levels = array_unique(array_merge($existing_levels, $levels));
                    
                    update_post_meta($post_id, '_pmp_enable_protection', '1');
                    update_post_meta($post_id, '_pmp_required_levels', $new_levels);
                    $updated++;
                    break;
                    
                case 'remove_protection':
                    delete_post_meta($post_id, '_pmp_enable_protection');
                    delete_post_meta($post_id, '_pmp_required_levels');
                    $updated++;
                    break;
            }
        }
        
        wp_send_json_success(array(
            'message' => sprintf(__('Aktualizováno %d příspěvků.', 'premium-membership-pro'), $updated),
            'updated' => $updated,
        ));
    }
    
    /**
     * Add filter dropdown
     */
    public static function add_level_filter($post_type) {
        if (!in_array($post_type, array('post', 'page'))) {
            return;
        }
        
        $selected = isset($_GET['pmp_level_filter']) ? $_GET['pmp_level_filter'] : '';
        
        // Get all levels
        $levels = get_posts(array(
            'post_type' => 'pmp_membership',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'orderby' => 'title',
            'order' => 'ASC',
        ));
        
        ?>
        <select name="pmp_level_filter">
            <option value=""><?php _e('Všechny úrovně', 'premium-membership-pro'); ?></option>
            <option value="public" <?php selected($selected, 'public'); ?>><?php _e('Veřejné', 'premium-membership-pro'); ?></option>
            <option value="protected" <?php selected($selected, 'protected'); ?>><?php _e('Chráněné', 'premium-membership-pro'); ?></option>
            <?php if (!empty($levels)): ?>
                <optgroup label="<?php esc_attr_e('Podle úrovně', 'premium-membership-pro'); ?>">
                    <?php foreach ($levels as $level): ?>
                        <option value="level_<?php echo $level->ID; ?>" <?php selected($selected, 'level_' . $level->ID); ?>>
                            <?php echo esc_html($level->post_title); ?>
                        </option>
                    <?php endforeach; ?>
                </optgroup>
            <?php endif; ?>
        </select>
        <?php
    }
    
    /**
     * Filter by level
     */
    public static function filter_by_level($query) {
        global $pagenow, $typenow;
        
        if ($pagenow !== 'edit.php' || !in_array($typenow, array('post', 'page'))) {
            return;
        }
        
        $filter = isset($_GET['pmp_level_filter']) ? $_GET['pmp_level_filter'] : '';
        
        if (empty($filter)) {
            return;
        }
        
        $meta_query = array();
        
        if ($filter === 'public') {
            $meta_query[] = array(
                'relation' => 'OR',
                array(
                    'key' => '_pmp_enable_protection',
                    'compare' => 'NOT EXISTS',
                ),
                array(
                    'key' => '_pmp_enable_protection',
                    'value' => '0',
                ),
            );
        } elseif ($filter === 'protected') {
            $meta_query[] = array(
                'key' => '_pmp_enable_protection',
                'value' => '1',
            );
        } elseif (strpos($filter, 'level_') === 0) {
            $level_id = str_replace('level_', '', $filter);
            $meta_query[] = array(
                'key' => '_pmp_required_levels',
                'value' => sprintf(':"%s";', $level_id),
                'compare' => 'LIKE',
            );
        }
        
        if (!empty($meta_query)) {
            $query->set('meta_query', $meta_query);
        }
    }
    
    /**
     * Save inline level edit via AJAX
     */
    public static function save_inline_level() {
        // Check nonce
        check_ajax_referer('pmp-inline-edit', 'nonce');
        
        // Check permissions
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(array('message' => __('Nemáte oprávnění upravovat příspěvky.', 'premium-membership-pro')));
        }
        
        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        
        if (!$post_id) {
            wp_send_json_error(array('message' => __('Neplatné ID příspěvku.', 'premium-membership-pro')));
        }
        
        // Check if user can edit this post
        if (!current_user_can('edit_post', $post_id)) {
            wp_send_json_error(array('message' => __('Nemáte oprávnění upravovat tento příspěvek.', 'premium-membership-pro')));
        }
        
        // Register this post for shutdown check
        PMP_Meta_Boxes::register_post_for_check($post_id);
        
        // DEBUG: Log all received POST data
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("=== PMP Inline Save START ===");
            error_log("PMP Inline Save - RAW POST data:");
            error_log("  post_id: " . $post_id);
            error_log("  enable_protection RAW: " . var_export($_POST['enable_protection'] ?? 'NOT SET', true));
            error_log("  enable_protection type: " . gettype($_POST['enable_protection'] ?? null));
            error_log("  enable_protection === true: " . (($_POST['enable_protection'] ?? null) === true ? 'YES' : 'NO'));
            error_log("  enable_protection === 'true': " . (($_POST['enable_protection'] ?? null) === 'true' ? 'YES' : 'NO'));
            error_log("  enable_protection === '1': " . (($_POST['enable_protection'] ?? null) === '1' ? 'YES' : 'NO'));
            error_log("  enable_protection === 1: " . (($_POST['enable_protection'] ?? null) === 1 ? 'YES' : 'NO'));
            error_log("  selected_levels: " . var_export($_POST['selected_levels'] ?? 'NOT SET', true));
        }
        
        // Handle enable_protection - can be boolean true/false or string 'true'/'false'
        $enable_protection = false;
        if (isset($_POST['enable_protection'])) {
            // Handle both boolean and string
            if ($_POST['enable_protection'] === true || $_POST['enable_protection'] === 'true' || $_POST['enable_protection'] === '1' || $_POST['enable_protection'] === 1) {
                $enable_protection = true;
                
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("PMP: enable_protection SET TO TRUE from POST data");
                }
            } else {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("PMP: enable_protection is SET but value doesn't match true/1");
                }
            }
        } else {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP: enable_protection is NOT SET in POST");
            }
        }
        
        $selected_levels = isset($_POST['selected_levels']) ? array_map('intval', $_POST['selected_levels']) : array();
        
        // CRITICAL: If ANY levels are selected, FORCE enable protection (ignore checkbox)
        // This is the key fix - levels selected = protection MUST be enabled
        if (!empty($selected_levels)) {
            $enable_protection = true;
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP: FORCED enable_protection = TRUE because selected_levels is not empty");
            }
        }
        
        // DEBUG: Log computed values
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("PMP Inline Save - COMPUTED values:");
            error_log("  enable_protection: " . ($enable_protection ? 'TRUE' : 'FALSE'));
            error_log("  selected_levels: " . implode(',', $selected_levels));
            error_log("  Will save _pmp_protected = " . ($enable_protection ? '1' : '0'));
        }
        
        // GUARANTEE: If selected_levels exists, protection_value MUST be '1'
        $protection_value = ($enable_protection || !empty($selected_levels)) ? '1' : '0';
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("  FINAL protection_value: " . $protection_value);
            error_log("  Reason: " . (!empty($selected_levels) ? "selected_levels not empty" : ($enable_protection ? "enable_protection true" : "both false")));
        }
        
        // ====================================================================
        // CRITICAL: FORCE IMMEDIATE SYNCHRONOUS SAVE - NO DELAYS, NO HOOKS
        // USING RAW SQL QUERIES FOR MAXIMUM RELIABILITY
        // ====================================================================
        
        global $wpdb;
        $table_name = $wpdb->postmeta;
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("=== PMP INLINE SAVE - SQL OPERATIONS ===");
            error_log("PMP: Target table: {$table_name}");
            error_log("PMP: Will save _pmp_protected = '{$protection_value}'");
        }
        
        // Step 1: DELETE using raw query
        $delete_sql = $wpdb->prepare(
            "DELETE FROM {$table_name} WHERE post_id = %d AND meta_key = %s",
            $post_id,
            '_pmp_protected'
        );
        $delete_result = $wpdb->query($delete_sql);
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("PMP: Step 1 - DELETE query: {$delete_sql}");
            error_log("PMP: Step 1 - DELETE result: " . var_export($delete_result, true));
            if ($wpdb->last_error) {
                error_log("PMP: Step 1 - DELETE error: {$wpdb->last_error}");
            }
        }
        
        // Step 2: INSERT using raw query
        $insert_sql = $wpdb->prepare(
            "INSERT INTO {$table_name} (post_id, meta_key, meta_value) VALUES (%d, %s, %s)",
            $post_id,
            '_pmp_protected',
            $protection_value
        );
        $insert_result = $wpdb->query($insert_sql);
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("PMP: Step 2 - INSERT query: {$insert_sql}");
            error_log("PMP: Step 2 - INSERT result: " . var_export($insert_result, true));
            if ($wpdb->last_error) {
                error_log("PMP: Step 2 - INSERT error: {$wpdb->last_error}");
            }
        }
        
        // Step 3: IMMEDIATE verification
        $verify_sql = $wpdb->prepare(
            "SELECT meta_value FROM {$table_name} WHERE post_id = %d AND meta_key = %s",
            $post_id,
            '_pmp_protected'
        );
        $verify_result = $wpdb->get_var($verify_sql);
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("PMP: Step 3 - VERIFY query: {$verify_sql}");
            error_log("PMP: Step 3 - VERIFY result: " . var_export($verify_result, true));
        }
        
        // Step 4: If verification failed, try REPLACE INTO
        if ($verify_result !== $protection_value) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP: Step 4 - VERIFICATION FAILED! Using REPLACE INTO...");
                error_log("PMP: Expected: '{$protection_value}', Got: " . var_export($verify_result, true));
            }
            
            // REPLACE INTO will insert or update
            $replace_sql = $wpdb->prepare(
                "REPLACE INTO {$table_name} (post_id, meta_key, meta_value) 
                 SELECT %d, %s, %s FROM DUAL
                 WHERE NOT EXISTS (
                     SELECT 1 FROM {$table_name} WHERE post_id = %d AND meta_key = %s AND meta_value = %s
                 )
                 UNION ALL
                 SELECT post_id, meta_key, %s FROM {$table_name} 
                 WHERE post_id = %d AND meta_key = %s
                 LIMIT 1",
                $post_id, '_pmp_protected', $protection_value,
                $post_id, '_pmp_protected', $protection_value,
                $protection_value, $post_id, '_pmp_protected'
            );
            
            // Actually, REPLACE INTO is simpler:
            $replace_sql = "REPLACE INTO {$table_name} (post_id, meta_key, meta_value) VALUES ({$post_id}, '_pmp_protected', '{$protection_value}')";
            $replace_result = $wpdb->query($replace_sql);
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP: Step 4 - REPLACE query: {$replace_sql}");
                error_log("PMP: Step 4 - REPLACE result: " . var_export($replace_result, true));
                if ($wpdb->last_error) {
                    error_log("PMP: Step 4 - REPLACE error: {$wpdb->last_error}");
                }
            }
            
            // Re-verify
            $verify_result = $wpdb->get_var($verify_sql);
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP: Step 4 - VERIFY after REPLACE: " . var_export($verify_result, true));
            }
        }
        
        // Step 5: Final sanity check - count rows
        $count_sql = $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table_name} WHERE post_id = %d AND meta_key = %s",
            $post_id,
            '_pmp_protected'
        );
        $row_count = $wpdb->get_var($count_sql);
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("PMP: Step 5 - Row count: {$row_count}");
            
            if ($row_count == 0) {
                error_log("PMP: ❌ CRITICAL - NO ROWS EXIST!");
            } elseif ($verify_result === $protection_value) {
                error_log("PMP: ✅ SUCCESS - Value is '{$verify_result}'");
            } else {
                error_log("PMP: ❌ FAILED - Value is '" . var_export($verify_result, true) . "' (expected '{$protection_value}')");
            }
        }
        
        // Step 6: update_post_meta as backup
        update_post_meta($post_id, '_pmp_protected', $protection_value);
        
        // Step 6: Final verification using get_post_meta
        $final_check = get_post_meta($post_id, '_pmp_protected', true);
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("PMP Inline Save - FINAL VERIFICATION:");
            error_log("  Direct SQL: " . var_export($verify_sql, true));
            error_log("  get_post_meta: " . var_export($final_check, true));
            error_log("  SUCCESS: " . ($verify_sql === $protection_value ? 'YES ✅' : 'NO ❌'));
        }
        
        // CRITICAL: If STILL not saved, this is a serious problem - force one last time
        if ($verify_sql !== $protection_value || $final_check !== $protection_value) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP Inline Save - CRITICAL: Value still not correct! FORCING FINAL TIME...");
            }
            
            // Nuclear option: Raw SQL with no conditions
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_pmp_protected'",
                $post_id
            ));
            
            $wpdb->query($wpdb->prepare(
                "INSERT INTO {$wpdb->postmeta} (post_id, meta_key, meta_value) VALUES (%d, '_pmp_protected', %s)",
                $post_id,
                $protection_value
            ));
            
            // Final final check
            $absolute_final = $wpdb->get_var($wpdb->prepare(
                "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_pmp_protected'",
                $post_id
            ));
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("  ABSOLUTE FINAL VALUE: " . var_export($absolute_final, true));
            }
        }
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("=== PMP Inline Save END ===");
        }
        
        // Save required levels
        if ($enable_protection && !empty($selected_levels)) {
            update_post_meta($post_id, '_pmp_required_levels', $selected_levels);
        } else {
            delete_post_meta($post_id, '_pmp_required_levels');
        }
        
        // CRITICAL: Clear WordPress object cache to force fresh reads
        wp_cache_delete($post_id, 'post_meta');
        clean_post_cache($post_id);
        
        // Get updated display HTML - force fresh database read
        global $wpdb;
        $required_levels = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_pmp_required_levels'",
            $post_id
        ));
        if ($required_levels) {
            $required_levels = maybe_unserialize($required_levels);
        }
        
        $is_protected = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_pmp_protected'",
            $post_id
        ));
        
        ob_start();
        
        if (!$is_protected) {
            echo '<span class="pmp-level-none" title="' . esc_attr__('Klikněte pro úpravu', 'premium-membership-pro') . '">';
            echo '<span class="dashicons dashicons-unlock"></span> ';
            echo '<span class="pmp-level-text">' . __('Veřejný', 'premium-membership-pro') . '</span>';
            echo '</span>';
        } elseif (empty($required_levels) || !is_array($required_levels)) {
            echo '<span class="pmp-level-any" title="' . esc_attr__('Klikněte pro úpravu', 'premium-membership-pro') . '">';
            echo '<span class="dashicons dashicons-groups"></span> ';
            echo '<span class="pmp-level-text">' . __('Jakékoli', 'premium-membership-pro') . '</span>';
            echo '</span>';
        } else {
            // Get level names
            $level_names = array();
            foreach ($required_levels as $level_id) {
                $level = get_post($level_id);
                if ($level) {
                    $level_names[] = $level->post_title;
                }
            }
            
            if (empty($level_names)) {
                echo '<span class="pmp-level-error" title="' . esc_attr__('Klikněte pro úpravu', 'premium-membership-pro') . '">';
                echo '<span class="dashicons dashicons-warning"></span> ';
                echo '<span class="pmp-level-text">' . __('Chyba', 'premium-membership-pro') . '</span>';
                echo '</span>';
            } else {
                // Display levels
                $count = count($level_names);
                $display_names = array_slice($level_names, 0, 2);
                $tooltip = __('Klikněte pro úpravu: ', 'premium-membership-pro') . implode(', ', $level_names);
                
                echo '<div class="pmp-levels-badges" title="' . esc_attr($tooltip) . '">';
                
                foreach ($display_names as $name) {
                    echo '<span class="pmp-level-badge">' . esc_html($name) . '</span>';
                }
                
                if ($count > 2) {
                    echo '<span class="pmp-level-more">+' . ($count - 2) . '</span>';
                }
                
                echo '</div>';
            }
        }
        
        echo '<span class="dashicons dashicons-edit pmp-edit-icon" title="' . esc_attr__('Upravit úrovně', 'premium-membership-pro') . '"></span>';
        
        $display_html = ob_get_clean();
        
        wp_send_json_success(array(
            'message' => __('Úrovně byly úspěšně uloženy.', 'premium-membership-pro'),
            'display_html' => $display_html,
        ));
    }
    
    /**
     * Enqueue scripts
     */
    public static function enqueue_scripts($hook) {
        if ($hook !== 'edit.php') {
            return;
        }
        
        wp_enqueue_style('pmp-post-level-column', PMP_PLUGIN_URL . 'assets/css/post-level-column.css', array(), PMP_VERSION);
        wp_enqueue_script('pmp-post-level-column', PMP_PLUGIN_URL . 'assets/js/post-level-column.js', array('jquery'), PMP_VERSION, true);
        
        wp_localize_script('pmp-post-level-column', 'pmpLevelColumn', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('bulk-posts'),
            'inline_nonce' => wp_create_nonce('pmp-inline-edit'),
        ));
    }
}
