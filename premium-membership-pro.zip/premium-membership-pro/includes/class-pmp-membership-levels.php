<?php
/**
 * Membership Levels Management Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Membership_Levels {
    
    public static function init() {
        add_action('add_meta_boxes', array(__CLASS__, 'add_meta_boxes'));
        add_action('save_post_pmp_membership', array(__CLASS__, 'save_membership_meta'));
    }
    
    public static function add_meta_boxes() {
        add_meta_box(
            'pmp_membership_icon',
            __('👑 Ikona úrovně', 'premium-membership-pro'),
            array(__CLASS__, 'render_icon_meta_box'),
            'pmp_membership',
            'side',
            'high'
        );
        
        add_meta_box(
            'pmp_membership_settings',
            __('Nastavení členství', 'premium-membership-pro'),
            array(__CLASS__, 'render_membership_settings_meta_box'),
            'pmp_membership',
            'normal',
            'high'
        );
        
        add_meta_box(
            'pmp_membership_pricing',
            __('Cenová nastavení', 'premium-membership-pro'),
            array(__CLASS__, 'render_pricing_meta_box'),
            'pmp_membership',
            'normal',
            'high'
        );
        
        add_meta_box(
            'pmp_membership_access',
            __('Přístupová pravidla', 'premium-membership-pro'),
            array(__CLASS__, 'render_access_rules_meta_box'),
            'pmp_membership',
            'normal',
            'high'
        );
    }
    
    public static function render_icon_meta_box($post) {
        wp_nonce_field('pmp_membership_icon', 'pmp_membership_icon_nonce');
        
        $current_icon = get_post_meta($post->ID, '_pmp_icon', true) ?: '⭐';
        
        $royal_icons = array(
            '👑' => 'Koruna (Premium/Král)',
            '💎' => 'Diamant (VIP)',
            '⭐' => 'Hvězda (Standard)',
            '🌟' => 'Hvězda zářivá',
            '✨' => 'Jiskry (Magic)',
            '🏆' => 'Pohár (Champion)',
            '🔱' => 'Trojzubec (Elite)',
            '💫' => 'Hvězda kometa',
            '🎖️' => 'Medaile',
            '🥇' => 'Zlatá medaile',
            '🥈' => 'Stříbrná medaile',
            '🥉' => 'Bronzová medaile',
            '🔰' => 'Začátečník',
            '⚜️' => 'Fleur-de-lis (Royal)',
            '🌺' => 'Květina',
            '🔥' => 'Oheň (Hot)',
            '⚡' => 'Blesk (Power)',
            '🎯' => 'Terč (Target)',
            '🎁' => 'Dárek',
            '🎓' => 'Studenti',
            '💼' => 'Business',
            '🚀' => 'Raketa (Growth)',
            '🌈' => 'Duha',
            '🎪' => 'Cirkus (Fun)',
            '🎭' => 'Divadlo',
        );
        
        ?>
        <div class="pmp-icon-picker">
            <p><strong><?php _e('Vybraná ikona:', 'premium-membership-pro'); ?></strong></p>
            <div class="pmp-current-icon" style="font-size: 48px; text-align: center; padding: 20px; background: #f0f0f1; border-radius: 8px; margin-bottom: 15px;">
                <span id="pmp-icon-preview"><?php echo $current_icon; ?></span>
            </div>
            
            <input type="hidden" name="pmp_icon" id="pmp-icon-input" value="<?php echo esc_attr($current_icon); ?>">
            
            <p><strong><?php _e('Klikni pro výběr:', 'premium-membership-pro'); ?></strong></p>
            <div class="pmp-icon-grid" style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px; max-height: 400px; overflow-y: auto; padding: 10px; background: #fff; border: 1px solid #ddd; border-radius: 4px;">
                <?php foreach ($royal_icons as $icon => $label): ?>
                    <button type="button" class="pmp-icon-option" data-icon="<?php echo esc_attr($icon); ?>" title="<?php echo esc_attr($label); ?>" style="font-size: 32px; padding: 10px; border: 2px solid #ddd; background: white; cursor: pointer; border-radius: 6px; transition: all 0.2s; <?php echo $icon === $current_icon ? 'border-color: #2271b1; background: #f0f6fc;' : ''; ?>">
                        <?php echo $icon; ?>
                    </button>
                <?php endforeach; ?>
            </div>
            
            <p class="description" style="margin-top: 10px;">
                <?php _e('Ikona se zobrazí vedle názvu úrovně v celém systému.', 'premium-membership-pro'); ?>
            </p>
        </div>
        
        <style>
        .pmp-icon-option:hover {
            border-color: #2271b1 !important;
            background: #f0f6fc !important;
            transform: scale(1.1);
        }
        .pmp-icon-option.selected {
            border-color: #2271b1 !important;
            background: #f0f6fc !important;
            box-shadow: 0 0 0 1px #2271b1;
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            $('.pmp-icon-option').on('click', function(e) {
                e.preventDefault();
                var icon = $(this).data('icon');
                
                // Update hidden input
                $('#pmp-icon-input').val(icon);
                
                // Update preview
                $('#pmp-icon-preview').text(icon);
                
                // Update selected state
                $('.pmp-icon-option').removeClass('selected').css({
                    'border-color': '#ddd',
                    'background': 'white'
                });
                $(this).addClass('selected').css({
                    'border-color': '#2271b1',
                    'background': '#f0f6fc'
                });
            });
        });
        </script>
        <?php
    }
    
    public static function render_membership_settings_meta_box($post) {
        wp_nonce_field('pmp_membership_settings', 'pmp_membership_settings_nonce');
        
        $billing_type = get_post_meta($post->ID, '_pmp_billing_type', true) ?: 'recurring';
        $period = get_post_meta($post->ID, '_pmp_period', true) ?: 'month';
        $period_count = get_post_meta($post->ID, '_pmp_period_count', true) ?: '1';
        $trial_enabled = get_post_meta($post->ID, '_pmp_trial_enabled', true);
        $trial_days = get_post_meta($post->ID, '_pmp_trial_days', true) ?: '7';
        $limit_access = get_post_meta($post->ID, '_pmp_limit_access', true);
        $max_content = get_post_meta($post->ID, '_pmp_max_content', true) ?: '0';
        ?>
        <table class="form-table">
            <tr>
                <th><label for="pmp_billing_type"><?php _e('Typ fakturace', 'premium-membership-pro'); ?></label></th>
                <td>
                    <select name="pmp_billing_type" id="pmp_billing_type">
                        <option value="recurring" <?php selected($billing_type, 'recurring'); ?>><?php _e('Opakující se', 'premium-membership-pro'); ?></option>
                        <option value="lifetime" <?php selected($billing_type, 'lifetime'); ?>><?php _e('Doživotní', 'premium-membership-pro'); ?></option>
                        <option value="fixed" <?php selected($billing_type, 'fixed'); ?>><?php _e('Pevné období', 'premium-membership-pro'); ?></option>
                    </select>
                </td>
            </tr>
            <tr class="recurring-field">
                <th><label for="pmp_period_count"><?php _e('Perioda', 'premium-membership-pro'); ?></label></th>
                <td>
                    <input type="number" name="pmp_period_count" id="pmp_period_count" value="<?php echo esc_attr($period_count); ?>" min="1" style="width: 80px;">
                    <select name="pmp_period" id="pmp_period">
                        <option value="day" <?php selected($period, 'day'); ?>><?php _e('den/dny/dnů', 'premium-membership-pro'); ?></option>
                        <option value="week" <?php selected($period, 'week'); ?>><?php _e('týden/týdny/týdnů', 'premium-membership-pro'); ?></option>
                        <option value="month" <?php selected($period, 'month'); ?>><?php _e('měsíc/měsíce/měsíců', 'premium-membership-pro'); ?></option>
                        <option value="year" <?php selected($period, 'year'); ?>><?php _e('rok/roky/let', 'premium-membership-pro'); ?></option>
                    </select>
                </td>
            </tr>
            <tr>
                <th><label for="pmp_trial_enabled"><?php _e('Zkušební období', 'premium-membership-pro'); ?></label></th>
                <td>
                    <label>
                        <input type="checkbox" name="pmp_trial_enabled" id="pmp_trial_enabled" value="1" <?php checked($trial_enabled, '1'); ?>>
                        <?php _e('Povolit zkušební období', 'premium-membership-pro'); ?>
                    </label>
                    <br>
                    <input type="number" name="pmp_trial_days" id="pmp_trial_days" value="<?php echo esc_attr($trial_days); ?>" min="1" style="width: 80px; margin-top: 5px;">
                    <?php _e('dnů zdarma', 'premium-membership-pro'); ?>
                </td>
            </tr>
            <tr>
                <th><label for="pmp_limit_access"><?php _e('Limit přístupu k obsahu', 'premium-membership-pro'); ?></label></th>
                <td>
                    <label>
                        <input type="checkbox" name="pmp_limit_access" id="pmp_limit_access" value="1" <?php checked($limit_access, '1'); ?>>
                        <?php _e('Omezit počet přístupů', 'premium-membership-pro'); ?>
                    </label>
                    <br>
                    <input type="number" name="pmp_max_content" id="pmp_max_content" value="<?php echo esc_attr($max_content); ?>" min="0" style="width: 80px; margin-top: 5px;">
                    <?php _e('max. článků za měsíc', 'premium-membership-pro'); ?>
                </td>
            </tr>
        </table>
        <?php
    }
    
    public static function render_pricing_meta_box($post) {
        $price = get_post_meta($post->ID, '_pmp_price', true) ?: '';
        $setup_fee = get_post_meta($post->ID, '_pmp_setup_fee', true) ?: '';
        $tax_rate = get_post_meta($post->ID, '_pmp_tax_rate', true) ?: '';
        ?>
        <table class="form-table">
            <tr>
                <th><label for="pmp_price"><?php _e('Cena', 'premium-membership-pro'); ?></label></th>
                <td>
                    <input type="number" name="pmp_price" id="pmp_price" value="<?php echo esc_attr($price); ?>" step="0.01" min="0">
                    <?php echo get_option('pmp_currency', 'CZK'); ?>
                </td>
            </tr>
            <tr>
                <th><label for="pmp_setup_fee"><?php _e('Poplatek za aktivaci', 'premium-membership-pro'); ?></label></th>
                <td>
                    <input type="number" name="pmp_setup_fee" id="pmp_setup_fee" value="<?php echo esc_attr($setup_fee); ?>" step="0.01" min="0">
                    <?php echo get_option('pmp_currency', 'CZK'); ?>
                </td>
            </tr>
            <tr>
                <th><label for="pmp_tax_rate"><?php _e('DPH (%)', 'premium-membership-pro'); ?></label></th>
                <td>
                    <input type="number" name="pmp_tax_rate" id="pmp_tax_rate" value="<?php echo esc_attr($tax_rate); ?>" step="0.01" min="0" max="100">
                    <span class="description"><?php _e('Např. 21 pro 21% DPH', 'premium-membership-pro'); ?></span>
                </td>
            </tr>
        </table>
        <?php
    }
    
    public static function render_access_rules_meta_box($post) {
        $access_type = get_post_meta($post->ID, '_pmp_access_type', true) ?: 'all';
        $allowed_categories = get_post_meta($post->ID, '_pmp_allowed_categories', true) ?: array();
        $allowed_posts = get_post_meta($post->ID, '_pmp_allowed_posts', true) ?: array();
        $allowed_groups = get_post_meta($post->ID, '_pmp_allowed_groups', true) ?: array();
        ?>
        <table class="form-table">
            <tr>
                <th><label for="pmp_access_type"><?php _e('Typ přístupu', 'premium-membership-pro'); ?></label></th>
                <td>
                    <select name="pmp_access_type" id="pmp_access_type">
                        <option value="all" <?php selected($access_type, 'all'); ?>><?php _e('Přístup ke všemu obsahu', 'premium-membership-pro'); ?></option>
                        <option value="groups" <?php selected($access_type, 'groups'); ?>><?php _e('Pouze vybrané skupiny obsahu', 'premium-membership-pro'); ?></option>
                        <option value="categories" <?php selected($access_type, 'categories'); ?>><?php _e('Pouze vybrané kategorie', 'premium-membership-pro'); ?></option>
                        <option value="posts" <?php selected($access_type, 'posts'); ?>><?php _e('Pouze vybrané příspěvky', 'premium-membership-pro'); ?></option>
                        <option value="mixed" <?php selected($access_type, 'mixed'); ?>><?php _e('Kombinace skupin, kategorií a příspěvků', 'premium-membership-pro'); ?></option>
                    </select>
                    <p class="description">
                        <?php _e('Vyberte, jak tato úroveň členství řídí přístup k obsahu', 'premium-membership-pro'); ?>
                    </p>
                </td>
            </tr>
            <tr class="access-groups" style="display:none;">
                <th><label><?php _e('Povolené skupiny obsahu', 'premium-membership-pro'); ?></label></th>
                <td>
                    <p class="description" style="margin-bottom: 10px;">
                        <strong><?php _e('Tip:', 'premium-membership-pro'); ?></strong> 
                        <?php _e('Skupiny obsahu vám umožní organizovat články do logických celků (např. "Pokročilé tutoriály", "Exkluzivní rozhovory").', 'premium-membership-pro'); ?>
                    </p>
                    <?php
                    $groups = get_terms(array(
                        'taxonomy' => 'pmp_content_group',
                        'hide_empty' => false,
                    ));
                    
                    if (!empty($groups) && !is_wp_error($groups)) {
                        foreach ($groups as $group) {
                            $checked = in_array($group->term_id, (array)$allowed_groups);
                            $count = $group->count;
                            echo '<label style="display: block; margin: 8px 0; padding: 8px; background: #f9f9f9; border-radius: 4px;">';
                            echo '<input type="checkbox" name="pmp_allowed_groups[]" value="' . $group->term_id . '" ' . checked($checked, true, false) . '>';
                            echo ' <strong>' . esc_html($group->name) . '</strong>';
                            if ($group->description) {
                                echo ' <span style="color: #666;">- ' . esc_html($group->description) . '</span>';
                            }
                            echo ' <em style="color: #999;">(' . sprintf(_n('%d článek', '%d články/ů', $count, 'premium-membership-pro'), $count) . ')</em>';
                            echo '</label>';
                        }
                    } else {
                        echo '<p style="background: #fff3cd; padding: 12px; border-left: 4px solid #ffc107; border-radius: 4px;">';
                        echo '⚠️ ' . __('Zatím nejsou vytvořeny žádné skupiny obsahu.', 'premium-membership-pro');
                        echo ' <a href="' . admin_url('edit-tags.php?taxonomy=pmp_content_group') . '">' . __('Vytvořit první skupinu', 'premium-membership-pro') . '</a>';
                        echo '</p>';
                    }
                    ?>
                </td>
            </tr>
            <tr class="access-categories" style="display:none;">
                <th><label><?php _e('Povolené kategorie', 'premium-membership-pro'); ?></label></th>
                <td>
                    <?php
                    $categories = get_categories(array('hide_empty' => false));
                    foreach ($categories as $category) {
                        $checked = in_array($category->term_id, (array)$allowed_categories);
                        echo '<label style="display: block; margin: 5px 0;">';
                        echo '<input type="checkbox" name="pmp_allowed_categories[]" value="' . $category->term_id . '" ' . checked($checked, true, false) . '>';
                        echo ' ' . esc_html($category->name);
                        echo '</label>';
                    }
                    ?>
                </td>
            </tr>
        </table>
        
        <script>
        jQuery(document).ready(function($) {
            $('#pmp_access_type').on('change', function() {
                var type = $(this).val();
                $('.access-groups, .access-categories, .access-posts').hide();
                
                if (type === 'groups' || type === 'mixed') {
                    $('.access-groups').show();
                }
                if (type === 'categories' || type === 'mixed') {
                    $('.access-categories').show();
                }
                if (type === 'posts' || type === 'mixed') {
                    $('.access-posts').show();
                }
            }).trigger('change');
        });
        </script>
        <?php
    }
    
    public static function save_membership_meta($post_id) {
        // Save icon
        if (isset($_POST['pmp_membership_icon_nonce']) && 
            wp_verify_nonce($_POST['pmp_membership_icon_nonce'], 'pmp_membership_icon')) {
            if (isset($_POST['pmp_icon'])) {
                update_post_meta($post_id, '_pmp_icon', sanitize_text_field($_POST['pmp_icon']));
            }
        }
        
        if (!isset($_POST['pmp_membership_settings_nonce']) || 
            !wp_verify_nonce($_POST['pmp_membership_settings_nonce'], 'pmp_membership_settings')) {
            return;
        }
        
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Save settings
        $fields = array(
            'pmp_billing_type',
            'pmp_period',
            'pmp_period_count',
            'pmp_trial_enabled',
            'pmp_trial_days',
            'pmp_limit_access',
            'pmp_max_content',
            'pmp_price',
            'pmp_setup_fee',
            'pmp_tax_rate',
            'pmp_access_type',
        );
        
        foreach ($fields as $field) {
            if (isset($_POST[$field])) {
                update_post_meta($post_id, '_' . $field, sanitize_text_field($_POST[$field]));
            } else {
                delete_post_meta($post_id, '_' . $field);
            }
        }
        
        // Save arrays
        if (isset($_POST['pmp_allowed_categories'])) {
            update_post_meta($post_id, '_pmp_allowed_categories', array_map('intval', $_POST['pmp_allowed_categories']));
        } else {
            delete_post_meta($post_id, '_pmp_allowed_categories');
        }
        
        if (isset($_POST['pmp_allowed_groups'])) {
            update_post_meta($post_id, '_pmp_allowed_groups', array_map('intval', $_POST['pmp_allowed_groups']));
        } else {
            delete_post_meta($post_id, '_pmp_allowed_groups');
        }
    }
    
    public static function get_level_details($level_id) {
        $post = get_post($level_id);
        if (!$post || $post->post_type !== 'pmp_membership') {
            return false;
        }
        
        return array(
            'id' => $level_id,
            'name' => $post->post_title,
            'description' => $post->post_content,
            'price' => get_post_meta($level_id, '_pmp_price', true),
            'billing_type' => get_post_meta($level_id, '_pmp_billing_type', true),
            'period' => get_post_meta($level_id, '_pmp_period', true),
            'period_count' => get_post_meta($level_id, '_pmp_period_count', true),
            'trial_enabled' => get_post_meta($level_id, '_pmp_trial_enabled', true),
            'trial_days' => get_post_meta($level_id, '_pmp_trial_days', true),
        );
    }
    
    public static function get_all_levels() {
        $levels = get_posts(array(
            'post_type' => 'pmp_membership',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'orderby' => 'menu_order',
            'order' => 'ASC',
        ));
        
        $result = array();
        foreach ($levels as $level) {
            $result[] = self::get_level_details($level->ID);
        }
        
        return $result;
    }
}
