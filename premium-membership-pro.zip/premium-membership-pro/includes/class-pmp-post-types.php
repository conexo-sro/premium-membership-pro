<?php
/**
 * Custom Post Types Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Post_Types {
    
    public static function init() {
        add_action('init', array(__CLASS__, 'register_post_types'));
        add_action('init', array(__CLASS__, 'register_taxonomies'));
    }
    
    public static function register_post_types() {
        // Membership Levels
        register_post_type('pmp_membership', array(
            'labels' => array(
                'name' => __('Úrovně členství', 'premium-membership-pro'),
                'singular_name' => __('Úroveň členství', 'premium-membership-pro'),
                'add_new' => __('Přidat novou', 'premium-membership-pro'),
                'add_new_item' => __('Přidat novou úroveň', 'premium-membership-pro'),
                'edit_item' => __('Upravit úroveň', 'premium-membership-pro'),
                'new_item' => __('Nová úroveň', 'premium-membership-pro'),
                'view_item' => __('Zobrazit úroveň', 'premium-membership-pro'),
                'search_items' => __('Hledat úrovně', 'premium-membership-pro'),
                'not_found' => __('Žádné úrovně nenalezeny', 'premium-membership-pro'),
            ),
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => false,
            'capability_type' => 'post',
            'hierarchical' => false,
            'supports' => array('title', 'editor', 'thumbnail'),
            'has_archive' => false,
            'rewrite' => false,
        ));
        
        // Digital Products
        register_post_type('pmp_product', array(
            'labels' => array(
                'name' => __('Digitální produkty', 'premium-membership-pro'),
                'singular_name' => __('Digitální produkt', 'premium-membership-pro'),
                'add_new' => __('Přidat nový', 'premium-membership-pro'),
                'add_new_item' => __('Přidat nový produkt', 'premium-membership-pro'),
                'edit_item' => __('Upravit produkt', 'premium-membership-pro'),
            ),
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => false,
            'supports' => array('title', 'editor', 'thumbnail'),
            'has_archive' => false,
        ));
        
        // Coupons
        register_post_type('pmp_coupon', array(
            'labels' => array(
                'name' => __('Kupóny', 'premium-membership-pro'),
                'singular_name' => __('Kupón', 'premium-membership-pro'),
                'add_new' => __('Přidat nový', 'premium-membership-pro'),
                'add_new_item' => __('Přidat nový kupón', 'premium-membership-pro'),
                'edit_item' => __('Upravit kupón', 'premium-membership-pro'),
            ),
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => false,
            'supports' => array('title'),
            'has_archive' => false,
        ));
    }
    
    public static function register_taxonomies() {
        // Product categories
        register_taxonomy('pmp_product_category', 'pmp_product', array(
            'labels' => array(
                'name' => __('Kategorie produktů', 'premium-membership-pro'),
                'singular_name' => __('Kategorie produktu', 'premium-membership-pro'),
            ),
            'hierarchical' => true,
            'show_ui' => true,
            'show_admin_column' => true,
            'query_var' => true,
        ));
        
        // Content Groups - for organizing protected content
        register_taxonomy('pmp_content_group', array('post', 'page'), array(
            'labels' => array(
                'name' => __('Skupiny obsahu', 'premium-membership-pro'),
                'singular_name' => __('Skupina obsahu', 'premium-membership-pro'),
                'all_items' => __('Všechny skupiny', 'premium-membership-pro'),
                'edit_item' => __('Upravit skupinu', 'premium-membership-pro'),
                'view_item' => __('Zobrazit skupinu', 'premium-membership-pro'),
                'update_item' => __('Aktualizovat skupinu', 'premium-membership-pro'),
                'add_new_item' => __('Přidat novou skupinu', 'premium-membership-pro'),
                'new_item_name' => __('Nová skupina obsahu', 'premium-membership-pro'),
                'search_items' => __('Hledat skupiny', 'premium-membership-pro'),
                'popular_items' => __('Populární skupiny', 'premium-membership-pro'),
                'menu_name' => __('Skupiny obsahu', 'premium-membership-pro'),
            ),
            'hierarchical' => true,
            'show_ui' => true,
            'show_admin_column' => true,
            'show_in_rest' => true,
            'query_var' => true,
            'rewrite' => array('slug' => 'content-group'),
            'public' => false,
            'show_in_nav_menus' => false,
        ));
    }
}
