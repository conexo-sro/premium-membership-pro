<?php
/**
 * Preview Mode - View site as different membership level
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Preview_Mode {
    
    /**
     * Initialize preview mode
     */
    public static function init() {
        // Add admin bar menu
        add_action('admin_bar_menu', array(__CLASS__, 'add_admin_bar_menu'), 100);
        
        // Handle preview mode switching
        add_action('init', array(__CLASS__, 'handle_preview_switch'));
        
        // Override membership check when in preview mode
        add_filter('pmp_user_has_access', array(__CLASS__, 'override_access_check'), 10, 3);
        
        // Add preview notice
        add_action('wp_footer', array(__CLASS__, 'add_preview_notice'));
        add_action('admin_footer', array(__CLASS__, 'add_preview_notice'));
        
        // Add styles
        add_action('wp_head', array(__CLASS__, 'add_preview_styles'));
        add_action('admin_head', array(__CLASS__, 'add_preview_styles'));
    }
    
    /**
     * Check if preview mode is active
     */
    public static function is_preview_mode() {
        return isset($_SESSION['pmp_preview_level']) || isset($_COOKIE['pmp_preview_level']);
    }
    
    /**
     * Get current preview level
     */
    public static function get_preview_level() {
        if (!session_id()) {
            @session_start();
        }
        
        if (isset($_SESSION['pmp_preview_level'])) {
            return intval($_SESSION['pmp_preview_level']);
        }
        
        if (isset($_COOKIE['pmp_preview_level'])) {
            return intval($_COOKIE['pmp_preview_level']);
        }
        
        return 0;
    }
    
    /**
     * Handle preview mode switching
     */
    public static function handle_preview_switch() {
        // Only for admins
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Start session if not started
        if (!session_id()) {
            @session_start();
        }
        
        // Switch to preview level
        if (isset($_GET['pmp_preview_level']) && check_admin_referer('pmp_preview_switch', 'pmp_nonce')) {
            $level = intval($_GET['pmp_preview_level']);
            
            if ($level > 0) {
                $_SESSION['pmp_preview_level'] = $level;
                setcookie('pmp_preview_level', $level, time() + 3600, '/');
            } else {
                // Exit preview mode
                unset($_SESSION['pmp_preview_level']);
                setcookie('pmp_preview_level', '', time() - 3600, '/');
            }
            
            // Redirect back without query params
            $redirect = remove_query_arg(array('pmp_preview_level', 'pmp_nonce'));
            wp_redirect($redirect);
            exit;
        }
    }
    
    /**
     * Override access check when in preview mode
     */
    public static function override_access_check($has_access, $post_id, $user_id) {
        // Only for admins
        if (!current_user_can('manage_options')) {
            return $has_access;
        }
        
        // Not in preview mode
        if (!self::is_preview_mode()) {
            return $has_access;
        }
        
        $preview_level = self::get_preview_level();
        
        // Get required levels for this post
        $required_levels = get_post_meta($post_id, '_pmp_required_levels', true);
        
        if (empty($required_levels)) {
            // No levels required = public
            return true;
        }
        
        // Check if preview level is in required levels
        return in_array($preview_level, $required_levels);
    }
    
    /**
     * Add admin bar menu
     */
    public static function add_admin_bar_menu($wp_admin_bar) {
        // Only for admins
        if (!current_user_can('manage_options')) {
            return;
        }
        
        global $wpdb;
        
        // Get all levels from database
        $levels = $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}pmp_membership_levels 
            WHERE is_active = 1 
            ORDER BY sort_order ASC, id ASC"
        );
        
        $current_preview = self::get_preview_level();
        $is_preview = self::is_preview_mode();
        
        // Get current level name
        $current_level_name = 'Normal View';
        if ($is_preview && $current_preview > 0) {
            $level = $wpdb->get_row($wpdb->prepare(
                "SELECT name FROM {$wpdb->prefix}pmp_membership_levels WHERE id = %d",
                $current_preview
            ));
            if ($level) {
                $current_level_name = $level->name;
            }
        }
        
        // Main menu item
        $wp_admin_bar->add_node(array(
            'id' => 'pmp-preview-mode',
            'title' => $is_preview 
                ? '👁️ Preview: <strong>' . esc_html($current_level_name) . '</strong>'
                : '👁️ Preview Mode',
            'href' => '#',
            'meta' => array(
                'class' => $is_preview ? 'pmp-preview-active' : ''
            )
        ));
        
        // Exit preview mode option
        if ($is_preview) {
            $wp_admin_bar->add_node(array(
                'parent' => 'pmp-preview-mode',
                'id' => 'pmp-exit-preview',
                'title' => '❌ Exit Preview Mode',
                'href' => wp_nonce_url(add_query_arg('pmp_preview_level', '0'), 'pmp_preview_switch', 'pmp_nonce')
            ));
            
            $wp_admin_bar->add_node(array(
                'parent' => 'pmp-preview-mode',
                'id' => 'pmp-preview-divider',
                'title' => '───────────────',
                'meta' => array('class' => 'pmp-divider')
            ));
        }
        
        // Public / No membership option
        $wp_admin_bar->add_node(array(
            'parent' => 'pmp-preview-mode',
            'id' => 'pmp-preview-public',
            'title' => (!$is_preview ? '✓ ' : '') . '🌍 Public (No Membership)',
            'href' => wp_nonce_url(add_query_arg('pmp_preview_level', '0'), 'pmp_preview_switch', 'pmp_nonce')
        ));
        
        // Level options
        foreach ($levels as $level) {
            $is_current = $is_preview && $current_preview === $level->ID;
            $level_icon = get_post_meta($level->ID, '_pmp_icon', true) ?: '⭐';
            
            $wp_admin_bar->add_node(array(
                'parent' => 'pmp-preview-mode',
                'id' => 'pmp-preview-level-' . $level->ID,
                'title' => ($is_current ? '✓ ' : '') . $level_icon . ' ' . esc_html($level->post_title),
                'href' => wp_nonce_url(add_query_arg('pmp_preview_level', $level->ID), 'pmp_preview_switch', 'pmp_nonce')
            ));
        }
    }
    
    /**
     * Add preview notice
     */
    public static function add_preview_notice() {
        if (!self::is_preview_mode() || !current_user_can('manage_options')) {
            return;
        }
        
        $level = self::get_preview_level();
        $level_post = get_post($level);
        $level_name = $level_post ? $level_post->post_title : 'Unknown';
        
        $exit_url = wp_nonce_url(add_query_arg('pmp_preview_level', '0'), 'pmp_preview_switch', 'pmp_nonce');
        
        ?>
        <div id="pmp-preview-notice">
            <div class="pmp-preview-notice-content">
                <span class="pmp-preview-icon">👁️</span>
                <span class="pmp-preview-text">
                    Preview Mode: <strong><?php echo esc_html($level_name); ?></strong>
                </span>
                <a href="<?php echo esc_url($exit_url); ?>" class="pmp-preview-exit">
                    ❌ Exit Preview
                </a>
            </div>
        </div>
        <?php
    }
    
    /**
     * Add preview styles
     */
    public static function add_preview_styles() {
        if (!self::is_preview_mode() || !current_user_can('manage_options')) {
            return;
        }
        ?>
        <style>
        /* Admin bar preview mode styles */
        #wp-admin-bar-pmp-preview-mode.pmp-preview-active > .ab-item {
            background: #d63638 !important;
            color: white !important;
        }
        
        #wp-admin-bar-pmp-preview-mode.pmp-preview-active > .ab-item strong {
            color: #fff !important;
        }
        
        .pmp-divider {
            pointer-events: none;
            cursor: default !important;
        }
        
        .pmp-divider > .ab-item {
            color: #999 !important;
            font-size: 10px !important;
            padding: 0 10px !important;
        }
        
        /* Preview notice banner */
        #pmp-preview-notice {
            position: fixed;
            top: 32px;
            left: 0;
            right: 0;
            background: linear-gradient(135deg, #d63638 0%, #c92a2a 100%);
            color: white;
            padding: 12px 20px;
            z-index: 99999;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
            animation: slideDown 0.3s ease-out;
        }
        
        @media screen and (max-width: 782px) {
            #pmp-preview-notice {
                top: 46px;
            }
        }
        
        @media screen and (max-width: 600px) {
            #pmp-preview-notice {
                top: 0;
            }
        }
        
        @keyframes slideDown {
            from {
                transform: translateY(-100%);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .pmp-preview-notice-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            align-items: center;
            gap: 15px;
            font-size: 14px;
        }
        
        .pmp-preview-icon {
            font-size: 20px;
        }
        
        .pmp-preview-text {
            flex: 1;
        }
        
        .pmp-preview-text strong {
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .pmp-preview-exit {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 6px 15px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.2s;
        }
        
        .pmp-preview-exit:hover {
            background: rgba(255,255,255,0.3);
            color: white;
            text-decoration: none;
        }
        
        /* Adjust body padding when preview notice is visible */
        body.admin-bar {
            padding-top: 32px !important;
        }
        
        @media screen and (max-width: 782px) {
            body.admin-bar {
                padding-top: 46px !important;
            }
        }
        </style>
        <?php
    }
}
