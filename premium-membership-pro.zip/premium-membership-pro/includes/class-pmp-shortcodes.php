<?php
/**
 * Shortcodes Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Shortcodes {
    
    public static function init() {
        add_shortcode('pmp_membership_levels', array(__CLASS__, 'membership_levels'));
        add_shortcode('pmp_account', array(__CLASS__, 'account_page'));
        add_shortcode('pmp_login_form', array(__CLASS__, 'login_form'));
        add_shortcode('pmp_registration_form', array(__CLASS__, 'registration_form'));
        add_shortcode('pmp_member_content', array(__CLASS__, 'member_content'));
        add_shortcode('pmp_non_member_content', array(__CLASS__, 'non_member_content'));
        add_shortcode('pmp_has_membership', array(__CLASS__, 'has_membership'));
    }
    
    public static function membership_levels($atts) {
        $atts = shortcode_atts(array(
            'show' => 'all',
            'layout' => 'grid',
        ), $atts);
        
        $levels = PMP_Membership_Levels::get_all_levels();
        
        ob_start();
        include PMP_PLUGIN_DIR . 'templates/membership-levels.php';
        return ob_get_clean();
    }
    
    public static function account_page($atts) {
        if (!is_user_logged_in()) {
            return '<p>' . __('Pro zobrazení účtu se prosím přihlaste.', 'premium-membership-pro') . '</p>';
        }
        
        $user_id = get_current_user_id();
        $membership = PMP_User_Management::get_user_membership($user_id);
        $transactions = PMP_Payments::get_user_transactions($user_id);
        
        ob_start();
        include PMP_PLUGIN_DIR . 'templates/account.php';
        return ob_get_clean();
    }
    
    public static function login_form($atts) {
        if (is_user_logged_in()) {
            $user = wp_get_current_user();
            return '<div class="pmp-login-card" style="max-width: 500px; margin: 40px auto;">
                <div class="pmp-success-message">
                    ✓ Jste přihlášeni jako <strong>' . esc_html($user->display_name) . '</strong>
                </div>
                <div style="text-align: center; margin-top: 20px;">
                    <a href="' . get_permalink(get_option('pmp_account_page')) . '" class="pmp-select-level" style="margin: 0 10px;">' . __('Můj účet', 'premium-membership-pro') . '</a>
                    <a href="' . wp_logout_url() . '" class="pmp-cancel-membership" style="margin: 0 10px;">' . __('Odhlásit se', 'premium-membership-pro') . '</a>
                </div>
            </div>';
        }
        
        $atts = shortcode_atts(array(
            'redirect' => '',
        ), $atts);
        
        ob_start();
        include PMP_PLUGIN_DIR . 'templates/login-page.php';
        return ob_get_clean();
    }
    
    public static function registration_form($atts) {
        if (is_user_logged_in()) {
            $user = wp_get_current_user();
            return '<div class="pmp-login-card" style="max-width: 500px; margin: 40px auto;">
                <div class="pmp-success-message">
                    ✓ Jste již přihlášeni jako <strong>' . esc_html($user->display_name) . '</strong>
                </div>
                <div style="text-align: center; margin-top: 20px;">
                    <a href="' . get_permalink(get_option('pmp_account_page')) . '" class="pmp-select-level">' . __('Můj účet', 'premium-membership-pro') . '</a>
                </div>
            </div>';
        }
        
        $atts = shortcode_atts(array(
            'redirect' => '',
        ), $atts);
        
        ob_start();
        include PMP_PLUGIN_DIR . 'templates/registration-page.php';
        return ob_get_clean();
    }
    
    public static function member_content($atts, $content = '') {
        if (!is_user_logged_in()) {
            return '';
        }
        
        $atts = shortcode_atts(array(
            'levels' => '',
        ), $atts);
        
        if (!empty($atts['levels'])) {
            $required_levels = array_map('trim', explode(',', $atts['levels']));
            $user_membership = PMP_User_Management::get_user_membership(get_current_user_id());
            
            if (!$user_membership) {
                return '';
            }
            
            $level_slug = get_post_field('post_name', $user_membership->level_id);
            if (!in_array($level_slug, $required_levels)) {
                return '';
            }
        }
        
        return do_shortcode($content);
    }
    
    public static function non_member_content($atts, $content = '') {
        if (is_user_logged_in() && PMP_User_Management::user_has_active_membership(get_current_user_id())) {
            return '';
        }
        
        return do_shortcode($content);
    }
    
    public static function has_membership($atts, $content = '') {
        $atts = shortcode_atts(array(
            'level' => '',
        ), $atts);
        
        if (!is_user_logged_in()) {
            return '';
        }
        
        $user_membership = PMP_User_Management::get_user_membership(get_current_user_id());
        if (!$user_membership) {
            return '';
        }
        
        if (!empty($atts['level'])) {
            $level_slug = get_post_field('post_name', $user_membership->level_id);
            if ($level_slug !== $atts['level']) {
                return '';
            }
        }
        
        return do_shortcode($content);
    }
}
