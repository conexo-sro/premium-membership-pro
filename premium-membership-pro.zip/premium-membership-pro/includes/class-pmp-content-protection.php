<?php
/**
 * Content Protection Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Content_Protection {
    
    public static function init() {
        add_filter('get_the_excerpt', array(__CLASS__, 'filter_excerpt'), 999);
        add_action('wp', array(__CLASS__, 'protect_feeds'));
    }
    
    public static function filter_excerpt($excerpt) {
        global $post;
        
        if (is_admin()) {
            return $excerpt;
        }
        
        $is_protected = get_post_meta($post->ID, '_pmp_protected', true);
        if (!$is_protected) {
            return $excerpt;
        }
        
        if (PMP_Access_Control::user_can_access($post->ID)) {
            return $excerpt;
        }
        
        return wp_trim_words($excerpt, 20) . '... ' . 
               '<a href="' . get_permalink($post->ID) . '">' . 
               __('[Prémiový obsah - přihlaste se pro pokračování]', 'premium-membership-pro') . 
               '</a>';
    }
    
    public static function protect_feeds() {
        if (!is_feed()) {
            return;
        }
        
        add_filter('the_content_feed', array(__CLASS__, 'filter_feed_content'));
        add_filter('the_excerpt_rss', array(__CLASS__, 'filter_feed_excerpt'));
    }
    
    public static function filter_feed_content($content) {
        global $post;
        
        $is_protected = get_post_meta($post->ID, '_pmp_protected', true);
        if (!$is_protected) {
            return $content;
        }
        
        return wp_trim_words($content, 55) . '... ' . 
               '<p><a href="' . get_permalink($post->ID) . '">' . 
               __('Čtěte celý článek na našem webu', 'premium-membership-pro') . 
               '</a></p>';
    }
    
    public static function filter_feed_excerpt($excerpt) {
        return self::filter_feed_content($excerpt);
    }
}
