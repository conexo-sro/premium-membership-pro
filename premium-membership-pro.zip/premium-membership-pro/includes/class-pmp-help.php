<?php
/**
 * Help & Tooltips System
 * Comprehensive help for all plugin features
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Help {
    
    public static function init() {
        // Add help tabs to admin pages
        add_action('load-toplevel_page_premium-membership-pro', array(__CLASS__, 'add_dashboard_help'));
        add_action('load-membership-pro_page_pmp-levels', array(__CLASS__, 'add_levels_help'));
        add_action('load-membership-pro_page_pmp-members', array(__CLASS__, 'add_members_help'));
        add_action('load-membership-pro_page_pmp-settings', array(__CLASS__, 'add_settings_help'));
        
        // Add tooltips to meta boxes
        add_action('admin_footer', array(__CLASS__, 'add_meta_box_tooltips'));
        
        // Enqueue tooltip scripts
        add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_scripts'));
    }
    
    /**
     * Enqueue tooltip scripts and styles
     */
    public static function enqueue_scripts() {
        $screen = get_current_screen();
        if (strpos($screen->id, 'membership-pro') !== false || $screen->post_type === 'post' || $screen->post_type === 'page') {
            wp_enqueue_style('pmp-tooltips', PMP_PLUGIN_URL . 'assets/css/tooltips.css', array(), PMP_VERSION);
            wp_enqueue_script('pmp-tooltips', PMP_PLUGIN_URL . 'assets/js/tooltips.js', array('jquery'), PMP_VERSION, true);
        }
    }
    
    /**
     * Dashboard help
     */
    public static function add_dashboard_help() {
        $screen = get_current_screen();
        
        $screen->add_help_tab(array(
            'id' => 'pmp_dashboard_overview',
            'title' => __('Přehled', 'premium-membership-pro'),
            'content' => '
                <h2>📊 Dashboard - Přehled</h2>
                <p><strong>Dashboard zobrazuje důležité statistiky a přehled vašeho membership systému.</strong></p>
                
                <h3>Celkem členů</h3>
                <p>Zobrazuje celkový počet aktivních členů napříč všemi úrovněmi. Kliknutím přejdete na seznam členů.</p>
                
                <h3>Celkové příjmy</h3>
                <p>Součet všech příjmů z membership předplatného. Zahrnuje všechny úspěšné transakce.</p>
                
                <h3>Míra odchodu (Churn Rate)</h3>
                <p>Procento členů, kteří zrušili předplatné za posledních 30 dní. Nižší hodnota je lepší.</p>
                
                <h3>Průměrná hodnota člena (ARPU)</h3>
                <p>Average Revenue Per User - průměrná měsíční hodnota jednoho člena. Vypočítá se: Celkové příjmy / Počet členů.</p>
                
                <h3>Členové podle úrovní</h3>
                <p>Graf zobrazuje rozdělení členů podle jednotlivých membership úrovní. Pomáhá identifikovat nejpopulárnější úrovně.</p>
                
                <h3>Nejoblíbenější obsah</h3>
                <p>Seznam 5 nejnavštěvovanějších chráněných stránek/postů. Ukazuje, jaký obsah nejvíce zajímá vaše členy.</p>
            ',
        ));
        
        $screen->add_help_tab(array(
            'id' => 'pmp_dashboard_quick_actions',
            'title' => __('Rychlé akce', 'premium-membership-pro'),
            'content' => '
                <h2>⚡ Rychlé akce</h2>
                
                <h3>Co můžete udělat z Dashboardu:</h3>
                <ul>
                    <li><strong>Přidat novou úroveň</strong> - Vytvoří novou membership úroveň (např. VIP)</li>
                    <li><strong>Přidat člena</strong> - Manuálně přidá nového člena do systému</li>
                    <li><strong>Zobrazit reporty</strong> - Otevře podrobné reporty s grafy</li>
                    <li><strong>Exportovat data</strong> - Stáhne data ve formátu CSV</li>
                </ul>
                
                <h3>Tipy:</h3>
                <ul>
                    <li>Dashboard se automaticky aktualizuje každých 5 minut</li>
                    <li>Můžete kliknout na jednotlivé statistiky pro více detailů</li>
                    <li>Grafy jsou interaktivní - najeďte myší pro přesné hodnoty</li>
                </ul>
            ',
        ));
        
        $screen->set_help_sidebar('
            <p><strong>📞 Potřebujete pomoc?</strong></p>
            <p><a href="https://github.com/conexo-sro/premium-membership-pro/issues" target="_blank">GitHub Issues</a></p>
            <p><a href="mailto:info@conexo.cz">Email: info@conexo.cz</a></p>
            <p><a href="https://conexo.cz" target="_blank">Web: conexo.cz</a></p>
        ');
    }
    
    /**
     * Levels help
     */
    public static function add_levels_help() {
        $screen = get_current_screen();
        
        $screen->add_help_tab(array(
            'id' => 'pmp_levels_overview',
            'title' => __('O úrovních', 'premium-membership-pro'),
            'content' => '
                <h2>⭐ Membership úrovně</h2>
                <p><strong>Úrovně definují různé typy členství s různými cenami a oprávněními.</strong></p>
                
                <h3>Základní nastavení:</h3>
                <ul>
                    <li><strong>Název</strong> - Název úrovně (např. "Basic", "Pro", "VIP")</li>
                    <li><strong>Popis</strong> - Krátký popis co úroveň nabízí</li>
                    <li><strong>Cena</strong> - Měsíční nebo roční cena</li>
                    <li><strong>Interval</strong> - Jak často se platí (měsíc/rok/jednorázově)</li>
                </ul>
                
                <h3>Příklady úrovní:</h3>
                <ul>
                    <li><strong>Free</strong> - 0 Kč, základní přístup</li>
                    <li><strong>Basic</strong> - 199 Kč/měsíc, rozšířený obsah</li>
                    <li><strong>Pro</strong> - 499 Kč/měsíc, veškerý obsah</li>
                    <li><strong>VIP</strong> - 999 Kč/rok, exkluzivní obsah</li>
                </ul>
            ',
        ));
        
        $screen->add_help_tab(array(
            'id' => 'pmp_levels_protection',
            'title' => __('Ochrana obsahu', 'premium-membership-pro'),
            'content' => '
                <h2>🔒 Jak funguje ochrana</h2>
                
                <h3>Přiřazení úrovní k obsahu:</h3>
                <ol>
                    <li>Vytvořte membership úroveň (např. "Premium")</li>
                    <li>Editujte post nebo stránku</li>
                    <li>V meta boxu vyberte úroveň "Premium"</li>
                    <li>Publikujte</li>
                </ol>
                
                <h3>Chování:</h3>
                <ul>
                    <li><strong>Člen s úrovní</strong> - Vidí plný obsah</li>
                    <li><strong>Člen bez úrovně</strong> - Vidí preview nebo blokační zprávu</li>
                    <li><strong>Ne-člen</strong> - Přesměrován na přihlášení</li>
                </ul>
                
                <h3>Multiple úrovně:</h3>
                <p>Můžete vybrat více úrovní - pak kdokoliv s JAKOUKOLI z vybraných úrovní má přístup (OR logika).</p>
            ',
        ));
    }
    
    /**
     * Members help
     */
    public static function add_members_help() {
        $screen = get_current_screen();
        
        $screen->add_help_tab(array(
            'id' => 'pmp_members_overview',
            'title' => __('Správa členů', 'premium-membership-pro'),
            'content' => '
                <h2>👥 Členové</h2>
                <p><strong>Zde spravujete všechny členy a jejich membership.</strong></p>
                
                <h3>Sloupce v tabulce:</h3>
                <ul>
                    <li><strong>Jméno</strong> - Jméno a příjmení člena</li>
                    <li><strong>Email</strong> - Kontaktní email</li>
                    <li><strong>Úroveň</strong> - Aktuální membership úroveň</li>
                    <li><strong>Status</strong> - Aktivní/Expirovaný/Zrušený</li>
                    <li><strong>Platí do</strong> - Datum expirace</li>
                    <li><strong>Registrován</strong> - Datum registrace</li>
                </ul>
                
                <h3>Akce:</h3>
                <ul>
                    <li><strong>Upravit</strong> - Změnit úroveň, status, datum expirace</li>
                    <li><strong>Smazat</strong> - Odstranit členství (ne uživatele!)</li>
                    <li><strong>Obnovit</strong> - Prodloužit membership</li>
                    <li><strong>Email</strong> - Poslat email členovi</li>
                </ul>
            ',
        ));
        
        $screen->add_help_tab(array(
            'id' => 'pmp_members_statuses',
            'title' => __('Statusy', 'premium-membership-pro'),
            'content' => '
                <h2>📊 Statusy členství</h2>
                
                <h3>Active (Aktivní)</h3>
                <p>Členství je aktivní a platné. Člen má plný přístup.</p>
                
                <h3>Expired (Expirované)</h3>
                <p>Členství vypršelo. Člen nemá přístup k chráněnému obsahu.</p>
                
                <h3>Cancelled (Zrušené)</h3>
                <p>Členství bylo zrušeno (členem nebo adminem). Bez přístupu.</p>
                
                <h3>Pending (Čekající)</h3>
                <p>Čeká se na potvrzení platby. Dočasně bez přístupu.</p>
                
                <h3>Trial (Zkušební)</h3>
                <p>Zkušební období. Má přístup, ale omezeně časově.</p>
                
                <h3>Změna statusu:</h3>
                <p>Status můžete změnit v detailu člena. Systém automaticky upraví přístup.</p>
            ',
        ));
    }
    
    /**
     * Settings help
     */
    public static function add_settings_help() {
        $screen = get_current_screen();
        
        $screen->add_help_tab(array(
            'id' => 'pmp_settings_general',
            'title' => __('Obecné', 'premium-membership-pro'),
            'content' => '
                <h2>⚙️ Obecné nastavení</h2>
                
                <h3>Základní stránky:</h3>
                <ul>
                    <li><strong>Přihlašovací stránka</strong> - Stránka s formulářem pro přihlášení</li>
                    <li><strong>Registrační stránka</strong> - Stránka s formulářem pro registraci</li>
                    <li><strong>Účet stránka</strong> - Dashboard pro členy</li>
                </ul>
                
                <h3>Měna:</h3>
                <p>Vyberte měnu pro zobrazení cen. Podporováno: CZK, EUR, USD, GBP.</p>
                
                <h3>Pozice měny:</h3>
                <ul>
                    <li><strong>Před částkou</strong> - $ 199.00</li>
                    <li><strong>Za částkou</strong> - 199.00 Kč</li>
                </ul>
                
                <h3>Email notifikace:</h3>
                <p>Zapněte/vypněte automatické emaily při registraci, expiracích, atd.</p>
            ',
        ));
        
        $screen->add_help_tab(array(
            'id' => 'pmp_settings_protection',
            'title' => __('Ochrana', 'premium-membership-pro'),
            'content' => '
                <h2>🔒 Nastavení ochrany</h2>
                
                <h3>Výchozí chování:</h3>
                <ul>
                    <li><strong>Blokovat vše</strong> - Úplně schovat obsah</li>
                    <li><strong>Ukázat preview</strong> - Ukázat začátek + rozmazat</li>
                    <li><strong>Přesměrovat</strong> - Přesměrovat na přihlášení</li>
                </ul>
                
                <h3>Preview délka:</h3>
                <p>Výchozí počet slov pro preview. Doporučeno: 150-300 slov.</p>
                
                <h3>Blokační zpráva:</h3>
                <p>Text zobrazený ne-členům. Použijte CTA pro konverzi!</p>
                <p>Příklad: "Tento obsah je dostupný pouze pro Premium členy. <a href=\'/registrace/\'>Zaregistrujte se</a>"</p>
                
                <h3>Blokovat excerpt:</h3>
                <p>Skrýt excerpt (úryvek) v listings? Zapnout pokud nechcete spoilovat obsah.</p>
            ',
        ));
        
        $screen->add_help_tab(array(
            'id' => 'pmp_settings_auth_pages',
            'title' => __('Auth stránky', 'premium-membership-pro'),
            'content' => '
                <h2>🎨 Přihlašovací stránky</h2>
                
                <h3>Background nastavení:</h3>
                <ul>
                    <li><strong>Background Image</strong> - Vlastní obrázek na pozadí</li>
                    <li><strong>Background Color</strong> - Barva pozadí (pokud není obrázek)</li>
                    <li><strong>Enable Gradient</strong> - Použít gradient místo jedné barvy</li>
                </ul>
                
                <h3>Bubble nastavení:</h3>
                <ul>
                    <li><strong>Bubble Color</strong> - Barva formulářové bubliny (RGBA)</li>
                    <li><strong>Blur Amount</strong> - Síla blur efektu (0-50px)</li>
                </ul>
                
                <h3>Tipy pro design:</h3>
                <ul>
                    <li>Použijte kontrastní barvy pro lepší čitelnost</li>
                    <li>Gradient dodá moderní vzhled</li>
                    <li>Blur 20px je optimální pro frosted glass efekt</li>
                    <li>Testujte na mobilu - bubble musí být čitelný</li>
                </ul>
            ',
        ));
    }
    
    /**
     * Add tooltips to meta boxes
     */
    public static function add_meta_box_tooltips() {
        $screen = get_current_screen();
        if (!in_array($screen->post_type, array('post', 'page'))) {
            return;
        }
        
        ?>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Meta box tooltips
            var tooltips = {
                'pmp_protection_enabled': {
                    title: 'Zapnout ochranu',
                    content: 'Aktivuje membership ochranu pro tento post/stránku. Pouze vybrané úrovně budou mít přístup.'
                },
                'pmp_required_levels': {
                    title: 'Požadované úrovně',
                    content: 'Vyberte které membership úrovně mají přístup. Můžete vybrat více - pak kdokoliv s JAKOUKOLI vybranou úrovní má přístup (OR logika).'
                },
                'pmp_preview_enabled': {
                    title: 'Povolit preview',
                    content: 'Ukáže ne-členům začátek obsahu. Zbytek bude rozmazaný s CTA zprávou. Pomáhá s konverzí!'
                },
                'pmp_preview_length': {
                    title: 'Délka preview',
                    content: 'Kolik slov ukázat ne-členům. Doporučeno: 150-300 slov. Příliš málo = frustrující, příliš mnoho = nedostatek motivace.'
                },
                'pmp_custom_message': {
                    title: 'Vlastní zpráva',
                    content: 'Text zobrazený pod preview. Použijte silné CTA! Příklad: "Staňte se členem pro přístup k plnému obsahu!"'
                }
            };
            
            // Add tooltip icons
            $.each(tooltips, function(field, data) {
                var $label = $('label[for="' + field + '"]');
                if ($label.length) {
                    var $icon = $('<span class="pmp-tooltip-icon" data-tooltip-title="' + data.title + '" data-tooltip-content="' + data.content + '">?</span>');
                    $label.append($icon);
                }
            });
            
            // Tooltip behavior
            $(document).on('click', '.pmp-tooltip-icon', function(e) {
                e.preventDefault();
                var $icon = $(this);
                var title = $icon.data('tooltip-title');
                var content = $icon.data('tooltip-content');
                
                // Remove existing tooltips
                $('.pmp-tooltip-popup').remove();
                
                // Create tooltip
                var $tooltip = $('<div class="pmp-tooltip-popup"><div class="pmp-tooltip-title">' + title + '</div><div class="pmp-tooltip-content">' + content + '</div></div>');
                
                $('body').append($tooltip);
                
                // Position tooltip
                var iconOffset = $icon.offset();
                $tooltip.css({
                    top: iconOffset.top - $tooltip.outerHeight() - 10,
                    left: iconOffset.left - ($tooltip.outerWidth() / 2) + ($icon.outerWidth() / 2)
                });
                
                // Auto-hide after 5 seconds
                setTimeout(function() {
                    $tooltip.fadeOut(300, function() {
                        $(this).remove();
                    });
                }, 5000);
            });
            
            // Click outside to close
            $(document).on('click', function(e) {
                if (!$(e.target).closest('.pmp-tooltip-icon, .pmp-tooltip-popup').length) {
                    $('.pmp-tooltip-popup').fadeOut(300, function() {
                        $(this).remove();
                    });
                }
            });
        });
        </script>
        <?php
    }
    
    /**
     * Get help content for specific feature
     */
    public static function get_help($feature) {
        $help = array(
            'membership_levels' => array(
                'title' => __('Membership úrovně', 'premium-membership-pro'),
                'content' => __('Vytvořte různé úrovně členství s různými cenami a oprávněními. Například: Basic (199 Kč/měsíc), Pro (499 Kč/měsíc), VIP (999 Kč/rok).', 'premium-membership-pro'),
            ),
            'content_protection' => array(
                'title' => __('Ochrana obsahu', 'premium-membership-pro'),
                'content' => __('Chraňte posty a stránky podle membership úrovní. Můžete povolit preview pro ne-členy nebo úplně skrýt obsah.', 'premium-membership-pro'),
            ),
            'preview_mode' => array(
                'title' => __('Preview režim', 'premium-membership-pro'),
                'content' => __('Ukáže ne-členům začátek obsahu (např. 200 slov), zbytek je rozmazaný. Pomáhá s konverzí - lidé vidí co dostannou.', 'premium-membership-pro'),
            ),
            'elementor_integration' => array(
                'title' => __('Elementor integrace', 'premium-membership-pro'),
                'content' => __('V Elementoru jděte do Settings (⚙️) → Membership Protection. Tam můžete nastavit ochranu přímo v page builderu.', 'premium-membership-pro'),
            ),
        );
        
        return isset($help[$feature]) ? $help[$feature] : null;
    }
}
