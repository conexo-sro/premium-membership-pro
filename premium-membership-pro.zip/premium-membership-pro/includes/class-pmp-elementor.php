<?php
/**
 * Elementor Integration
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Elementor {
    
    /**
     * Initialize Elementor integration
     */
    public static function init() {
        // Check if Elementor is installed and active
        add_action('plugins_loaded', array(__CLASS__, 'check_elementor'));
    }
    
    /**
     * Check if Elementor is available
     */
    public static function check_elementor() {
        // Check if integration is disabled in settings
        $elementor_enabled = get_option('pmp_enable_elementor', '1');
        if ($elementor_enabled !== '1') {
            return;
        }
        
        // Only proceed if Elementor is active
        if (!did_action('elementor/loaded')) {
            return;
        }
        
        // All checks passed - register everything
        
        // Try newer hook first (Elementor 3.5+)
        add_action('elementor/widgets/register', array(__CLASS__, 'register_widgets'));
        
        // Also add old hook for backward compatibility (Elementor < 3.5)
        add_action('elementor/widgets/widgets_registered', array(__CLASS__, 'register_widgets_old'));
        
        // Widget category
        add_action('elementor/elements/categories_registered', array(__CLASS__, 'add_widget_category'));
        
        // Editor scripts
        add_action('elementor/editor/after_enqueue_scripts', array(__CLASS__, 'enqueue_editor_scripts'));
        
        // Register document controls (Settings panel)
        add_action('elementor/documents/register_controls', array('PMP_Meta_Boxes', 'add_elementor_controls'), 10);
        
        // Debug log
        if (WP_DEBUG) {
            error_log('PMP: Elementor integration initialized');
        }
    }
    
    /**
     * Check if Elementor is active
     */
    public static function is_elementor_active() {
        return did_action('elementor/loaded');
    }
    
    /**
     * Check if Elementor integration is enabled
     */
    public static function is_integration_enabled() {
        return get_option('pmp_enable_elementor', '1') === '1';
    }
    
    /**
     * Check if Elementor integration is ready (enabled AND Elementor is active)
     */
    public static function is_integration_ready() {
        return self::is_integration_enabled() && self::is_elementor_active();
    }
    
    /**
     * Get integration status for admin
     */
    public static function get_integration_status() {
        $status = array(
            'enabled' => self::is_integration_enabled(),
            'elementor_installed' => defined('ELEMENTOR_VERSION'),
            'elementor_active' => self::is_elementor_active(),
            'elementor_version' => defined('ELEMENTOR_VERSION') ? ELEMENTOR_VERSION : null,
            'elementor_pro_installed' => defined('ELEMENTOR_PRO_VERSION'),
            'elementor_pro_version' => defined('ELEMENTOR_PRO_VERSION') ? ELEMENTOR_PRO_VERSION : null,
            'widgets_registered' => 0,
            'integration_ready' => self::is_integration_ready(),
        );
        
        // Count registered widgets if integration is ready
        if ($status['integration_ready']) {
            $status['widgets_registered'] = 7; // We have 7 widgets
        }
        
        return $status;
    }
    
    /**
     * Register custom widget category
     */
    public static function add_widget_category($elements_manager) {
        $elements_manager->add_category(
            'pmp-elements',
            array(
                'title' => __('Premium Membership Pro', 'premium-membership-pro'),
                'icon' => 'fa fa-id-card',
            )
        );
    }
    
    /**
     * Register widgets
     */
    public static function register_widgets($widgets_manager) {
        // First, load base widget class
        $base_path = PMP_PLUGIN_DIR . 'elementor/widgets/base-widget.php';
        if (file_exists($base_path)) {
            require_once $base_path;
        }
        
        // Check if base class loaded successfully
        if (!class_exists('PMP_Elementor_Base_Widget')) {
            if (WP_DEBUG) {
                error_log('PMP ERROR: Base widget class failed to load');
            }
            return;
        }
        
        // Now load all widget files
        $widget_files = array(
            'membership-levels.php',
            'login-form.php',
            'registration-form.php',
            'account-page.php',
            'member-content.php',
            'pricing-table.php',
            'membership-status.php',
        );
        
        foreach ($widget_files as $file) {
            $path = PMP_PLUGIN_DIR . 'elementor/widgets/' . $file;
            if (file_exists($path)) {
                require_once $path;
            }
        }
        
        // Register widgets only if classes exist
        if (class_exists('PMP_Elementor_Membership_Levels_Widget')) {
            $widgets_manager->register(new \PMP_Elementor_Membership_Levels_Widget());
        }
        if (class_exists('PMP_Elementor_Login_Form_Widget')) {
            $widgets_manager->register(new \PMP_Elementor_Login_Form_Widget());
        }
        if (class_exists('PMP_Elementor_Registration_Form_Widget')) {
            $widgets_manager->register(new \PMP_Elementor_Registration_Form_Widget());
        }
        if (class_exists('PMP_Elementor_Account_Page_Widget')) {
            $widgets_manager->register(new \PMP_Elementor_Account_Page_Widget());
        }
        if (class_exists('PMP_Elementor_Member_Content_Widget')) {
            $widgets_manager->register(new \PMP_Elementor_Member_Content_Widget());
        }
        if (class_exists('PMP_Elementor_Pricing_Table_Widget')) {
            $widgets_manager->register(new \PMP_Elementor_Pricing_Table_Widget());
        }
        if (class_exists('PMP_Elementor_Membership_Status_Widget')) {
            $widgets_manager->register(new \PMP_Elementor_Membership_Status_Widget());
        }
        
        // Debug logging
        if (WP_DEBUG) {
            error_log('PMP: Registered ' . count($widget_files) . ' Elementor widgets');
        }
    }
    
    /**
     * Register widgets (old method for Elementor < 3.5)
     */
    public static function register_widgets_old() {
        // Get widgets manager
        $widgets_manager = \Elementor\Plugin::instance()->widgets_manager;
        
        if (!$widgets_manager) {
            return;
        }
        
        // Use same registration logic
        self::register_widgets($widgets_manager);
    }
    
    /**
     * Enqueue editor scripts
     */
    public static function enqueue_editor_scripts() {
        $css_path = PMP_PLUGIN_DIR . 'elementor/assets/editor.css';
        $js_path = PMP_PLUGIN_DIR . 'elementor/assets/editor.js';
        
        if (file_exists($css_path)) {
            wp_enqueue_style(
                'pmp-elementor-editor',
                PMP_PLUGIN_URL . 'elementor/assets/editor.css',
                array(),
                PMP_VERSION
            );
        }
        
        if (file_exists($js_path)) {
            wp_enqueue_script(
                'pmp-elementor-editor',
                PMP_PLUGIN_URL . 'elementor/assets/editor.js',
                array('jquery', 'elementor-editor'),
                PMP_VERSION,
                true
            );
        }
    }
    
    /**
     * Get available membership levels for Elementor controls
     */
    public static function get_membership_levels_for_control() {
        $options = array(
            '' => __('-- Vyberte úroveň --', 'premium-membership-pro')
        );
        
        // Check if post type exists
        if (!post_type_exists('pmp_membership')) {
            return $options;
        }
        
        $levels = get_posts(array(
            'post_type' => 'pmp_membership',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'orderby' => 'menu_order',
            'order' => 'ASC'
        ));
        
        if (empty($levels)) {
            return $options;
        }
        
        foreach ($levels as $level) {
            $options[$level->ID] = $level->post_title;
        }
        
        return $options;
    }
}
