<?php
/**
 * Meta Boxes for Post/Page Membership Settings
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Meta_Boxes {
    
    public static function init() {
        // Add meta boxes with explicit priority
        add_action('add_meta_boxes', array(__CLASS__, 'add_meta_boxes'), 10);
        
        // Save meta box data
        add_action('save_post', array(__CLASS__, 'save_meta_boxes'), 10, 2);
        
        // Set default protection value for new posts - multiple hooks for reliability
        add_action('save_post', array(__CLASS__, 'set_default_protection_value'), 5, 3);
        add_action('wp_insert_post', array(__CLASS__, 'set_default_protection_on_insert'), 10, 3);
        
        // CRITICAL: Additional hook for when post status changes (draft → publish)
        add_action('transition_post_status', array(__CLASS__, 'ensure_protection_on_publish'), 10, 3);
        
        // ULTIMATE: Shutdown hook to catch ANY posts that still have empty _pmp_protected
        add_action('shutdown', array(__CLASS__, 'ultimate_protection_check'), 999);
        
        // CRITICAL: Filter to provide default value when meta doesn't exist
        add_filter('default_post_metadata', array(__CLASS__, 'filter_default_protection_value'), 10, 5);
        
        // Add admin bar menu
        add_action('admin_bar_menu', array(__CLASS__, 'add_admin_bar_menu'), 100);
        
        // Add columns to post list
        add_filter('manage_posts_columns', array(__CLASS__, 'add_list_columns'));
        add_filter('manage_pages_columns', array(__CLASS__, 'add_list_columns'));
        add_action('manage_posts_custom_column', array(__CLASS__, 'display_list_columns'), 10, 2);
        add_action('manage_pages_custom_column', array(__CLASS__, 'display_list_columns'), 10, 2);
        
        // Quick edit
        add_action('quick_edit_custom_box', array(__CLASS__, 'quick_edit_box'), 10, 2);
        add_action('admin_footer', array(__CLASS__, 'quick_edit_script'));
        
        // Note: Elementor integration is handled by PMP_Elementor class
        
        // Debug: Log when init is called
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('PMP_Meta_Boxes::init() called');
        }
    }
    
    /**
     * Add meta boxes to posts and pages
     */
    public static function add_meta_boxes() {
        $post_types = array('post', 'page');
        
        // Allow other plugins to add post types
        $post_types = apply_filters('pmp_meta_box_post_types', $post_types);
        
        // Debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('PMP_Meta_Boxes::add_meta_boxes() called for post types: ' . implode(', ', $post_types));
        }
        
        foreach ($post_types as $post_type) {
            // Main protection meta box
            add_meta_box(
                'pmp-membership-settings',
                '🔒 Ochrana obsahu - Členství',
                array(__CLASS__, 'render_meta_box'),
                $post_type,
                'side',
                'high'
            );
            
            // Debug logging
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('PMP: Registered meta box "pmp-membership-settings" for post type: ' . $post_type);
            }
        }
    }
    
    /**
     * Set default protection value for new posts
     * This ensures _pmp_protected always has a value (never empty)
     * DEFAULT: '1' = Protected by default (user must explicitly make public)
     */
    public static function set_default_protection_value($post_id, $post, $update) {
        // Register for shutdown check
        self::register_post_for_check($post_id);
        
        // Only for posts and pages
        if (!in_array($post->post_type, array('post', 'page'))) {
            return;
        }
        
        // Skip autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        // Skip revisions
        if (wp_is_post_revision($post_id)) {
            return;
        }
        
        // Skip auto-drafts
        if ($post->post_status === 'auto-draft') {
            return;
        }
        
        // Check if _pmp_protected already exists
        $existing_value = get_post_meta($post_id, '_pmp_protected', true);
        
        // If it's empty or doesn't exist, set default value '1' (protected)
        // IMPORTANT: Never leave it empty! Always set either '0' or '1'
        if ($existing_value === '' || $existing_value === false) {
            update_post_meta($post_id, '_pmp_protected', '1');
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP: Set default _pmp_protected = '1' (protected) for post {$post_id} ({$post->post_title})");
            }
        }
    }
    
    /**
     * Set default protection on wp_insert_post (runs earlier than save_post)
     * This is more aggressive and catches posts that save_post might miss
     * USES DIRECT SQL FOR GUARANTEED SAVE
     */
    public static function set_default_protection_on_insert($post_id, $post, $update) {
        // Only for posts and pages
        if (!in_array($post->post_type, array('post', 'page'))) {
            return;
        }
        
        // Skip revisions
        if (wp_is_post_revision($post_id)) {
            return;
        }
        
        // Skip auto-drafts
        if ($post->post_status === 'auto-draft') {
            return;
        }
        
        global $wpdb;
        
        // For NEW posts (not updates), FORCE set to '1' using direct SQL
        if (!$update) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("=== PMP NEW POST CREATED ===");
                error_log("PMP: post_id={$post_id}, title={$post->post_title}, type={$post->post_type}");
            }
            
            // Step 1: DELETE any existing value (shouldn't exist but just in case)
            $wpdb->delete(
                $wpdb->postmeta,
                array(
                    'post_id' => $post_id,
                    'meta_key' => '_pmp_protected'
                ),
                array('%d', '%s')
            );
            
            // Step 2: INSERT new value '1' (protected by default)
            $insert_result = $wpdb->insert(
                $wpdb->postmeta,
                array(
                    'post_id' => $post_id,
                    'meta_key' => '_pmp_protected',
                    'meta_value' => '1'
                ),
                array('%d', '%s', '%s')
            );
            
            // Step 3: Immediate SQL verification
            $verify = $wpdb->get_var($wpdb->prepare(
                "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_pmp_protected'",
                $post_id
            ));
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP: INSERT result: " . var_export($insert_result, true));
                error_log("PMP: SQL verification: " . var_export($verify, true));
                
                if ($wpdb->last_error) {
                    error_log("PMP: SQL ERROR: " . $wpdb->last_error);
                }
                
                if ($verify === '1') {
                    error_log("PMP: SUCCESS - New post has _pmp_protected = '1' ✅");
                } else {
                    error_log("PMP: FAILED - Value is: " . var_export($verify, true) . " ❌");
                }
                error_log("=== PMP NEW POST END ===");
            }
            
            // Step 4: Also call update_post_meta for WordPress cache
            update_post_meta($post_id, '_pmp_protected', '1');
            
        } else {
            // For EXISTING posts being updated, only fill if empty
            $existing_value = $wpdb->get_var($wpdb->prepare(
                "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_pmp_protected'",
                $post_id
            ));
            
            if ($existing_value === null || $existing_value === '') {
                // Use same SQL approach
                $wpdb->delete(
                    $wpdb->postmeta,
                    array('post_id' => $post_id, 'meta_key' => '_pmp_protected'),
                    array('%d', '%s')
                );
                
                $wpdb->insert(
                    $wpdb->postmeta,
                    array('post_id' => $post_id, 'meta_key' => '_pmp_protected', 'meta_value' => '1'),
                    array('%d', '%s', '%s')
                );
                
                update_post_meta($post_id, '_pmp_protected', '1');
                
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("PMP: [wp_insert_post] Filled empty _pmp_protected = '1' for existing post {$post_id}");
                }
            }
        }
    }
    
    /**
     * Ensure protection value exists when post is published
     * This catches posts that wp_insert_post might have missed
     * Runs on transition_post_status (any status change)
     */
    public static function ensure_protection_on_publish($new_status, $old_status, $post) {
        // Only for posts and pages
        if (!in_array($post->post_type, array('post', 'page'))) {
            return;
        }
        
        // Skip revisions
        if (wp_is_post_revision($post->ID)) {
            return;
        }
        
        global $wpdb;
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("=== PMP TRANSITION POST STATUS ===");
            error_log("PMP: post_id={$post->ID}, title={$post->post_title}");
            error_log("PMP: old_status={$old_status} → new_status={$new_status}");
        }
        
        // Check current value via direct SQL
        $current_value = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_pmp_protected'",
            $post->ID
        ));
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("PMP: Current _pmp_protected value: " . var_export($current_value, true));
        }
        
        // If value is missing or empty, FORCE set to '1' using SQL
        if ($current_value === null || $current_value === '') {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP: VALUE MISSING! Forcing SQL insert...");
            }
            
            // DELETE any existing (just in case)
            $wpdb->delete(
                $wpdb->postmeta,
                array('post_id' => $post->ID, 'meta_key' => '_pmp_protected'),
                array('%d', '%s')
            );
            
            // INSERT new value
            $insert_result = $wpdb->insert(
                $wpdb->postmeta,
                array(
                    'post_id' => $post->ID,
                    'meta_key' => '_pmp_protected',
                    'meta_value' => '1'
                ),
                array('%d', '%s', '%s')
            );
            
            // Verify
            $verify = $wpdb->get_var($wpdb->prepare(
                "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_pmp_protected'",
                $post->ID
            ));
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP: INSERT result: " . var_export($insert_result, true));
                error_log("PMP: Verification: " . var_export($verify, true));
                
                if ($verify === '1') {
                    error_log("PMP: ✅ SUCCESS - _pmp_protected = '1'");
                } else {
                    error_log("PMP: ❌ FAILED - Value is: " . var_export($verify, true));
                    if ($wpdb->last_error) {
                        error_log("PMP: SQL ERROR: " . $wpdb->last_error);
                    }
                }
            }
            
            // Also update WordPress cache
            update_post_meta($post->ID, '_pmp_protected', '1');
        } else {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP: Value exists: '{$current_value}' - no action needed");
            }
        }
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("=== PMP TRANSITION END ===");
        }
    }
    
    /**
     * Filter default post metadata to provide '1' when _pmp_protected doesn't exist
     * This ensures get_post_meta() always returns '1' even if not in database
     */
    public static function filter_default_protection_value($value, $object_id, $meta_key, $single, $meta_type) {
        // Only for our specific meta key
        if ($meta_key !== '_pmp_protected') {
            return $value;
        }
        
        // Only for posts and pages
        $post = get_post($object_id);
        if (!$post || !in_array($post->post_type, array('post', 'page'))) {
            return $value;
        }
        
        // If the meta doesn't exist in database, return '1' as default
        // This filter runs BEFORE WordPress checks the database
        // So we need to actually check if it exists
        global $wpdb;
        $check = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = %s",
            $object_id,
            '_pmp_protected'
        ));
        
        // If it doesn't exist, return '1' and save it to database
        if ($check === null) {
            // Save to database immediately
            update_post_meta($object_id, '_pmp_protected', '1');
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP: [filter] Set default _pmp_protected = '1' for post {$object_id}");
            }
            
            return '1';
        }
        
        // If it exists but is empty, return '1' and update
        if ($check === '') {
            update_post_meta($object_id, '_pmp_protected', '1');
            return '1';
        }
        
        // Return the existing value
        return $value;
    }
    
    /**
     * Render meta box content
     */
    public static function render_meta_box($post) {
        wp_nonce_field('pmp_meta_box', 'pmp_meta_box_nonce');
        
        // Use '_pmp_protected' to be consistent with other components
        $protection_enabled = get_post_meta($post->ID, '_pmp_protected', true);
        $required_levels = get_post_meta($post->ID, '_pmp_required_levels', true);
        $preview_enabled = get_post_meta($post->ID, '_pmp_preview_enabled', true);
        $preview_length = get_post_meta($post->ID, '_pmp_preview_length', true) ?: 200;
        $custom_message = get_post_meta($post->ID, '_pmp_custom_message', true);
        
        if (!is_array($required_levels)) {
            $required_levels = array();
        }
        
        // Get all membership levels
        $levels = get_posts(array(
            'post_type' => 'pmp_membership',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'orderby' => 'menu_order',
            'order' => 'ASC'
        ));
        
        ?>
        <div class="pmp-meta-box">
            <style>
                .pmp-meta-box { font-size: 13px; }
                .pmp-meta-box label { display: block; margin: 10px 0 5px; font-weight: 600; }
                .pmp-meta-box input[type="checkbox"] { margin-right: 5px; }
                .pmp-meta-box .pmp-levels { max-height: 200px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; background: #f9f9f9; border-radius: 4px; }
                .pmp-meta-box .pmp-level-item { margin: 5px 0; }
                .pmp-meta-box .pmp-preview-settings { margin: 15px 0; padding: 10px; background: #f0f0f1; border-left: 3px solid #2271b1; border-radius: 4px; }
                .pmp-meta-box input[type="number"] { width: 80px; }
                .pmp-meta-box textarea { width: 100%; height: 60px; }
                .pmp-meta-box .description { font-size: 12px; color: #666; font-style: italic; margin-top: 3px; }
                .pmp-status-badge { display: inline-block; padding: 2px 8px; border-radius: 3px; font-size: 11px; font-weight: 600; }
                .pmp-status-protected { background: #d63638; color: white; }
                .pmp-status-public { background: #00a32a; color: white; }
                .pmp-protection-toggle { background: #f0f0f1; padding: 12px; border-radius: 6px; margin-bottom: 15px; border: 2px solid #c3c4c7; }
                .pmp-protection-toggle.enabled { border-color: #d63638; background: #fff5f5; }
                .pmp-protection-label { display: flex; align-items: center; gap: 10px; cursor: pointer; }
                .pmp-protection-label strong { font-size: 14px; }
            </style>
            
            <!-- Protection Toggle -->
            <div class="pmp-protection-toggle <?php echo $protection_enabled ? 'enabled' : ''; ?>">
                <label class="pmp-protection-label">
                    <input type="checkbox" 
                           name="pmp_enable_protection" 
                           id="pmp_enable_protection"
                           value="1" 
                           <?php checked($protection_enabled, '1'); ?>>
                    <strong><?php _e('🔒 Chránit tento obsah', 'premium-membership-pro'); ?></strong>
                </label>
                <span class="description">
                    <?php _e('Pouze členové s vybranými úrovněmi budou mít přístup k tomuto obsahu', 'premium-membership-pro'); ?>
                </span>
            </div>
            
            <div id="pmp-levels-wrapper" style="<?php echo $protection_enabled ? '' : 'display:none;'; ?>">
                <label><?php _e('Požadované úrovně členství:', 'premium-membership-pro'); ?></label>
                
                <?php if (empty($levels)): ?>
                    <p class="description">
                        <?php _e('Nejsou k dispozici žádné úrovně členství.', 'premium-membership-pro'); ?>
                        <a href="<?php echo admin_url('post-new.php?post_type=pmp_membership'); ?>">
                            <?php _e('Vytvořit první úroveň', 'premium-membership-pro'); ?>
                        </a>
                    </p>
                <?php else: ?>
                    <div class="pmp-levels">
                        <?php foreach ($levels as $level): ?>
                            <div class="pmp-level-item">
                                <label>
                                    <input type="checkbox" 
                                           name="pmp_required_levels[]" 
                                           value="<?php echo $level->ID; ?>"
                                           <?php checked(in_array($level->ID, $required_levels)); ?>>
                                    <?php echo esc_html($level->post_title); ?>
                                </label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <p class="description">
                        <?php _e('Pokud nevyberete žádnou úroveň, bude vyžadováno jakékoli aktivní členství.', 'premium-membership-pro'); ?>
                    </p>
                <?php endif; ?>
                
                <div class="pmp-preview-settings">
                    <label>
                        <input type="checkbox" name="pmp_preview_enabled" value="1" <?php checked($preview_enabled, '1'); ?>>
                        <strong><?php _e('Povolit náhled obsahu', 'premium-membership-pro'); ?></strong>
                    </label>
                    
                    <div id="pmp-preview-options" style="<?php echo $preview_enabled ? '' : 'display:none;'; ?>">
                        <label>
                            <?php _e('Délka náhledu (počet slov):', 'premium-membership-pro'); ?>
                            <input type="number" name="pmp_preview_length" value="<?php echo esc_attr($preview_length); ?>" min="50" max="1000">
                        </label>
                        
                        <label>
                            <?php _e('Vlastní zpráva:', 'premium-membership-pro'); ?>
                            <textarea name="pmp_custom_message" placeholder="<?php _e('Předplaťte si, abyste mohli číst celý obsah...', 'premium-membership-pro'); ?>"><?php echo esc_textarea($custom_message); ?></textarea>
                        </label>
                    </div>
                </div>
            </div>
            
            <script>
            jQuery(document).ready(function($) {
                // Toggle protection toggle styling
                $('input[name="pmp_enable_protection"]').on('change', function() {
                    var $toggle = $('.pmp-protection-toggle');
                    $('#pmp-levels-wrapper').toggle(this.checked);
                    
                    if (this.checked) {
                        $toggle.addClass('enabled');
                    } else {
                        $toggle.removeClass('enabled');
                    }
                });
                
                $('input[name="pmp_preview_enabled"]').on('change', function() {
                    $('#pmp-preview-options').toggle(this.checked);
                });
            });
            </script>
        </div>
        <?php
    }
    
    /**
     * Save meta box data
     */
    public static function save_meta_boxes($post_id, $post) {
        // Verify nonce
        if (!isset($_POST['pmp_meta_box_nonce']) || !wp_verify_nonce($_POST['pmp_meta_box_nonce'], 'pmp_meta_box')) {
            return;
        }
        
        // Check autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        // Check permissions
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Save protection enabled - use '_pmp_protected' to be consistent with other components
        $protection_enabled = isset($_POST['pmp_enable_protection']) ? '1' : '0';
        update_post_meta($post_id, '_pmp_protected', $protection_enabled);
        
        // Save required levels
        $required_levels = isset($_POST['pmp_required_levels']) ? array_map('intval', $_POST['pmp_required_levels']) : array();
        update_post_meta($post_id, '_pmp_required_levels', $required_levels);
        
        // Save preview settings
        $preview_enabled = isset($_POST['pmp_preview_enabled']) ? '1' : '0';
        update_post_meta($post_id, '_pmp_preview_enabled', $preview_enabled);
        
        $preview_length = isset($_POST['pmp_preview_length']) ? intval($_POST['pmp_preview_length']) : 200;
        update_post_meta($post_id, '_pmp_preview_length', $preview_length);
        
        $custom_message = isset($_POST['pmp_custom_message']) ? sanitize_textarea_field($_POST['pmp_custom_message']) : '';
        update_post_meta($post_id, '_pmp_custom_message', $custom_message);
    }
    
    /**
     * Add admin bar menu for quick access
     */
    public static function add_admin_bar_menu($wp_admin_bar) {
        if (!is_singular()) {
            return;
        }
        
        $post_id = get_the_ID();
        $protection_enabled = get_post_meta($post_id, '_pmp_protected', true);
        
        if (!$protection_enabled) {
            return;
        }
        
        $required_levels = get_post_meta($post_id, '_pmp_required_levels', true);
        if (!is_array($required_levels)) {
            $required_levels = array();
        }
        
        $level_names = array();
        foreach ($required_levels as $level_id) {
            $level = get_post($level_id);
            if ($level) {
                $level_names[] = $level->post_title;
            }
        }
        
        $wp_admin_bar->add_node(array(
            'id' => 'pmp-protection-status',
            'title' => '🔒 ' . __('Protected Content', 'premium-membership-pro'),
            'href' => get_edit_post_link($post_id) . '#pmp-membership-settings',
            'meta' => array(
                'title' => sprintf(__('Required levels: %s', 'premium-membership-pro'), implode(', ', $level_names))
            )
        ));
    }
    
    /**
     * Add columns to post/page list
     */
    public static function add_list_columns($columns) {
        $new_columns = array();
        
        foreach ($columns as $key => $value) {
            $new_columns[$key] = $value;
            
            // Add membership column after title
            if ($key === 'title') {
                $new_columns['pmp_membership'] = '🔒 ' . __('Membership', 'premium-membership-pro');
            }
        }
        
        return $new_columns;
    }
    
    /**
     * Display column content
     */
    public static function display_list_columns($column, $post_id) {
        if ($column !== 'pmp_membership') {
            return;
        }
        
        $protection_enabled = get_post_meta($post_id, '_pmp_protection_enabled', true);
        
        if (!$protection_enabled) {
            echo '<span class="pmp-status-badge pmp-status-public">' . __('Public', 'premium-membership-pro') . '</span>';
            return;
        }
        
        $required_levels = get_post_meta($post_id, '_pmp_required_levels', true);
        if (!is_array($required_levels) || empty($required_levels)) {
            echo '<span class="pmp-status-badge pmp-status-protected">' . __('Protected', 'premium-membership-pro') . '</span>';
            return;
        }
        
        echo '<span class="pmp-status-badge pmp-status-protected">' . __('Protected', 'premium-membership-pro') . '</span><br>';
        
        $level_names = array();
        foreach ($required_levels as $level_id) {
            $level = get_post($level_id);
            if ($level) {
                $level_names[] = $level->post_title;
            }
        }
        
        echo '<small style="color: #666;">' . implode(', ', $level_names) . '</small>';
    }
    
    /**
     * Add quick edit box
     */
    public static function quick_edit_box($column_name, $post_type) {
        if ($column_name !== 'pmp_membership') {
            return;
        }
        
        // Get all levels for quick edit
        $levels = get_posts(array(
            'post_type' => 'pmp_membership',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'orderby' => 'menu_order',
            'order' => 'ASC'
        ));
        
        ?>
        <fieldset class="inline-edit-col-right">
            <div class="inline-edit-col">
                <label>
                    <span class="title">🔒 <?php _e('Membership', 'premium-membership-pro'); ?></span>
                    <span class="input-text-wrap">
                        <label>
                            <input type="checkbox" name="pmp_protection_enabled" value="1">
                            <?php _e('Enable protection', 'premium-membership-pro'); ?>
                        </label>
                    </span>
                </label>
            </div>
        </fieldset>
        <?php
    }
    
    /**
     * Quick edit JavaScript
     */
    public static function quick_edit_script() {
        global $current_screen;
        
        if (!in_array($current_screen->post_type, array('post', 'page'))) {
            return;
        }
        
        ?>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Store original Quick Edit function
            var $wp_inline_edit = inlineEditPost.edit;
            
            // Override Quick Edit function
            inlineEditPost.edit = function(id) {
                // Call original Quick Edit function
                $wp_inline_edit.apply(this, arguments);
                
                // Get post ID
                var post_id = 0;
                if (typeof(id) == 'object') {
                    post_id = parseInt(this.getId(id));
                }
                
                if (post_id > 0) {
                    // Get current protection status from inline data
                    var $row = $('#post-' + post_id);
                    var protection = $row.find('.pmp-status-protected').length > 0;
                    
                    // Set checkbox
                    $('input[name="pmp_protection_enabled"]').prop('checked', protection);
                }
            };
        });
        </script>
        <?php
    }
    
    /**
     * Add Elementor controls
     */
    public static function add_elementor_controls($document) {
        // Debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('PMP: add_elementor_controls called');
        }
        
        // Get post object
        $post_id = $document->get_main_id();
        if (!$post_id) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('PMP: No post_id found');
            }
            return;
        }
        
        $post = get_post($post_id);
        if (!$post) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('PMP: No post found for ID: ' . $post_id);
            }
            return;
        }
        
        // Only for posts and pages
        if (!in_array($post->post_type, array('post', 'page'))) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('PMP: Post type not supported: ' . $post->post_type);
            }
            return;
        }
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('PMP: Adding Elementor controls for post ID: ' . $post_id . ', type: ' . $post->post_type);
        }
        
        // Get all membership levels
        $levels = get_posts(array(
            'post_type' => 'pmp_membership',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'orderby' => 'menu_order',
            'order' => 'ASC'
        ));
        
        $levels_options = array();
        foreach ($levels as $level) {
            $levels_options[$level->ID] = $level->post_title;
        }
        
        // === MEMBERSHIP PROTECTION SECTION ===
        $document->start_controls_section(
            'pmp_membership_section',
            array(
                'label' => '🔒 ' . __('Ochrana členství', 'premium-membership-pro'),
                'tab' => \Elementor\Controls_Manager::TAB_SETTINGS,
            )
        );
        
        $document->add_control(
            'pmp_enable_protection',
            array(
                'label' => __('Chránit tento obsah', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => get_post_meta($post_id, '_pmp_enable_protection', true) ? 'yes' : '',
                'label_on' => __('Ano', 'premium-membership-pro'),
                'label_off' => __('Ne', 'premium-membership-pro'),
                'description' => __('Pouze členové s vybranými úrovněmi budou mít přístup', 'premium-membership-pro'),
            )
        );
        
        $document->add_control(
            'pmp_required_levels',
            array(
                'label' => __('Požadované úrovně', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $levels_options,
                'default' => get_post_meta($post_id, '_pmp_required_levels', true) ?: array(),
                'condition' => array(
                    'pmp_enable_protection' => 'yes',
                ),
                'description' => __('Pokud nevyberete žádnou, bude vyžadováno jakékoli členství', 'premium-membership-pro'),
            )
        );
        
        $document->add_control(
            'pmp_preview_enabled',
            array(
                'label' => __('Povolit náhled', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => get_post_meta($post_id, '_pmp_preview_enabled', true) ? 'yes' : '',
                'label_on' => __('Ano', 'premium-membership-pro'),
                'label_off' => __('Ne', 'premium-membership-pro'),
                'condition' => array(
                    'pmp_enable_protection' => 'yes',
                ),
            )
        );
        
        $document->add_control(
            'pmp_preview_length',
            array(
                'label' => __('Délka náhledu (slov)', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => get_post_meta($post_id, '_pmp_preview_length', true) ?: 200,
                'min' => 50,
                'max' => 1000,
                'condition' => array(
                    'pmp_enable_protection' => 'yes',
                    'pmp_preview_enabled' => 'yes',
                ),
            )
        );
        
        $document->add_control(
            'pmp_custom_message',
            array(
                'label' => __('Vlastní zpráva', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => get_post_meta($post_id, '_pmp_custom_message', true),
                'placeholder' => __('Předplaťte si, abyste mohli číst celý obsah...', 'premium-membership-pro'),
                'condition' => array(
                    'pmp_enable_protection' => 'yes',
                    'pmp_preview_enabled' => 'yes',
                ),
            )
        );
        
        $document->end_controls_section();
        
        // === CONTENT LOCK SECTION ===
        $document->start_controls_section(
            'pmp_content_lock_section',
            array(
                'label' => '🔒 ' . __('Uzamknutí obsahu', 'premium-membership-pro'),
                'tab' => \Elementor\Controls_Manager::TAB_SETTINGS,
            )
        );
        
        $is_locked = get_post_meta($post_id, '_pmp_content_locked', true);
        $locked_by = get_post_meta($post_id, '_pmp_locked_by', true);
        
        if ($is_locked && $locked_by) {
            $user = get_userdata($locked_by);
            $locked_at = get_post_meta($post_id, '_pmp_locked_at', true);
            
            $document->add_control(
                'pmp_lock_status',
                array(
                    'type' => \Elementor\Controls_Manager::RAW_HTML,
                    'raw' => sprintf(
                        '<div style="background: #fff5f5; border-left: 4px solid #e53e3e; padding: 15px; margin: 10px 0; border-radius: 4px;">
                            <strong style="color: #c53030;">🔒 Obsah je uzamknut</strong><br>
                            <span style="font-size: 13px; color: #742a2a;">
                                Uzamkl: %s<br>
                                Před: %s
                            </span>
                        </div>',
                        $user ? $user->display_name : __('Neznámý', 'premium-membership-pro'),
                        $locked_at ? human_time_diff($locked_at, current_time('timestamp')) : ''
                    ),
                    'content_classes' => 'elementor-panel-alert elementor-panel-alert-danger',
                )
            );
        }
        
        $document->add_control(
            'pmp_content_locked',
            array(
                'label' => __('Uzamknout obsah', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'default' => $is_locked ? 'yes' : '',
                'label_on' => __('Uzamknuto', 'premium-membership-pro'),
                'label_off' => __('Odemknuto', 'premium-membership-pro'),
                'description' => __('Uzamkne obsah před editací ostatními a skryje ho na frontendu', 'premium-membership-pro'),
            )
        );
        
        $document->add_control(
            'pmp_lock_reason',
            array(
                'label' => __('Důvod uzamknutí', 'premium-membership-pro'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => get_post_meta($post_id, '_pmp_lock_reason', true),
                'placeholder' => __('Volitelně zadejte důvod uzamknutí...', 'premium-membership-pro'),
                'rows' => 3,
                'condition' => array(
                    'pmp_content_locked' => 'yes',
                ),
            )
        );
        
        $document->end_controls_section();
        
        // === MEMBERSHIP ASSIGNMENT INFO SECTION ===
        $document->start_controls_section(
            'pmp_assignment_info_section',
            array(
                'label' => '👥 ' . __('Přidělení členství', 'premium-membership-pro'),
                'tab' => \Elementor\Controls_Manager::TAB_SETTINGS,
            )
        );
        
        // Show assignment stats
        $required_levels = get_post_meta($post_id, '_pmp_required_levels', true);
        $member_count = 0;
        
        if (!empty($required_levels) && is_array($required_levels)) {
            global $wpdb;
            $placeholders = implode(',', array_fill(0, count($required_levels), '%d'));
            $member_count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(DISTINCT user_id)
                 FROM {$wpdb->prefix}pmp_memberships
                 WHERE level_id IN ($placeholders)
                 AND status = 'active'
                 AND (expires_at IS NULL OR expires_at > NOW())",
                $required_levels
            ));
        }
        
        $document->add_control(
            'pmp_assignment_stats',
            array(
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw' => sprintf(
                    '<div style="background: linear-gradient(135deg, #f0fff4 0%%, #e6fffa 100%%); border-left: 4px solid #48bb78; padding: 20px; margin: 10px 0; text-align: center; border-radius: 8px;">
                        <div style="font-size: 48px; font-weight: 700; color: #22543d; line-height: 1;">%d</div>
                        <div style="font-size: 12px; color: #2f855a; text-transform: uppercase; font-weight: 600; letter-spacing: 1px; margin-top: 8px;">členů má přístup</div>
                    </div>',
                    $member_count
                ),
            )
        );
        
        $document->add_control(
            'pmp_assignment_info',
            array(
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw' => '<p style="text-align: center; margin: 15px 0; font-size: 13px; color: #718096; line-height: 1.6;">
                    Pro přidělení členství uživatelům použijte tlačítko v klasickém editoru nebo v seznamu příspěvků.
                </p>',
            )
        );
        
        $document->end_controls_section();
        
        // Save Elementor settings
        add_action('elementor/document/after_save', function($document) use ($post_id) {
            $settings = $document->get_settings();
            
            // Save protection settings (use consistent meta key)
            if (isset($settings['pmp_enable_protection'])) {
                update_post_meta($post_id, '_pmp_enable_protection', $settings['pmp_enable_protection'] === 'yes' ? '1' : '0');
            }
            
            if (isset($settings['pmp_required_levels'])) {
                $levels = is_array($settings['pmp_required_levels']) ? $settings['pmp_required_levels'] : array();
                update_post_meta($post_id, '_pmp_required_levels', $levels);
            }
            
            if (isset($settings['pmp_preview_enabled'])) {
                update_post_meta($post_id, '_pmp_preview_enabled', $settings['pmp_preview_enabled'] === 'yes' ? '1' : '0');
            }
            
            if (isset($settings['pmp_preview_length'])) {
                update_post_meta($post_id, '_pmp_preview_length', intval($settings['pmp_preview_length']));
            }
            
            if (isset($settings['pmp_custom_message'])) {
                update_post_meta($post_id, '_pmp_custom_message', sanitize_textarea_field($settings['pmp_custom_message']));
            }
            
            // Save lock settings
            if (isset($settings['pmp_content_locked'])) {
                $is_locked = $settings['pmp_content_locked'] === 'yes' ? '1' : '0';
                update_post_meta($post_id, '_pmp_content_locked', $is_locked);
                
                if ($is_locked === '1') {
                    update_post_meta($post_id, '_pmp_locked_by', get_current_user_id());
                    update_post_meta($post_id, '_pmp_locked_at', current_time('timestamp'));
                } else {
                    delete_post_meta($post_id, '_pmp_locked_by');
                    delete_post_meta($post_id, '_pmp_locked_at');
                }
            }
            
            if (isset($settings['pmp_lock_reason'])) {
                update_post_meta($post_id, '_pmp_lock_reason', sanitize_textarea_field($settings['pmp_lock_reason']));
            }
        }, 10, 1);
    }
    
    /**
     * Track post IDs that need checking
     */
    private static $posts_to_check = array();
    
    /**
     * Register a post ID for checking in shutdown hook
     */
    public static function register_post_for_check($post_id) {
        if (!in_array($post_id, self::$posts_to_check)) {
            self::$posts_to_check[] = $post_id;
        }
    }
    
    /**
     * ULTIMATE protection check - runs on shutdown
     * Checks ALL posts registered during this request and ensures _pmp_protected is set
     */
    public static function ultimate_protection_check() {
        global $wpdb;
        
        // Only run in admin or during AJAX
        if (!is_admin() && !wp_doing_ajax()) {
            return;
        }
        
        // Get posts registered during this request
        $posts_to_check = self::$posts_to_check;
        
        // Also get recently modified posts as backup
        $recent_posts = $wpdb->get_col("
            SELECT ID FROM {$wpdb->posts} 
            WHERE post_type IN ('post', 'page') 
            AND post_modified >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)
        ");
        
        // Merge both lists
        $all_posts = array_unique(array_merge($posts_to_check, $recent_posts));
        
        if (empty($all_posts)) {
            return;
        }
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("=== PMP ULTIMATE PROTECTION CHECK (shutdown) ===");
            error_log("PMP: Posts registered: " . implode(', ', $posts_to_check));
            error_log("PMP: Posts from DB: " . implode(', ', $recent_posts));
            error_log("PMP: Total checking: " . count($all_posts) . " posts");
        }
        
        $fixed_count = 0;
        
        foreach ($all_posts as $post_id) {
            // Check if _pmp_protected exists
            $value = $wpdb->get_var($wpdb->prepare(
                "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_pmp_protected'",
                $post_id
            ));
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("PMP: Post {$post_id} → _pmp_protected = " . var_export($value, true));
            }
            
            // If empty or doesn't exist, fix it
            if ($value === null || $value === '') {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("PMP: Post {$post_id} has empty _pmp_protected - FIXING NOW");
                }
                
                // DELETE old
                $wpdb->query($wpdb->prepare(
                    "DELETE FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_pmp_protected'",
                    $post_id
                ));
                
                // INSERT new
                $insert_sql = $wpdb->prepare(
                    "INSERT INTO {$wpdb->postmeta} (post_id, meta_key, meta_value) VALUES (%d, '_pmp_protected', '1')",
                    $post_id
                );
                $insert_result = $wpdb->query($insert_sql);
                
                // Verify
                $verify = $wpdb->get_var($wpdb->prepare(
                    "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_pmp_protected'",
                    $post_id
                ));
                
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("PMP: INSERT query: {$insert_sql}");
                    error_log("PMP: INSERT result: " . var_export($insert_result, true));
                    
                    if ($wpdb->last_error) {
                        error_log("PMP: SQL ERROR: {$wpdb->last_error}");
                    }
                    
                    if ($verify === '1') {
                        error_log("PMP: ✅ FIXED post {$post_id} → _pmp_protected = '1'");
                        $fixed_count++;
                    } else {
                        error_log("PMP: ❌ FAILED to fix post {$post_id} - verify returned: " . var_export($verify, true));
                    }
                }
            }
        }
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("PMP: Fixed {$fixed_count} posts");
            error_log("=== PMP ULTIMATE CHECK END ===");
        }
    }
}
