<?php
/**
 * Content Lock
 * Lock/unlock posts and pages with visual indicator
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Content_Lock {
    
    public static function init() {
        // Add lock meta box
        add_action('add_meta_boxes', array(__CLASS__, 'add_lock_meta_box'));
        
        // Save lock status
        add_action('save_post', array(__CLASS__, 'save_lock_status'), 10, 2);
        
        // Add lock column to post list
        add_filter('manage_posts_columns', array(__CLASS__, 'add_lock_column'));
        add_filter('manage_pages_columns', array(__CLASS__, 'add_lock_column'));
        add_action('manage_posts_custom_column', array(__CLASS__, 'display_lock_column'), 10, 2);
        add_action('manage_pages_custom_column', array(__CLASS__, 'display_lock_column'), 10, 2);
        
        // Add lock quick edit
        add_action('quick_edit_custom_box', array(__CLASS__, 'quick_edit_lock'), 10, 2);
        add_action('admin_footer-edit.php', array(__CLASS__, 'quick_edit_script'));
        
        // Add lock bulk action
        add_filter('bulk_actions-edit-post', array(__CLASS__, 'add_bulk_lock_actions'));
        add_filter('bulk_actions-edit-page', array(__CLASS__, 'add_bulk_lock_actions'));
        add_filter('handle_bulk_actions-edit-post', array(__CLASS__, 'handle_bulk_lock'), 10, 3);
        add_filter('handle_bulk_actions-edit-page', array(__CLASS__, 'handle_bulk_lock'), 10, 3);
        
        // Add lock to admin bar
        add_action('admin_bar_menu', array(__CLASS__, 'add_lock_to_admin_bar'), 999);
        
        // Add lock indicator to post row
        add_filter('post_row_actions', array(__CLASS__, 'add_lock_row_action'), 10, 2);
        add_filter('page_row_actions', array(__CLASS__, 'add_lock_row_action'), 10, 2);
        
        // AJAX toggle lock
        add_action('wp_ajax_pmp_toggle_lock', array(__CLASS__, 'ajax_toggle_lock'));
        
        // Enqueue scripts
        add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_scripts'));
        
        // Filter content if locked
        add_filter('the_content', array(__CLASS__, 'filter_locked_content'), 999);
        
        // Block editing of locked posts
        add_action('edit_post', array(__CLASS__, 'block_locked_edit'), 10, 2);
        add_action('wp_insert_post', array(__CLASS__, 'block_locked_edit'), 10, 2);
    }
    
    /**
     * Add lock meta box
     */
    public static function add_lock_meta_box() {
        $post_types = array('post', 'page');
        $post_types = apply_filters('pmp_lock_post_types', $post_types);
        
        foreach ($post_types as $post_type) {
            add_meta_box(
                'pmp_content_lock',
                '🔒 ' . __('Uzamknutí obsahu', 'premium-membership-pro'),
                array(__CLASS__, 'render_lock_meta_box'),
                $post_type,
                'side',
                'high'
            );
        }
    }
    
    /**
     * Render lock meta box
     */
    public static function render_lock_meta_box($post) {
        wp_nonce_field('pmp_lock_meta_box', 'pmp_lock_nonce');
        
        $is_locked = get_post_meta($post->ID, '_pmp_content_locked', true);
        $locked_by = get_post_meta($post->ID, '_pmp_locked_by', true);
        $locked_at = get_post_meta($post->ID, '_pmp_locked_at', true);
        $lock_reason = get_post_meta($post->ID, '_pmp_lock_reason', true);
        
        ?>
        <div class="pmp-lock-meta-box">
            
            <!-- Lock Toggle -->
            <div class="pmp-lock-toggle">
                <label class="pmp-switch">
                    <input type="checkbox" 
                           name="pmp_content_locked" 
                           id="pmp_content_locked" 
                           value="1" 
                           <?php checked($is_locked, '1'); ?>
                           data-post-id="<?php echo $post->ID; ?>">
                    <span class="pmp-slider"></span>
                </label>
                <label for="pmp_content_locked" class="pmp-lock-label">
                    <strong><?php _e('Uzamknout obsah', 'premium-membership-pro'); ?></strong>
                </label>
            </div>
            
            <!-- Lock Status -->
            <div class="pmp-lock-status" style="display: <?php echo $is_locked ? 'block' : 'none'; ?>">
                <div class="pmp-lock-indicator pmp-locked">
                    <span class="dashicons dashicons-lock"></span>
                    <span><?php _e('Obsah je uzamknut', 'premium-membership-pro'); ?></span>
                </div>
                
                <?php if ($locked_by && $locked_at): ?>
                <div class="pmp-lock-info">
                    <?php
                    $user = get_userdata($locked_by);
                    $time = human_time_diff($locked_at, current_time('timestamp'));
                    ?>
                    <p class="pmp-lock-meta">
                        <span class="dashicons dashicons-admin-users"></span>
                        <?php printf(__('Uzamkl: %s', 'premium-membership-pro'), $user ? $user->display_name : __('Neznámý', 'premium-membership-pro')); ?>
                    </p>
                    <p class="pmp-lock-meta">
                        <span class="dashicons dashicons-clock"></span>
                        <?php printf(__('Před %s', 'premium-membership-pro'), $time); ?>
                    </p>
                </div>
                <?php endif; ?>
                
                <!-- Lock Reason -->
                <div class="pmp-lock-reason-field">
                    <label for="pmp_lock_reason">
                        <?php _e('Důvod uzamknutí:', 'premium-membership-pro'); ?>
                    </label>
                    <textarea 
                        name="pmp_lock_reason" 
                        id="pmp_lock_reason" 
                        rows="3" 
                        class="widefat"
                        placeholder="<?php esc_attr_e('Volitelně zadejte důvod...', 'premium-membership-pro'); ?>"><?php echo esc_textarea($lock_reason); ?></textarea>
                </div>
            </div>
            
            <!-- Unlock Status -->
            <div class="pmp-unlock-status" style="display: <?php echo !$is_locked ? 'block' : 'none'; ?>">
                <div class="pmp-lock-indicator pmp-unlocked">
                    <span class="dashicons dashicons-unlock"></span>
                    <span><?php _e('Obsah není uzamknut', 'premium-membership-pro'); ?></span>
                </div>
                <p class="description">
                    <?php _e('Zapnutím zámku zabráníte editaci a zobrazení obsahu na frontendu.', 'premium-membership-pro'); ?>
                </p>
            </div>
            
            <!-- Lock Features -->
            <div class="pmp-lock-features">
                <h4><?php _e('Co dělá uzamknutí:', 'premium-membership-pro'); ?></h4>
                <ul>
                    <li><span class="dashicons dashicons-yes"></span> <?php _e('Blokuje editaci pro ostatní adminy', 'premium-membership-pro'); ?></li>
                    <li><span class="dashicons dashicons-yes"></span> <?php _e('Skrývá obsah na frontendu', 'premium-membership-pro'); ?></li>
                    <li><span class="dashicons dashicons-yes"></span> <?php _e('Viditelné v admin seznamu', 'premium-membership-pro'); ?></li>
                    <li><span class="dashicons dashicons-yes"></span> <?php _e('Bulk akce dostupné', 'premium-membership-pro'); ?></li>
                </ul>
            </div>
            
            <!-- Quick Unlock (only for locked posts) -->
            <?php if ($is_locked): ?>
            <div class="pmp-quick-actions">
                <button type="button" class="button button-secondary pmp-force-unlock" data-post-id="<?php echo $post->ID; ?>">
                    <span class="dashicons dashicons-unlock"></span>
                    <?php _e('Odemnkout rychle', 'premium-membership-pro'); ?>
                </button>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * Save lock status
     */
    public static function save_lock_status($post_id, $post) {
        // Check nonce
        if (!isset($_POST['pmp_lock_nonce']) || !wp_verify_nonce($_POST['pmp_lock_nonce'], 'pmp_lock_meta_box')) {
            return;
        }
        
        // Check autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        // Check permissions
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Check if post is locked by someone else
        $existing_lock = get_post_meta($post_id, '_pmp_content_locked', true);
        $locked_by = get_post_meta($post_id, '_pmp_locked_by', true);
        
        if ($existing_lock && $locked_by && $locked_by != get_current_user_id()) {
            // Don't allow changes if locked by someone else
            wp_die(__('Tento obsah je uzamknut jiným uživatelem a nelze ho upravit.', 'premium-membership-pro'));
        }
        
        // Save lock status
        $is_locked = isset($_POST['pmp_content_locked']) ? '1' : '0';
        update_post_meta($post_id, '_pmp_content_locked', $is_locked);
        
        if ($is_locked) {
            // Save lock metadata
            update_post_meta($post_id, '_pmp_locked_by', get_current_user_id());
            update_post_meta($post_id, '_pmp_locked_at', current_time('timestamp'));
            
            // Save lock reason
            if (isset($_POST['pmp_lock_reason'])) {
                update_post_meta($post_id, '_pmp_lock_reason', sanitize_textarea_field($_POST['pmp_lock_reason']));
            }
        } else {
            // Clear lock metadata
            delete_post_meta($post_id, '_pmp_locked_by');
            delete_post_meta($post_id, '_pmp_locked_at');
            delete_post_meta($post_id, '_pmp_lock_reason');
        }
    }
    
    /**
     * Add lock column
     */
    public static function add_lock_column($columns) {
        $new_columns = array();
        
        foreach ($columns as $key => $title) {
            $new_columns[$key] = $title;
            
            // Add lock column after title
            if ($key === 'title') {
                $new_columns['pmp_lock'] = '<span class="dashicons dashicons-lock" title="' . esc_attr__('Uzamknutí', 'premium-membership-pro') . '"></span>';
            }
        }
        
        return $new_columns;
    }
    
    /**
     * Display lock column
     */
    public static function display_lock_column($column, $post_id) {
        if ($column !== 'pmp_lock') {
            return;
        }
        
        $is_locked = get_post_meta($post_id, '_pmp_content_locked', true);
        $locked_by = get_post_meta($post_id, '_pmp_locked_by', true);
        $locked_at = get_post_meta($post_id, '_pmp_locked_at', true);
        
        if ($is_locked) {
            $user = get_userdata($locked_by);
            $time = $locked_at ? human_time_diff($locked_at, current_time('timestamp')) : '';
            
            $tooltip = sprintf(
                __('Uzamkl: %s před %s', 'premium-membership-pro'),
                $user ? $user->display_name : __('Neznámý', 'premium-membership-pro'),
                $time
            );
            
            echo '<span class="pmp-lock-badge pmp-locked" title="' . esc_attr($tooltip) . '">';
            echo '<span class="dashicons dashicons-lock"></span>';
            echo '</span>';
        } else {
            echo '<span class="pmp-lock-badge pmp-unlocked" title="' . esc_attr__('Není uzamknut', 'premium-membership-pro') . '">';
            echo '<span class="dashicons dashicons-unlock"></span>';
            echo '</span>';
        }
    }
    
    /**
     * Add quick edit lock
     */
    public static function quick_edit_lock($column_name, $post_type) {
        if ($column_name !== 'pmp_lock') {
            return;
        }
        
        ?>
        <fieldset class="inline-edit-col-right">
            <div class="inline-edit-col">
                <label>
                    <span class="title"><?php _e('Uzamknutí', 'premium-membership-pro'); ?></span>
                    <span class="input-text-wrap">
                        <label class="pmp-switch-small">
                            <input type="checkbox" name="pmp_content_locked" value="1">
                            <span class="pmp-slider-small"></span>
                        </label>
                        <span class="pmp-lock-quick-label"><?php _e('Uzamknout', 'premium-membership-pro'); ?></span>
                    </span>
                </label>
            </div>
        </fieldset>
        <?php
    }
    
    /**
     * Quick edit script
     */
    public static function quick_edit_script() {
        global $current_screen;
        
        if (!in_array($current_screen->post_type, array('post', 'page'))) {
            return;
        }
        
        ?>
        <script type="text/javascript">
        (function($) {
            var $wp_inline_edit = inlineEditPost.edit;
            
            inlineEditPost.edit = function(id) {
                $wp_inline_edit.apply(this, arguments);
                
                var post_id = 0;
                if (typeof(id) == 'object') {
                    post_id = parseInt(this.getId(id));
                }
                
                if (post_id > 0) {
                    var $row = $('#post-' + post_id);
                    var $lock_badge = $row.find('.pmp-lock-badge');
                    var is_locked = $lock_badge.hasClass('pmp-locked');
                    
                    $('#edit-' + post_id + ' input[name="pmp_content_locked"]').prop('checked', is_locked);
                }
            };
        })(jQuery);
        </script>
        <?php
    }
    
    /**
     * Add bulk lock actions
     */
    public static function add_bulk_lock_actions($actions) {
        $actions['pmp_lock'] = __('🔒 Uzamknout', 'premium-membership-pro');
        $actions['pmp_unlock'] = __('🔓 Odemknout', 'premium-membership-pro');
        return $actions;
    }
    
    /**
     * Handle bulk lock
     */
    public static function handle_bulk_lock($redirect_to, $action, $post_ids) {
        if ($action === 'pmp_lock') {
            foreach ($post_ids as $post_id) {
                update_post_meta($post_id, '_pmp_content_locked', '1');
                update_post_meta($post_id, '_pmp_locked_by', get_current_user_id());
                update_post_meta($post_id, '_pmp_locked_at', current_time('timestamp'));
            }
            
            $redirect_to = add_query_arg('pmp_locked', count($post_ids), $redirect_to);
        } elseif ($action === 'pmp_unlock') {
            foreach ($post_ids as $post_id) {
                delete_post_meta($post_id, '_pmp_content_locked');
                delete_post_meta($post_id, '_pmp_locked_by');
                delete_post_meta($post_id, '_pmp_locked_at');
                delete_post_meta($post_id, '_pmp_lock_reason');
            }
            
            $redirect_to = add_query_arg('pmp_unlocked', count($post_ids), $redirect_to);
        }
        
        return $redirect_to;
    }
    
    /**
     * Add lock to admin bar
     */
    public static function add_lock_to_admin_bar($wp_admin_bar) {
        if (!is_singular()) {
            return;
        }
        
        $post_id = get_the_ID();
        $is_locked = get_post_meta($post_id, '_pmp_content_locked', true);
        
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        $icon = $is_locked ? 'dashicons-lock' : 'dashicons-unlock';
        $title = $is_locked ? __('Uzamknuto', 'premium-membership-pro') : __('Odemknuto', 'premium-membership-pro');
        
        $wp_admin_bar->add_node(array(
            'id' => 'pmp-content-lock',
            'title' => '<span class="ab-icon dashicons ' . $icon . '"></span><span class="ab-label">' . $title . '</span>',
            'href' => '#',
            'meta' => array(
                'class' => 'pmp-admin-bar-lock',
                'onclick' => 'return false;',
            ),
        ));
        
        $wp_admin_bar->add_node(array(
            'id' => 'pmp-toggle-lock',
            'parent' => 'pmp-content-lock',
            'title' => $is_locked ? __('🔓 Odemknout', 'premium-membership-pro') : __('🔒 Uzamknout', 'premium-membership-pro'),
            'href' => '#',
            'meta' => array(
                'class' => 'pmp-toggle-lock-link',
                'data-post-id' => $post_id,
                'data-nonce' => wp_create_nonce('pmp_toggle_lock_' . $post_id),
            ),
        ));
    }
    
    /**
     * Add lock row action
     */
    public static function add_lock_row_action($actions, $post) {
        if (!current_user_can('edit_post', $post->ID)) {
            return $actions;
        }
        
        $is_locked = get_post_meta($post->ID, '_pmp_content_locked', true);
        
        if ($is_locked) {
            $actions['pmp_unlock'] = '<a href="#" class="pmp-row-lock-toggle" data-post-id="' . $post->ID . '" data-action="unlock" data-nonce="' . wp_create_nonce('pmp_toggle_lock_' . $post->ID) . '">🔓 ' . __('Odemknout', 'premium-membership-pro') . '</a>';
        } else {
            $actions['pmp_lock'] = '<a href="#" class="pmp-row-lock-toggle" data-post-id="' . $post->ID . '" data-action="lock" data-nonce="' . wp_create_nonce('pmp_toggle_lock_' . $post->ID) . '">🔒 ' . __('Uzamknout', 'premium-membership-pro') . '</a>';
        }
        
        return $actions;
    }
    
    /**
     * AJAX: Toggle lock
     */
    public static function ajax_toggle_lock() {
        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        $nonce = isset($_POST['nonce']) ? $_POST['nonce'] : '';
        
        if (!wp_verify_nonce($nonce, 'pmp_toggle_lock_' . $post_id)) {
            wp_send_json_error(array('message' => __('Neplatný nonce.', 'premium-membership-pro')));
        }
        
        if (!current_user_can('edit_post', $post_id)) {
            wp_send_json_error(array('message' => __('Nemáte oprávnění.', 'premium-membership-pro')));
        }
        
        $is_locked = get_post_meta($post_id, '_pmp_content_locked', true);
        
        if ($is_locked) {
            // Unlock
            delete_post_meta($post_id, '_pmp_content_locked');
            delete_post_meta($post_id, '_pmp_locked_by');
            delete_post_meta($post_id, '_pmp_locked_at');
            delete_post_meta($post_id, '_pmp_lock_reason');
            
            wp_send_json_success(array(
                'message' => __('Obsah odemknut.', 'premium-membership-pro'),
                'locked' => false,
            ));
        } else {
            // Lock
            update_post_meta($post_id, '_pmp_content_locked', '1');
            update_post_meta($post_id, '_pmp_locked_by', get_current_user_id());
            update_post_meta($post_id, '_pmp_locked_at', current_time('timestamp'));
            
            wp_send_json_success(array(
                'message' => __('Obsah uzamknut.', 'premium-membership-pro'),
                'locked' => true,
            ));
        }
    }
    
    /**
     * Enqueue scripts
     */
    public static function enqueue_scripts($hook) {
        global $post_type;
        
        if (!in_array($post_type, array('post', 'page')) && !in_array($hook, array('edit.php', 'post.php', 'post-new.php'))) {
            return;
        }
        
        wp_enqueue_style('pmp-content-lock', PMP_PLUGIN_URL . 'assets/css/content-lock.css', array(), PMP_VERSION);
        wp_enqueue_script('pmp-content-lock', PMP_PLUGIN_URL . 'assets/js/content-lock.js', array('jquery'), PMP_VERSION, true);
        
        wp_localize_script('pmp-content-lock', 'pmpLock', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'locked_text' => __('Uzamknuto', 'premium-membership-pro'),
            'unlocked_text' => __('Odemknuto', 'premium-membership-pro'),
        ));
    }
    
    /**
     * Filter locked content on frontend
     */
    public static function filter_locked_content($content) {
        if (is_admin()) {
            return $content;
        }
        
        $post_id = get_the_ID();
        $is_locked = get_post_meta($post_id, '_pmp_content_locked', true);
        
        if (!$is_locked) {
            return $content;
        }
        
        // Show to admins
        if (current_user_can('edit_post', $post_id)) {
            return '<div class="pmp-locked-admin-notice">🔒 ' . __('Tento obsah je uzamknut. Pouze vy (admin) ho vidíte.', 'premium-membership-pro') . '</div>' . $content;
        }
        
        // Hide from others
        $lock_reason = get_post_meta($post_id, '_pmp_lock_reason', true);
        
        $message = '<div class="pmp-locked-content-message">';
        $message .= '<div class="pmp-locked-icon">🔒</div>';
        $message .= '<h3>' . __('Obsah není dostupný', 'premium-membership-pro') . '</h3>';
        $message .= '<p>' . __('Tento obsah je dočasně uzamknut a není k dispozici.', 'premium-membership-pro') . '</p>';
        
        if ($lock_reason) {
            $message .= '<p class="pmp-lock-reason"><strong>' . __('Důvod:', 'premium-membership-pro') . '</strong> ' . esc_html($lock_reason) . '</p>';
        }
        
        $message .= '</div>';
        
        return $message;
    }
    
    /**
     * Block editing of locked posts
     */
    public static function block_locked_edit($post_id, $post) {
        // Only check on actual edits (not autosaves)
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        $is_locked = get_post_meta($post_id, '_pmp_content_locked', true);
        $locked_by = get_post_meta($post_id, '_pmp_locked_by', true);
        
        if ($is_locked && $locked_by && $locked_by != get_current_user_id()) {
            $user = get_userdata($locked_by);
            wp_die(sprintf(
                __('Tento obsah je uzamknut uživatelem %s a nelze ho upravit.', 'premium-membership-pro'),
                $user ? $user->display_name : __('Neznámý', 'premium-membership-pro')
            ));
        }
    }
}
