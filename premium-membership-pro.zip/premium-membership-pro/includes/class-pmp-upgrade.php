<?php
/**
 * Upgrade Page
 * Premium features and upgrade options
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Upgrade {
    
    public static function init() {
        // Add upgrade menu item
        add_action('admin_menu', array(__CLASS__, 'add_menu'), 100);
        
        // Enqueue upgrade page styles
        add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_scripts'));
        
        // Add upgrade notices
        add_action('admin_notices', array(__CLASS__, 'upgrade_notices'));
    }
    
    /**
     * Add upgrade menu
     */
    public static function add_menu() {
        add_submenu_page(
            'premium-membership-pro',
            __('Upgrade na Premium', 'premium-membership-pro'),
            '<span style="color: #f39c12;">⭐ ' . __('Upgrade', 'premium-membership-pro') . '</span>',
            'manage_options',
            'pmp-upgrade',
            array(__CLASS__, 'render_page')
        );
    }
    
    /**
     * Enqueue scripts
     */
    public static function enqueue_scripts($hook) {
        if ($hook !== 'membership-pro_page_pmp-upgrade') {
            return;
        }
        
        wp_enqueue_style('pmp-upgrade', PMP_PLUGIN_URL . 'assets/css/upgrade.css', array(), PMP_VERSION);
    }
    
    /**
     * Render upgrade page
     */
    public static function render_page() {
        ?>
        <div class="wrap pmp-upgrade-page">
            <div class="pmp-upgrade-header">
                <h1>
                    ⭐ <?php _e('Upgrade na Premium Membership Pro', 'premium-membership-pro'); ?>
                </h1>
                <p class="subtitle">
                    <?php _e('Získejte přístup k pokročilým funkcím a prémiovému obsahu', 'premium-membership-pro'); ?>
                </p>
            </div>
            
            <!-- Current Version -->
            <div class="pmp-current-version">
                <div class="pmp-version-badge">
                    <span class="pmp-badge-label"><?php _e('Aktuální verze', 'premium-membership-pro'); ?></span>
                    <span class="pmp-badge-version">FREE v<?php echo PMP_VERSION; ?></span>
                </div>
                <p><?php _e('Používáte bezplatnou verzi pluginu s základními funkcemi.', 'premium-membership-pro'); ?></p>
            </div>
            
            <!-- Pricing Plans -->
            <div class="pmp-pricing-section">
                <h2><?php _e('Vyberte si plán', 'premium-membership-pro'); ?></h2>
                
                <div class="pmp-pricing-grid">
                    
                    <!-- Free Plan -->
                    <div class="pmp-pricing-card pmp-current">
                        <div class="pmp-plan-badge"><?php _e('Aktuální', 'premium-membership-pro'); ?></div>
                        <h3><?php _e('Free', 'premium-membership-pro'); ?></h3>
                        <div class="pmp-price">
                            <span class="pmp-amount">0 Kč</span>
                            <span class="pmp-period"><?php _e('navždy', 'premium-membership-pro'); ?></span>
                        </div>
                        
                        <ul class="pmp-features">
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Základní ochrana obsahu', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Neomezené membership úrovně', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Preview režim s blur efektem', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Elementor integrace', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Krásné auth stránky', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Meta boxy v editoru', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Základní reporty', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-no"></span> <?php _e('Platební brány', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-no"></span> <?php _e('Automatické faktury', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-no"></span> <?php _e('Email automations', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-no"></span> <?php _e('Pokročilé reporty', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-no"></span> <?php _e('Prioritní podpora', 'premium-membership-pro'); ?></li>
                        </ul>
                        
                        <button class="button button-secondary" disabled>
                            <?php _e('Aktuální plán', 'premium-membership-pro'); ?>
                        </button>
                    </div>
                    
                    <!-- Pro Plan -->
                    <div class="pmp-pricing-card pmp-popular">
                        <div class="pmp-plan-badge pmp-popular-badge"><?php _e('Nejoblíbenější', 'premium-membership-pro'); ?></div>
                        <h3><?php _e('Professional', 'premium-membership-pro'); ?></h3>
                        <div class="pmp-price">
                            <span class="pmp-amount">2 990 Kč</span>
                            <span class="pmp-period"><?php _e('/ rok', 'premium-membership-pro'); ?></span>
                        </div>
                        
                        <ul class="pmp-features">
                            <li><span class="dashicons dashicons-yes"></span> <strong><?php _e('Vše z Free +', 'premium-membership-pro'); ?></strong></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Stripe integrace', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('PayPal integrace', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Automatické faktury (PDF)', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Email automations', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Pokročilé reporty', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Export dat (CSV, Excel)', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Drip content', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Content scheduling', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Affiliate system', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('API přístup', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Prioritní email podpora', 'premium-membership-pro'); ?></li>
                        </ul>
                        
                        <a href="https://conexo.cz/premium-membership-pro/upgrade?plan=pro" class="button button-primary button-hero" target="_blank">
                            <?php _e('Upgradovat nyní', 'premium-membership-pro'); ?> →
                        </a>
                    </div>
                    
                    <!-- Enterprise Plan -->
                    <div class="pmp-pricing-card">
                        <h3><?php _e('Enterprise', 'premium-membership-pro'); ?></h3>
                        <div class="pmp-price">
                            <span class="pmp-amount">9 990 Kč</span>
                            <span class="pmp-period"><?php _e('/ rok', 'premium-membership-pro'); ?></span>
                        </div>
                        
                        <ul class="pmp-features">
                            <li><span class="dashicons dashicons-yes"></span> <strong><?php _e('Vše z Professional +', 'premium-membership-pro'); ?></strong></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Neomezené weby', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('White-label možnosti', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Vlastní branding', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Custom integrace', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Multisite podpora', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Dedikovaný account manager', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Telefonická podpora', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Instalace a setup', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Custom vývoj', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('SLA 99.9%', 'premium-membership-pro'); ?></li>
                            <li><span class="dashicons dashicons-yes"></span> <?php _e('Vše ostatní', 'premium-membership-pro'); ?></li>
                        </ul>
                        
                        <a href="mailto:info@conexo.cz?subject=Premium%20Membership%20Pro%20Enterprise" class="button button-secondary button-hero">
                            <?php _e('Kontaktovat nás', 'premium-membership-pro'); ?> →
                        </a>
                    </div>
                    
                </div>
            </div>
            
            <!-- Premium Features Showcase -->
            <div class="pmp-features-showcase">
                <h2><?php _e('Premium funkce', 'premium-membership-pro'); ?></h2>
                
                <div class="pmp-features-grid">
                    
                    <div class="pmp-feature-box">
                        <div class="pmp-feature-icon">💳</div>
                        <h3><?php _e('Platební brány', 'premium-membership-pro'); ?></h3>
                        <p><?php _e('Přijímejte platby přes Stripe a PayPal. Automatické recurring payments, refundy a více.', 'premium-membership-pro'); ?></p>
                    </div>
                    
                    <div class="pmp-feature-box">
                        <div class="pmp-feature-icon">📧</div>
                        <h3><?php _e('Email Automations', 'premium-membership-pro'); ?></h3>
                        <p><?php _e('Automatické emaily při registraci, expiracích, renewalech. Vlastní šablony a triggery.', 'premium-membership-pro'); ?></p>
                    </div>
                    
                    <div class="pmp-feature-box">
                        <div class="pmp-feature-icon">📊</div>
                        <h3><?php _e('Pokročilé reporty', 'premium-membership-pro'); ?></h3>
                        <p><?php _e('MRR, churn rate, LTV, conversion rates. Exportujte data do Excel. Integrujte s Google Analytics.', 'premium-membership-pro'); ?></p>
                    </div>
                    
                    <div class="pmp-feature-box">
                        <div class="pmp-feature-icon">🧾</div>
                        <h3><?php _e('Automatické faktury', 'premium-membership-pro'); ?></h3>
                        <p><?php _e('Generujte PDF faktury automaticky. Compliance s českými účetními standardy. QR kódy pro platby.', 'premium-membership-pro'); ?></p>
                    </div>
                    
                    <div class="pmp-feature-box">
                        <div class="pmp-feature-icon">💧</div>
                        <h3><?php _e('Drip Content', 'premium-membership-pro'); ?></h3>
                        <p><?php _e('Uvolňujte obsah postupně. Nastavte kdy členové získají přístup k jednotlivým lekcím nebo modulům.', 'premium-membership-pro'); ?></p>
                    </div>
                    
                    <div class="pmp-feature-box">
                        <div class="pmp-feature-icon">🔗</div>
                        <h3><?php _e('API & Integrace', 'premium-membership-pro'); ?></h3>
                        <p><?php _e('REST API pro vlastní integrace. Webhooks. Zapier. Make.com. Propojte s CRM, email marketing a více.', 'premium-membership-pro'); ?></p>
                    </div>
                    
                </div>
            </div>
            
            <!-- FAQ -->
            <div class="pmp-faq-section">
                <h2><?php _e('Často kladené otázky', 'premium-membership-pro'); ?></h2>
                
                <div class="pmp-faq-grid">
                    
                    <div class="pmp-faq-item">
                        <h3><?php _e('Jak probíhá upgrade?', 'premium-membership-pro'); ?></h3>
                        <p><?php _e('Po zakoupení získáte přístup ke stažení premium verze. Jednoduše nahradíte free plugin premium verzí. Všechna vaše data zůstanou zachována.', 'premium-membership-pro'); ?></p>
                    </div>
                    
                    <div class="pmp-faq-item">
                        <h3><?php _e('Lze upgradovat kdykoliv?', 'premium-membership-pro'); ?></h3>
                        <p><?php _e('Ano! Můžete upgradovat kdykoliv. Platba je jednorázová roční a můžete zrušit kdykoli.', 'premium-membership-pro'); ?></p>
                    </div>
                    
                    <div class="pmp-faq-item">
                        <h3><?php _e('Co když budu potřebovat pomoc?', 'premium-membership-pro'); ?></h3>
                        <p><?php _e('Premium uživatelé mají prioritní podporu přes email. Enterprise zákazníci mají i telefonickou podporu a dedikovaného account managera.', 'premium-membership-pro'); ?></p>
                    </div>
                    
                    <div class="pmp-faq-item">
                        <h3><?php _e('Funguje na více webech?', 'premium-membership-pro'); ?></h3>
                        <p><?php _e('Professional plán je pro 1 web. Enterprise plán je pro neomezený počet webů.', 'premium-membership-pro'); ?></p>
                    </div>
                    
                    <div class="pmp-faq-item">
                        <h3><?php _e('Jsou aktualizace zdarma?', 'premium-membership-pro'); ?></h3>
                        <p><?php _e('Ano! Všechny aktualizace a nové funkce jsou zahrnuty v ceně licence po dobu jejího trvání.', 'premium-membership-pro'); ?></p>
                    </div>
                    
                    <div class="pmp-faq-item">
                        <h3><?php _e('Nabízíte refund?', 'premium-membership-pro'); ?></h3>
                        <p><?php _e('Ano, nabízíme 30denní money-back garance. Pokud nebudete spokojeni, vrátíme vám peníze.', 'premium-membership-pro'); ?></p>
                    </div>
                    
                </div>
            </div>
            
            <!-- CTA Section -->
            <div class="pmp-cta-section">
                <h2><?php _e('Připraveni upgradovat?', 'premium-membership-pro'); ?></h2>
                <p><?php _e('Získejte přístup ke všem premium funkcím ještě dnes!', 'premium-membership-pro'); ?></p>
                <div class="pmp-cta-buttons">
                    <a href="https://conexo.cz/premium-membership-pro/upgrade?plan=pro" class="button button-primary button-hero" target="_blank">
                        ⭐ <?php _e('Upgradovat na Professional', 'premium-membership-pro'); ?>
                    </a>
                    <a href="mailto:info@conexo.cz?subject=Premium%20Membership%20Pro" class="button button-secondary button-hero">
                        📧 <?php _e('Kontaktovat sales', 'premium-membership-pro'); ?>
                    </a>
                </div>
            </div>
            
            <!-- Footer -->
            <div class="pmp-upgrade-footer">
                <p>
                    <?php _e('Máte otázky?', 'premium-membership-pro'); ?> 
                    <a href="mailto:info@conexo.cz">info@conexo.cz</a> | 
                    <a href="https://conexo.cz" target="_blank">conexo.cz</a> |
                    <a href="https://github.com/conexo-sro/premium-membership-pro" target="_blank">GitHub</a>
                </p>
            </div>
        </div>
        <?php
    }
    
    /**
     * Upgrade notices
     */
    public static function upgrade_notices() {
        $screen = get_current_screen();
        
        // Show on main plugin pages
        if (strpos($screen->id, 'membership-pro') === false || $screen->id === 'membership-pro_page_pmp-upgrade') {
            return;
        }
        
        // Dismiss option
        if (isset($_GET['pmp_dismiss_upgrade_notice'])) {
            update_option('pmp_upgrade_notice_dismissed', time());
            wp_redirect(remove_query_arg('pmp_dismiss_upgrade_notice'));
            exit;
        }
        
        // Check if dismissed (show again after 7 days)
        $dismissed = get_option('pmp_upgrade_notice_dismissed');
        if ($dismissed && (time() - $dismissed) < (7 * DAY_IN_SECONDS)) {
            return;
        }
        
        ?>
        <div class="notice notice-info is-dismissible pmp-upgrade-notice">
            <p>
                <strong>⭐ <?php _e('Upgrade na Premium!', 'premium-membership-pro'); ?></strong>
                <?php _e('Získejte platební brány, email automations, pokročilé reporty a více.', 'premium-membership-pro'); ?>
                <a href="<?php echo admin_url('admin.php?page=pmp-upgrade'); ?>" class="button button-primary button-small" style="margin-left: 10px;">
                    <?php _e('Zobrazit plány', 'premium-membership-pro'); ?>
                </a>
                <a href="<?php echo add_query_arg('pmp_dismiss_upgrade_notice', '1'); ?>" style="margin-left: 10px;">
                    <?php _e('Připomenout později', 'premium-membership-pro'); ?>
                </a>
            </p>
        </div>
        <?php
    }
}
