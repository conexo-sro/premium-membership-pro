<?php
/**
 * Uninstall Dialog
 * Ask user if they want to keep data when uninstalling
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Uninstall_Dialog {
    
    public static function init() {
        // Add uninstall settings
        add_action('admin_init', array(__CLASS__, 'register_settings'));
        
        // Add settings to plugin page
        add_filter('plugin_action_links_' . plugin_basename(PMP_PLUGIN_FILE), array(__CLASS__, 'add_settings_link'));
        
        // Add uninstall notice
        add_action('admin_notices', array(__CLASS__, 'uninstall_notice'));
        
        // Handle AJAX save
        add_action('wp_ajax_pmp_save_uninstall_option', array(__CLASS__, 'ajax_save_uninstall_option'));
        
        // Add modal to plugins page
        add_action('admin_footer-plugins.php', array(__CLASS__, 'add_uninstall_modal'));
        
        // Enqueue scripts
        add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_scripts'));
    }
    
    /**
     * Register settings
     */
    public static function register_settings() {
        register_setting('pmp_uninstall', 'pmp_keep_data_on_uninstall');
    }
    
    /**
     * Enqueue scripts
     */
    public static function enqueue_scripts($hook) {
        if ($hook !== 'plugins.php') {
            return;
        }
        
        wp_enqueue_style('pmp-uninstall-dialog', PMP_PLUGIN_URL . 'assets/css/uninstall-dialog.css', array(), PMP_VERSION);
        wp_enqueue_script('pmp-uninstall-dialog', PMP_PLUGIN_URL . 'assets/js/uninstall-dialog.js', array('jquery'), PMP_VERSION, true);
        
        wp_localize_script('pmp-uninstall-dialog', 'pmpUninstall', array(
            'plugin' => plugin_basename(PMP_PLUGIN_FILE),
            'nonce' => wp_create_nonce('pmp_uninstall_dialog'),
        ));
    }
    
    /**
     * Add settings link
     */
    public static function add_settings_link($links) {
        $settings_link = '<a href="' . admin_url('admin.php?page=pmp-settings') . '">' . __('Nastavení', 'premium-membership-pro') . '</a>';
        array_unshift($links, $settings_link);
        return $links;
    }
    
    /**
     * Uninstall notice
     */
    public static function uninstall_notice() {
        $screen = get_current_screen();
        if ($screen->id !== 'plugins') {
            return;
        }
        
        // Check if we should show the notice
        if (!isset($_GET['pmp_show_uninstall_info'])) {
            return;
        }
        
        ?>
        <div class="notice notice-info is-dismissible">
            <p>
                <strong><?php _e('Nastavení odinstalace Premium Membership Pro', 'premium-membership-pro'); ?></strong>
            </p>
            <p>
                <?php _e('Můžete si vybrat, zda chcete při odinstalaci smazat všechna data nebo je zachovat.', 'premium-membership-pro'); ?>
                <a href="<?php echo admin_url('admin.php?page=pmp-settings#uninstall'); ?>">
                    <?php _e('Nastavit v Settings', 'premium-membership-pro'); ?>
                </a>
            </p>
        </div>
        <?php
    }
    
    /**
     * Add uninstall modal
     */
    public static function add_uninstall_modal() {
        $keep_data = get_option('pmp_keep_data_on_uninstall', false);
        ?>
        
        <div id="pmp-uninstall-modal" class="pmp-modal" style="display: none;">
            <div class="pmp-modal-overlay"></div>
            <div class="pmp-modal-content">
                <div class="pmp-modal-header">
                    <h2><?php _e('Odinstalovat Premium Membership Pro?', 'premium-membership-pro'); ?></h2>
                    <button class="pmp-modal-close">&times;</button>
                </div>
                
                <div class="pmp-modal-body">
                    <div class="pmp-warning-box">
                        <span class="dashicons dashicons-warning"></span>
                        <p><?php _e('Opravdu chcete odinstalovat plugin? Tato akce nelze vrátit zpět.', 'premium-membership-pro'); ?></p>
                    </div>
                    
                    <div class="pmp-uninstall-options">
                        <h3><?php _e('Co se stane s vašimi daty?', 'premium-membership-pro'); ?></h3>
                        
                        <label class="pmp-option-card <?php echo !$keep_data ? 'pmp-selected' : ''; ?>">
                            <input type="radio" name="pmp_uninstall_option" value="delete" <?php checked(!$keep_data); ?>>
                            <div class="pmp-option-content">
                                <div class="pmp-option-icon pmp-delete-icon">🗑️</div>
                                <div class="pmp-option-text">
                                    <strong><?php _e('Smazat všechna data', 'premium-membership-pro'); ?></strong>
                                    <p><?php _e('Odstraní všechny tabulky, nastavení, posty a uživatelská data.', 'premium-membership-pro'); ?></p>
                                    <ul class="pmp-delete-list">
                                        <li>❌ Všechny membership úrovně</li>
                                        <li>❌ Všechny členství uživatelů</li>
                                        <li>❌ Všechny transakce</li>
                                        <li>❌ Všechna nastavení</li>
                                        <li>❌ Access logy</li>
                                        <li>❌ Vytvořené stránky (přihlášení, registrace)</li>
                                    </ul>
                                </div>
                            </div>
                        </label>
                        
                        <label class="pmp-option-card <?php echo $keep_data ? 'pmp-selected' : ''; ?>">
                            <input type="radio" name="pmp_uninstall_option" value="keep" <?php checked($keep_data); ?>>
                            <div class="pmp-option-content">
                                <div class="pmp-option-icon pmp-keep-icon">💾</div>
                                <div class="pmp-option-text">
                                    <strong><?php _e('Zachovat data', 'premium-membership-pro'); ?></strong>
                                    <p><?php _e('Ponechá všechna data. Můžete plugin později znovu nainstalovat.', 'premium-membership-pro'); ?></p>
                                    <ul class="pmp-keep-list">
                                        <li>✅ Membership úrovně zachovány</li>
                                        <li>✅ Členství uživatelů zachována</li>
                                        <li>✅ Transakce zachovány</li>
                                        <li>✅ Nastavení zachována</li>
                                        <li>✅ Logy zachovány</li>
                                        <li>✅ Stránky zachovány</li>
                                    </ul>
                                </div>
                            </div>
                        </label>
                    </div>
                    
                    <div class="pmp-data-summary">
                        <h4><?php _e('Přehled dat k odstranění:', 'premium-membership-pro'); ?></h4>
                        <?php
                        global $wpdb;
                        
                        // Count levels
                        $levels = wp_count_posts('pmp_membership');
                        $levels_count = $levels->publish + $levels->draft;
                        
                        // Count memberships
                        $memberships_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}pmp_memberships");
                        
                        // Count transactions
                        $transactions_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}pmp_transactions");
                        
                        // Count logs
                        $logs_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}pmp_access_logs");
                        ?>
                        <ul class="pmp-data-counts">
                            <li><strong><?php echo number_format($levels_count); ?></strong> <?php _e('membership úrovní', 'premium-membership-pro'); ?></li>
                            <li><strong><?php echo number_format($memberships_count); ?></strong> <?php _e('aktivních členství', 'premium-membership-pro'); ?></li>
                            <li><strong><?php echo number_format($transactions_count); ?></strong> <?php _e('transakcí', 'premium-membership-pro'); ?></li>
                            <li><strong><?php echo number_format($logs_count); ?></strong> <?php _e('access logů', 'premium-membership-pro'); ?></li>
                        </ul>
                    </div>
                </div>
                
                <div class="pmp-modal-footer">
                    <button class="button button-secondary pmp-modal-cancel">
                        <?php _e('Zrušit', 'premium-membership-pro'); ?>
                    </button>
                    <button class="button button-primary pmp-confirm-uninstall" disabled>
                        <?php _e('Pokračovat v odinstalaci', 'premium-membership-pro'); ?>
                    </button>
                </div>
            </div>
        </div>
        
        <?php
    }
    
    /**
     * AJAX: Save uninstall option
     */
    public static function ajax_save_uninstall_option() {
        check_ajax_referer('pmp_uninstall_dialog', 'nonce');
        
        if (!current_user_can('activate_plugins')) {
            wp_send_json_error(array('message' => __('Nemáte oprávnění.', 'premium-membership-pro')));
        }
        
        $option = isset($_POST['option']) ? sanitize_text_field($_POST['option']) : 'delete';
        $keep_data = ($option === 'keep');
        
        update_option('pmp_keep_data_on_uninstall', $keep_data);
        
        wp_send_json_success(array(
            'message' => __('Nastavení uloženo.', 'premium-membership-pro'),
            'keep_data' => $keep_data,
        ));
    }
}
