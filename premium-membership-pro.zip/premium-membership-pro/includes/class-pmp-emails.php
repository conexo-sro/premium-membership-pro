<?php
/**
 * Emails Management Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Emails {
    
    public static function init() {
        add_filter('wp_mail_from', array(__CLASS__, 'from_email'));
        add_filter('wp_mail_from_name', array(__CLASS__, 'from_name'));
    }
    
    public static function from_email($email) {
        $custom_email = get_option('pmp_from_email');
        return $custom_email ? $custom_email : $email;
    }
    
    public static function from_name($name) {
        $custom_name = get_option('pmp_from_name');
        return $custom_name ? $custom_name : $name;
    }
    
    public static function send_welcome_email($user_id, $level_id) {
        $user = get_userdata($user_id);
        $level = get_post($level_id);
        
        $subject = sprintf(__('Vítejte v %s!', 'premium-membership-pro'), $level->post_title);
        
        $message = self::get_email_template('welcome', array(
            'user_name' => $user->display_name,
            'level_name' => $level->post_title,
            'login_url' => wp_login_url(),
            'account_url' => get_permalink(get_option('pmp_account_page')),
        ));
        
        self::send_email($user->user_email, $subject, $message, 'welcome');
        self::log_email($user_id, 'welcome', $subject);
    }
    
    public static function send_cancellation_email($user_id, $level_id, $reason = '') {
        $user = get_userdata($user_id);
        $level = get_post($level_id);
        
        $subject = sprintf(__('Vaše členství %s bylo zrušeno', 'premium-membership-pro'), $level->post_title);
        
        $message = self::get_email_template('cancellation', array(
            'user_name' => $user->display_name,
            'level_name' => $level->post_title,
            'reason' => $reason,
            'reactivate_url' => get_permalink(get_option('pmp_pricing_page')),
        ));
        
        self::send_email($user->user_email, $subject, $message, 'cancellation');
        self::log_email($user_id, 'cancellation', $subject);
    }
    
    public static function send_renewal_email($user_id, $level_id) {
        $user = get_userdata($user_id);
        $level = get_post($level_id);
        
        $subject = sprintf(__('Vaše členství %s bylo obnoveno', 'premium-membership-pro'), $level->post_title);
        
        $message = self::get_email_template('renewal', array(
            'user_name' => $user->display_name,
            'level_name' => $level->post_title,
            'account_url' => get_permalink(get_option('pmp_account_page')),
        ));
        
        self::send_email($user->user_email, $subject, $message, 'renewal');
        self::log_email($user_id, 'renewal', $subject);
    }
    
    public static function send_expiration_email($user_id, $level_id) {
        $user = get_userdata($user_id);
        $level = get_post($level_id);
        
        $subject = sprintf(__('Vaše členství %s vypršelo', 'premium-membership-pro'), $level->post_title);
        
        $message = self::get_email_template('expiration', array(
            'user_name' => $user->display_name,
            'level_name' => $level->post_title,
            'renew_url' => get_permalink(get_option('pmp_pricing_page')),
        ));
        
        self::send_email($user->user_email, $subject, $message, 'expiration');
        self::log_email($user_id, 'expiration', $subject);
    }
    
    public static function send_expiration_reminder($user_id, $level_id, $end_date) {
        $user = get_userdata($user_id);
        $level = get_post($level_id);
        
        $days_left = ceil((strtotime($end_date) - time()) / (60 * 60 * 24));
        
        $subject = sprintf(__('Vaše členství vyprší za %d dní', 'premium-membership-pro'), $days_left);
        
        $message = self::get_email_template('expiration_reminder', array(
            'user_name' => $user->display_name,
            'level_name' => $level->post_title,
            'days_left' => $days_left,
            'end_date' => date_i18n(get_option('date_format'), strtotime($end_date)),
            'renew_url' => get_permalink(get_option('pmp_account_page')),
        ));
        
        self::send_email($user->user_email, $subject, $message, 'expiration_reminder');
        self::log_email($user_id, 'expiration_reminder', $subject);
    }
    
    public static function send_bank_transfer_instructions($user_id, $level_id, $transaction_id) {
        $user = get_userdata($user_id);
        $level = get_post($level_id);
        $transaction = PMP_Payments::get_transaction($transaction_id);
        
        $subject = __('Pokyny pro dokončení platby bankovním převodem', 'premium-membership-pro');
        
        $bank_details = array(
            'account_number' => get_option('pmp_bank_account_number', ''),
            'bank_code' => get_option('pmp_bank_code', ''),
            'iban' => get_option('pmp_bank_iban', ''),
            'swift' => get_option('pmp_bank_swift', ''),
        );
        
        $message = self::get_email_template('bank_transfer', array(
            'user_name' => $user->display_name,
            'level_name' => $level->post_title,
            'amount' => pmp_format_price($transaction->amount),
            'invoice_number' => $transaction->invoice_number,
            'bank_details' => $bank_details,
        ));
        
        self::send_email($user->user_email, $subject, $message, 'bank_transfer');
        self::log_email($user_id, 'bank_transfer', $subject);
    }
    
    private static function send_email($to, $subject, $message, $type) {
        $headers = array('Content-Type: text/html; charset=UTF-8');
        
        $message = self::wrap_email_template($message);
        
        wp_mail($to, $subject, $message, $headers);
    }
    
    private static function get_email_template($type, $vars = array()) {
        $template_path = PMP_PLUGIN_DIR . 'templates/emails/' . $type . '.php';
        
        if (!file_exists($template_path)) {
            return self::get_default_template($type, $vars);
        }
        
        ob_start();
        extract($vars);
        include $template_path;
        return ob_get_clean();
    }
    
    private static function get_default_template($type, $vars) {
        switch ($type) {
            case 'welcome':
                return sprintf(
                    __('Vítejte, %s!<br><br>Děkujeme za registraci k členství %s.<br><br>Nyní máte přístup k prémiový obsahu na našem webu.<br><br><a href="%s">Přihlásit se</a>', 'premium-membership-pro'),
                    $vars['user_name'],
                    $vars['level_name'],
                    $vars['login_url']
                );
                
            case 'cancellation':
                return sprintf(
                    __('Dobrý den, %s,<br><br>Vaše členství %s bylo zrušeno.<br><br>Budeme rádi, pokud se k nám vrátíte.<br><br><a href="%s">Znovu aktivovat</a>', 'premium-membership-pro'),
                    $vars['user_name'],
                    $vars['level_name'],
                    $vars['reactivate_url']
                );
                
            case 'expiration_reminder':
                return sprintf(
                    __('Dobrý den, %s,<br><br>Vaše členství %s vyprší za %d dní (%s).<br><br>Pro zachování přístupu prosím obnovte své členství.<br><br><a href="%s">Obnovit členství</a>', 'premium-membership-pro'),
                    $vars['user_name'],
                    $vars['level_name'],
                    $vars['days_left'],
                    $vars['end_date'],
                    $vars['renew_url']
                );
                
            default:
                return '';
        }
    }
    
    private static function wrap_email_template($content) {
        $header = get_option('pmp_email_header', '');
        $footer = get_option('pmp_email_footer', '');
        
        $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">';
        $html .= '<div style="max-width: 600px; margin: 0 auto; padding: 20px;">';
        
        if ($header) {
            $html .= '<div style="margin-bottom: 20px;">' . $header . '</div>';
        }
        
        $html .= '<div style="background: #f9f9f9; padding: 20px; border-radius: 5px;">';
        $html .= $content;
        $html .= '</div>';
        
        if ($footer) {
            $html .= '<div style="margin-top: 20px; font-size: 12px; color: #666;">' . $footer . '</div>';
        }
        
        $html .= '</div></body></html>';
        
        return $html;
    }
    
    private static function log_email($user_id, $type, $subject) {
        global $wpdb;
        
        $wpdb->insert(
            $wpdb->prefix . 'pmp_email_logs',
            array(
                'user_id' => $user_id,
                'email_type' => $type,
                'subject' => $subject,
                'status' => 'sent',
                'sent_at' => current_time('mysql'),
            ),
            array('%d', '%s', '%s', '%s', '%s')
        );
    }
}
