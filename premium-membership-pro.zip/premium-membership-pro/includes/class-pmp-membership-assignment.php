<?php
/**
 * Membership Assignment
 * Assign memberships directly from posts/pages
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Membership_Assignment {
    
    public static function init() {
        // Add assignment meta box
        add_action('add_meta_boxes', array(__CLASS__, 'add_assignment_meta_box'));
        
        // Add assignment button to editor
        add_action('media_buttons', array(__CLASS__, 'add_assignment_button'));
        
        // Add assignment to admin bar
        add_action('admin_bar_menu', array(__CLASS__, 'add_assignment_to_admin_bar'), 998);
        
        // AJAX handlers
        add_action('wp_ajax_pmp_search_users', array(__CLASS__, 'ajax_search_users'));
        add_action('wp_ajax_pmp_assign_membership', array(__CLASS__, 'ajax_assign_membership'));
        add_action('wp_ajax_pmp_get_assignment_modal', array(__CLASS__, 'ajax_get_assignment_modal'));
        
        // Enqueue scripts
        add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_scripts'));
        
        // Add assignment notice
        add_action('admin_notices', array(__CLASS__, 'assignment_notice'));
    }
    
    /**
     * Add assignment meta box
     */
    public static function add_assignment_meta_box() {
        $post_types = array('post', 'page');
        $post_types = apply_filters('pmp_assignment_post_types', $post_types);
        
        foreach ($post_types as $post_type) {
            add_meta_box(
                'pmp_membership_assignment',
                '👥 ' . __('Přidělení členství', 'premium-membership-pro'),
                array(__CLASS__, 'render_assignment_meta_box'),
                $post_type,
                'side',
                'default'
            );
        }
    }
    
    /**
     * Render assignment meta box
     */
    public static function render_assignment_meta_box($post) {
        // Get required levels for this post
        $required_levels = get_post_meta($post->ID, '_pmp_required_levels', true);
        $required_levels = $required_levels ? $required_levels : array();
        
        // Get all membership levels
        $levels = get_posts(array(
            'post_type' => 'pmp_membership',
            'posts_per_page' => -1,
            'post_status' => 'publish',
        ));
        
        ?>
        <div class="pmp-assignment-meta-box">
            
            <!-- Info -->
            <div class="pmp-assignment-info">
                <p class="description">
                    <?php _e('Přidělte členství uživatelům, kteří potřebují přístup k tomuto obsahu.', 'premium-membership-pro'); ?>
                </p>
            </div>
            
            <!-- Required Levels -->
            <?php if (!empty($required_levels) && !empty($levels)): ?>
            <div class="pmp-required-levels-box">
                <h4><?php _e('Požadované úrovně:', 'premium-membership-pro'); ?></h4>
                <ul class="pmp-levels-list">
                    <?php foreach ($levels as $level): ?>
                        <?php if (in_array($level->ID, $required_levels)): ?>
                            <li>
                                <span class="pmp-level-badge"><?php echo esc_html($level->post_title); ?></span>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
            
            <!-- Quick Assignment Button -->
            <div class="pmp-quick-assignment">
                <button type="button" class="button button-primary button-large pmp-open-assignment-modal" data-post-id="<?php echo $post->ID; ?>">
                    <span class="dashicons dashicons-groups"></span>
                    <?php _e('Přidělit členství uživatelům', 'premium-membership-pro'); ?>
                </button>
            </div>
            
            <!-- Recent Assignments -->
            <?php
            $recent_assignments = self::get_recent_assignments($post->ID);
            if (!empty($recent_assignments)):
            ?>
            <div class="pmp-recent-assignments">
                <h4><?php _e('Nedávná přidělení:', 'premium-membership-pro'); ?></h4>
                <ul class="pmp-assignments-list">
                    <?php foreach ($recent_assignments as $assignment): ?>
                        <li>
                            <span class="dashicons dashicons-yes"></span>
                            <strong><?php echo esc_html($assignment['user_name']); ?></strong>
                            <span class="pmp-assignment-level"><?php echo esc_html($assignment['level_name']); ?></span>
                            <span class="pmp-assignment-time"><?php echo esc_html($assignment['time_ago']); ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
            
            <!-- Stats -->
            <div class="pmp-assignment-stats">
                <?php
                $total_members = self::count_members_with_access($post->ID);
                ?>
                <div class="pmp-stat-box">
                    <span class="pmp-stat-number"><?php echo number_format($total_members); ?></span>
                    <span class="pmp-stat-label"><?php _e('členů má přístup', 'premium-membership-pro'); ?></span>
                </div>
            </div>
            
        </div>
        <?php
    }
    
    /**
     * Add assignment button to editor
     */
    public static function add_assignment_button() {
        global $post;
        
        if (!$post || !in_array($post->post_type, array('post', 'page'))) {
            return;
        }
        
        ?>
        <button type="button" class="button pmp-editor-assignment-button" data-post-id="<?php echo $post->ID; ?>">
            <span class="dashicons dashicons-groups"></span>
            <?php _e('Přidělit členství', 'premium-membership-pro'); ?>
        </button>
        <?php
    }
    
    /**
     * Add assignment to admin bar
     */
    public static function add_assignment_to_admin_bar($wp_admin_bar) {
        if (!is_singular(array('post', 'page'))) {
            return;
        }
        
        $post_id = get_the_ID();
        
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        $wp_admin_bar->add_node(array(
            'id' => 'pmp-assign-membership',
            'title' => '<span class="ab-icon dashicons dashicons-groups"></span><span class="ab-label">' . __('Přidělit členství', 'premium-membership-pro') . '</span>',
            'href' => '#',
            'meta' => array(
                'class' => 'pmp-admin-bar-assignment',
                'data-post-id' => $post_id,
            ),
        ));
    }
    
    /**
     * Enqueue scripts
     */
    public static function enqueue_scripts($hook) {
        global $post_type, $post;
        
        if (!in_array($post_type, array('post', 'page')) && !in_array($hook, array('post.php', 'post-new.php'))) {
            return;
        }
        
        wp_enqueue_style('pmp-assignment', PMP_PLUGIN_URL . 'assets/css/membership-assignment.css', array(), PMP_VERSION);
        wp_enqueue_script('pmp-assignment', PMP_PLUGIN_URL . 'assets/js/membership-assignment.js', array('jquery', 'jquery-ui-autocomplete'), PMP_VERSION, true);
        
        wp_localize_script('pmp-assignment', 'pmpAssignment', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'post_id' => $post ? $post->ID : 0,
            'nonce' => wp_create_nonce('pmp_assignment'),
            'strings' => array(
                'search_placeholder' => __('Hledat uživatele...', 'premium-membership-pro'),
                'no_results' => __('Žádní uživatelé nenalezeni', 'premium-membership-pro'),
                'select_level' => __('Vyberte úroveň', 'premium-membership-pro'),
                'assign_success' => __('Členství přiděleno!', 'premium-membership-pro'),
                'assign_error' => __('Chyba při přidělování', 'premium-membership-pro'),
            ),
        ));
    }
    
    /**
     * AJAX: Get assignment modal
     */
    public static function ajax_get_assignment_modal() {
        check_ajax_referer('pmp_assignment', 'nonce');
        
        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        
        if (!$post_id || !current_user_can('edit_post', $post_id)) {
            wp_send_json_error(array('message' => __('Nemáte oprávnění.', 'premium-membership-pro')));
        }
        
        $post = get_post($post_id);
        $required_levels = get_post_meta($post_id, '_pmp_required_levels', true);
        $required_levels = $required_levels ? $required_levels : array();
        
        // Get all membership levels
        $levels = get_posts(array(
            'post_type' => 'pmp_membership',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'orderby' => 'title',
            'order' => 'ASC',
        ));
        
        ob_start();
        ?>
        
        <div class="pmp-assignment-modal-header">
            <h2><?php _e('Přidělit členství', 'premium-membership-pro'); ?></h2>
            <p class="pmp-modal-subtitle">
                <?php printf(__('Pro obsah: <strong>%s</strong>', 'premium-membership-pro'), esc_html($post->post_title)); ?>
            </p>
        </div>
        
        <div class="pmp-assignment-modal-body">
            
            <!-- User Search -->
            <div class="pmp-form-group">
                <label for="pmp_user_search">
                    <span class="dashicons dashicons-search"></span>
                    <?php _e('Vyhledat uživatele:', 'premium-membership-pro'); ?>
                </label>
                <input type="text" 
                       id="pmp_user_search" 
                       class="pmp-user-search-input" 
                       placeholder="<?php esc_attr_e('Začněte psát jméno nebo email...', 'premium-membership-pro'); ?>"
                       autocomplete="off">
                <div class="pmp-user-search-results"></div>
            </div>
            
            <!-- Selected User -->
            <div class="pmp-selected-user" style="display: none;">
                <div class="pmp-user-card">
                    <div class="pmp-user-avatar"></div>
                    <div class="pmp-user-info">
                        <strong class="pmp-user-name"></strong>
                        <span class="pmp-user-email"></span>
                    </div>
                    <button type="button" class="pmp-remove-user" title="<?php esc_attr_e('Odstranit', 'premium-membership-pro'); ?>">
                        <span class="dashicons dashicons-no-alt"></span>
                    </button>
                </div>
            </div>
            
            <!-- Level Selection -->
            <div class="pmp-form-group">
                <label for="pmp_level_select">
                    <span class="dashicons dashicons-admin-network"></span>
                    <?php _e('Vyberte úroveň:', 'premium-membership-pro'); ?>
                </label>
                
                <?php if (!empty($levels)): ?>
                    <div class="pmp-levels-grid">
                        <?php foreach ($levels as $level): ?>
                            <?php
                            $price = get_post_meta($level->ID, '_pmp_price', true);
                            $interval = get_post_meta($level->ID, '_pmp_interval', true);
                            $is_required = in_array($level->ID, $required_levels);
                            ?>
                            <label class="pmp-level-card <?php echo $is_required ? 'pmp-required-level' : ''; ?>">
                                <input type="radio" name="pmp_level" value="<?php echo $level->ID; ?>">
                                <div class="pmp-level-card-content">
                                    <?php if ($is_required): ?>
                                        <span class="pmp-required-badge"><?php _e('Požadováno', 'premium-membership-pro'); ?></span>
                                    <?php endif; ?>
                                    <h4><?php echo esc_html($level->post_title); ?></h4>
                                    <?php if ($price): ?>
                                        <p class="pmp-level-price">
                                            <?php echo esc_html($price); ?> Kč / <?php echo esc_html($interval); ?>
                                        </p>
                                    <?php endif; ?>
                                </div>
                            </label>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="pmp-no-levels">
                        <?php _e('Nejsou k dispozici žádné membership úrovně.', 'premium-membership-pro'); ?>
                        <a href="<?php echo admin_url('post-new.php?post_type=pmp_membership'); ?>">
                            <?php _e('Vytvořit první úroveň', 'premium-membership-pro'); ?>
                        </a>
                    </p>
                <?php endif; ?>
            </div>
            
            <!-- Duration -->
            <div class="pmp-form-group">
                <label>
                    <span class="dashicons dashicons-calendar"></span>
                    <?php _e('Doba trvání:', 'premium-membership-pro'); ?>
                </label>
                <div class="pmp-duration-options">
                    <label class="pmp-duration-option">
                        <input type="radio" name="pmp_duration" value="1_month" checked>
                        <span><?php _e('1 měsíc', 'premium-membership-pro'); ?></span>
                    </label>
                    <label class="pmp-duration-option">
                        <input type="radio" name="pmp_duration" value="3_months">
                        <span><?php _e('3 měsíce', 'premium-membership-pro'); ?></span>
                    </label>
                    <label class="pmp-duration-option">
                        <input type="radio" name="pmp_duration" value="6_months">
                        <span><?php _e('6 měsíců', 'premium-membership-pro'); ?></span>
                    </label>
                    <label class="pmp-duration-option">
                        <input type="radio" name="pmp_duration" value="1_year">
                        <span><?php _e('1 rok', 'premium-membership-pro'); ?></span>
                    </label>
                    <label class="pmp-duration-option">
                        <input type="radio" name="pmp_duration" value="lifetime">
                        <span><?php _e('Doživotně', 'premium-membership-pro'); ?></span>
                    </label>
                    <label class="pmp-duration-option">
                        <input type="radio" name="pmp_duration" value="custom">
                        <span><?php _e('Vlastní', 'premium-membership-pro'); ?></span>
                    </label>
                </div>
                
                <!-- Custom Date -->
                <div class="pmp-custom-date" style="display: none;">
                    <label for="pmp_custom_date"><?php _e('Platnost do:', 'premium-membership-pro'); ?></label>
                    <input type="date" id="pmp_custom_date" class="pmp-date-input" min="<?php echo date('Y-m-d'); ?>">
                </div>
            </div>
            
            <!-- Note -->
            <div class="pmp-form-group">
                <label for="pmp_assignment_note">
                    <span class="dashicons dashicons-edit"></span>
                    <?php _e('Poznámka (volitelně):', 'premium-membership-pro'); ?>
                </label>
                <textarea id="pmp_assignment_note" 
                          class="pmp-textarea" 
                          rows="3" 
                          placeholder="<?php esc_attr_e('Např. důvod přidělení, speciální podmínky...', 'premium-membership-pro'); ?>"></textarea>
            </div>
            
            <!-- Send Email -->
            <div class="pmp-form-group">
                <label class="pmp-checkbox-label">
                    <input type="checkbox" id="pmp_send_email" checked>
                    <span><?php _e('Odeslat notifikační email uživateli', 'premium-membership-pro'); ?></span>
                </label>
            </div>
            
        </div>
        
        <div class="pmp-assignment-modal-footer">
            <button type="button" class="button button-secondary pmp-modal-cancel">
                <?php _e('Zrušit', 'premium-membership-pro'); ?>
            </button>
            <button type="button" class="button button-primary pmp-confirm-assignment" disabled>
                <span class="dashicons dashicons-yes"></span>
                <?php _e('Přidělit členství', 'premium-membership-pro'); ?>
            </button>
        </div>
        
        <?php
        $html = ob_get_clean();
        
        wp_send_json_success(array('html' => $html));
    }
    
    /**
     * AJAX: Search users
     */
    public static function ajax_search_users() {
        check_ajax_referer('pmp_assignment', 'nonce');
        
        $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
        
        if (strlen($search) < 2) {
            wp_send_json_success(array('users' => array()));
        }
        
        $users = get_users(array(
            'search' => '*' . $search . '*',
            'search_columns' => array('user_login', 'user_email', 'display_name'),
            'number' => 10,
        ));
        
        $results = array();
        foreach ($users as $user) {
            $results[] = array(
                'id' => $user->ID,
                'name' => $user->display_name,
                'email' => $user->user_email,
                'avatar' => get_avatar_url($user->ID, array('size' => 32)),
            );
        }
        
        wp_send_json_success(array('users' => $results));
    }
    
    /**
     * AJAX: Assign membership
     */
    public static function ajax_assign_membership() {
        check_ajax_referer('pmp_assignment', 'nonce');
        
        $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
        $level_id = isset($_POST['level_id']) ? intval($_POST['level_id']) : 0;
        $duration = isset($_POST['duration']) ? sanitize_text_field($_POST['duration']) : '1_month';
        $custom_date = isset($_POST['custom_date']) ? sanitize_text_field($_POST['custom_date']) : '';
        $note = isset($_POST['note']) ? sanitize_textarea_field($_POST['note']) : '';
        $send_email = isset($_POST['send_email']) ? (bool)$_POST['send_email'] : true;
        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        
        if (!$user_id || !$level_id) {
            wp_send_json_error(array('message' => __('Chybí uživatel nebo úroveň.', 'premium-membership-pro')));
        }
        
        // Calculate expiration date
        $expires_at = self::calculate_expiration($duration, $custom_date);
        
        // Assign membership
        global $wpdb;
        
        $result = $wpdb->insert(
            $wpdb->prefix . 'pmp_memberships',
            array(
                'user_id' => $user_id,
                'level_id' => $level_id,
                'status' => 'active',
                'started_at' => current_time('mysql'),
                'expires_at' => $expires_at,
                'created_at' => current_time('mysql'),
            ),
            array('%d', '%d', '%s', '%s', '%s', '%s')
        );
        
        if (!$result) {
            wp_send_json_error(array('message' => __('Chyba při ukládání členství.', 'premium-membership-pro')));
        }
        
        $membership_id = $wpdb->insert_id;
        
        // Save note
        if ($note) {
            update_user_meta($user_id, '_pmp_membership_note_' . $membership_id, $note);
        }
        
        // Save assignment context
        update_user_meta($user_id, '_pmp_assigned_from_post', $post_id);
        update_user_meta($user_id, '_pmp_assigned_at', current_time('timestamp'));
        update_user_meta($user_id, '_pmp_assigned_by', get_current_user_id());
        
        // Send email
        if ($send_email) {
            self::send_assignment_email($user_id, $level_id, $expires_at);
        }
        
        // Get user data
        $user = get_userdata($user_id);
        $level = get_post($level_id);
        
        wp_send_json_success(array(
            'message' => sprintf(
                __('Členství "%s" přiděleno uživateli %s', 'premium-membership-pro'),
                $level->post_title,
                $user->display_name
            ),
            'membership_id' => $membership_id,
        ));
    }
    
    /**
     * Calculate expiration date
     */
    private static function calculate_expiration($duration, $custom_date = '') {
        if ($duration === 'custom' && $custom_date) {
            return date('Y-m-d H:i:s', strtotime($custom_date . ' 23:59:59'));
        }
        
        if ($duration === 'lifetime') {
            return '2099-12-31 23:59:59';
        }
        
        $intervals = array(
            '1_month' => '+1 month',
            '3_months' => '+3 months',
            '6_months' => '+6 months',
            '1_year' => '+1 year',
        );
        
        $interval = isset($intervals[$duration]) ? $intervals[$duration] : '+1 month';
        
        return date('Y-m-d H:i:s', strtotime($interval));
    }
    
    /**
     * Send assignment email
     */
    private static function send_assignment_email($user_id, $level_id, $expires_at) {
        $user = get_userdata($user_id);
        $level = get_post($level_id);
        
        $subject = sprintf(__('Bylo vám přiděleno členství: %s', 'premium-membership-pro'), $level->post_title);
        
        $message = sprintf(
            __('Dobrý den %s,', 'premium-membership-pro') . "\n\n" .
            __('Bylo vám přiděleno nové členství:', 'premium-membership-pro') . "\n\n" .
            __('Úroveň: %s', 'premium-membership-pro') . "\n" .
            __('Platnost do: %s', 'premium-membership-pro') . "\n\n" .
            __('Nyní máte přístup ke všemu chráněnému obsahu pro tuto úroveň.', 'premium-membership-pro') . "\n\n" .
            __('Přihlásit se můžete zde:', 'premium-membership-pro') . "\n" .
            '%s',
            $user->display_name,
            $level->post_title,
            date_i18n(get_option('date_format'), strtotime($expires_at)),
            wp_login_url()
        );
        
        wp_mail($user->user_email, $subject, $message);
    }
    
    /**
     * Get recent assignments for post
     */
    private static function get_recent_assignments($post_id, $limit = 5) {
        global $wpdb;
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT m.*, u.display_name, l.post_title as level_name
             FROM {$wpdb->prefix}pmp_memberships m
             LEFT JOIN {$wpdb->users} u ON m.user_id = u.ID
             LEFT JOIN {$wpdb->posts} l ON m.level_id = l.ID
             WHERE m.user_id IN (
                 SELECT user_id FROM {$wpdb->usermeta}
                 WHERE meta_key = '_pmp_assigned_from_post'
                 AND meta_value = %d
             )
             ORDER BY m.created_at DESC
             LIMIT %d",
            $post_id,
            $limit
        ));
        
        $assignments = array();
        foreach ($results as $row) {
            $assignments[] = array(
                'user_name' => $row->display_name,
                'level_name' => $row->level_name,
                'time_ago' => human_time_diff(strtotime($row->created_at), current_time('timestamp')) . ' ' . __('ago', 'premium-membership-pro'),
            );
        }
        
        return $assignments;
    }
    
    /**
     * Count members with access to post
     */
    private static function count_members_with_access($post_id) {
        global $wpdb;
        
        $required_levels = get_post_meta($post_id, '_pmp_required_levels', true);
        
        if (empty($required_levels)) {
            return 0;
        }
        
        $placeholders = implode(',', array_fill(0, count($required_levels), '%d'));
        
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT user_id)
             FROM {$wpdb->prefix}pmp_memberships
             WHERE level_id IN ($placeholders)
             AND status = 'active'
             AND (expires_at IS NULL OR expires_at > NOW())",
            $required_levels
        ));
        
        return intval($count);
    }
    
    /**
     * Assignment notice
     */
    public static function assignment_notice() {
        if (!isset($_GET['pmp_assigned'])) {
            return;
        }
        
        $count = intval($_GET['pmp_assigned']);
        
        ?>
        <div class="notice notice-success is-dismissible">
            <p>
                <strong><?php _e('Úspěch!', 'premium-membership-pro'); ?></strong>
                <?php printf(_n('Členství bylo přiděleno %d uživateli.', 'Členství bylo přiděleno %d uživatelům.', $count, 'premium-membership-pro'), $count); ?>
            </p>
        </div>
        <?php
    }
}
