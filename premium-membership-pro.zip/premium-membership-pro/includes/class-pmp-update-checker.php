<?php
/**
 * Plugin Update Checker
 * Checks for updates from GitHub or custom server
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Update_Checker {
    
    private $plugin_slug;
    private $plugin_basename;
    private $version;
    private $cache_key;
    private $cache_allowed;
    private $update_url;
    
    public function __construct($plugin_file, $update_url = '') {
        $this->plugin_slug = plugin_basename($plugin_file);
        $this->plugin_basename = plugin_basename($plugin_file);
        $this->version = PMP_VERSION;
        $this->cache_key = 'pmp_update_checker';
        $this->cache_allowed = true;
        
        // Update URL - GitHub or custom server
        if (empty($update_url)) {
            // Default to GitHub
            $this->update_url = 'https://api.github.com/repos/conexo-sro/premium-membership-pro/releases/latest';
        } else {
            $this->update_url = $update_url;
        }
        
        // Add filters
        add_filter('plugins_api', array($this, 'info'), 20, 3);
        add_filter('site_transient_update_plugins', array($this, 'update'));
        add_action('upgrader_process_complete', array($this, 'purge'), 10, 2);
        
        // Add custom update check action
        add_action('admin_init', array($this, 'maybe_check_for_updates'));
        
        // Add "check for updates" link to plugin row
        add_filter('plugin_row_meta', array($this, 'add_check_update_link'), 10, 2);
        add_filter('plugin_action_links_' . $this->plugin_basename, array($this, 'add_check_update_action'), 10, 1);
    }
    
    /**
     * Check for updates on admin page load (once per day)
     */
    public function maybe_check_for_updates() {
        $last_check = get_transient($this->cache_key . '_last_check');
        
        if (false === $last_check) {
            $this->check_for_update();
            set_transient($this->cache_key . '_last_check', time(), DAY_IN_SECONDS);
        }
    }
    
    /**
     * Force check for updates (for manual button)
     */
    public function force_check() {
        delete_transient($this->cache_key);
        delete_transient($this->cache_key . '_last_check');
        return $this->check_for_update();
    }
    
    /**
     * Get update information
     */
    public function check_for_update() {
        $remote = get_transient($this->cache_key);
        
        if (false === $remote || !$this->cache_allowed) {
            $remote = wp_remote_get(
                $this->update_url,
                array(
                    'timeout' => 10,
                    'headers' => array(
                        'Accept' => 'application/json',
                        'User-Agent' => 'Premium-Membership-Pro/' . $this->version . '; ' . get_bloginfo('url')
                    )
                )
            );
            
            if (is_wp_error($remote) || 200 !== wp_remote_retrieve_response_code($remote) || empty(wp_remote_retrieve_body($remote))) {
                return false;
            }
            
            $remote = json_decode(wp_remote_retrieve_body($remote));
            
            if (!$remote) {
                return false;
            }
            
            // Cache for 12 hours
            set_transient($this->cache_key, $remote, 43200);
        }
        
        return $remote;
    }
    
    /**
     * Update plugin transient
     */
    public function update($transient) {
        if (empty($transient->checked)) {
            return $transient;
        }
        
        $remote = $this->check_for_update();
        
        if ($remote && version_compare($this->version, $remote->tag_name, '<')) {
            $res = new stdClass();
            $res->slug = $this->plugin_slug;
            $res->plugin = $this->plugin_basename;
            $res->new_version = $remote->tag_name;
            $res->tested = PMP_TESTED_WP_VERSION;
            $res->package = $remote->zipball_url;
            
            // If using custom server, expect different structure
            if (isset($remote->download_url)) {
                $res->package = $remote->download_url;
            }
            
            $transient->response[$this->plugin_basename] = $res;
        }
        
        return $transient;
    }
    
    /**
     * Plugin information for popup
     */
    public function info($res, $action, $args) {
        if ('plugin_information' !== $action) {
            return $res;
        }
        
        if ($this->plugin_slug !== $args->slug) {
            return $res;
        }
        
        $remote = $this->check_for_update();
        
        if (!$remote) {
            return $res;
        }
        
        $res = new stdClass();
        $res->name = 'Premium Membership Pro';
        $res->slug = $this->plugin_slug;
        $res->version = $remote->tag_name;
        $res->tested = PMP_TESTED_WP_VERSION;
        $res->requires = PMP_MIN_WP_VERSION;
        $res->author = '<a href="https://conexo.cz">CONEXO s.r.o.</a>';
        $res->author_profile = 'https://conexo.cz';
        $res->download_link = $remote->zipball_url;
        $res->trunk = $remote->zipball_url;
        $res->requires_php = PMP_MIN_PHP_VERSION;
        $res->last_updated = $remote->published_at;
        
        $res->sections = array(
            'description' => 'Kompletní systém pro správu členství, prémiový obsah, předplatné a prodej digitálních produktů.',
            'installation' => 'Nahrát plugin přes WordPress admin nebo FTP.',
            'changelog' => $this->parse_changelog($remote->body),
        );
        
        if (!empty($remote->body)) {
            $res->sections['changelog'] = nl2br($remote->body);
        }
        
        return $res;
    }
    
    /**
     * Parse changelog from markdown
     */
    private function parse_changelog($body) {
        if (empty($body)) {
            return 'Žádné informace o změnách.';
        }
        
        // Simple markdown to HTML conversion
        $body = str_replace('### ', '<h4>', $body);
        $body = str_replace('## ', '<h3>', $body);
        $body = str_replace('# ', '<h2>', $body);
        $body = nl2br($body);
        
        return $body;
    }
    
    /**
     * Purge cache after update
     */
    public function purge($upgrader, $options) {
        if ($this->cache_allowed && 'update' === $options['action'] && 'plugin' === $options['type']) {
            delete_transient($this->cache_key);
            delete_transient($this->cache_key . '_last_check');
        }
    }
    
    /**
     * Add "Check for updates" link to plugin row
     */
    public function add_check_update_link($links, $file) {
        if ($file !== $this->plugin_basename) {
            return $links;
        }
        
        $check_url = add_query_arg(array(
            'force-check' => '1',
            'plugin' => $this->plugin_basename,
            '_wpnonce' => wp_create_nonce('pmp_check_updates'),
        ), admin_url('plugins.php'));
        
        $links[] = '<a href="' . esc_url($check_url) . '" style="color: #667eea; font-weight: 600;">🔄 ' . __('Zkontrolovat aktualizace', 'premium-membership-pro') . '</a>';
        
        return $links;
    }
    
    /**
     * Add check update to action links
     */
    public function add_check_update_action($links) {
        // Add GitHub releases link
        $github_link = '<a href="https://github.com/conexo-sro/premium-membership-pro/releases" target="_blank" style="color: #667eea;">📦 ' . __('Releases', 'premium-membership-pro') . '</a>';
        $links[] = $github_link;
        
        return $links;
    }
}
