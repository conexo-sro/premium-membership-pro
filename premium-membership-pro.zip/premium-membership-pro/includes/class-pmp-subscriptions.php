<?php
/**
 * Subscriptions Management Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Subscriptions {
    
    public static function init() {
        add_action('pmp_check_subscriptions', array(__CLASS__, 'check_expired_subscriptions'));
        
        // Schedule cron job if not scheduled
        if (!wp_next_scheduled('pmp_check_subscriptions')) {
            wp_schedule_event(time(), 'daily', 'pmp_check_subscriptions');
        }
    }
    
    public static function create_subscription($user_id, $level_id, $gateway_data = array()) {
        global $wpdb;
        
        $level = PMP_Membership_Levels::get_level_details($level_id);
        if (!$level) {
            return false;
        }
        
        $start_date = current_time('mysql');
        $end_date = self::calculate_end_date($level);
        $trial_end_date = null;
        
        if ($level['trial_enabled']) {
            $trial_days = intval($level['trial_days']);
            $trial_end_date = date('Y-m-d H:i:s', strtotime("+{$trial_days} days"));
        }
        
        $subscription_id = $wpdb->insert(
            $wpdb->prefix . 'pmp_memberships',
            array(
                'user_id' => $user_id,
                'level_id' => $level_id,
                'status' => 'active',
                'start_date' => $start_date,
                'end_date' => $end_date,
                'trial_end_date' => $trial_end_date,
                'payment_gateway' => isset($gateway_data['gateway']) ? $gateway_data['gateway'] : null,
                'subscription_id' => isset($gateway_data['subscription_id']) ? $gateway_data['subscription_id'] : null,
                'created_at' => $start_date,
                'updated_at' => $start_date,
            ),
            array('%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );
        
        if ($subscription_id) {
            // Send welcome email
            PMP_Emails::send_welcome_email($user_id, $level_id);
            
            // Hook for extensions
            do_action('pmp_subscription_created', $wpdb->insert_id, $user_id, $level_id);
            
            return $wpdb->insert_id;
        }
        
        return false;
    }
    
    public static function cancel_subscription($subscription_id, $reason = '') {
        global $wpdb;
        
        $subscription = self::get_subscription($subscription_id);
        if (!$subscription) {
            return false;
        }
        
        $result = $wpdb->update(
            $wpdb->prefix . 'pmp_memberships',
            array(
                'status' => 'cancelled',
                'updated_at' => current_time('mysql'),
            ),
            array('id' => $subscription_id),
            array('%s', '%s'),
            array('%d')
        );
        
        if ($result) {
            // Send cancellation email
            PMP_Emails::send_cancellation_email($subscription->user_id, $subscription->level_id, $reason);
            
            // Hook for extensions
            do_action('pmp_subscription_cancelled', $subscription_id, $subscription->user_id, $reason);
            
            return true;
        }
        
        return false;
    }
    
    public static function renew_subscription($subscription_id) {
        global $wpdb;
        
        $subscription = self::get_subscription($subscription_id);
        if (!$subscription) {
            return false;
        }
        
        $level = PMP_Membership_Levels::get_level_details($subscription->level_id);
        $new_end_date = self::calculate_end_date($level, $subscription->end_date);
        
        $result = $wpdb->update(
            $wpdb->prefix . 'pmp_memberships',
            array(
                'status' => 'active',
                'end_date' => $new_end_date,
                'updated_at' => current_time('mysql'),
            ),
            array('id' => $subscription_id),
            array('%s', '%s', '%s'),
            array('%d')
        );
        
        if ($result) {
            // Send renewal confirmation email
            PMP_Emails::send_renewal_email($subscription->user_id, $subscription->level_id);
            
            // Hook for extensions
            do_action('pmp_subscription_renewed', $subscription_id, $subscription->user_id);
            
            return true;
        }
        
        return false;
    }
    
    public static function get_subscription($subscription_id) {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}pmp_memberships WHERE id = %d",
            $subscription_id
        ));
    }
    
    public static function get_user_subscriptions($user_id, $status = 'all') {
        global $wpdb;
        
        $query = "SELECT * FROM {$wpdb->prefix}pmp_memberships WHERE user_id = %d";
        
        if ($status !== 'all') {
            $query .= $wpdb->prepare(" AND status = %s", $status);
        }
        
        $query .= " ORDER BY created_at DESC";
        
        return $wpdb->get_results($wpdb->prepare($query, $user_id));
    }
    
    public static function check_expired_subscriptions() {
        global $wpdb;
        
        $expired = $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}pmp_memberships 
            WHERE status = 'active' 
            AND end_date IS NOT NULL 
            AND end_date < NOW()"
        );
        
        foreach ($expired as $subscription) {
            $wpdb->update(
                $wpdb->prefix . 'pmp_memberships',
                array(
                    'status' => 'expired',
                    'updated_at' => current_time('mysql'),
                ),
                array('id' => $subscription->id),
                array('%s', '%s'),
                array('%d')
            );
            
            // Send expiration email
            PMP_Emails::send_expiration_email($subscription->user_id, $subscription->level_id);
            
            // Hook for extensions
            do_action('pmp_subscription_expired', $subscription->id, $subscription->user_id);
        }
        
        // Check for upcoming expirations (7 days before)
        $upcoming = $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}pmp_memberships 
            WHERE status = 'active' 
            AND end_date IS NOT NULL 
            AND end_date BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 7 DAY)
            AND NOT EXISTS (
                SELECT 1 FROM {$wpdb->prefix}pmp_email_logs 
                WHERE user_id = {$wpdb->prefix}pmp_memberships.user_id 
                AND email_type = 'expiration_reminder'
                AND sent_at > DATE_SUB(NOW(), INTERVAL 14 DAY)
            )"
        );
        
        foreach ($upcoming as $subscription) {
            // Send reminder email
            PMP_Emails::send_expiration_reminder($subscription->user_id, $subscription->level_id, $subscription->end_date);
        }
    }
    
    private static function calculate_end_date($level, $from_date = null) {
        if ($level['billing_type'] === 'lifetime') {
            return null;
        }
        
        $base_date = $from_date ? strtotime($from_date) : time();
        $period = $level['period'];
        $period_count = intval($level['period_count']);
        
        switch ($period) {
            case 'day':
                return date('Y-m-d H:i:s', strtotime("+{$period_count} days", $base_date));
            case 'week':
                return date('Y-m-d H:i:s', strtotime("+{$period_count} weeks", $base_date));
            case 'month':
                return date('Y-m-d H:i:s', strtotime("+{$period_count} months", $base_date));
            case 'year':
                return date('Y-m-d H:i:s', strtotime("+{$period_count} years", $base_date));
            default:
                return date('Y-m-d H:i:s', strtotime("+1 month", $base_date));
        }
    }
    
    public static function upgrade_subscription($user_id, $new_level_id) {
        global $wpdb;
        
        // Cancel current subscription
        $current = PMP_User_Management::get_user_membership($user_id);
        if ($current) {
            self::cancel_subscription($current->id, 'Upgrade to new level');
        }
        
        // Create new subscription
        return self::create_subscription($user_id, $new_level_id);
    }
    
    public static function downgrade_subscription($user_id, $new_level_id) {
        return self::upgrade_subscription($user_id, $new_level_id);
    }
}
