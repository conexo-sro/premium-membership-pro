<?php
/**
 * Content Groups Management Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Content_Groups {
    
    public static function init() {
        add_action('init', array(__CLASS__, 'register_taxonomy'));
        add_action('admin_menu', array(__CLASS__, 'add_admin_pages'));
        add_action('add_meta_boxes', array(__CLASS__, 'add_bulk_meta_box'));
        add_action('pmp_content_group_add_form_fields', array(__CLASS__, 'add_group_fields'));
        add_action('pmp_content_group_edit_form_fields', array(__CLASS__, 'edit_group_fields'));
        add_action('created_pmp_content_group', array(__CLASS__, 'save_group_meta'));
        add_action('edited_pmp_content_group', array(__CLASS__, 'save_group_meta'));
        
        // AJAX handlers
        add_action('wp_ajax_pmp_bulk_protect', array(__CLASS__, 'ajax_bulk_protect'));
        add_action('wp_ajax_pmp_bulk_unprotect', array(__CLASS__, 'ajax_bulk_unprotect'));
        add_action('wp_ajax_pmp_add_to_group', array(__CLASS__, 'ajax_add_to_group'));
    }
    
    public static function register_taxonomy() {
        register_taxonomy('pmp_content_group', array('post', 'page'), array(
            'labels' => array(
                'name' => __('Skupiny obsahu', 'premium-membership-pro'),
                'singular_name' => __('Skupina obsahu', 'premium-membership-pro'),
                'menu_name' => __('Skupiny obsahu', 'premium-membership-pro'),
                'all_items' => __('Všechny skupiny', 'premium-membership-pro'),
                'edit_item' => __('Upravit skupinu', 'premium-membership-pro'),
                'view_item' => __('Zobrazit skupinu', 'premium-membership-pro'),
                'update_item' => __('Aktualizovat skupinu', 'premium-membership-pro'),
                'add_new_item' => __('Přidat novou skupinu', 'premium-membership-pro'),
                'new_item_name' => __('Název nové skupiny', 'premium-membership-pro'),
                'search_items' => __('Hledat skupiny', 'premium-membership-pro'),
            ),
            'hierarchical' => true,
            'show_ui' => true,
            'show_admin_column' => true,
            'show_in_rest' => true,
            'query_var' => true,
            'rewrite' => array('slug' => 'content-group'),
            'capabilities' => array(
                'manage_terms' => 'manage_options',
                'edit_terms' => 'manage_options',
                'delete_terms' => 'manage_options',
                'assign_terms' => 'edit_posts',
            ),
        ));
    }
    
    public static function add_admin_pages() {
        add_submenu_page(
            'premium-membership-pro',
            __('Správa obsahu', 'premium-membership-pro'),
            __('Správa obsahu', 'premium-membership-pro'),
            'manage_options',
            'pmp-content-management',
            array(__CLASS__, 'content_management_page')
        );
    }
    
    public static function add_bulk_meta_box() {
        add_meta_box(
            'pmp_bulk_actions',
            __('Hromadné akce', 'premium-membership-pro'),
            array(__CLASS__, 'render_bulk_meta_box'),
            array('post', 'page'),
            'side',
            'low'
        );
    }
    
    public static function render_bulk_meta_box($post) {
        $groups = get_terms(array(
            'taxonomy' => 'pmp_content_group',
            'hide_empty' => false,
        ));
        
        ?>
        <div class="pmp-bulk-actions">
            <p><strong><?php _e('Přidat do skupiny:', 'premium-membership-pro'); ?></strong></p>
            <select id="pmp-group-select" style="width: 100%;">
                <option value=""><?php _e('-- Vyberte skupinu --', 'premium-membership-pro'); ?></option>
                <?php foreach ($groups as $group): ?>
                    <option value="<?php echo $group->term_id; ?>">
                        <?php echo esc_html($group->name); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="button" class="button button-secondary" id="pmp-add-to-group" style="width: 100%; margin-top: 10px;">
                <?php _e('Přidat do skupiny', 'premium-membership-pro'); ?>
            </button>
            
            <hr style="margin: 15px 0;">
            
            <p><em style="font-size: 12px;"><?php _e('Tip: Použijte skupiny pro organizaci obsahu podle témat nebo úrovní členství', 'premium-membership-pro'); ?></em></p>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            $('#pmp-add-to-group').on('click', function() {
                var groupId = $('#pmp-group-select').val();
                if (!groupId) {
                    alert('<?php _e('Vyberte prosím skupinu', 'premium-membership-pro'); ?>');
                    return;
                }
                
                $.post(ajaxurl, {
                    action: 'pmp_add_to_group',
                    post_id: <?php echo $post->ID; ?>,
                    group_id: groupId,
                    nonce: '<?php echo wp_create_nonce('pmp_bulk_actions'); ?>'
                }, function(response) {
                    if (response.success) {
                        alert('<?php _e('Přidáno do skupiny!', 'premium-membership-pro'); ?>');
                        location.reload();
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    public static function add_group_fields($taxonomy) {
        ?>
        <div class="form-field">
            <label for="pmp_auto_protect"><?php _e('Automatická ochrana', 'premium-membership-pro'); ?></label>
            <label>
                <input type="checkbox" name="pmp_auto_protect" id="pmp_auto_protect" value="1">
                <?php _e('Automaticky chránit veškerý obsah v této skupině', 'premium-membership-pro'); ?>
            </label>
        </div>
        
        <div class="form-field">
            <label for="pmp_default_preview_type"><?php _e('Výchozí typ náhledu', 'premium-membership-pro'); ?></label>
            <select name="pmp_default_preview_type" id="pmp_default_preview_type" style="width: 95%;">
                <option value="blur"><?php _e('Rozostřený obsah', 'premium-membership-pro'); ?></option>
                <option value="teaser"><?php _e('Textový náhled', 'premium-membership-pro'); ?></option>
                <option value="locked"><?php _e('Úplně uzamčeno', 'premium-membership-pro'); ?></option>
            </select>
        </div>
        
        <div class="form-field">
            <label for="pmp_default_preview_length"><?php _e('Výchozí procento zobrazení', 'premium-membership-pro'); ?></label>
            <select name="pmp_default_preview_length" id="pmp_default_preview_length" style="width: 95%;">
                <option value="10">10%</option>
                <option value="20">20%</option>
                <option value="30" selected>30%</option>
                <option value="40">40%</option>
                <option value="50">50%</option>
                <option value="75">75%</option>
            </select>
        </div>
        
        <div class="form-field">
            <label for="pmp_group_levels"><?php _e('Požadované úrovně členství', 'premium-membership-pro'); ?></label>
            <?php
            $levels = PMP_Membership_Levels::get_all_levels();
            foreach ($levels as $level) {
                echo '<label style="display: block; margin: 5px 0;">';
                echo '<input type="checkbox" name="pmp_group_levels[]" value="' . $level['id'] . '">';
                echo ' ' . esc_html($level['name']);
                echo '</label>';
            }
            ?>
        </div>
        
        <div class="form-field">
            <label for="pmp_group_color"><?php _e('Barva skupiny', 'premium-membership-pro'); ?></label>
            <input type="color" name="pmp_group_color" id="pmp_group_color" value="#0073aa">
            <p class="description"><?php _e('Barva pro vizuální odlišení v administraci', 'premium-membership-pro'); ?></p>
        </div>
        
        <div class="form-field">
            <label for="pmp_group_icon"><?php _e('Ikona skupiny (emoji)', 'premium-membership-pro'); ?></label>
            <input type="text" name="pmp_group_icon" id="pmp_group_icon" placeholder="📁" style="width: 95%;">
            <p class="description"><?php _e('Např: 📁 🔒 ⭐ 💎 📚 🎥', 'premium-membership-pro'); ?></p>
        </div>
        <?php
    }
    
    public static function edit_group_fields($term) {
        $auto_protect = get_term_meta($term->term_id, 'pmp_auto_protect', true);
        $preview_type = get_term_meta($term->term_id, 'pmp_default_preview_type', true) ?: 'blur';
        $preview_length = get_term_meta($term->term_id, 'pmp_default_preview_length', true) ?: '30';
        $group_levels = get_term_meta($term->term_id, 'pmp_group_levels', true) ?: array();
        $group_color = get_term_meta($term->term_id, 'pmp_group_color', true) ?: '#0073aa';
        $group_icon = get_term_meta($term->term_id, 'pmp_group_icon', true) ?: '📁';
        
        ?>
        <tr class="form-field">
            <th scope="row"><label for="pmp_auto_protect"><?php _e('Automatická ochrana', 'premium-membership-pro'); ?></label></th>
            <td>
                <label>
                    <input type="checkbox" name="pmp_auto_protect" id="pmp_auto_protect" value="1" <?php checked($auto_protect, '1'); ?>>
                    <?php _e('Automaticky chránit veškerý obsah v této skupině', 'premium-membership-pro'); ?>
                </label>
            </td>
        </tr>
        
        <tr class="form-field">
            <th scope="row"><label for="pmp_default_preview_type"><?php _e('Výchozí typ náhledu', 'premium-membership-pro'); ?></label></th>
            <td>
                <select name="pmp_default_preview_type" id="pmp_default_preview_type">
                    <option value="blur" <?php selected($preview_type, 'blur'); ?>><?php _e('Rozostřený obsah', 'premium-membership-pro'); ?></option>
                    <option value="teaser" <?php selected($preview_type, 'teaser'); ?>><?php _e('Textový náhled', 'premium-membership-pro'); ?></option>
                    <option value="locked" <?php selected($preview_type, 'locked'); ?>><?php _e('Úplně uzamčeno', 'premium-membership-pro'); ?></option>
                </select>
            </td>
        </tr>
        
        <tr class="form-field">
            <th scope="row"><label for="pmp_default_preview_length"><?php _e('Výchozí procento zobrazení', 'premium-membership-pro'); ?></label></th>
            <td>
                <select name="pmp_default_preview_length" id="pmp_default_preview_length">
                    <option value="10" <?php selected($preview_length, '10'); ?>>10%</option>
                    <option value="20" <?php selected($preview_length, '20'); ?>>20%</option>
                    <option value="30" <?php selected($preview_length, '30'); ?>>30%</option>
                    <option value="40" <?php selected($preview_length, '40'); ?>>40%</option>
                    <option value="50" <?php selected($preview_length, '50'); ?>>50%</option>
                    <option value="75" <?php selected($preview_length, '75'); ?>>75%</option>
                </select>
            </td>
        </tr>
        
        <tr class="form-field">
            <th scope="row"><label><?php _e('Požadované úrovně členství', 'premium-membership-pro'); ?></label></th>
            <td>
                <?php
                $levels = PMP_Membership_Levels::get_all_levels();
                foreach ($levels as $level) {
                    $checked = in_array($level['id'], (array)$group_levels);
                    echo '<label style="display: block; margin: 5px 0;">';
                    echo '<input type="checkbox" name="pmp_group_levels[]" value="' . $level['id'] . '" ' . checked($checked, true, false) . '>';
                    echo ' ' . esc_html($level['name']);
                    echo '</label>';
                }
                ?>
            </td>
        </tr>
        
        <tr class="form-field">
            <th scope="row"><label for="pmp_group_color"><?php _e('Barva skupiny', 'premium-membership-pro'); ?></label></th>
            <td>
                <input type="color" name="pmp_group_color" id="pmp_group_color" value="<?php echo esc_attr($group_color); ?>">
                <p class="description"><?php _e('Barva pro vizuální odlišení v administraci', 'premium-membership-pro'); ?></p>
            </td>
        </tr>
        
        <tr class="form-field">
            <th scope="row"><label for="pmp_group_icon"><?php _e('Ikona skupiny (emoji)', 'premium-membership-pro'); ?></label></th>
            <td>
                <input type="text" name="pmp_group_icon" id="pmp_group_icon" value="<?php echo esc_attr($group_icon); ?>">
                <p class="description"><?php _e('Např: 📁 🔒 ⭐ 💎 📚 🎥', 'premium-membership-pro'); ?></p>
            </td>
        </tr>
        <?php
    }
    
    public static function save_group_meta($term_id) {
        if (isset($_POST['pmp_auto_protect'])) {
            update_term_meta($term_id, 'pmp_auto_protect', '1');
        } else {
            delete_term_meta($term_id, 'pmp_auto_protect');
        }
        
        if (isset($_POST['pmp_default_preview_type'])) {
            update_term_meta($term_id, 'pmp_default_preview_type', sanitize_text_field($_POST['pmp_default_preview_type']));
        }
        
        if (isset($_POST['pmp_default_preview_length'])) {
            update_term_meta($term_id, 'pmp_default_preview_length', sanitize_text_field($_POST['pmp_default_preview_length']));
        }
        
        if (isset($_POST['pmp_group_levels'])) {
            update_term_meta($term_id, 'pmp_group_levels', array_map('intval', $_POST['pmp_group_levels']));
        } else {
            delete_term_meta($term_id, 'pmp_group_levels');
        }
        
        if (isset($_POST['pmp_group_color'])) {
            update_term_meta($term_id, 'pmp_group_color', sanitize_hex_color($_POST['pmp_group_color']));
        }
        
        if (isset($_POST['pmp_group_icon'])) {
            update_term_meta($term_id, 'pmp_group_icon', sanitize_text_field($_POST['pmp_group_icon']));
        }
    }
    
    public static function content_management_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        $groups = get_terms(array(
            'taxonomy' => 'pmp_content_group',
            'hide_empty' => false,
        ));
        
        ?>
        <div class="wrap">
            <h1><?php _e('Správa obsahu', 'premium-membership-pro'); ?></h1>
            
            <div class="pmp-content-management">
                <div class="pmp-management-tabs">
                    <button class="pmp-tab active" data-tab="groups"><?php _e('Skupiny obsahu', 'premium-membership-pro'); ?></button>
                    <button class="pmp-tab" data-tab="bulk"><?php _e('Hromadné akce', 'premium-membership-pro'); ?></button>
                    <button class="pmp-tab" data-tab="protected"><?php _e('Chráněný obsah', 'premium-membership-pro'); ?></button>
                </div>
                
                <!-- Groups Tab -->
                <div class="pmp-tab-content active" id="tab-groups">
                    <div class="pmp-groups-grid">
                        <?php foreach ($groups as $group): 
                            $count = $group->count;
                            $auto_protect = get_term_meta($group->term_id, 'pmp_auto_protect', true);
                            $color = get_term_meta($group->term_id, 'pmp_group_color', true) ?: '#0073aa';
                            $icon = get_term_meta($group->term_id, 'pmp_group_icon', true) ?: '📁';
                            $preview_type = get_term_meta($group->term_id, 'pmp_default_preview_type', true) ?: 'blur';
                            $levels = get_term_meta($group->term_id, 'pmp_group_levels', true) ?: array();
                            ?>
                            <div class="pmp-group-card" style="border-left: 4px solid <?php echo esc_attr($color); ?>;">
                                <div class="pmp-group-header">
                                    <span class="pmp-group-icon"><?php echo esc_html($icon); ?></span>
                                    <h3><?php echo esc_html($group->name); ?></h3>
                                </div>
                                
                                <div class="pmp-group-stats">
                                    <span class="pmp-stat">
                                        <strong><?php echo $count; ?></strong> 
                                        <?php echo _n('článek', 'články', $count, 'premium-membership-pro'); ?>
                                    </span>
                                    <?php if ($auto_protect): ?>
                                        <span class="pmp-badge pmp-protected">🔒 Auto-ochrana</span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="pmp-group-info">
                                    <p><strong><?php _e('Náhled:', 'premium-membership-pro'); ?></strong> 
                                        <?php 
                                        $preview_labels = array(
                                            'blur' => __('Rozostřený', 'premium-membership-pro'),
                                            'teaser' => __('Textový', 'premium-membership-pro'),
                                            'locked' => __('Uzamčeno', 'premium-membership-pro'),
                                        );
                                        echo $preview_labels[$preview_type];
                                        ?>
                                    </p>
                                    
                                    <?php if (!empty($levels)): ?>
                                        <p><strong><?php _e('Úrovně:', 'premium-membership-pro'); ?></strong>
                                            <?php
                                            foreach ($levels as $level_id) {
                                                $level = get_post($level_id);
                                                if ($level) {
                                                    echo '<span class="pmp-level-badge">' . esc_html($level->post_title) . '</span> ';
                                                }
                                            }
                                            ?>
                                        </p>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="pmp-group-actions">
                                    <a href="<?php echo admin_url('edit-tags.php?action=edit&taxonomy=pmp_content_group&tag_ID=' . $group->term_id); ?>" class="button">
                                        <?php _e('Upravit', 'premium-membership-pro'); ?>
                                    </a>
                                    <a href="<?php echo admin_url('edit.php?pmp_content_group=' . $group->slug); ?>" class="button">
                                        <?php _e('Zobrazit obsah', 'premium-membership-pro'); ?>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        
                        <div class="pmp-group-card pmp-add-new">
                            <a href="<?php echo admin_url('edit-tags.php?taxonomy=pmp_content_group'); ?>">
                                <span class="dashicons dashicons-plus-alt"></span>
                                <h3><?php _e('Přidat novou skupinu', 'premium-membership-pro'); ?></h3>
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Bulk Actions Tab -->
                <div class="pmp-tab-content" id="tab-bulk">
                    <?php self::render_bulk_actions_tab(); ?>
                </div>
                
                <!-- Protected Content Tab -->
                <div class="pmp-tab-content" id="tab-protected">
                    <?php self::render_protected_content_tab(); ?>
                </div>
            </div>
        </div>
        
        <style>
        .pmp-management-tabs {
            display: flex;
            gap: 10px;
            margin: 20px 0;
            border-bottom: 2px solid #ddd;
        }
        .pmp-tab {
            padding: 12px 24px;
            background: #f0f0f1;
            border: none;
            border-radius: 5px 5px 0 0;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
        }
        .pmp-tab.active {
            background: #fff;
            border-bottom: 2px solid #fff;
            margin-bottom: -2px;
            color: #2271b1;
        }
        .pmp-tab-content {
            display: none;
            padding: 30px 0;
        }
        .pmp-tab-content.active {
            display: block;
        }
        .pmp-groups-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .pmp-group-card {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        .pmp-group-card.pmp-add-new {
            border: 2px dashed #ddd;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 250px;
        }
        .pmp-group-card.pmp-add-new a {
            text-align: center;
            color: #666;
            text-decoration: none;
        }
        .pmp-group-card.pmp-add-new .dashicons {
            font-size: 48px;
            width: 48px;
            height: 48px;
        }
        .pmp-group-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 15px;
        }
        .pmp-group-icon {
            font-size: 32px;
        }
        .pmp-group-header h3 {
            margin: 0;
            font-size: 18px;
        }
        .pmp-group-stats {
            display: flex;
            gap: 15px;
            margin: 15px 0;
            padding: 15px 0;
            border-top: 1px solid #eee;
            border-bottom: 1px solid #eee;
        }
        .pmp-badge {
            padding: 4px 10px;
            background: #f0f0f1;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        .pmp-badge.pmp-protected {
            background: #d4edda;
            color: #155724;
        }
        .pmp-group-info {
            margin: 15px 0;
            font-size: 13px;
        }
        .pmp-level-badge {
            display: inline-block;
            padding: 2px 8px;
            background: #2271b1;
            color: #fff;
            border-radius: 3px;
            font-size: 11px;
            margin: 2px;
        }
        .pmp-group-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            $('.pmp-tab').on('click', function() {
                var tab = $(this).data('tab');
                $('.pmp-tab, .pmp-tab-content').removeClass('active');
                $(this).addClass('active');
                $('#tab-' + tab).addClass('active');
            });
        });
        </script>
        <?php
    }
    
    private static function render_bulk_actions_tab() {
        ?>
        <div class="pmp-bulk-actions-panel">
            <h2><?php _e('Hromadné úpravy ochrany obsahu', 'premium-membership-pro'); ?></h2>
            
            <div class="pmp-action-cards">
                <div class="pmp-action-card">
                    <h3>🔒 <?php _e('Ochránit obsah', 'premium-membership-pro'); ?></h3>
                    <p><?php _e('Nastavte ochranu pro více článků najednou', 'premium-membership-pro'); ?></p>
                    
                    <select id="bulk-group-select" style="width: 100%; margin: 10px 0;">
                        <option value=""><?php _e('-- Vyberte skupinu --', 'premium-membership-pro'); ?></option>
                        <?php
                        $groups = get_terms(array('taxonomy' => 'pmp_content_group', 'hide_empty' => false));
                        foreach ($groups as $group) {
                            echo '<option value="' . $group->term_id . '">' . esc_html($group->name) . '</option>';
                        }
                        ?>
                    </select>
                    
                    <button class="button button-primary" id="bulk-protect-btn" style="width: 100%;">
                        <?php _e('Ochránit všechny články ve skupině', 'premium-membership-pro'); ?>
                    </button>
                </div>
                
                <div class="pmp-action-card">
                    <h3>🔓 <?php _e('Odemknout obsah', 'premium-membership-pro'); ?></h3>
                    <p><?php _e('Odeberte ochranu z více článků najednou', 'premium-membership-pro'); ?></p>
                    
                    <select id="bulk-unprotect-select" style="width: 100%; margin: 10px 0;">
                        <option value=""><?php _e('-- Vyberte skupinu --', 'premium-membership-pro'); ?></option>
                        <?php
                        foreach ($groups as $group) {
                            echo '<option value="' . $group->term_id . '">' . esc_html($group->name) . '</option>';
                        }
                        ?>
                    </select>
                    
                    <button class="button" id="bulk-unprotect-btn" style="width: 100%;">
                        <?php _e('Odemknout všechny články ve skupině', 'premium-membership-pro'); ?>
                    </button>
                </div>
            </div>
        </div>
        
        <style>
        .pmp-action-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .pmp-action-card {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 25px;
        }
        .pmp-action-card h3 {
            margin-top: 0;
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            $('#bulk-protect-btn').on('click', function() {
                var groupId = $('#bulk-group-select').val();
                if (!groupId) {
                    alert('<?php _e('Vyberte prosím skupinu', 'premium-membership-pro'); ?>');
                    return;
                }
                
                if (!confirm('<?php _e('Opravdu chcete ochránit všechny články v této skupině?', 'premium-membership-pro'); ?>')) {
                    return;
                }
                
                $(this).prop('disabled', true).text('<?php _e('Zpracovávám...', 'premium-membership-pro'); ?>');
                
                $.post(ajaxurl, {
                    action: 'pmp_bulk_protect',
                    group_id: groupId,
                    nonce: '<?php echo wp_create_nonce('pmp_bulk_actions'); ?>'
                }, function(response) {
                    if (response.success) {
                        alert(response.data.message);
                        location.reload();
                    } else {
                        alert(response.data.message);
                    }
                });
            });
            
            $('#bulk-unprotect-btn').on('click', function() {
                var groupId = $('#bulk-unprotect-select').val();
                if (!groupId) {
                    alert('<?php _e('Vyberte prosím skupinu', 'premium-membership-pro'); ?>');
                    return;
                }
                
                if (!confirm('<?php _e('Opravdu chcete odemknout všechny články v této skupině?', 'premium-membership-pro'); ?>')) {
                    return;
                }
                
                $(this).prop('disabled', true).text('<?php _e('Zpracovávám...', 'premium-membership-pro'); ?>');
                
                $.post(ajaxurl, {
                    action: 'pmp_bulk_unprotect',
                    group_id: groupId,
                    nonce: '<?php echo wp_create_nonce('pmp_bulk_actions'); ?>'
                }, function(response) {
                    if (response.success) {
                        alert(response.data.message);
                        location.reload();
                    } else {
                        alert(response.data.message);
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    private static function render_protected_content_tab() {
        global $wpdb;
        
        $protected_posts = $wpdb->get_results(
            "SELECT p.ID, p.post_title, p.post_type, pm.meta_value as is_protected
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_pmp_protected'
            WHERE p.post_status = 'publish' AND pm.meta_value = '1'
            ORDER BY p.post_date DESC
            LIMIT 50"
        );
        
        ?>
        <div class="pmp-protected-content-list">
            <h2><?php _e('Chráněný obsah', 'premium-membership-pro'); ?> (<?php echo count($protected_posts); ?>)</h2>
            
            <table class="widefat">
                <thead>
                    <tr>
                        <th><?php _e('Název', 'premium-membership-pro'); ?></th>
                        <th><?php _e('Typ', 'premium-membership-pro'); ?></th>
                        <th><?php _e('Skupiny', 'premium-membership-pro'); ?></th>
                        <th><?php _e('Náhled', 'premium-membership-pro'); ?></th>
                        <th><?php _e('Úrovně', 'premium-membership-pro'); ?></th>
                        <th><?php _e('Akce', 'premium-membership-pro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($protected_posts as $post): 
                        $groups = get_the_terms($post->ID, 'pmp_content_group');
                        $preview_type = get_post_meta($post->ID, '_pmp_preview_type', true) ?: 'blur';
                        $required_levels = get_post_meta($post->ID, '_pmp_required_levels', true) ?: array();
                        ?>
                        <tr>
                            <td><strong><?php echo esc_html($post->post_title); ?></strong></td>
                            <td><?php echo esc_html($post->post_type); ?></td>
                            <td>
                                <?php 
                                if ($groups && !is_wp_error($groups)) {
                                    foreach ($groups as $group) {
                                        $icon = get_term_meta($group->term_id, 'pmp_group_icon', true) ?: '📁';
                                        echo '<span style="margin-right: 5px;">' . $icon . ' ' . esc_html($group->name) . '</span>';
                                    }
                                } else {
                                    echo '-';
                                }
                                ?>
                            </td>
                            <td>
                                <?php
                                $preview_labels = array(
                                    'blur' => '🔒 Rozostřený',
                                    'teaser' => '📄 Textový',
                                    'locked' => '🚫 Uzamčeno',
                                );
                                echo $preview_labels[$preview_type];
                                ?>
                            </td>
                            <td>
                                <?php
                                if (!empty($required_levels)) {
                                    foreach ($required_levels as $level_id) {
                                        $level = get_post($level_id);
                                        if ($level) {
                                            echo '<span class="pmp-level-badge">' . esc_html($level->post_title) . '</span> ';
                                        }
                                    }
                                } else {
                                    echo '-';
                                }
                                ?>
                            </td>
                            <td>
                                <a href="<?php echo get_edit_post_link($post->ID); ?>" class="button button-small">
                                    <?php _e('Upravit', 'premium-membership-pro'); ?>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    // AJAX Handlers
    public static function ajax_bulk_protect() {
        check_ajax_referer('pmp_bulk_actions', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Nemáte oprávnění', 'premium-membership-pro')));
        }
        
        $group_id = intval($_POST['group_id']);
        $group = get_term($group_id, 'pmp_content_group');
        
        if (!$group || is_wp_error($group)) {
            wp_send_json_error(array('message' => __('Skupina nenalezena', 'premium-membership-pro')));
        }
        
        // Get group settings
        $preview_type = get_term_meta($group_id, 'pmp_default_preview_type', true) ?: 'blur';
        $preview_length = get_term_meta($group_id, 'pmp_default_preview_length', true) ?: '30';
        $required_levels = get_term_meta($group_id, 'pmp_group_levels', true) ?: array();
        
        // Get all posts in this group
        $posts = get_posts(array(
            'post_type' => array('post', 'page'),
            'posts_per_page' => -1,
            'tax_query' => array(
                array(
                    'taxonomy' => 'pmp_content_group',
                    'field' => 'term_id',
                    'terms' => $group_id,
                ),
            ),
        ));
        
        $count = 0;
        foreach ($posts as $post) {
            update_post_meta($post->ID, '_pmp_protected', '1');
            update_post_meta($post->ID, '_pmp_preview_type', $preview_type);
            update_post_meta($post->ID, '_pmp_preview_length', $preview_length);
            if (!empty($required_levels)) {
                update_post_meta($post->ID, '_pmp_required_levels', $required_levels);
            }
            $count++;
        }
        
        wp_send_json_success(array(
            'message' => sprintf(__('Úspěšně chráněno %d článků', 'premium-membership-pro'), $count)
        ));
    }
    
    public static function ajax_bulk_unprotect() {
        check_ajax_referer('pmp_bulk_actions', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Nemáte oprávnění', 'premium-membership-pro')));
        }
        
        $group_id = intval($_POST['group_id']);
        
        $posts = get_posts(array(
            'post_type' => array('post', 'page'),
            'posts_per_page' => -1,
            'tax_query' => array(
                array(
                    'taxonomy' => 'pmp_content_group',
                    'field' => 'term_id',
                    'terms' => $group_id,
                ),
            ),
        ));
        
        $count = 0;
        foreach ($posts as $post) {
            delete_post_meta($post->ID, '_pmp_protected');
            $count++;
        }
        
        wp_send_json_success(array(
            'message' => sprintf(__('Úspěšně odemknuto %d článků', 'premium-membership-pro'), $count)
        ));
    }
    
    public static function ajax_add_to_group() {
        check_ajax_referer('pmp_bulk_actions', 'nonce');
        
        $post_id = intval($_POST['post_id']);
        $group_id = intval($_POST['group_id']);
        
        wp_set_post_terms($post_id, array($group_id), 'pmp_content_group', true);
        
        wp_send_json_success(array('message' => __('Přidáno do skupiny', 'premium-membership-pro')));
    }
}
