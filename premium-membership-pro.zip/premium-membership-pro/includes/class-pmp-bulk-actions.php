<?php
/**
 * Bulk Actions for Content Protection
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Bulk_Actions {
    
    public static function init() {
        add_filter('bulk_actions-edit-post', array(__CLASS__, 'register_bulk_actions'));
        add_filter('bulk_actions-edit-page', array(__CLASS__, 'register_bulk_actions'));
        add_filter('handle_bulk_actions-edit-post', array(__CLASS__, 'handle_bulk_actions'), 10, 3);
        add_filter('handle_bulk_actions-edit-page', array(__CLASS__, 'handle_bulk_actions'), 10, 3);
        add_action('admin_notices', array(__CLASS__, 'bulk_action_notices'));
    }
    
    public static function register_bulk_actions($bulk_actions) {
        $bulk_actions['pmp_protect'] = __('🔒 Chránit obsah', 'premium-membership-pro');
        $bulk_actions['pmp_unprotect'] = __('🔓 Zrušit ochranu', 'premium-membership-pro');
        $bulk_actions['pmp_set_preview_blur'] = __('👁️ Nastavit rozostření', 'premium-membership-pro');
        $bulk_actions['pmp_set_preview_teaser'] = __('📄 Nastavit textový náhled', 'premium-membership-pro');
        $bulk_actions['pmp_set_preview_locked'] = __('🚫 Nastavit uzamčeno', 'premium-membership-pro');
        return $bulk_actions;
    }
    
    public static function handle_bulk_actions($redirect_to, $action, $post_ids) {
        // Protect content
        if ($action === 'pmp_protect') {
            foreach ($post_ids as $post_id) {
                update_post_meta($post_id, '_pmp_protected', '1');
            }
            $redirect_to = add_query_arg('pmp_protected', count($post_ids), $redirect_to);
        }
        
        // Unprotect content
        if ($action === 'pmp_unprotect') {
            foreach ($post_ids as $post_id) {
                delete_post_meta($post_id, '_pmp_protected');
            }
            $redirect_to = add_query_arg('pmp_unprotected', count($post_ids), $redirect_to);
        }
        
        // Set blur preview
        if ($action === 'pmp_set_preview_blur') {
            foreach ($post_ids as $post_id) {
                update_post_meta($post_id, '_pmp_preview_type', 'blur');
            }
            $redirect_to = add_query_arg('pmp_preview_set', count($post_ids), $redirect_to);
        }
        
        // Set teaser preview
        if ($action === 'pmp_set_preview_teaser') {
            foreach ($post_ids as $post_id) {
                update_post_meta($post_id, '_pmp_preview_type', 'teaser');
            }
            $redirect_to = add_query_arg('pmp_preview_set', count($post_ids), $redirect_to);
        }
        
        // Set locked preview
        if ($action === 'pmp_set_preview_locked') {
            foreach ($post_ids as $post_id) {
                update_post_meta($post_id, '_pmp_preview_type', 'locked');
            }
            $redirect_to = add_query_arg('pmp_preview_set', count($post_ids), $redirect_to);
        }
        
        return $redirect_to;
    }
    
    public static function bulk_action_notices() {
        if (!empty($_REQUEST['pmp_protected'])) {
            $count = intval($_REQUEST['pmp_protected']);
            printf(
                '<div class="notice notice-success is-dismissible"><p>' .
                _n('%s článek byl chráněn.', '%s články/ů bylo chráněno.', $count, 'premium-membership-pro') .
                '</p></div>',
                $count
            );
        }
        
        if (!empty($_REQUEST['pmp_unprotected'])) {
            $count = intval($_REQUEST['pmp_unprotected']);
            printf(
                '<div class="notice notice-success is-dismissible"><p>' .
                _n('Ochrana byla zrušena pro %s článek.', 'Ochrana byla zrušena pro %s články/ů.', $count, 'premium-membership-pro') .
                '</p></div>',
                $count
            );
        }
        
        if (!empty($_REQUEST['pmp_preview_set'])) {
            $count = intval($_REQUEST['pmp_preview_set']);
            printf(
                '<div class="notice notice-success is-dismissible"><p>' .
                _n('Typ náhledu byl nastaven pro %s článek.', 'Typ náhledu byl nastaven pro %s články/ů.', $count, 'premium-membership-pro') .
                '</p></div>',
                $count
            );
        }
    }
}
