<?php
/**
 * Payments Processing Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Payments {
    
    public static function init() {
        add_action('wp_ajax_pmp_process_payment', array(__CLASS__, 'ajax_process_payment'));
        add_action('wp_ajax_nopriv_pmp_process_payment', array(__CLASS__, 'ajax_process_payment'));
    }
    
    public static function ajax_process_payment() {
        check_ajax_referer('pmp_nonce', 'nonce');
        
        $level_id = isset($_POST['level_id']) ? intval($_POST['level_id']) : 0;
        $gateway = isset($_POST['gateway']) ? sanitize_text_field($_POST['gateway']) : '';
        $coupon_code = isset($_POST['coupon']) ? sanitize_text_field($_POST['coupon']) : '';
        
        if (!$level_id || !$gateway) {
            wp_send_json_error(array('message' => __('Neplatné údaje', 'premium-membership-pro')));
        }
        
        $user_id = get_current_user_id();
        if (!$user_id) {
            wp_send_json_error(array('message' => __('Musíte být přihlášeni', 'premium-membership-pro')));
        }
        
        $level = PMP_Membership_Levels::get_level_details($level_id);
        if (!$level) {
            wp_send_json_error(array('message' => __('Úroveň členství nenalezena', 'premium-membership-pro')));
        }
        
        $amount = floatval($level['price']);
        
        // Apply coupon if provided
        if ($coupon_code) {
            $discount = self::apply_coupon($coupon_code, $level_id);
            if ($discount) {
                $amount = $amount - ($amount * $discount / 100);
            }
        }
        
        // Process payment based on gateway
        switch ($gateway) {
            case 'stripe':
                $result = self::process_stripe_payment($user_id, $level_id, $amount);
                break;
            case 'paypal':
                $result = self::process_paypal_payment($user_id, $level_id, $amount);
                break;
            case 'bank_transfer':
                $result = self::process_bank_transfer($user_id, $level_id, $amount);
                break;
            default:
                wp_send_json_error(array('message' => __('Nepodporovaná platební brána', 'premium-membership-pro')));
        }
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    public static function create_transaction($user_id, $membership_id, $amount, $gateway, $transaction_data = array()) {
        global $wpdb;
        
        $currency = get_option('pmp_currency', 'CZK');
        $status = isset($transaction_data['status']) ? $transaction_data['status'] : 'completed';
        
        $wpdb->insert(
            $wpdb->prefix . 'pmp_transactions',
            array(
                'user_id' => $user_id,
                'membership_id' => $membership_id,
                'amount' => $amount,
                'currency' => $currency,
                'status' => $status,
                'payment_gateway' => $gateway,
                'transaction_id' => isset($transaction_data['transaction_id']) ? $transaction_data['transaction_id'] : null,
                'invoice_number' => isset($transaction_data['invoice_number']) ? $transaction_data['invoice_number'] : self::generate_invoice_number(),
                'description' => isset($transaction_data['description']) ? $transaction_data['description'] : null,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ),
            array('%d', '%d', '%f', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );
        
        return $wpdb->insert_id;
    }
    
    private static function process_stripe_payment($user_id, $level_id, $amount) {
        // This is a placeholder - you would integrate with Stripe API here
        $stripe_enabled = get_option('pmp_enable_stripe', '0');
        
        if ($stripe_enabled !== '1') {
            return array('success' => false, 'message' => __('Stripe není aktivní', 'premium-membership-pro'));
        }
        
        // Here you would:
        // 1. Create Stripe customer
        // 2. Create payment intent or subscription
        // 3. Handle payment confirmation
        
        // For demo purposes, simulate success
        $subscription_id = PMP_Subscriptions::create_subscription($user_id, $level_id, array(
            'gateway' => 'stripe',
            'subscription_id' => 'sub_' . uniqid(),
        ));
        
        if ($subscription_id) {
            $transaction_id = self::create_transaction($user_id, $subscription_id, $amount, 'stripe', array(
                'transaction_id' => 'ch_' . uniqid(),
                'status' => 'completed',
            ));
            
            return array(
                'success' => true,
                'message' => __('Platba byla úspěšně zpracována', 'premium-membership-pro'),
                'redirect' => get_permalink(get_option('pmp_thank_you_page')),
            );
        }
        
        return array('success' => false, 'message' => __('Chyba při vytváření členství', 'premium-membership-pro'));
    }
    
    private static function process_paypal_payment($user_id, $level_id, $amount) {
        $paypal_enabled = get_option('pmp_enable_paypal', '0');
        
        if ($paypal_enabled !== '1') {
            return array('success' => false, 'message' => __('PayPal není aktivní', 'premium-membership-pro'));
        }
        
        // PayPal integration would go here
        // Similar to Stripe implementation
        
        return array('success' => false, 'message' => __('PayPal integrace není implementována', 'premium-membership-pro'));
    }
    
    private static function process_bank_transfer($user_id, $level_id, $amount) {
        $bank_enabled = get_option('pmp_enable_bank_transfer', '0');
        
        if ($bank_enabled !== '1') {
            return array('success' => false, 'message' => __('Bankovní převod není aktivní', 'premium-membership-pro'));
        }
        
        // Create pending subscription
        $subscription_id = PMP_Subscriptions::create_subscription($user_id, $level_id, array(
            'gateway' => 'bank_transfer',
            'subscription_id' => 'bank_' . uniqid(),
        ));
        
        if ($subscription_id) {
            // Update to pending status
            global $wpdb;
            $wpdb->update(
                $wpdb->prefix . 'pmp_memberships',
                array('status' => 'pending'),
                array('id' => $subscription_id),
                array('%s'),
                array('%d')
            );
            
            $transaction_id = self::create_transaction($user_id, $subscription_id, $amount, 'bank_transfer', array(
                'status' => 'pending',
            ));
            
            // Send payment instructions email
            PMP_Emails::send_bank_transfer_instructions($user_id, $level_id, $transaction_id);
            
            return array(
                'success' => true,
                'message' => __('Pokyny pro bankovní převod byly odeslány na váš email', 'premium-membership-pro'),
                'redirect' => get_permalink(get_option('pmp_thank_you_page')),
            );
        }
        
        return array('success' => false, 'message' => __('Chyba při vytváření objednávky', 'premium-membership-pro'));
    }
    
    private static function apply_coupon($code, $level_id) {
        $coupons = get_posts(array(
            'post_type' => 'pmp_coupon',
            'post_status' => 'publish',
            'posts_per_page' => 1,
            'meta_query' => array(
                array(
                    'key' => '_pmp_coupon_code',
                    'value' => $code,
                    'compare' => '=',
                ),
            ),
        ));
        
        if (empty($coupons)) {
            return false;
        }
        
        $coupon = $coupons[0];
        
        // Check if coupon is valid
        $valid_from = get_post_meta($coupon->ID, '_pmp_valid_from', true);
        $valid_to = get_post_meta($coupon->ID, '_pmp_valid_to', true);
        $usage_limit = get_post_meta($coupon->ID, '_pmp_usage_limit', true);
        $used_count = get_post_meta($coupon->ID, '_pmp_used_count', true) ?: 0;
        
        $now = current_time('timestamp');
        
        if ($valid_from && strtotime($valid_from) > $now) {
            return false;
        }
        
        if ($valid_to && strtotime($valid_to) < $now) {
            return false;
        }
        
        if ($usage_limit && $used_count >= $usage_limit) {
            return false;
        }
        
        // Check if coupon applies to this level
        $applicable_levels = get_post_meta($coupon->ID, '_pmp_applicable_levels', true);
        if (!empty($applicable_levels) && !in_array($level_id, $applicable_levels)) {
            return false;
        }
        
        // Increment usage count
        update_post_meta($coupon->ID, '_pmp_used_count', $used_count + 1);
        
        // Return discount percentage
        return get_post_meta($coupon->ID, '_pmp_discount_amount', true);
    }
    
    private static function generate_invoice_number() {
        $prefix = get_option('pmp_invoice_prefix', 'INV');
        $year = date('Y');
        $number = get_option('pmp_last_invoice_number', 0) + 1;
        
        update_option('pmp_last_invoice_number', $number);
        
        return sprintf('%s-%s-%05d', $prefix, $year, $number);
    }
    
    public static function get_user_transactions($user_id, $limit = 10) {
        global $wpdb;
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}pmp_transactions 
            WHERE user_id = %d 
            ORDER BY created_at DESC 
            LIMIT %d",
            $user_id,
            $limit
        ));
    }
    
    public static function get_transaction($transaction_id) {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}pmp_transactions WHERE id = %d",
            $transaction_id
        ));
    }
}
