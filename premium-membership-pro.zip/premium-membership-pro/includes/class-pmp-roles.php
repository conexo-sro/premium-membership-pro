<?php
/**
 * Roles and Capabilities Management
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Roles {
    
    // Custom capabilities
    private static $capabilities = array(
        // Dashboard
        'pmp_view_dashboard' => 'Zobrazit dashboard',
        
        // Members management
        'pmp_manage_members' => 'Spravovat členy',
        'pmp_view_members' => 'Zobrazit členy',
        'pmp_edit_members' => 'Upravovat členy',
        'pmp_delete_members' => 'Mazat členy',
        
        // Membership levels
        'pmp_manage_levels' => 'Spravovat úrovně',
        'pmp_view_levels' => 'Zobrazit úrovně',
        'pmp_edit_levels' => 'Upravovat úrovně',
        'pmp_delete_levels' => 'Mazat úrovně',
        
        // Transactions
        'pmp_view_transactions' => 'Zobrazit transakce',
        'pmp_manage_transactions' => 'Spravovat transakce',
        
        // Reports
        'pmp_view_reports' => 'Zobrazit reporty',
        
        // Products
        'pmp_manage_products' => 'Spravovat produkty',
        
        // Coupons
        'pmp_manage_coupons' => 'Spravovat kupóny',
        
        // Emails
        'pmp_manage_emails' => 'Spravovat e-maily',
        'pmp_send_test_emails' => 'Odesílat testovací e-maily',
        
        // Content protection
        'pmp_manage_protection' => 'Spravovat ochranu obsahu',
        
        // Logs
        'pmp_view_logs' => 'Zobrazit logy',
        
        // Import/Export
        'pmp_import_data' => 'Importovat data',
        'pmp_export_data' => 'Exportovat data',
        
        // Settings
        'pmp_manage_settings' => 'Spravovat nastavení',
    );
    
    /**
     * Initialize roles and capabilities
     */
    public static function init() {
        add_action('admin_init', array(__CLASS__, 'check_capabilities'));
        
        // User Role Editor compatibility
        add_filter('ure_built_in_wp_caps', array(__CLASS__, 'register_caps_with_ure'));
        add_filter('ure_capabilities_groups_tree', array(__CLASS__, 'add_caps_group_to_ure'));
        
        // Members plugin compatibility
        add_filter('members_get_capabilities', array(__CLASS__, 'register_caps_with_members'));
        
        // Capability Manager Enhanced compatibility
        add_filter('capsman_get_capabilities', array(__CLASS__, 'register_caps_with_capsman'));
    }
    
    /**
     * Register capabilities with User Role Editor
     */
    public static function register_caps_with_ure($caps) {
        foreach (self::$capabilities as $cap => $label) {
            $caps[$cap] = array(
                'inner' => $label,
                'human' => $label
            );
        }
        return $caps;
    }
    
    /**
     * Add capabilities group to User Role Editor
     */
    public static function add_caps_group_to_ure($groups) {
        $groups['premium_membership'] = array(
            'caption' => __('Premium Membership Pro', 'premium-membership-pro'),
            'parent' => 'custom',
            'level' => 2
        );
        
        return $groups;
    }
    
    /**
     * Register capabilities with Members plugin
     */
    public static function register_caps_with_members($caps) {
        foreach (self::$capabilities as $cap => $label) {
            $caps[$cap] = $label;
        }
        return $caps;
    }
    
    /**
     * Register capabilities with Capability Manager Enhanced
     */
    public static function register_caps_with_capsman($caps) {
        foreach (self::$capabilities as $cap => $label) {
            $caps[$cap] = $label;
        }
        return $caps;
    }
    
    /**
     * Create custom capabilities on plugin activation
     */
    public static function add_capabilities() {
        // Administrator gets ALL capabilities - they should have full access
        $admin_role = get_role('administrator');
        if ($admin_role) {
            foreach (self::$capabilities as $cap => $label) {
                $admin_role->add_cap($cap);
            }
            // Ensure manage_options capability (should already exist)
            $admin_role->add_cap('manage_options');
            
            // Ensure WordPress core admin capabilities
            $admin_role->add_cap('edit_dashboard');
            $admin_role->add_cap('manage_categories');
        }
        
        // Editor gets limited capabilities for content management
        $editor_role = get_role('editor');
        if ($editor_role) {
            $editor_caps = array(
                'pmp_view_dashboard',
                'pmp_view_members',
                'pmp_view_levels',
                'pmp_view_transactions',
                'pmp_view_reports',
                'pmp_manage_protection',
            );
            foreach ($editor_caps as $cap) {
                $editor_role->add_cap($cap);
            }
        }
        
        // Create custom Membership Manager role with comprehensive permissions
        // Remove existing role first to ensure clean setup
        remove_role('membership_manager');
        
        add_role(
            'membership_manager',
            __('Membership Manager', 'premium-membership-pro'),
            array(
                'read' => true,
                'pmp_view_dashboard' => true,
                'pmp_manage_members' => true,
                'pmp_view_members' => true,
                'pmp_edit_member' => true,
                'pmp_view_levels' => true,
                'pmp_view_transactions' => true,
                'pmp_view_reports' => true,
                'pmp_manage_emails' => true,
                'pmp_view_logs' => true,
                'pmp_export_data' => true,
            )
        );
    }
    
    /**
     * Remove custom capabilities on plugin deactivation
     */
    public static function remove_capabilities() {
        $roles = array('administrator', 'editor', 'membership_manager');
        
        foreach ($roles as $role_name) {
            $role = get_role($role_name);
            if ($role) {
                foreach (self::$capabilities as $cap => $label) {
                    $role->remove_cap($cap);
                }
            }
        }
        
        // Remove custom role
        remove_role('membership_manager');
    }
    
    /**
     * Check if current user has capability
     */
    public static function current_user_can($capability) {
        // Administrators can do everything
        if (current_user_can('manage_options')) {
            return true;
        }
        
        // Check specific capability
        return current_user_can($capability);
    }
    
    /**
     * Get capability for menu item
     */
    public static function get_menu_capability($page) {
        $capabilities_map = array(
            'premium-membership-pro' => 'pmp_view_dashboard',
            'pmp-members' => 'pmp_view_members',
            'pmp-transactions' => 'pmp_view_transactions',
            'pmp-reports' => 'pmp_view_reports',
            'pmp-emails' => 'pmp_manage_emails',
            'pmp-content-protection' => 'pmp_manage_protection',
            'pmp-access-logs' => 'pmp_view_logs',
            'pmp-import-export' => 'pmp_export_data',
            'pmp-settings' => 'pmp_manage_settings',
            'pmp-documentation' => 'pmp_view_dashboard',
            'pmp-roles' => 'pmp_manage_settings',
        );
        
        return isset($capabilities_map[$page]) ? $capabilities_map[$page] : 'manage_options';
    }
    
    /**
     * Get all capabilities
     */
    public static function get_capabilities() {
        return self::$capabilities;
    }
    
    /**
     * Get user's membership capabilities
     */
    public static function get_user_capabilities($user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        $user = get_userdata($user_id);
        if (!$user) {
            return array();
        }
        
        $user_caps = array();
        foreach (self::$capabilities as $cap => $label) {
            if ($user->has_cap($cap)) {
                $user_caps[$cap] = $label;
            }
        }
        
        return $user_caps;
    }
    
    /**
     * Check capabilities on admin init
     */
    public static function check_capabilities() {
        // Ensure administrator role always has all capabilities
        // This runs on every admin_init to guarantee capabilities are present
        $admin_role = get_role('administrator');
        if ($admin_role) {
            $missing_caps = 0;
            foreach (self::$capabilities as $cap => $label) {
                if (!$admin_role->has_cap($cap)) {
                    $admin_role->add_cap($cap);
                    $missing_caps++;
                }
            }
            
            // If we added capabilities, show a notice
            if ($missing_caps > 0 && current_user_can('manage_options')) {
                add_action('admin_notices', function() use ($missing_caps) {
                    echo '<div class="notice notice-success is-dismissible">';
                    echo '<p><strong>Premium Membership Pro:</strong> ';
                    printf(__('Přidáno %d oprávnění pro Administrátory.', 'premium-membership-pro'), $missing_caps);
                    echo '</p></div>';
                });
            }
        }
    }
    
    /**
     * Check if User Role Editor is active
     */
    public static function is_ure_active() {
        return class_exists('User_Role_Editor');
    }
    
    /**
     * Check if Members plugin is active
     */
    public static function is_members_active() {
        return function_exists('members_plugin');
    }
    
    /**
     * Check if Capability Manager Enhanced is active
     */
    public static function is_capsman_active() {
        return function_exists('pp_capabilities_autoloader');
    }
    
    /**
     * Get active role management plugins
     */
    public static function get_active_role_plugins() {
        $plugins = array();
        
        if (self::is_ure_active()) {
            $plugins[] = array(
                'name' => 'User Role Editor',
                'slug' => 'user-role-editor',
                'integrated' => true
            );
        }
        
        if (self::is_members_active()) {
            $plugins[] = array(
                'name' => 'Members',
                'slug' => 'members',
                'integrated' => true
            );
        }
        
        if (self::is_capsman_active()) {
            $plugins[] = array(
                'name' => 'Capability Manager Enhanced',
                'slug' => 'capability-manager-enhanced',
                'integrated' => true
            );
        }
        
        return $plugins;
    }
    
    /**
     * Sync capabilities with external role manager
     */
    public static function sync_with_external_manager() {
        $synced = array();
        
        // Sync with User Role Editor if active
        if (self::is_ure_active()) {
            // URE automatically picks up capabilities through filters
            $synced[] = 'User Role Editor';
        }
        
        // Sync with Members if active
        if (self::is_members_active()) {
            // Members automatically picks up capabilities through filters
            $synced[] = 'Members';
        }
        
        // Sync with Capability Manager if active
        if (self::is_capsman_active()) {
            // CapMan automatically picks up capabilities through filters
            $synced[] = 'Capability Manager Enhanced';
        }
        
        return $synced;
    }
    
    /**
     * Get capability requirement for action
     */
    public static function can_user_do($action, $user_id = null) {
        if (!$user_id) {
            $user_id = get_current_user_id();
        }
        
        $user = get_userdata($user_id);
        if (!$user) {
            return false;
        }
        
        // Administrators can do everything
        if ($user->has_cap('manage_options')) {
            return true;
        }
        
        // Map actions to capabilities
        $action_map = array(
            'view_dashboard' => 'pmp_view_dashboard',
            'manage_members' => 'pmp_manage_members',
            'view_members' => 'pmp_view_members',
            'edit_member' => 'pmp_edit_members',
            'delete_member' => 'pmp_delete_members',
            'manage_levels' => 'pmp_manage_levels',
            'view_transactions' => 'pmp_view_transactions',
            'view_reports' => 'pmp_view_reports',
            'manage_emails' => 'pmp_manage_emails',
            'view_logs' => 'pmp_view_logs',
            'import_data' => 'pmp_import_data',
            'export_data' => 'pmp_export_data',
            'manage_settings' => 'pmp_manage_settings',
        );
        
        $required_cap = isset($action_map[$action]) ? $action_map[$action] : false;
        
        if (!$required_cap) {
            return false;
        }
        
        return $user->has_cap($required_cap);
    }
    
    /**
     * Get capability label in current language
     */
    public static function get_capability_label($cap) {
        $caps = self::$capabilities;
        return isset($caps[$cap]) ? $caps[$cap] : $cap;
    }
    
    /**
     * Get all capabilities with their labels
     */
    public static function get_capabilities_with_labels() {
        return self::$capabilities;
    }
    
    /**
     * Add capability to specific role
     */
    public static function add_cap_to_role($role_name, $capability) {
        $role = get_role($role_name);
        if ($role && isset(self::$capabilities[$capability])) {
            $role->add_cap($capability);
            return true;
        }
        return false;
    }
    
    /**
     * Remove capability from specific role
     */
    public static function remove_cap_from_role($role_name, $capability) {
        $role = get_role($role_name);
        if ($role && isset(self::$capabilities[$capability])) {
            $role->remove_cap($capability);
            return true;
        }
        return false;
    }
    
    /**
     * Check if capability is PMP capability
     */
    public static function is_pmp_capability($cap) {
        return isset(self::$capabilities[$cap]);
    }
    
    /**
     * Get roles that have specific capability
     */
    public static function get_roles_with_capability($capability) {
        if (!isset(self::$capabilities[$capability])) {
            return array();
        }
        
        $roles_with_cap = array();
        $all_roles = wp_roles()->roles;
        
        foreach ($all_roles as $role_name => $role_info) {
            $role = get_role($role_name);
            if ($role && $role->has_cap($capability)) {
                $roles_with_cap[] = $role_name;
            }
        }
        
        return $roles_with_cap;
    }
    
    /**
     * Export roles configuration
     */
    public static function export_roles_config() {
        $config = array();
        $all_roles = wp_roles()->roles;
        
        foreach ($all_roles as $role_name => $role_info) {
            $role = get_role($role_name);
            if (!$role) continue;
            
            $pmp_caps = array();
            foreach (self::$capabilities as $cap => $label) {
                if ($role->has_cap($cap)) {
                    $pmp_caps[] = $cap;
                }
            }
            
            if (!empty($pmp_caps)) {
                $config[$role_name] = $pmp_caps;
            }
        }
        
        return $config;
    }
    
    /**
     * Import roles configuration
     */
    public static function import_roles_config($config) {
        if (!is_array($config)) {
            return false;
        }
        
        foreach ($config as $role_name => $capabilities) {
            $role = get_role($role_name);
            if (!$role) continue;
            
            // Remove all PMP capabilities first
            foreach (self::$capabilities as $cap => $label) {
                $role->remove_cap($cap);
            }
            
            // Add specified capabilities
            foreach ($capabilities as $cap) {
                if (isset(self::$capabilities[$cap])) {
                    $role->add_cap($cap);
                }
            }
        }
        
        return true;
    }
}
