<?php
/**
 * Admin Panel Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class PMP_Admin {
    
    public static function init() {
        // Debug - verify admin is loaded
        add_action('admin_notices', array(__CLASS__, 'admin_loaded_notice'));
        add_action('admin_menu', array(__CLASS__, 'add_admin_menu')); // Default priority 10
        add_action('admin_init', array(__CLASS__, 'register_settings'));
        add_action('admin_init', array(__CLASS__, 'handle_create_tables'));
    }
    
    public static function admin_loaded_notice() {
        // Remove this notice after confirming menu works
        if (isset($_GET['pmp_debug'])) {
            echo '<div class="notice notice-info"><p>PMP Admin Class loaded successfully!</p></div>';
        }
    }
    
    public static function add_admin_menu() {
        // ALWAYS use manage_options for menu visibility
        // This ensures menu is ALWAYS visible to administrators
        $main_capability = 'manage_options';
        
        // Main menu
        add_menu_page(
            __('Premium Membership Pro', 'premium-membership-pro'),
            __('Membership PRO', 'premium-membership-pro'),
            $main_capability,
            'premium-membership-pro',
            array(__CLASS__, 'dashboard_page'),
            'dashicons-id-alt',
            30
        );
        
        // Dashboard
        add_submenu_page(
            'premium-membership-pro',
            __('Přehled', 'premium-membership-pro'),
            __('📊 Přehled', 'premium-membership-pro'),
            $main_capability,
            'premium-membership-pro',
            array(__CLASS__, 'dashboard_page')
        );
        
        // Membership levels
        add_submenu_page(
            'premium-membership-pro',
            __('Úrovně členství', 'premium-membership-pro'),
            __('⭐ Úrovně', 'premium-membership-pro'),
            $main_capability,
            'pmp-levels',
            array(__CLASS__, 'levels_page')
        );
        
        // Members management
        add_submenu_page(
            'premium-membership-pro',
            __('Členové', 'premium-membership-pro'),
            __('👥 Členové', 'premium-membership-pro'),
            $main_capability,
            'pmp-members',
            array(__CLASS__, 'members_page')
        );
        
        // Transactions
        add_submenu_page(
            'premium-membership-pro',
            __('Transakce', 'premium-membership-pro'),
            __('💳 Transakce', 'premium-membership-pro'),
            $main_capability,
            'pmp-transactions',
            array(__CLASS__, 'transactions_page')
        );
        
        // Reports & Analytics
        add_submenu_page(
            'premium-membership-pro',
            __('Reporty', 'premium-membership-pro'),
            __('📈 Reporty', 'premium-membership-pro'),
            $main_capability,
            'pmp-reports',
            array(__CLASS__, 'reports_page')
        );
        
        // Emails
        add_submenu_page(
            'premium-membership-pro',
            __('E-maily', 'premium-membership-pro'),
            __('📧 E-maily', 'premium-membership-pro'),
            $main_capability,
            'pmp-emails',
            array(__CLASS__, 'emails_page')
        );
        
        // Content Protection
        add_submenu_page(
            'premium-membership-pro',
            __('Ochrana obsahu', 'premium-membership-pro'),
            __('🔒 Ochrana obsahu', 'premium-membership-pro'),
            $main_capability,
            'pmp-content-protection',
            array(__CLASS__, 'content_protection_page')
        );
        
        // Access Logs
        add_submenu_page(
            'premium-membership-pro',
            __('Logy přístupů', 'premium-membership-pro'),
            __('📋 Logy', 'premium-membership-pro'),
            $main_capability,
            'pmp-access-logs',
            array(__CLASS__, 'access_logs_page')
        );
        
        // Import / Export
        add_submenu_page(
            'premium-membership-pro',
            __('Import / Export', 'premium-membership-pro'),
            __('⚙️ Import/Export', 'premium-membership-pro'),
            $main_capability,
            'pmp-import-export',
            array(__CLASS__, 'import_export_page')
        );
        
        // Roles management
        add_submenu_page(
            'premium-membership-pro',
            __('Správa rolí', 'premium-membership-pro'),
            __('👤 Role', 'premium-membership-pro'),
            'manage_options',
            'pmp-roles',
            array(__CLASS__, 'roles_page')
        );
        
        // Settings
        add_submenu_page(
            'premium-membership-pro',
            __('Nastavení', 'premium-membership-pro'),
            __('⚙️ Nastavení', 'premium-membership-pro'),
            $main_capability,
            'pmp-settings',
            array(__CLASS__, 'settings_page')
        );
        
        // Documentation
        add_submenu_page(
            'premium-membership-pro',
            __('Dokumentace', 'premium-membership-pro'),
            __('📖 Dokumentace', 'premium-membership-pro'),
            $main_capability,
            'pmp-documentation',
            array(__CLASS__, 'documentation_page')
        );
    }
    
    public static function levels_page() {
        // Get all membership levels
        $args = array(
            'post_type' => 'pmp_membership',
            'posts_per_page' => -1,
            'post_status' => 'any',
            'orderby' => 'menu_order',
            'order' => 'ASC'
        );
        $levels = get_posts($args);
        
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">
                <?php _e('Úrovně členství', 'premium-membership-pro'); ?>
            </h1>
            <a href="<?php echo admin_url('post-new.php?post_type=pmp_membership'); ?>" class="page-title-action">
                <?php _e('Přidat novou', 'premium-membership-pro'); ?>
            </a>
            <hr class="wp-header-end">
            
            <?php if (empty($levels)): ?>
                <div class="notice notice-info">
                    <p>
                        <strong><?php _e('Zatím nemáte žádné úrovně členství.', 'premium-membership-pro'); ?></strong>
                    </p>
                    <p>
                        <?php _e('Vytvořte svou první úroveň členství kliknutím na tlačítko "Přidat novou" výše.', 'premium-membership-pro'); ?>
                    </p>
                </div>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th style="width: 60px;"><?php _e('Ikona', 'premium-membership-pro'); ?></th>
                            <th><?php _e('Název', 'premium-membership-pro'); ?></th>
                            <th><?php _e('Cena', 'premium-membership-pro'); ?></th>
                            <th><?php _e('Interval', 'premium-membership-pro'); ?></th>
                            <th><?php _e('Aktivní členové', 'premium-membership-pro'); ?></th>
                            <th><?php _e('Status', 'premium-membership-pro'); ?></th>
                            <th><?php _e('Akce', 'premium-membership-pro'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($levels as $level): 
                            $icon = get_post_meta($level->ID, '_pmp_icon', true) ?: '⭐';
                            $price = get_post_meta($level->ID, '_pmp_price', true);
                            $interval = get_post_meta($level->ID, '_pmp_interval', true);
                            $interval_count = get_post_meta($level->ID, '_pmp_interval_count', true);
                            
                            // Count active members
                            global $wpdb;
                            $active_members = $wpdb->get_var($wpdb->prepare(
                                "SELECT COUNT(*) FROM {$wpdb->prefix}pmp_memberships 
                                WHERE level_id = %d AND status = 'active'",
                                $level->ID
                            ));
                            
                            // Format interval
                            $interval_text = '';
                            if ($interval == 'once') {
                                $interval_text = __('Jednorázově', 'premium-membership-pro');
                            } elseif ($interval == 'lifetime') {
                                $interval_text = __('Doživotně', 'premium-membership-pro');
                            } else {
                                $intervals = array(
                                    'day' => __('den', 'premium-membership-pro'),
                                    'week' => __('týden', 'premium-membership-pro'),
                                    'month' => __('měsíc', 'premium-membership-pro'),
                                    'year' => __('rok', 'premium-membership-pro'),
                                );
                                $interval_text = $interval_count . ' ' . ($intervals[$interval] ?? $interval);
                            }
                        ?>
                            <tr>
                                <td style="font-size: 32px; text-align: center;">
                                    <?php echo $icon; ?>
                                </td>
                                <td>
                                    <strong>
                                        <a href="<?php echo admin_url('post.php?post=' . $level->ID . '&action=edit'); ?>">
                                            <?php echo esc_html($level->post_title); ?>
                                        </a>
                                    </strong>
                                    <?php if ($level->post_status !== 'publish'): ?>
                                        <span class="post-state"> — <?php echo get_post_status_object($level->post_status)->label; ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo $price ? pmp_format_price($price) : __('Zdarma', 'premium-membership-pro'); ?>
                                </td>
                                <td><?php echo esc_html($interval_text); ?></td>
                                <td>
                                    <a href="<?php echo admin_url('admin.php?page=pmp-members&level=' . $level->ID); ?>">
                                        <?php echo number_format($active_members); ?>
                                    </a>
                                </td>
                                <td>
                                    <?php if ($level->post_status === 'publish'): ?>
                                        <span style="color: #46b450;">● <?php _e('Aktivní', 'premium-membership-pro'); ?></span>
                                    <?php else: ?>
                                        <span style="color: #999;">● <?php _e('Neaktivní', 'premium-membership-pro'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo admin_url('post.php?post=' . $level->ID . '&action=edit'); ?>" class="button button-small">
                                        <?php _e('Upravit', 'premium-membership-pro'); ?>
                                    </a>
                                    <a href="<?php echo get_permalink($level->ID); ?>" class="button button-small" target="_blank">
                                        <?php _e('Zobrazit', 'premium-membership-pro'); ?>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
            
            <p style="margin-top: 20px;">
                <a href="<?php echo admin_url('edit.php?post_type=pmp_membership'); ?>" class="button">
                    <?php _e('Zobrazit vše v WordPress editoru', 'premium-membership-pro'); ?>
                </a>
            </p>
        </div>
        <?php
    }
    
    public static function dashboard_page() {
        $total_members = PMP_Analytics::get_total_members();
        $total_revenue = PMP_Analytics::get_total_revenue();
        $monthly_revenue = PMP_Analytics::get_total_revenue('month');
        $new_members = PMP_Analytics::get_new_members(30);
        $churn_rate = PMP_Analytics::get_churn_rate();
        $members_by_level = PMP_Analytics::get_members_by_level();
        $popular_content = PMP_Analytics::get_popular_content();
        
        ?>
        <div class="wrap">
            <h1><?php _e('Premium Membership Pro - Přehled', 'premium-membership-pro'); ?></h1>
            
            <?php
            // Show Elementor integration status
            if (class_exists('PMP_Elementor')) {
                $integration_status = PMP_Elementor::get_integration_status();
                
                if ($integration_status['integration_ready']): ?>
                    <div class="notice notice-success" style="position: relative;">
                        <h3 style="margin-top: 10px;">🎨 Elementor integrace aktivní</h3>
                        <p>
                            <strong><?php echo $integration_status['widgets_registered']; ?> widgetů</strong> je dostupných v Elementor editoru.
                            <?php if ($integration_status['elementor_pro_installed']): ?>
                                <br>Elementor Pro <?php echo $integration_status['elementor_pro_version']; ?> detekován ✅
                            <?php endif; ?>
                        </p>
                        <p>
                            <a href="<?php echo admin_url('admin.php?page=pmp-settings'); ?>" class="button">Spravovat integraci</a>
                        </p>
                    </div>
                <?php elseif ($integration_status['elementor_installed'] && !$integration_status['enabled']): ?>
                    <div class="notice notice-warning">
                        <h3 style="margin-top: 10px;">⚠️ Elementor integrace vypnuta</h3>
                        <p>
                            Elementor je nainstalován, ale integrace je vypnuta v nastavení.
                        </p>
                        <p>
                            <a href="<?php echo admin_url('admin.php?page=pmp-settings'); ?>" class="button">Povolit integraci</a>
                        </p>
                    </div>
                <?php elseif (!$integration_status['elementor_installed']): ?>
                    <div class="notice notice-info">
                        <h3 style="margin-top: 10px;">💡 Tip: Použijte Elementor</h3>
                        <p>
                            Premium Membership Pro nabízí 6 vlastních widgetů pro Elementor!
                            Vytvářejte krásné membership stránky pomocí drag & drop.
                        </p>
                        <p>
                            <a href="<?php echo admin_url('plugin-install.php?s=elementor&tab=search&type=term'); ?>" class="button button-primary">Nainstalovat Elementor</a>
                            <a href="<?php echo admin_url('admin.php?page=pmp-settings'); ?>" class="button">Nastavení integrace</a>
                        </p>
                    </div>
                <?php endif;
            }
            ?>
            
            <div class="pmp-dashboard">
                <div class="pmp-stats-grid">
                    <div class="pmp-stat-box">
                        <h3><?php _e('Celkem členů', 'premium-membership-pro'); ?></h3>
                        <p class="pmp-stat-number"><?php echo number_format($total_members); ?></p>
                        <p class="pmp-stat-change">+<?php echo $new_members; ?> za posledních 30 dní</p>
                    </div>
                    
                    <div class="pmp-stat-box">
                        <h3><?php _e('Celkové příjmy', 'premium-membership-pro'); ?></h3>
                        <p class="pmp-stat-number"><?php echo pmp_format_price($total_revenue); ?></p>
                        <p class="pmp-stat-change"><?php echo pmp_format_price($monthly_revenue); ?> tento měsíc</p>
                    </div>
                    
                    <div class="pmp-stat-box">
                        <h3><?php _e('Míra odchodu', 'premium-membership-pro'); ?></h3>
                        <p class="pmp-stat-number"><?php echo $churn_rate; ?>%</p>
                        <p class="pmp-stat-change">za poslední měsíc</p>
                    </div>
                    
                    <div class="pmp-stat-box">
                        <h3><?php _e('Noví členové', 'premium-membership-pro'); ?></h3>
                        <p class="pmp-stat-number"><?php echo $new_members; ?></p>
                        <p class="pmp-stat-change">za posledních 30 dní</p>
                    </div>
                </div>
                
                <div class="pmp-charts">
                    <div class="pmp-chart-box">
                        <h3><?php _e('Členové podle úrovně', 'premium-membership-pro'); ?></h3>
                        <table class="widefat">
                            <thead>
                                <tr>
                                    <th><?php _e('Úroveň', 'premium-membership-pro'); ?></th>
                                    <th><?php _e('Počet členů', 'premium-membership-pro'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($members_by_level as $level => $count): ?>
                                    <tr>
                                        <td><?php echo esc_html($level); ?></td>
                                        <td><?php echo number_format($count); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="pmp-chart-box">
                        <h3><?php _e('Nejpopulárnější obsah', 'premium-membership-pro'); ?></h3>
                        <table class="widefat">
                            <thead>
                                <tr>
                                    <th><?php _e('Příspěvek', 'premium-membership-pro'); ?></th>
                                    <th><?php _e('Zhlédnutí', 'premium-membership-pro'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($popular_content as $item): 
                                    $post = get_post($item->post_id);
                                    if ($post):
                                    ?>
                                    <tr>
                                        <td><a href="<?php echo get_edit_post_link($post->ID); ?>"><?php echo esc_html($post->post_title); ?></a></td>
                                        <td><?php echo number_format($item->views); ?></td>
                                    </tr>
                                <?php endif; endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <style>
        .pmp-stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .pmp-stat-box {
            background: #fff;
            padding: 20px;
            border: 1px solid #ccd0d4;
            box-shadow: 0 1px 1px rgba(0,0,0,.04);
        }
        .pmp-stat-box h3 {
            margin: 0 0 10px 0;
            font-size: 14px;
            color: #666;
        }
        .pmp-stat-number {
            font-size: 32px;
            font-weight: bold;
            margin: 10px 0;
            color: #2271b1;
        }
        .pmp-stat-change {
            font-size: 12px;
            color: #666;
        }
        .pmp-charts {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .pmp-chart-box {
            background: #fff;
            padding: 20px;
            border: 1px solid #ccd0d4;
            box-shadow: 0 1px 1px rgba(0,0,0,.04);
        }
        .pmp-chart-box h3 {
            margin: 0 0 15px 0;
        }
        </style>
        <?php
    }
    
    public static function members_page() {
        global $wpdb;
        
        // Handle membership assignment
        if (isset($_POST['pmp_assign_membership']) && check_admin_referer('pmp_assign_membership')) {
            $user_id = intval($_POST['user_id']);
            $level_id = intval($_POST['level_id']);
            
            if ($user_id && $level_id) {
                // Check if user already has membership
                $existing = $wpdb->get_var($wpdb->prepare(
                    "SELECT id FROM {$wpdb->prefix}pmp_memberships WHERE user_id = %d AND status = 'active'",
                    $user_id
                ));
                
                if ($existing) {
                    // Update existing
                    $wpdb->update(
                        $wpdb->prefix . 'pmp_memberships',
                        array('level_id' => $level_id),
                        array('id' => $existing),
                        array('%d'),
                        array('%d')
                    );
                    echo '<div class="notice notice-success"><p>Členství aktualizováno!</p></div>';
                } else {
                    // Create new
                    $wpdb->insert(
                        $wpdb->prefix . 'pmp_memberships',
                        array(
                            'user_id' => $user_id,
                            'level_id' => $level_id,
                            'status' => 'active',
                            'start_date' => current_time('mysql'),
                            'created_at' => current_time('mysql')
                        ),
                        array('%d', '%d', '%s', '%s', '%s')
                    );
                    echo '<div class="notice notice-success"><p>Členství přiděleno!</p></div>';
                }
            }
        }
        
        // Get all users
        $users = get_users(array(
            'orderby' => 'registered',
            'order' => 'DESC',
            'number' => 100
        ));
        
        // Get all membership levels from database table
        $levels = $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}pmp_membership_levels 
            WHERE is_active = 1 
            ORDER BY sort_order ASC, id ASC"
        );
        
        // Debug: Check if levels exist
        if (defined('WP_DEBUG') && WP_DEBUG && empty($levels)) {
            error_log('PMP Members Page: No membership levels found!');
            error_log('PMP: Checking table: ' . $wpdb->prefix . 'pmp_membership_levels');
            
            // Try to get count
            $count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}pmp_membership_levels");
            error_log('PMP: Total levels in table: ' . $count);
        }
        
        ?>
        <div class="wrap">
            <h1><?php _e('👥 Členové', 'premium-membership-pro'); ?></h1>
            
            <p class="description">Zobrazeno: <?php echo count($users); ?> uživatelů (celkem <?php echo count_users()['total_users']; ?>)</p>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th style="width: 40px;">ID</th>
                        <th><?php _e('Uživatel', 'premium-membership-pro'); ?></th>
                        <th><?php _e('Email', 'premium-membership-pro'); ?></th>
                        <th><?php _e('Role', 'premium-membership-pro'); ?></th>
                        <th><?php _e('Současná úroveň', 'premium-membership-pro'); ?></th>
                        <th><?php _e('Status', 'premium-membership-pro'); ?></th>
                        <th><?php _e('Přiřadit úroveň', 'premium-membership-pro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): 
                        // Get current membership
                        $membership = $wpdb->get_row($wpdb->prepare(
                            "SELECT m.*, p.post_title as level_name 
                            FROM {$wpdb->prefix}pmp_memberships m 
                            LEFT JOIN {$wpdb->posts} p ON m.level_id = p.ID
                            WHERE m.user_id = %d AND m.status = 'active' 
                            ORDER BY m.created_at DESC 
                            LIMIT 1",
                            $user->ID
                        ));
                        
                        // Get icon if membership exists
                        $level_icon = '';
                        if ($membership && $membership->level_id) {
                            $level_icon = get_post_meta($membership->level_id, '_pmp_icon', true) ?: '⭐';
                        }
                        
                        $user_roles = implode(', ', $user->roles);
                        ?>
                        <tr>
                            <td><?php echo $user->ID; ?></td>
                            <td>
                                <strong>
                                    <a href="<?php echo get_edit_user_link($user->ID); ?>">
                                        <?php echo esc_html($user->display_name); ?>
                                    </a>
                                </strong>
                                <br>
                                <span style="color: #666; font-size: 12px;"><?php echo esc_html($user->user_login); ?></span>
                            </td>
                            <td><?php echo esc_html($user->user_email); ?></td>
                            <td><span class="dashicons dashicons-admin-users"></span> <?php echo esc_html($user_roles); ?></td>
                            <td>
                                <?php if ($membership): ?>
                                    <span style="background: #2271b1; color: white; padding: 3px 8px; border-radius: 3px; font-size: 12px;">
                                        <?php echo $level_icon; ?> <?php echo esc_html($membership->level_name); ?>
                                    </span>
                            <td><span class="dashicons dashicons-admin-users"></span> <?php echo esc_html($user_roles); ?></td>
                            <td>
                                <?php if ($membership): ?>
                                    <span style="background: #2271b1; color: white; padding: 3px 8px; border-radius: 3px; font-size: 12px;">
                                        ⭐ <?php echo esc_html($membership->level_name); ?>
                                    </span>
                                    <br>
                                    <span style="color: #666; font-size: 11px;">
                                        Od: <?php echo date_i18n(get_option('date_format'), strtotime($membership->start_date)); ?>
                                    </span>
                                <?php else: ?>
                                    <span style="color: #d63638;">❌ Bez členství</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($membership): ?>
                                    <span style="color: #00a32a; font-weight: bold;">✓ Aktivní</span>
                                <?php else: ?>
                                    <span style="color: #999;">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <form method="post" style="display: flex; gap: 5px; align-items: center;">
                                    <?php wp_nonce_field('pmp_assign_membership'); ?>
                                    <input type="hidden" name="user_id" value="<?php echo $user->ID; ?>">
                                    <select name="level_id" style="max-width: 250px;">
                                        <option value="">— Vybrat úroveň —</option>
                                        <?php foreach ($levels as $level): 
                                            $dropdown_icon = get_post_meta($level->ID, '_pmp_icon', true) ?: '⭐';
                                        ?>
                                            <option value="<?php echo $level->ID; ?>" <?php selected($membership ? $membership->level_id : 0, $level->ID); ?>>
                                                <?php echo $dropdown_icon; ?> <?php echo esc_html($level->post_title); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit" name="pmp_assign_membership" class="button button-primary button-small">
                                        <?php echo $membership ? '🔄 Změnit' : '➕ Přidat'; ?>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <?php if (count_users()['total_users'] > 100): ?>
                <p class="description" style="margin-top: 20px;">
                    ℹ️ Zobrazeno prvních 100 uživatelů. Pro zobrazení všech použijte filtrování nebo upravte limit.
                </p>
            <?php endif; ?>
        </div>
        
        <style>
        .pmp-status-active {
            color: #00a32a;
            font-weight: bold;
        }
        .wp-list-table th {
            font-weight: 600;
        }
        </style>
        <?php
    }
    
    public static function reports_page() {
        global $wpdb;
        
        // Time period selection
        $period = isset($_GET['period']) ? sanitize_text_field($_GET['period']) : '30days';
        
        $date_from = date('Y-m-d 00:00:00');
        switch($period) {
            case '7days':
                $date_from = date('Y-m-d 00:00:00', strtotime('-7 days'));
                break;
            case '30days':
                $date_from = date('Y-m-d 00:00:00', strtotime('-30 days'));
                break;
            case '90days':
                $date_from = date('Y-m-d 00:00:00', strtotime('-90 days'));
                break;
            case 'year':
                $date_from = date('Y-m-d 00:00:00', strtotime('-1 year'));
                break;
        }
        
        // Revenue statistics
        $revenue_data = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(created_at) as date, SUM(amount) as total, COUNT(*) as count
            FROM {$wpdb->prefix}pmp_transactions
            WHERE status = 'completed' AND created_at >= %s
            GROUP BY DATE(created_at)
            ORDER BY date ASC",
            $date_from
        ));
        
        // Membership growth
        $member_growth = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(created_at) as date, COUNT(*) as count
            FROM {$wpdb->prefix}pmp_memberships
            WHERE created_at >= %s
            GROUP BY DATE(created_at)
            ORDER BY date ASC",
            $date_from
        ));
        
        // Top members by spending
        $top_members = $wpdb->get_results(
            "SELECT u.user_login, u.user_email, SUM(t.amount) as total_spent, COUNT(t.id) as transaction_count
            FROM {$wpdb->prefix}pmp_transactions t
            LEFT JOIN {$wpdb->users} u ON t.user_id = u.ID
            WHERE t.status = 'completed'
            GROUP BY t.user_id
            ORDER BY total_spent DESC
            LIMIT 10"
        );
        
        // Revenue by membership level
        $revenue_by_level = $wpdb->get_results(
            "SELECT p.post_title as level_name, SUM(t.amount) as total_revenue, COUNT(t.id) as transaction_count
            FROM {$wpdb->prefix}pmp_transactions t
            LEFT JOIN {$wpdb->prefix}pmp_memberships m ON t.user_id = m.user_id
            LEFT JOIN {$wpdb->posts} p ON m.level_id = p.ID
            WHERE t.status = 'completed'
            GROUP BY m.level_id
            ORDER BY total_revenue DESC"
        );
        
        ?>
        <div class="wrap">
            <h1><?php _e('Reporty a analytika', 'premium-membership-pro'); ?></h1>
            
            <div class="pmp-report-filters">
                <select id="pmp-period-select" onchange="location.href='?page=pmp-reports&period='+this.value">
                    <option value="7days" <?php selected($period, '7days'); ?>>Posledních 7 dní</option>
                    <option value="30days" <?php selected($period, '30days'); ?>>Posledních 30 dní</option>
                    <option value="90days" <?php selected($period, '90days'); ?>>Posledních 90 dní</option>
                    <option value="year" <?php selected($period, 'year'); ?>>Poslední rok</option>
                </select>
            </div>
            
            <div class="pmp-reports-grid">
                <div class="pmp-report-box">
                    <h2><?php _e('Graf příjmů', 'premium-membership-pro'); ?></h2>
                    <table class="widefat">
                        <thead>
                            <tr>
                                <th>Datum</th>
                                <th>Příjmy</th>
                                <th>Transakcí</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($revenue_data as $row): ?>
                                <tr>
                                    <td><?php echo date_i18n(get_option('date_format'), strtotime($row->date)); ?></td>
                                    <td><?php echo pmp_format_price($row->total); ?></td>
                                    <td><?php echo $row->count; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="pmp-report-box">
                    <h2><?php _e('Růst členské základny', 'premium-membership-pro'); ?></h2>
                    <table class="widefat">
                        <thead>
                            <tr>
                                <th>Datum</th>
                                <th>Nových členů</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($member_growth as $row): ?>
                                <tr>
                                    <td><?php echo date_i18n(get_option('date_format'), strtotime($row->date)); ?></td>
                                    <td><?php echo $row->count; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="pmp-report-box">
                    <h2><?php _e('Top 10 členů (podle útraty)', 'premium-membership-pro'); ?></h2>
                    <table class="widefat">
                        <thead>
                            <tr>
                                <th>Uživatel</th>
                                <th>Email</th>
                                <th>Celkem utraceno</th>
                                <th>Transakcí</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($top_members as $member): ?>
                                <tr>
                                    <td><?php echo esc_html($member->user_login); ?></td>
                                    <td><?php echo esc_html($member->user_email); ?></td>
                                    <td><strong><?php echo pmp_format_price($member->total_spent); ?></strong></td>
                                    <td><?php echo $member->transaction_count; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="pmp-report-box">
                    <h2><?php _e('Příjmy podle úrovně členství', 'premium-membership-pro'); ?></h2>
                    <table class="widefat">
                        <thead>
                            <tr>
                                <th>Úroveň</th>
                                <th>Celkové příjmy</th>
                                <th>Transakcí</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($revenue_by_level as $level): ?>
                                <tr>
                                    <td><?php echo esc_html($level->level_name); ?></td>
                                    <td><strong><?php echo pmp_format_price($level->total_revenue); ?></strong></td>
                                    <td><?php echo $level->transaction_count; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <style>
            .pmp-report-filters {
                margin: 20px 0;
            }
            .pmp-report-filters select {
                padding: 5px 10px;
                font-size: 14px;
            }
            .pmp-reports-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
                gap: 20px;
                margin: 20px 0;
            }
            .pmp-report-box {
                background: #fff;
                padding: 20px;
                border: 1px solid #ccd0d4;
                box-shadow: 0 1px 1px rgba(0,0,0,.04);
            }
            .pmp-report-box h2 {
                margin-top: 0;
                margin-bottom: 15px;
                font-size: 16px;
            }
            </style>
        </div>
        <?php
    }
    
    public static function emails_page() {
        global $wpdb;
        
        if (isset($_POST['pmp_send_test_email'])) {
            check_admin_referer('pmp_test_email');
            $test_email = sanitize_email($_POST['test_email']);
            
            if ($test_email) {
                $subject = 'Test email z Premium Membership Pro';
                $message = 'Toto je testovací email. Pokud ho vidíte, e-mailové nastavení funguje správně!';
                
                $sent = wp_mail($test_email, $subject, $message);
                
                if ($sent) {
                    echo '<div class="notice notice-success"><p>Testovací email odeslán na ' . esc_html($test_email) . '</p></div>';
                } else {
                    echo '<div class="notice notice-error"><p>Nepodařilo se odeslat testovací email.</p></div>';
                }
            }
        }
        
        // Email logs
        $email_logs = $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}pmp_email_logs ORDER BY sent_at DESC LIMIT 50"
        );
        
        ?>
        <div class="wrap">
            <h1><?php _e('E-mailové nastavení a historie', 'premium-membership-pro'); ?></h1>
            
            <div class="pmp-email-settings">
                <h2><?php _e('Šablony e-mailů', 'premium-membership-pro'); ?></h2>
                <p><?php _e('Upravte šablony e-mailů v souboru includes/class-pmp-emails.php', 'premium-membership-pro'); ?></p>
                
                <div class="pmp-email-templates">
                    <ul>
                        <li><strong>Uvítací email</strong> - Odesílá se při registraci nového člena</li>
                        <li><strong>Připomínka expirace</strong> - 7 dní před vypršením členství</li>
                        <li><strong>Notifikace vypršení</strong> - Po vypršení členství</li>
                        <li><strong>Potvrzení platby</strong> - Po úspěšné platbě</li>
                        <li><strong>Pokyny bankovního převodu</strong> - Detaily pro platbu převodem</li>
                    </ul>
                </div>
                
                <h2><?php _e('Testovací email', 'premium-membership-pro'); ?></h2>
                <form method="post">
                    <?php wp_nonce_field('pmp_test_email'); ?>
                    <table class="form-table">
                        <tr>
                            <th><label for="test_email">E-mailová adresa</label></th>
                            <td>
                                <input type="email" name="test_email" id="test_email" class="regular-text" 
                                       value="<?php echo esc_attr(get_option('admin_email')); ?>">
                                <p class="description">Odeslat testovací email na tuto adresu</p>
                            </td>
                        </tr>
                    </table>
                    <?php submit_button('Odeslat testovací email', 'secondary', 'pmp_send_test_email'); ?>
                </form>
                
                <h2><?php _e('Historie odeslaných e-mailů', 'premium-membership-pro'); ?></h2>
                <table class="widefat">
                    <thead>
                        <tr>
                            <th>Datum</th>
                            <th>Příjemce</th>
                            <th>Předmět</th>
                            <th>Typ</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($email_logs)): ?>
                            <tr>
                                <td colspan="5">Zatím nebyly odeslány žádné e-maily.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach($email_logs as $log): ?>
                                <tr>
                                    <td><?php echo date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($log->sent_at)); ?></td>
                                    <td><?php echo esc_html($log->recipient); ?></td>
                                    <td><?php echo esc_html($log->subject); ?></td>
                                    <td><?php echo esc_html($log->email_type); ?></td>
                                    <td><span class="pmp-status-<?php echo esc_attr($log->status); ?>"><?php echo esc_html($log->status); ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <style>
            .pmp-email-settings {
                background: #fff;
                padding: 20px;
                margin: 20px 0;
            }
            .pmp-email-templates ul {
                list-style: disc;
                margin-left: 20px;
            }
            .pmp-email-templates li {
                margin: 10px 0;
            }
            </style>
        </div>
        <?php
    }
    
    public static function content_protection_page() {
        global $wpdb;
        
        // Get protected posts - use correct meta key '_pmp_protected' and filter by status/type
        $protected_posts = $wpdb->get_results(
            "SELECT p.ID, p.post_title, p.post_type, pm.meta_value as protected
            FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_pmp_protected'
            WHERE pm.meta_value = '1' AND p.post_status = 'publish' AND p.post_type IN ('post', 'page')
            ORDER BY p.post_title ASC"
        );
        
        // Get protection statistics
        $total_protected = count($protected_posts);
        $posts_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ('post', 'page')");
        $protection_percentage = $posts_count > 0 ? round(($total_protected / $posts_count) * 100, 1) : 0;
        
        ?>
        <div class="wrap">
            <h1><?php _e('Ochrana obsahu', 'premium-membership-pro'); ?></h1>
            
            <div class="pmp-protection-stats">
                <div class="pmp-stat-box">
                    <h3>Chráněný obsah</h3>
                    <p class="pmp-stat-number"><?php echo $total_protected; ?></p>
                    <p class="pmp-stat-change"><?php echo $protection_percentage; ?>% z celkového obsahu</p>
                </div>
            </div>
            
            <h2><?php _e('Chráněné příspěvky a stránky', 'premium-membership-pro'); ?></h2>
            <table class="widefat">
                <thead>
                    <tr>
                        <th>Název</th>
                        <th>Typ</th>
                        <th>Typ náhledu</th>
                        <th>Požadované úrovně</th>
                        <th>Akce</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($protected_posts as $post): 
                        $preview_type = get_post_meta($post->ID, '_pmp_preview_type', true) ?: 'blur';
                        $required_levels = get_post_meta($post->ID, '_pmp_required_levels', true);
                        ?>
                        <tr>
                            <td>
                                <strong><a href="<?php echo get_edit_post_link($post->ID); ?>"><?php echo esc_html($post->post_title); ?></a></strong>
                            </td>
                            <td><?php echo esc_html($post->post_type); ?></td>
                            <td>
                                <?php 
                                switch($preview_type) {
                                    case 'blur': echo '🔒 Rozostřený obsah'; break;
                                    case 'teaser': echo '📄 Textový náhled'; break;
                                    case 'locked': echo '🚫 Úplně uzamčeno'; break;
                                    default: echo $preview_type;
                                }
                                ?>
                            </td>
                            <td>
                                <?php 
                                if (is_array($required_levels) && !empty($required_levels)) {
                                    foreach($required_levels as $level_id) {
                                        $level = get_post($level_id);
                                        if ($level) {
                                            echo '<span class="pmp-level-badge">' . esc_html($level->post_title) . '</span> ';
                                        }
                                    }
                                } else {
                                    echo '<em>Žádné požadavky</em>';
                                }
                                ?>
                            </td>
                            <td>
                                <a href="<?php echo get_edit_post_link($post->ID); ?>" class="button button-small">Upravit</a>
                                <a href="<?php echo get_permalink($post->ID); ?>" class="button button-small" target="_blank">Zobrazit</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($protected_posts)): ?>
                        <tr>
                            <td colspan="5">Zatím nemáte žádný chráněný obsah.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <div class="pmp-protection-info">
                <h2><?php _e('Jak chránit obsah', 'premium-membership-pro'); ?></h2>
                <ol>
                    <li>Upravte příspěvek nebo stránku</li>
                    <li>V pravém panelu najděte meta box "Ochrana obsahu"</li>
                    <li>Zaškrtněte "Chránit tento obsah"</li>
                    <li>Vyberte typ náhledu (Rozostřený, Textový nebo Uzamčený)</li>
                    <li>Vyberte požadované úrovně členství</li>
                    <li>Uložte změny</li>
                </ol>
            </div>
            
            <style>
            .pmp-protection-stats {
                margin: 20px 0;
            }
            .pmp-level-badge {
                display: inline-block;
                padding: 3px 8px;
                background: #2271b1;
                color: #fff;
                border-radius: 3px;
                font-size: 12px;
                margin: 2px;
            }
            .pmp-protection-info {
                background: #fff;
                padding: 20px;
                margin: 20px 0;
                border-left: 4px solid #2271b1;
            }
            .pmp-protection-info ol {
                margin-left: 20px;
            }
            .pmp-protection-info li {
                margin: 10px 0;
            }
            </style>
        </div>
        <?php
    }
    
    public static function access_logs_page() {
        global $wpdb;
        
        $logs = $wpdb->get_results(
            "SELECT l.*, u.user_login, p.post_title 
            FROM {$wpdb->prefix}pmp_access_logs l
            LEFT JOIN {$wpdb->users} u ON l.user_id = u.ID
            LEFT JOIN {$wpdb->posts} p ON l.post_id = p.ID
            ORDER BY l.accessed_at DESC
            LIMIT 100"
        );
        
        ?>
        <div class="wrap">
            <h1><?php _e('Logy přístupů k chráněnému obsahu', 'premium-membership-pro'); ?></h1>
            
            <table class="widefat">
                <thead>
                    <tr>
                        <th>Datum a čas</th>
                        <th>Uživatel</th>
                        <th>Příspěvek</th>
                        <th>Status přístupu</th>
                        <th>IP adresa</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($logs as $log): ?>
                        <tr>
                            <td><?php echo date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($log->accessed_at)); ?></td>
                            <td><?php echo $log->user_login ? esc_html($log->user_login) : 'Host'; ?></td>
                            <td><a href="<?php echo get_edit_post_link($log->post_id); ?>"><?php echo esc_html($log->post_title); ?></a></td>
                            <td>
                                <?php if ($log->access_granted): ?>
                                    <span style="color: green;">✓ Povolen</span>
                                <?php else: ?>
                                    <span style="color: red;">✗ Odepřen</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html($log->ip_address); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($logs)): ?>
                        <tr>
                            <td colspan="5">Zatím nebyly zaznamenány žádné přístupy.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    public static function import_export_page() {
        // Handle export
        if (isset($_POST['pmp_export_members'])) {
            check_admin_referer('pmp_export');
            self::export_members_csv();
            exit;
        }
        
        // Handle import
        if (isset($_POST['pmp_import_members']) && isset($_FILES['import_file'])) {
            check_admin_referer('pmp_import');
            $result = self::import_members_csv($_FILES['import_file']);
            if ($result['success']) {
                echo '<div class="notice notice-success"><p>Import dokončen: ' . $result['imported'] . ' členů importováno.</p></div>';
            } else {
                echo '<div class="notice notice-error"><p>Chyba při importu: ' . $result['error'] . '</p></div>';
            }
        }
        
        ?>
        <div class="wrap">
            <h1><?php _e('Import / Export dat', 'premium-membership-pro'); ?></h1>
            
            <div class="pmp-import-export-boxes">
                <div class="pmp-ie-box">
                    <h2>📤 Export členů</h2>
                    <p>Exportujte seznam všech členů do CSV souboru.</p>
                    <form method="post">
                        <?php wp_nonce_field('pmp_export'); ?>
                        <?php submit_button('Exportovat členy do CSV', 'primary', 'pmp_export_members'); ?>
                    </form>
                </div>
                
                <div class="pmp-ie-box">
                    <h2>📥 Import členů</h2>
                    <p>Importujte členy z CSV souboru. Formát: user_email, level_id, status, expires_at</p>
                    <form method="post" enctype="multipart/form-data">
                        <?php wp_nonce_field('pmp_import'); ?>
                        <input type="file" name="import_file" accept=".csv" required>
                        <?php submit_button('Importovat členy z CSV', 'primary', 'pmp_import_members'); ?>
                    </form>
                </div>
                
                <div class="pmp-ie-box">
                    <h2>⚙️ Export nastavení</h2>
                    <p>Exportujte nastavení pluginu pro použití na jiném webu.</p>
                    <button class="button" onclick="alert('Funkce bude přidána v další verzi')">Exportovat nastavení</button>
                </div>
                
                <div class="pmp-ie-box">
                    <h2>⚙️ Import nastavení</h2>
                    <p>Importujte nastavení pluginu z jiného webu.</p>
                    <button class="button" onclick="alert('Funkce bude přidána v další verzi')">Importovat nastavení</button>
                </div>
            </div>
            
            <style>
            .pmp-import-export-boxes {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
                gap: 20px;
                margin: 20px 0;
            }
            .pmp-ie-box {
                background: #fff;
                padding: 20px;
                border: 1px solid #ccd0d4;
                box-shadow: 0 1px 1px rgba(0,0,0,.04);
            }
            .pmp-ie-box h2 {
                margin-top: 0;
            }
            </style>
        </div>
        <?php
    }
    
    public static function documentation_page() {
        ?>
        <div class="wrap">
            <h1><?php _e('📖 Dokumentace Premium Membership Pro', 'premium-membership-pro'); ?></h1>
            
            <div class="pmp-docs-grid">
                <div class="pmp-doc-box">
                    <h2>🚀 Rychlý start</h2>
                    <ol>
                        <li>Vytvořte úroveň členství v <a href="<?php echo admin_url('post-new.php?post_type=pmp_membership'); ?>">Membership → Úrovně</a></li>
                        <li>Nastavte cenu a období platnosti</li>
                        <li>Vytvořte stránku s ceníkem pomocí shortcode <code>[pmp_membership_levels]</code></li>
                        <li>Chraňte obsah v editoru příspěvku</li>
                        <li>Aktivujte platební brány v <a href="<?php echo admin_url('admin.php?page=pmp-settings'); ?>">Nastavení</a></li>
                    </ol>
                </div>
                
                <div class="pmp-doc-box">
                    <h2>📝 Shortcody</h2>
                    <table class="widefat">
                        <tr>
                            <td><code>[pmp_membership_levels]</code></td>
                            <td>Zobrazí ceník všech úrovní</td>
                        </tr>
                        <tr>
                            <td><code>[pmp_account]</code></td>
                            <td>Stránka uživatelského účtu</td>
                        </tr>
                        <tr>
                            <td><code>[pmp_login_form]</code></td>
                            <td>Přihlašovací formulář</td>
                        </tr>
                        <tr>
                            <td><code>[pmp_member_content]</code></td>
                            <td>Obsah pouze pro členy</td>
                        </tr>
                        <tr>
                            <td><code>[pmp_has_membership level="ID"]</code></td>
                            <td>Obsah pro konkrétní úroveň</td>
                        </tr>
                    </table>
                </div>
                
                <div class="pmp-doc-box">
                    <h2>🔒 Typy náhledů článků</h2>
                    <ul>
                        <li><strong>Rozostřený obsah</strong> - Zobrazí strukturu, ale text je rozmazaný (doporučeno)</li>
                        <li><strong>Textový náhled</strong> - Zobrazí jen začátek článku s fade efektem</li>
                        <li><strong>Úplně uzamčeno</strong> - Pouze ikona zámku, žádný obsah</li>
                    </ul>
                    <p>Procento zobrazení: 10%, 20%, 30% (výchozí), 40%, 50%, 75%</p>
                </div>
                
                <div class="pmp-doc-box">
                    <h2>💳 Platební brány</h2>
                    <ul>
                        <li><strong>Stripe</strong> - Kreditní karty, plně automatické</li>
                        <li><strong>PayPal</strong> - PayPal platby, plně automatické</li>
                        <li><strong>Bankovní převod</strong> - Ruční schválení plateb adminem</li>
                    </ul>
                    <p>Nastavte klíče v <a href="<?php echo admin_url('admin.php?page=pmp-settings'); ?>">Nastavení → Platební brány</a></p>
                </div>
                
                <div class="pmp-doc-box">
                    <h2>📧 E-mailové notifikace</h2>
                    <p>Plugin automaticky odesílá tyto e-maily:</p>
                    <ul>
                        <li>Uvítací email při registraci</li>
                        <li>Připomínka 7 dní před expirací</li>
                        <li>Notifikace o vypršení členství</li>
                        <li>Potvrzení platby</li>
                        <li>Pokyny pro bankovní převod</li>
                    </ul>
                </div>
                
                <div class="pmp-doc-box">
                    <h2>🎟️ Slevové kupóny</h2>
                    <p>Vytvořte kupóny v <a href="<?php echo admin_url('edit.php?post_type=pmp_coupon'); ?>">Membership → Kupóny</a></p>
                    <ul>
                        <li>Procentuální sleva (např. 20%)</li>
                        <li>Datum vypršení platnosti</li>
                        <li>Limit počtu použití</li>
                        <li>Omezení na konkrétní úrovně</li>
                    </ul>
                </div>
                
                <div class="pmp-doc-box">
                    <h2>📊 Analytika</h2>
                    <p>Sledujte výkonnost v <a href="<?php echo admin_url('admin.php?page=premium-membership-pro'); ?>">Dashboard</a>:</p>
                    <ul>
                        <li>Celkový počet členů</li>
                        <li>Příjmy (celkové a měsíční)</li>
                        <li>Míra odchodu (churn rate)</li>
                        <li>Noví členové za období</li>
                        <li>Nejpopulárnější obsah</li>
                    </ul>
                </div>
                
                <div class="pmp-doc-box">
                    <h2>🛠️ PHP funkce</h2>
                    <pre style="background: #f0f0f0; padding: 10px;">
// Zkontrolovat členství
if (pmp_user_has_membership()) {
    // Uživatel je člen
}

// Získat data
$membership = pmp_get_user_membership();

// Zkontrolovat přístup
if (pmp_user_can_access_content($post_id)) {
    the_content();
}

// Formátovat cenu
echo pmp_format_price(199);
                    </pre>
                </div>
                
                <div class="pmp-doc-box">
                    <h2>🔌 Hooky pro vývojáře</h2>
                    <pre style="background: #f0f0f0; padding: 10px;">
// Po vytvoření členství
add_action('pmp_subscription_created', 
    function($id, $user_id, $level_id) {
        // Váš kód
    }, 10, 3);

// Po zrušení
add_action('pmp_subscription_cancelled',
    function($id, $user_id, $reason) {
        // Váš kód
    }, 10, 3);

// Po vypršení
add_action('pmp_subscription_expired',
    function($id, $user_id) {
        // Váš kód
    }, 10, 2);
                    </pre>
                </div>
                
                <div class="pmp-doc-box">
                    <h2>❓ Často kladené otázky</h2>
                    <dl>
                        <dt><strong>Mohu mít více úrovní členství?</strong></dt>
                        <dd>Ano, neomezený počet úrovní.</dd>
                        
                        <dt><strong>Jsou náhledy SEO friendly?</strong></dt>
                        <dd>Ano, vyhledávače indexují plný obsah.</dd>
                        
                        <dt><strong>Funguje s jakýmkoli tématem?</strong></dt>
                        <dd>Ano, plugin je kompatibilní se všemi WordPress tématy.</dd>
                        
                        <dt><strong>Podporuje opakující se platby?</strong></dt>
                        <dd>Ano, měsíční, roční nebo vlastní období.</dd>
                    </dl>
                </div>
                
                <div class="pmp-doc-box">
                    <h2>🆘 Podpora</h2>
                    <ul>
                        <li>📧 Email: info@conexo.cz</li>
                        <li>🐛 GitHub Issues: <a href="https://github.com/conexo-sro/premium-membership-pro/issues" target="_blank">Nahlásit chybu</a></li>
                        <li>📖 README.md v pluginu</li>
                        <li>💬 WordPress.org fórum (připravujeme)</li>
                    </ul>
                </div>
                
                <div class="pmp-doc-box">
                    <h2>🔄 Aktualizace</h2>
                    <p>Aktuální verze: <strong>1.1.0</strong></p>
                    <p>Poslední změny:</p>
                    <ul>
                        <li>✨ Rozostřené náhledy článků</li>
                        <li>🎨 3 typy náhledů</li>
                        <li>📱 Responzivní design</li>
                        <li>🎭 Moderní animace</li>
                    </ul>
                    <p><a href="<?php echo admin_url('plugins.php'); ?>">Zkontrolovat aktualizace →</a></p>
                </div>
            </div>
            
            <style>
            .pmp-docs-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
                gap: 20px;
                margin: 20px 0;
            }
            .pmp-doc-box {
                background: #fff;
                padding: 20px;
                border: 1px solid #ccd0d4;
                box-shadow: 0 1px 1px rgba(0,0,0,.04);
            }
            .pmp-doc-box h2 {
                margin-top: 0;
                border-bottom: 2px solid #2271b1;
                padding-bottom: 10px;
            }
            .pmp-doc-box ol, .pmp-doc-box ul {
                margin-left: 20px;
            }
            .pmp-doc-box li {
                margin: 8px 0;
            }
            .pmp-doc-box code {
                background: #f0f0f0;
                padding: 2px 6px;
                border-radius: 3px;
                font-size: 13px;
            }
            .pmp-doc-box dt {
                font-weight: bold;
                margin-top: 10px;
            }
            .pmp-doc-box dd {
                margin-left: 20px;
                margin-bottom: 10px;
            }
            </style>
        </div>
        <?php
    }
    
    private static function export_members_csv() {
        global $wpdb;
        
        $members = $wpdb->get_results(
            "SELECT m.*, u.user_email, u.user_login, p.post_title as level_name
            FROM {$wpdb->prefix}pmp_memberships m
            LEFT JOIN {$wpdb->users} u ON m.user_id = u.ID
            LEFT JOIN {$wpdb->posts} p ON m.level_id = p.ID
            ORDER BY m.created_at DESC"
        );
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=members-export-' . date('Y-m-d') . '.csv');
        
        $output = fopen('php://output', 'w');
        
        // UTF-8 BOM for Excel
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        
        // Headers
        fputcsv($output, array('ID', 'Username', 'Email', 'Level', 'Status', 'Created', 'Expires'));
        
        foreach ($members as $member) {
            fputcsv($output, array(
                $member->id,
                $member->user_login,
                $member->user_email,
                $member->level_name,
                $member->status,
                $member->created_at,
                $member->expires_at
            ));
        }
        
        fclose($output);
    }
    
    private static function import_members_csv($file) {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return array('success' => false, 'error' => 'Chyba nahrání souboru');
        }
        
        $handle = fopen($file['tmp_name'], 'r');
        if (!$handle) {
            return array('success' => false, 'error' => 'Nelze otevřít soubor');
        }
        
        // Skip header
        fgetcsv($handle);
        
        $imported = 0;
        while (($data = fgetcsv($handle)) !== false) {
            // Import logic here - to be implemented
            $imported++;
        }
        
        fclose($handle);
        
        return array('success' => true, 'imported' => $imported);
    }
    
    public static function transactions_page() {
        global $wpdb;
        
        $transactions = $wpdb->get_results(
            "SELECT t.*, u.user_login, u.user_email 
            FROM {$wpdb->prefix}pmp_transactions t 
            LEFT JOIN {$wpdb->users} u ON t.user_id = u.ID 
            ORDER BY t.created_at DESC 
            LIMIT 100"
        );
        
        ?>
        <div class="wrap">
            <h1><?php _e('Transakce', 'premium-membership-pro'); ?></h1>
            
            <table class="widefat">
                <thead>
                    <tr>
                        <th><?php _e('Faktura', 'premium-membership-pro'); ?></th>
                        <th><?php _e('Uživatel', 'premium-membership-pro'); ?></th>
                        <th><?php _e('Částka', 'premium-membership-pro'); ?></th>
                        <th><?php _e('Status', 'premium-membership-pro'); ?></th>
                        <th><?php _e('Platební brána', 'premium-membership-pro'); ?></th>
                        <th><?php _e('Datum', 'premium-membership-pro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($transactions as $transaction): ?>
                        <tr>
                            <td><?php echo esc_html($transaction->invoice_number); ?></td>
                            <td><?php echo esc_html($transaction->user_login); ?></td>
                            <td><?php echo pmp_format_price($transaction->amount); ?></td>
                            <td><span class="pmp-status-<?php echo esc_attr($transaction->status); ?>"><?php echo esc_html($transaction->status); ?></span></td>
                            <td><?php echo esc_html($transaction->payment_gateway); ?></td>
                            <td><?php echo date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($transaction->created_at)); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    public static function settings_page() {
        // Handle cleanup actions
        if (isset($_GET['action']) && isset($_GET['_wpnonce'])) {
            $action = sanitize_text_field($_GET['action']);
            
            switch ($action) {
                case 'clear-logs':
                    if (wp_verify_nonce($_GET['_wpnonce'], 'pmp-clear-logs')) {
                        self::clear_access_logs();
                        echo '<div class="notice notice-success"><p>' . __('Logy přístupů byly vyčištěny.', 'premium-membership-pro') . '</p></div>';
                    }
                    break;
                    
                case 'clear-transients':
                    if (wp_verify_nonce($_GET['_wpnonce'], 'pmp-clear-transients')) {
                        self::clear_transients();
                        echo '<div class="notice notice-success"><p>' . __('Dočasná data byla vyčištěna.', 'premium-membership-pro') . '</p></div>';
                    }
                    break;
                    
                case 'delete-all-data':
                    if (wp_verify_nonce($_GET['_wpnonce'], 'pmp-delete-all-data')) {
                        self::delete_all_data();
                        echo '<div class="notice notice-warning"><p><strong>' . __('VŠECHNA DATA BYLA SMAZÁNA!', 'premium-membership-pro') . '</strong></p></div>';
                    }
                    break;
            }
        }
        
        if (isset($_POST['pmp_settings_submit'])) {
            check_admin_referer('pmp_settings');
            self::save_settings();
            echo '<div class="notice notice-success"><p>' . __('Nastavení uloženo.', 'premium-membership-pro') . '</p></div>';
        }
        
        ?>
        <div class="wrap">
            <h1><?php _e('Nastavení Premium Membership Pro', 'premium-membership-pro'); ?></h1>
            
            <form method="post" action="">
                <?php wp_nonce_field('pmp_settings'); ?>
                
                <h2><?php _e('Obecné nastavení', 'premium-membership-pro'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th><label for="pmp_currency"><?php _e('Měna', 'premium-membership-pro'); ?></label></th>
                        <td>
                            <select name="pmp_currency" id="pmp_currency">
                                <option value="CZK" <?php selected(get_option('pmp_currency'), 'CZK'); ?>>CZK (Kč)</option>
                                <option value="EUR" <?php selected(get_option('pmp_currency'), 'EUR'); ?>>EUR (€)</option>
                                <option value="USD" <?php selected(get_option('pmp_currency'), 'USD'); ?>>USD ($)</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="pmp_currency_position"><?php _e('Pozice měny', 'premium-membership-pro'); ?></label></th>
                        <td>
                            <select name="pmp_currency_position" id="pmp_currency_position">
                                <option value="before" <?php selected(get_option('pmp_currency_position'), 'before'); ?>><?php _e('Před částkou', 'premium-membership-pro'); ?></option>
                                <option value="after" <?php selected(get_option('pmp_currency_position'), 'after'); ?>><?php _e('Za částkou', 'premium-membership-pro'); ?></option>
                            </select>
                        </td>
                    </tr>
                </table>
                
                <h2><?php _e('Platební brány', 'premium-membership-pro'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th><?php _e('Stripe', 'premium-membership-pro'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="pmp_enable_stripe" value="1" <?php checked(get_option('pmp_enable_stripe'), '1'); ?>>
                                <?php _e('Povolit Stripe', 'premium-membership-pro'); ?>
                            </label>
                            <br>
                            <input type="text" name="pmp_stripe_public_key" value="<?php echo esc_attr(get_option('pmp_stripe_public_key')); ?>" placeholder="<?php _e('Veřejný klíč', 'premium-membership-pro'); ?>" class="regular-text">
                            <br>
                            <input type="text" name="pmp_stripe_secret_key" value="<?php echo esc_attr(get_option('pmp_stripe_secret_key')); ?>" placeholder="<?php _e('Tajný klíč', 'premium-membership-pro'); ?>" class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th><?php _e('PayPal', 'premium-membership-pro'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="pmp_enable_paypal" value="1" <?php checked(get_option('pmp_enable_paypal'), '1'); ?>>
                                <?php _e('Povolit PayPal', 'premium-membership-pro'); ?>
                            </label>
                            <br>
                            <input type="text" name="pmp_paypal_client_id" value="<?php echo esc_attr(get_option('pmp_paypal_client_id')); ?>" placeholder="<?php _e('Client ID', 'premium-membership-pro'); ?>" class="regular-text">
                            <br>
                            <input type="text" name="pmp_paypal_secret" value="<?php echo esc_attr(get_option('pmp_paypal_secret')); ?>" placeholder="<?php _e('Secret', 'premium-membership-pro'); ?>" class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th><?php _e('Bankovní převod', 'premium-membership-pro'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="pmp_enable_bank_transfer" value="1" <?php checked(get_option('pmp_enable_bank_transfer'), '1'); ?>>
                                <?php _e('Povolit bankovní převod', 'premium-membership-pro'); ?>
                            </label>
                            <br>
                            <input type="text" name="pmp_bank_account_number" value="<?php echo esc_attr(get_option('pmp_bank_account_number')); ?>" placeholder="<?php _e('Číslo účtu', 'premium-membership-pro'); ?>" class="regular-text">
                            <br>
                            <input type="text" name="pmp_bank_iban" value="<?php echo esc_attr(get_option('pmp_bank_iban')); ?>" placeholder="<?php _e('IBAN', 'premium-membership-pro'); ?>" class="regular-text">
                        </td>
                    </tr>
                </table>
                
                <h2><?php _e('🔌 Integrace', 'premium-membership-pro'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th><?php _e('Elementor', 'premium-membership-pro'); ?></th>
                        <td>
                            <?php 
                            $elementor_installed = defined('ELEMENTOR_VERSION');
                            $elementor_pro_installed = defined('ELEMENTOR_PRO_VERSION');
                            ?>
                            
                            <?php if ($elementor_installed): ?>
                                <div style="margin-bottom: 15px; padding: 10px; background: #e7f7e7; border-left: 4px solid #00a32a;">
                                    <strong>✅ Elementor je nainstalován</strong>
                                    <br>Verze: <?php echo ELEMENTOR_VERSION; ?>
                                </div>
                            <?php else: ?>
                                <div style="margin-bottom: 15px; padding: 10px; background: #fff8e5; border-left: 4px solid #dba617;">
                                    <strong>⚠️ Elementor není nainstalován</strong>
                                    <br><a href="<?php echo admin_url('plugin-install.php?s=elementor&tab=search&type=term'); ?>" target="_blank">Nainstalovat Elementor</a>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($elementor_pro_installed): ?>
                                <div style="margin-bottom: 15px; padding: 10px; background: #e7f7e7; border-left: 4px solid #00a32a;">
                                    <strong>✅ Elementor Pro je nainstalován</strong>
                                    <br>Verze: <?php echo ELEMENTOR_PRO_VERSION; ?>
                                </div>
                            <?php endif; ?>
                            
                            <label style="display: block; margin: 15px 0;">
                                <input type="checkbox" name="pmp_enable_elementor" value="1" 
                                    <?php checked(get_option('pmp_enable_elementor', '1'), '1'); ?>
                                    <?php disabled(!$elementor_installed); ?>>
                                <?php _e('Povolit Elementor integraci', 'premium-membership-pro'); ?>
                            </label>
                            
                            <?php if (get_option('pmp_enable_elementor', '1') == '1' && $elementor_installed): ?>
                                <div style="margin-top: 10px; padding: 10px; background: #f0f0f1; border-radius: 4px;">
                                    <strong>📊 Dostupné widgety:</strong>
                                    <ul style="margin: 10px 0 0 20px; list-style: disc;">
                                        <li>Úrovně členství (Membership Levels)</li>
                                        <li>Přihlašovací formulář (Login Form)</li>
                                        <li>Registrační formulář (Registration Form)</li>
                                        <li>Můj účet (Account Page)</li>
                                        <li>Obsah pro členy (Member Content)</li>
                                        <li>Cenová tabulka (Pricing Table)</li>
                                    </ul>
                                    <p style="margin: 10px 0 0 0;">
                                        <em>Widgety najdete v Elementor editoru v kategorii "Premium Membership Pro"</em>
                                    </p>
                                </div>
                            <?php endif; ?>
                            
                            <?php if (!$elementor_installed): ?>
                                <p class="description">
                                    <?php _e('Pro použití Elementor integrace musíte nejprve nainstalovat Elementor plugin.', 'premium-membership-pro'); ?>
                                </p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    
                    <tr>
                        <th><?php _e('User Role Editor', 'premium-membership-pro'); ?></th>
                        <td>
                            <?php 
                            $ure_installed = class_exists('User_Role_Editor');
                            $members_installed = class_exists('Members_Plugin');
                            $capsman_installed = class_exists('CapabilityManager');
                            ?>
                            
                            <?php if ($ure_installed): ?>
                                <div style="margin-bottom: 15px; padding: 10px; background: #e7f7e7; border-left: 4px solid #00a32a;">
                                    <strong>✅ User Role Editor je nainstalován</strong>
                                </div>
                            <?php elseif ($members_installed): ?>
                                <div style="margin-bottom: 15px; padding: 10px; background: #e7f7e7; border-left: 4px solid #00a32a;">
                                    <strong>✅ Members Plugin je nainstalován</strong>
                                </div>
                            <?php elseif ($capsman_installed): ?>
                                <div style="margin-bottom: 15px; padding: 10px; background: #e7f7e7; border-left: 4px solid #00a32a;">
                                    <strong>✅ Capability Manager Enhanced je nainstalován</strong>
                                </div>
                            <?php else: ?>
                                <div style="margin-bottom: 15px; padding: 10px; background: #fff8e5; border-left: 4px solid #dba617;">
                                    <strong>ℹ️ Žádný plugin pro správu rolí není nainstalován</strong>
                                </div>
                            <?php endif; ?>
                            
                            <p class="description">
                                <?php _e('Premium Membership Pro automaticky integruje svoje oprávnění s těmito pluginy.', 'premium-membership-pro'); ?>
                                <br>
                                <a href="<?php echo admin_url('admin.php?page=pmp-roles'); ?>"><?php _e('Spravovat role a oprávnění →', 'premium-membership-pro'); ?></a>
                            </p>
                        </td>
                    </tr>
                </table>
                
                <h2><?php _e('🗑️ Odstranění dat', 'premium-membership-pro'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th><?php _e('Zachovat data při odinstalaci', 'premium-membership-pro'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="pmp_keep_data_on_uninstall" value="1" 
                                    <?php checked(get_option('pmp_keep_data_on_uninstall'), '1'); ?>>
                                <?php _e('Zachovat všechna data při smazání pluginu', 'premium-membership-pro'); ?>
                            </label>
                            <p class="description">
                                <?php _e('Pokud je tato možnost zaškrtnuta, data zůstanou v databázi i po smazání pluginu. Doporučeno pro dočasné vypnutí nebo reinstalaci.', 'premium-membership-pro'); ?>
                            </p>
                            
                            <div style="margin-top: 20px; padding: 15px; background: #fff8e5; border-left: 4px solid #dba617; border-radius: 4px;">
                                <h4 style="margin-top: 0;">⚠️ <?php _e('Upozornění', 'premium-membership-pro'); ?></h4>
                                <p style="margin: 0;">
                                    <strong><?php _e('Pokud není zaškrtnuto:', 'premium-membership-pro'); ?></strong>
                                    <br><?php _e('Při smazání pluginu budou odstraněna VŠECHNA data:', 'premium-membership-pro'); ?>
                                </p>
                                <ul style="margin: 10px 0 0 20px;">
                                    <li><?php _e('Všechny úrovně členství', 'premium-membership-pro'); ?></li>
                                    <li><?php _e('Všichni členové a jejich členství', 'premium-membership-pro'); ?></li>
                                    <li><?php _e('Všechny transakce a platby', 'premium-membership-pro'); ?></li>
                                    <li><?php _e('Všechny produkty a kupóny', 'premium-membership-pro'); ?></li>
                                    <li><?php _e('Všechny logy přístupů', 'premium-membership-pro'); ?></li>
                                    <li><?php _e('Všechna nastavení pluginu', 'premium-membership-pro'); ?></li>
                                    <li><?php _e('Vlastní role a oprávnění', 'premium-membership-pro'); ?></li>
                                </ul>
                                <p style="margin: 15px 0 0 0; font-weight: 600;">
                                    <?php _e('Tato akce je NEVRATNÁ! Vždy si nejprve zálohujte databázi.', 'premium-membership-pro'); ?>
                                </p>
                            </div>
                            
                            <?php if (get_option('pmp_keep_data_on_uninstall') == '1'): ?>
                                <div style="margin-top: 15px; padding: 10px; background: #e7f7e7; border-left: 4px solid #00a32a; border-radius: 4px;">
                                    <strong>✅ <?php _e('Data budou zachována', 'premium-membership-pro'); ?></strong>
                                    <p style="margin: 5px 0 0 0;">
                                        <?php _e('Při smazání pluginu zůstanou všechna data v databázi a můžete plugin kdykoli znovu nainstalovat bez ztráty dat.', 'premium-membership-pro'); ?>
                                    </p>
                                </div>
                            <?php else: ?>
                                <div style="margin-top: 15px; padding: 10px; background: #f8d7da; border-left: 4px solid #dc3545; border-radius: 4px;">
                                    <strong>❌ <?php _e('Data budou smazána', 'premium-membership-pro'); ?></strong>
                                    <p style="margin: 5px 0 0 0;">
                                        <?php _e('Při smazání pluginu budou odstraněna VŠECHNA data. Tuto akci nelze vrátit zpět!', 'premium-membership-pro'); ?>
                                    </p>
                                </div>
                            <?php endif; ?>
                        </td>
                    </tr>
                    
                    <tr>
                        <th><?php _e('Vyčistit data nyní', 'premium-membership-pro'); ?></th>
                        <td>
                            <p class="description" style="margin-bottom: 10px;">
                                <?php _e('Můžete ručně vyčistit určitá data bez nutnosti odinstalace pluginu.', 'premium-membership-pro'); ?>
                            </p>
                            
                            <div style="margin: 15px 0;">
                                <button type="button" class="button" onclick="pmpConfirmClearLogs()">
                                    🗑️ <?php _e('Vyčistit logy přístupů', 'premium-membership-pro'); ?>
                                </button>
                                <p class="description">
                                    <?php _e('Smaže všechny záznamy o přístupech k chráněnému obsahu.', 'premium-membership-pro'); ?>
                                </p>
                            </div>
                            
                            <div style="margin: 15px 0;">
                                <button type="button" class="button" onclick="pmpConfirmClearTransients()">
                                    🧹 <?php _e('Vyčistit dočasná data (cache)', 'premium-membership-pro'); ?>
                                </button>
                                <p class="description">
                                    <?php _e('Smaže všechna dočasná data a cache vytvořené pluginem.', 'premium-membership-pro'); ?>
                                </p>
                            </div>
                            
                            <div style="margin: 15px 0; padding: 15px; background: #f8d7da; border-left: 4px solid #dc3545; border-radius: 4px;">
                                <h4 style="margin-top: 0; color: #721c24;">⚠️ <?php _e('Nebezpečná zóna', 'premium-membership-pro'); ?></h4>
                                <button type="button" class="button button-link-delete" onclick="pmpConfirmDeleteAllData()" style="color: #dc3545;">
                                    💀 <?php _e('SMAZAT VŠECHNA DATA', 'premium-membership-pro'); ?>
                                </button>
                                <p class="description" style="color: #721c24; font-weight: 600; margin: 10px 0 0 0;">
                                    <?php _e('Toto smaže VŠECHNA data pluginu včetně členů, transakcí a nastavení. Tato akce je NEVRATNÁ!', 'premium-membership-pro'); ?>
                                </p>
                            </div>
                        </td>
                    </tr>
                </table>
                
                <script>
                function pmpConfirmClearLogs() {
                    if (confirm('<?php _e('Opravdu chcete smazat všechny logy přístupů? Tuto akci nelze vrátit zpět.', 'premium-membership-pro'); ?>')) {
                        window.location.href = '<?php echo admin_url('admin.php?page=pmp-settings&action=clear-logs&_wpnonce=' . wp_create_nonce('pmp-clear-logs')); ?>';
                    }
                }
                
                function pmpConfirmClearTransients() {
                    if (confirm('<?php _e('Opravdu chcete vyčistit všechna dočasná data (cache)?', 'premium-membership-pro'); ?>')) {
                        window.location.href = '<?php echo admin_url('admin.php?page=pmp-settings&action=clear-transients&_wpnonce=' . wp_create_nonce('pmp-clear-transients')); ?>';
                    }
                }
                
                function pmpConfirmDeleteAllData() {
                    var confirmation = prompt('<?php _e('VAROVÁNÍ: Toto smaže VŠECHNA data!\n\nZadejte "DELETE ALL DATA" pro potvrzení:', 'premium-membership-pro'); ?>');
                    if (confirmation === 'DELETE ALL DATA') {
                        if (confirm('<?php _e('Poslední potvrzení: Opravdu chcete SMAZAT VŠECHNA DATA? Tato akce je NEVRATNÁ!', 'premium-membership-pro'); ?>')) {
                            window.location.href = '<?php echo admin_url('admin.php?page=pmp-settings&action=delete-all-data&_wpnonce=' . wp_create_nonce('pmp-delete-all-data')); ?>';
                        }
                    } else if (confirmation !== null) {
                        alert('<?php _e('Nesprávné potvrzení. Data nebyla smazána.', 'premium-membership-pro'); ?>');
                    }
                }
                </script>
                
                <?php submit_button(__('Uložit nastavení', 'premium-membership-pro'), 'primary', 'pmp_settings_submit'); ?>
            </form>
            
            <!-- Database Tables Section -->
            <hr style="margin: 40px 0;">
            
            <h2>🗄️ <?php _e('Databázové tabulky', 'premium-membership-pro'); ?></h2>
            
            <?php
            // Show result notice if tables were just created
            if (isset($_GET['pmp_tables_created']) && $result = get_transient('pmp_create_tables_result')) {
                delete_transient('pmp_create_tables_result');
                
                if (!empty($result['created'])) {
                    echo '<div class="notice notice-success is-dismissible">';
                    echo '<p><strong>✅ ' . __('Tabulky byly úspěšně vytvořeny!', 'premium-membership-pro') . '</strong></p>';
                    echo '<ul style="margin: 10px 0 0 20px;">';
                    foreach ($result['created'] as $table) {
                        echo '<li>' . esc_html($table) . '</li>';
                    }
                    echo '</ul>';
                    echo '</div>';
                }
                
                if (!empty($result['failed'])) {
                    echo '<div class="notice notice-error is-dismissible">';
                    echo '<p><strong>❌ ' . __('Nepodařilo se vytvořit některé tabulky:', 'premium-membership-pro') . '</strong></p>';
                    echo '<ul style="margin: 10px 0 0 20px;">';
                    foreach ($result['failed'] as $table) {
                        echo '<li>' . esc_html($table) . '</li>';
                    }
                    echo '</ul>';
                    echo '<p>' . __('Zkontrolujte databázová oprávnění a zkuste to znovu.', 'premium-membership-pro') . '</p>';
                    echo '</div>';
                }
            }
            ?>
            
            <div style="background: white; border: 1px solid #ccc; border-radius: 4px; padding: 20px; max-width: 800px;">
                <h3 style="margin-top: 0;"><?php _e('Kontrola a vytvoření tabulek', 'premium-membership-pro'); ?></h3>
                
                <?php
                global $wpdb;
                $tables = array(
                    $wpdb->prefix . 'pmp_memberships' => __('Členství', 'premium-membership-pro'),
                    $wpdb->prefix . 'pmp_transactions' => __('Transakce', 'premium-membership-pro'),
                    $wpdb->prefix . 'pmp_access_logs' => __('Logy přístupů', 'premium-membership-pro'),
                    $wpdb->prefix . 'pmp_email_logs' => __('Logy emailů', 'premium-membership-pro')
                );
                
                $all_exist = true;
                ?>
                
                <table class="widefat" style="margin: 20px 0;">
                    <thead>
                        <tr>
                            <th style="padding: 10px;"><?php _e('Tabulka', 'premium-membership-pro'); ?></th>
                            <th style="padding: 10px;"><?php _e('Popis', 'premium-membership-pro'); ?></th>
                            <th style="padding: 10px;"><?php _e('Status', 'premium-membership-pro'); ?></th>
                            <th style="padding: 10px; text-align: center;"><?php _e('Počet záznamů', 'premium-membership-pro'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($tables as $table => $description): 
                            $exists = $wpdb->get_var("SHOW TABLES LIKE '$table'") == $table;
                            $count = $exists ? $wpdb->get_var("SELECT COUNT(*) FROM $table") : 0;
                            if (!$exists) $all_exist = false;
                        ?>
                        <tr>
                            <td style="padding: 10px;"><code><?php echo esc_html($table); ?></code></td>
                            <td style="padding: 10px;"><?php echo esc_html($description); ?></td>
                            <td style="padding: 10px;">
                                <?php if ($exists): ?>
                                    <span style="color: #00a32a; font-weight: 600;">✅ <?php _e('Existuje', 'premium-membership-pro'); ?></span>
                                <?php else: ?>
                                    <span style="color: #dc3545; font-weight: 600;">❌ <?php _e('Neexistuje', 'premium-membership-pro'); ?></span>
                                <?php endif; ?>
                            </td>
                            <td style="padding: 10px; text-align: center;">
                                <?php echo $exists ? number_format($count, 0, ',', ' ') : '—'; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <?php if ($all_exist): ?>
                    <div style="padding: 15px; background: #e7f7e7; border-left: 4px solid #00a32a; border-radius: 4px; margin: 20px 0;">
                        <strong>✅ <?php _e('Všechny tabulky jsou vytvořené a fungují správně!', 'premium-membership-pro'); ?></strong>
                        <p style="margin: 10px 0 0 0;">
                            <?php _e('Plugin je plně funkční. Pokud přesto máte problémy, můžete tabulky znovu vytvořit pomocí tlačítka níže.', 'premium-membership-pro'); ?>
                        </p>
                    </div>
                <?php else: ?>
                    <div style="padding: 15px; background: #f8d7da; border-left: 4px solid #dc3545; border-radius: 4px; margin: 20px 0;">
                        <strong>❌ <?php _e('Některé tabulky chybí!', 'premium-membership-pro'); ?></strong>
                        <p style="margin: 10px 0 0 0;">
                            <?php _e('Použijte tlačítko níže pro vytvoření chybějících tabulek.', 'premium-membership-pro'); ?>
                        </p>
                    </div>
                <?php endif; ?>
                
                <form method="post" action="" onsubmit="return confirm('<?php _e('Opravdu chcete (znovu) vytvořit databázové tabulky? Existující data nebudou ztracena.', 'premium-membership-pro'); ?>');">
                    <?php wp_nonce_field('pmp_create_tables_action', 'pmp_create_tables_nonce'); ?>
                    <button type="submit" name="pmp_create_tables" class="button button-primary button-large">
                        🔧 <?php _e('Vytvořit / Opravit Tabulky', 'premium-membership-pro'); ?>
                    </button>
                    <p class="description" style="margin-top: 10px;">
                        <?php _e('Tento nástroj zkontroluje a vytvoří všechny potřebné databázové tabulky. Existující data nebudou smazána.', 'premium-membership-pro'); ?>
                    </p>
                </form>
                
                <div style="margin-top: 20px; padding: 15px; background: #fff8e5; border-left: 4px solid #dba617; border-radius: 4px;">
                    <strong>ℹ️ <?php _e('Co toto tlačítko dělá?', 'premium-membership-pro'); ?></strong>
                    <ul style="margin: 10px 0 0 20px;">
                        <li><?php _e('Zkontroluje existenci všech 4 databázových tabulek', 'premium-membership-pro'); ?></li>
                        <li><?php _e('Vytvoří chybějící tabulky', 'premium-membership-pro'); ?></li>
                        <li><?php _e('Opraví strukturu existujících tabulek (pokud je potřeba)', 'premium-membership-pro'); ?></li>
                        <li><?php _e('Zachová všechna existující data', 'premium-membership-pro'); ?></li>
                    </ul>
                    <p style="margin: 10px 0 0 0;">
                        <strong><?php _e('Bezpečné použití:', 'premium-membership-pro'); ?></strong>
                        <?php _e('Tato akce NEODSTRANÍ žádná data. Pouze vytvoří chybějící tabulky nebo opraví jejich strukturu.', 'premium-membership-pro'); ?>
                    </p>
                </div>
                
                <div style="margin-top: 15px;">
                    <strong><?php _e('Databázová verze:', 'premium-membership-pro'); ?></strong>
                    <code><?php echo esc_html(get_option('pmp_db_version', 'N/A')); ?></code>
                    &nbsp;|&nbsp;
                    <strong><?php _e('Verze pluginu:', 'premium-membership-pro'); ?></strong>
                    <code><?php echo PMP_VERSION; ?></code>
                </div>
            </div>
            
            <!-- Update Section -->
            <hr style="margin: 40px 0;">
            
            <h2>🔄 <?php _e('Aktualizace pluginu', 'premium-membership-pro'); ?></h2>
            
            <?php
            // Handle manual update check
            if (isset($_GET['action']) && $_GET['action'] === 'check-updates' && isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'pmp-check-updates')) {
                global $pmp_update_checker;
                if ($pmp_update_checker) {
                    $update_info = $pmp_update_checker->force_check();
                    if ($update_info && version_compare(PMP_VERSION, $update_info->tag_name, '<')) {
                        echo '<div class="notice notice-info"><p><strong>🎉 ' . sprintf(__('Dostupná nová verze: %s', 'premium-membership-pro'), $update_info->tag_name) . '</strong><br>';
                        echo __('Přejděte na Pluginy → Aktualizace pro instalaci.', 'premium-membership-pro') . '</p></div>';
                    } else {
                        echo '<div class="notice notice-success"><p>✅ ' . __('Používáte nejnovější verzi pluginu.', 'premium-membership-pro') . '</p></div>';
                    }
                }
            }
            ?>
            
            <table class="form-table">
                <tr>
                    <th><?php _e('Aktuální verze', 'premium-membership-pro'); ?></th>
                    <td>
                        <strong><?php echo PMP_VERSION; ?></strong>
                        <p class="description"><?php _e('Nainstalovaná verze pluginu', 'premium-membership-pro'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><?php _e('Automatické aktualizace', 'premium-membership-pro'); ?></th>
                    <td>
                        <p>
                            <?php _e('Plugin kontroluje dostupnost aktualizací jednou denně.', 'premium-membership-pro'); ?>
                            <br>
                            <?php _e('Aktualizace se zobrazí v sekci Pluginy → Aktualizace.', 'premium-membership-pro'); ?>
                        </p>
                        <p>
                            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=pmp-settings&action=check-updates'), 'pmp-check-updates'); ?>" class="button button-secondary">
                                🔍 <?php _e('Zkontrolovat aktualizace nyní', 'premium-membership-pro'); ?>
                            </a>
                            <a href="<?php echo admin_url('plugins.php'); ?>" class="button button-secondary">
                                📦 <?php _e('Přehled pluginů', 'premium-membership-pro'); ?>
                            </a>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th><?php _e('Zdroj aktualizací', 'premium-membership-pro'); ?></th>
                    <td>
                        <p>
                            <strong>GitHub:</strong> 
                            <a href="https://github.com/conexo-sro/premium-membership-pro/releases" target="_blank">
                                github.com/conexo-sro/premium-membership-pro
                            </a>
                        </p>
                        <p class="description">
                            <?php _e('Aktualizace jsou dostupné na GitHub. Plugin automaticky kontroluje nové verze.', 'premium-membership-pro'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th><?php _e('Changelog', 'premium-membership-pro'); ?></th>
                    <td>
                        <a href="<?php echo admin_url('admin.php?page=pmp-documentation'); ?>" class="button button-secondary">
                            📋 <?php _e('Zobrazit historii změn', 'premium-membership-pro'); ?>
                        </a>
                    </td>
                </tr>
            </table>
            
        </div>
        <?php
    }
    
    public static function roles_page() {
        // Handle manual capability repair
        if (isset($_POST['pmp_repair_capabilities'])) {
            check_admin_referer('pmp_repair_caps');
            PMP_Roles::add_capabilities();
            echo '<div class="notice notice-success is-dismissible"><p><strong>✅ Oprávnění byla obnovena!</strong> Všechna oprávnění byla znovu přidána všem rolím.</p></div>';
        }
        
        // Handle role capability updates
        if (isset($_POST['pmp_update_role_caps'])) {
            check_admin_referer('pmp_role_caps');
            self::update_role_capabilities();
            echo '<div class="notice notice-success"><p>Oprávnění role byla aktualizována.</p></div>';
        }
        
        $all_caps = PMP_Roles::get_capabilities();
        $roles = array('administrator', 'editor', 'membership_manager', 'author', 'contributor');
        
        ?>
        <div class="wrap">
            <h1>👤 Správa rolí a oprávnění</h1>
            
            <!-- Quick repair box -->
            <div style="background: #fff; border: 1px solid #c3c4c7; padding: 15px; margin: 20px 0; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
                <h3 style="margin-top: 0;">🔧 Oprava oprávnění</h3>
                <p>Pokud nevidíte menu pluginu nebo máte problémy s přístupem, použijte toto tlačítko k obnovení oprávnění:</p>
                <form method="post" style="display: inline;">
                    <?php wp_nonce_field('pmp_repair_caps'); ?>
                    <button type="submit" name="pmp_repair_capabilities" class="button button-primary">
                        ⚡ Obnovit všechna oprávnění
                    </button>
                </form>
                <p class="description">Toto znovu přidá všechna oprávnění Administrátorům, Editorům a Membership Managerům.</p>
            </div>
            
            <?php 
            // Check for external role management plugins
            $external_plugins = PMP_Roles::get_active_role_plugins();
            if (!empty($external_plugins)): ?>
                <div class="notice notice-info">
                    <h3 style="margin-top: 10px;">🔌 Detekované pluginy pro správu rolí</h3>
                    <p>Premium Membership Pro je kompatibilní s následujícími pluginy:</p>
                    <ul style="margin-left: 20px;">
                        <?php foreach ($external_plugins as $plugin): ?>
                            <li>
                                <strong><?php echo esc_html($plugin['name']); ?></strong>
                                <?php if ($plugin['integrated']): ?>
                                    <span style="color: #00a32a;">✓ Aktivní a integrovaný</span>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <p><em>💡 Tip: Můžete upravovat oprávnění PMP buď zde, nebo v <?php echo esc_html($external_plugins[0]['name']); ?>.</em></p>
                </div>
            <?php else: ?>
                <div class="notice notice-info">
                    <h3 style="margin-top: 10px;">💡 Doporučené pluginy</h3>
                    <p>Pro pokročilou správu rolí doporučujeme nainstalovat jeden z těchto pluginů:</p>
                    <ul style="margin-left: 20px;">
                        <li><strong>User Role Editor</strong> - Nejoblíbenější plugin pro správu rolí</li>
                        <li><strong>Members</strong> - Komplexní správa členství a rolí</li>
                        <li><strong>Capability Manager Enhanced</strong> - Pokročilá správa oprávnění</li>
                    </ul>
                    <p><em>Premium Membership Pro je s těmito pluginy plně kompatibilní!</em></p>
                </div>
            <?php endif; ?>
            
            <div class="pmp-roles-info">
                <h2>📋 Přehled rolí</h2>
                <table class="widefat">
                    <thead>
                        <tr>
                            <th>Role</th>
                            <th>Počet uživatelů</th>
                            <th>Oprávnění PMP</th>
                            <th>Popis</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($roles as $role_name):
                            $role = get_role($role_name);
                            if (!$role) continue;
                            
                            $user_count = count(get_users(array('role' => $role_name)));
                            $pmp_caps_count = 0;
                            foreach ($all_caps as $cap => $label) {
                                if ($role->has_cap($cap)) {
                                    $pmp_caps_count++;
                                }
                            }
                            
                            $descriptions = array(
                                'administrator' => 'Plná kontrola nad pluginem a celým webem',
                                'editor' => 'Může zobrazovat statistiky a spravovat obsah',
                                'membership_manager' => 'Specializovaná role pro správu členství',
                                'author' => 'Může vytvářet a upravovat vlastní příspěvky',
                                'contributor' => 'Může vytvářet návrhy příspěvků',
                            );
                            ?>
                            <tr>
                                <td><strong><?php echo esc_html(translate_user_role($role->name)); ?></strong></td>
                                <td><?php echo $user_count; ?></td>
                                <td><?php echo $pmp_caps_count; ?> / <?php echo count($all_caps); ?></td>
                                <td><?php echo isset($descriptions[$role_name]) ? $descriptions[$role_name] : ''; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="pmp-role-editor">
                <h2>✏️ Upravit oprávnění rolí</h2>
                <p>Zaškrtněte oprávnění, která má role mít. <strong>Administrátoři mají vždy všechna oprávnění.</strong></p>
                
                <form method="post">
                    <?php wp_nonce_field('pmp_role_caps'); ?>
                    
                    <div class="pmp-roles-grid">
                        <?php foreach ($roles as $role_name):
                            $role = get_role($role_name);
                            if (!$role) continue;
                            
                            // Skip administrator - always has all caps
                            if ($role_name === 'administrator') continue;
                            ?>
                            
                            <div class="pmp-role-box">
                                <h3><?php echo esc_html(translate_user_role($role->name)); ?></h3>
                                
                                <table class="form-table">
                                    <?php foreach ($all_caps as $cap => $label): ?>
                                        <tr>
                                            <td>
                                                <label>
                                                    <input type="checkbox" 
                                                           name="roles[<?php echo esc_attr($role_name); ?>][<?php echo esc_attr($cap); ?>]" 
                                                           value="1"
                                                           <?php checked($role->has_cap($cap)); ?>>
                                                    <?php echo esc_html($label); ?>
                                                </label>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </table>
                            </div>
                            
                        <?php endforeach; ?>
                    </div>
                    
                    <?php submit_button('Uložit oprávnění', 'primary', 'pmp_update_role_caps'); ?>
                </form>
            </div>
            
            <div class="pmp-cap-legend">
                <h2>📖 Význam oprávnění</h2>
                <table class="widefat">
                    <thead>
                        <tr>
                            <th>Oprávnění</th>
                            <th>Co umožňuje</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($all_caps as $cap => $label): ?>
                            <tr>
                                <td><code><?php echo esc_html($cap); ?></code></td>
                                <td><?php echo esc_html($label); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="pmp-roles-warning">
                <h3>⚠️ Důležité upozornění</h3>
                <ul>
                    <li><strong>Administrátoři</strong> mají vždy všechna oprávnění a nelze jim je odebrat</li>
                    <li><strong>Membership Manager</strong> je specializovaná role vytvořená tímto pluginem</li>
                    <li>Odebrání oprávnění může zabránit uživatelům v přístupu k částem pluginu</li>
                    <li>Změny se projeví okamžitě po uložení</li>
                </ul>
            </div>
            
            <style>
            .pmp-roles-info,
            .pmp-role-editor,
            .pmp-cap-legend,
            .pmp-roles-warning {
                background: #fff;
                padding: 20px;
                margin: 20px 0;
                border: 1px solid #ccd0d4;
                box-shadow: 0 1px 1px rgba(0,0,0,.04);
            }
            .pmp-roles-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
                gap: 20px;
                margin: 20px 0;
            }
            .pmp-role-box {
                background: #f8f9fa;
                padding: 15px;
                border: 1px solid #ddd;
                border-radius: 4px;
            }
            .pmp-role-box h3 {
                margin-top: 0;
                padding-bottom: 10px;
                border-bottom: 2px solid #2271b1;
            }
            .pmp-role-box .form-table td {
                padding: 8px 0;
            }
            .pmp-role-box label {
                display: flex;
                align-items: center;
                gap: 8px;
            }
            .pmp-roles-warning {
                background: #fff3cd;
                border-left: 4px solid #ffc107;
            }
            .pmp-roles-warning ul {
                margin-left: 20px;
            }
            .pmp-roles-warning li {
                margin: 8px 0;
            }
            </style>
        </div>
        <?php
    }
    
    private static function update_role_capabilities() {
        if (!isset($_POST['roles']) || !is_array($_POST['roles'])) {
            return;
        }
        
        $all_caps = PMP_Roles::get_capabilities();
        
        foreach ($_POST['roles'] as $role_name => $caps) {
            $role = get_role($role_name);
            if (!$role || $role_name === 'administrator') {
                continue;
            }
            
            // Remove all PMP capabilities first
            foreach ($all_caps as $cap => $label) {
                $role->remove_cap($cap);
            }
            
            // Add back only selected capabilities
            foreach ($caps as $cap => $value) {
                if (isset($all_caps[$cap]) && $value == '1') {
                    $role->add_cap($cap);
                }
            }
        }
    }
    
    public static function register_settings() {
        // Settings are saved in save_settings() method
    }
    
    private static function save_settings() {
        $settings = array(
            'pmp_currency',
            'pmp_currency_position',
            'pmp_enable_stripe',
            'pmp_stripe_public_key',
            'pmp_stripe_secret_key',
            'pmp_enable_paypal',
            'pmp_paypal_client_id',
            'pmp_paypal_secret',
            'pmp_enable_bank_transfer',
            'pmp_bank_account_number',
            'pmp_bank_iban',
            'pmp_enable_elementor',
            'pmp_keep_data_on_uninstall',
        );
        
        foreach ($settings as $setting) {
            if (isset($_POST[$setting])) {
                update_option($setting, sanitize_text_field($_POST[$setting]));
            } else {
                delete_option($setting);
            }
        }
    }
    
    /**
     * Clear access logs
     */
    private static function clear_access_logs() {
        global $wpdb;
        $table = $wpdb->prefix . 'pmp_access_logs';
        $wpdb->query("TRUNCATE TABLE {$table}");
    }
    
    /**
     * Clear all transients
     */
    private static function clear_transients() {
        global $wpdb;
        
        // Delete all PMP transients
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_pmp_%'");
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_pmp_%'");
        
        // Clear object cache
        wp_cache_flush();
    }
    
    /**
     * Handle create tables action
     */
    public static function handle_create_tables() {
        // Check if action is triggered
        if (!isset($_POST['pmp_create_tables']) || !isset($_POST['pmp_create_tables_nonce'])) {
            return;
        }
        
        // Verify nonce
        if (!wp_verify_nonce($_POST['pmp_create_tables_nonce'], 'pmp_create_tables_action')) {
            wp_die('Neplatný bezpečnostní token!');
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_die('Nemáte oprávnění provádět tuto akci!');
        }
        
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        $tables_created = array();
        $tables_failed = array();
        
        // 1. MEMBERSHIPS TABLE
        $table_memberships = $wpdb->prefix . 'pmp_memberships';
        $sql_memberships = "CREATE TABLE $table_memberships (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            level_id bigint(20) unsigned NOT NULL,
            status varchar(50) NOT NULL DEFAULT 'active',
            start_date datetime NOT NULL,
            end_date datetime DEFAULT NULL,
            trial_end_date datetime DEFAULT NULL,
            payment_gateway varchar(50) DEFAULT NULL,
            subscription_id varchar(255) DEFAULT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY level_id (level_id),
            KEY status (status)
        ) $charset_collate;";
        
        dbDelta($sql_memberships);
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_memberships'") == $table_memberships) {
            $tables_created[] = $table_memberships;
        } else {
            $tables_failed[] = $table_memberships;
        }
        
        // 2. TRANSACTIONS TABLE
        $table_transactions = $wpdb->prefix . 'pmp_transactions';
        $sql_transactions = "CREATE TABLE $table_transactions (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            membership_id bigint(20) unsigned DEFAULT NULL,
            amount decimal(10,2) NOT NULL,
            currency varchar(10) NOT NULL DEFAULT 'CZK',
            status varchar(50) NOT NULL DEFAULT 'pending',
            payment_gateway varchar(50) NOT NULL,
            transaction_id varchar(255) DEFAULT NULL,
            invoice_number varchar(100) DEFAULT NULL,
            description text,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY membership_id (membership_id),
            KEY status (status)
        ) $charset_collate;";
        
        dbDelta($sql_transactions);
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_transactions'") == $table_transactions) {
            $tables_created[] = $table_transactions;
        } else {
            $tables_failed[] = $table_transactions;
        }
        
        // 3. ACCESS LOGS TABLE
        $table_logs = $wpdb->prefix . 'pmp_access_logs';
        $sql_logs = "CREATE TABLE $table_logs (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            post_id bigint(20) unsigned NOT NULL,
            membership_level_id bigint(20) unsigned NOT NULL,
            access_type varchar(50) NOT NULL,
            ip_address varchar(45) DEFAULT NULL,
            user_agent text,
            accessed_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY post_id (post_id),
            KEY accessed_at (accessed_at)
        ) $charset_collate;";
        
        dbDelta($sql_logs);
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_logs'") == $table_logs) {
            $tables_created[] = $table_logs;
        } else {
            $tables_failed[] = $table_logs;
        }
        
        // 4. EMAIL LOGS TABLE
        $table_emails = $wpdb->prefix . 'pmp_email_logs';
        $sql_emails = "CREATE TABLE $table_emails (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            email_type varchar(100) NOT NULL,
            subject varchar(255) NOT NULL,
            status varchar(50) NOT NULL DEFAULT 'sent',
            sent_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY email_type (email_type)
        ) $charset_collate;";
        
        dbDelta($sql_emails);
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_emails'") == $table_emails) {
            $tables_created[] = $table_emails;
        } else {
            $tables_failed[] = $table_emails;
        }
        
        // Update database version
        update_option('pmp_db_version', PMP_VERSION);
        
        // Set transient with results
        $result = array(
            'created' => $tables_created,
            'failed' => $tables_failed,
            'total' => count($tables_created) + count($tables_failed)
        );
        
        set_transient('pmp_create_tables_result', $result, 60);
        
        // Redirect back
        wp_redirect(add_query_arg('pmp_tables_created', '1', wp_get_referer()));
        exit;
    }
    
    /**
     * Delete ALL plugin data (DANGEROUS!)
     */
    private static function delete_all_data() {
        global $wpdb;
        
        // 1. Delete all tables
        $tables = array(
            $wpdb->prefix . 'pmp_memberships',
            $wpdb->prefix . 'pmp_transactions',
            $wpdb->prefix . 'pmp_access_logs',
        );
        
        foreach ($tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS {$table}");
        }
        
        // 2. Delete all options
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'pmp_%'");
        
        // 3. Delete all post types
        $post_types = array('pmp_membership', 'pmp_product', 'pmp_coupon');
        
        foreach ($post_types as $post_type) {
            $posts = get_posts(array(
                'post_type' => $post_type,
                'numberposts' => -1,
                'post_status' => 'any',
            ));
            
            foreach ($posts as $post) {
                wp_delete_post($post->ID, true);
            }
        }
        
        // 4. Delete all user meta
        $wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE 'pmp_%'");
        
        // 5. Remove capabilities
        PMP_Roles::remove_capabilities();
        
        // 6. Remove custom role
        remove_role('membership_manager');
        
        // 7. Clear cache
        wp_cache_flush();
        
        // 8. Recreate tables for continued use
        $plugin = Premium_Membership_Pro::get_instance();
        if (method_exists($plugin, 'create_tables')) {
            // Tables will be recreated on next page load
        }
    }
}
