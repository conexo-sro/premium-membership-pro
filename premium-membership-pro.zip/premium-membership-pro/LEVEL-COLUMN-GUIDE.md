# 📊 Návod: Sloupec "Úroveň" v seznamu příspěvků

## ✅ Sloupec je již implementován!

Plugin **Premium Membership Pro v1.5.6** již obsahuje plně funkční sloupec "Úroveň" v seznamu příspěvků a stránek.

---

## 🔍 Kde najít sloupec "Úroveň"

### V seznamu příspěvků/stránek:

```
WordPress Admin
    ↓
Příspěvky → Všechny příspěvky
nebo
Stránky → Všechny stránky
    ↓
Sloupce:
┌────────┬────────────────┬──────────┬──────────┬─────────┐
│ ☑      │ Název          │ 🛡️ Úroveň│ Autor    │ Datum   │
├────────┼────────────────┼──────────┼──────────┼─────────┤
│ ☑      │ Vítejte        │ 🔓 Veřejný│ admin    │ 1.1.2025│
├────────┼────────────────┼──────────┼──────────┼─────────┤
│ ☑      │ Premium obsah  │ [Premium]│ admin    │ 2.1.2025│
├────────┼────────────────┼──────────┼──────────┼─────────┤
│ ☑      │ VIP článek     │ [VIP]    │ admin    │ 3.1.2025│
├────────┼────────────────┼──────────┼──────────┼─────────┤
│ ☑      │ Pouze členové  │ 👥 Jaké- │ admin    │ 4.1.2025│
│        │                │   koli   │          │         │
└────────┴────────────────┴──────────┴──────────┴─────────┘
                              ↑
                        TENTO SLOUPEC!
```

---

## 👁️ Pokud sloupec nevidíte

### Krok 1: Zkontrolujte "Možnosti obrazovky"

**V pravém horním rohu seznamu příspěvků:**

```
┌────────────────────────────────┐
│ [Možnosti obrazovky ▼]         │
└────────────────────────────────┘
```

**Rozbalí se panel se sloupci:**

```
┌────────────────────────────────┐
│ Možnosti obrazovky             │
├────────────────────────────────┤
│ Sloupce:                       │
│ ☑ Autor                        │
│ ☑ Kategorie                    │
│ ☑ Štítky                       │
│ ☑ Komentáře                    │
│ ☑ Datum                        │
│ ☑ Úroveň           ← ZKONTROLUJ│
└────────────────────────────────┘
```

**Zaškrtněte "Úroveň"!**

---

## 🎨 Typy zobrazení ve sloupci

### 1. Veřejný obsah (🔓 Veřejný)

```
┌──────────────┐
│ 🔓 Veřejný   │  ← Zelený badge
└──────────────┘
```

**Význam:** Příspěvek není chráněný, přístupný pro všechny

---

### 2. Jakékoli členství (👥 Jakékoli)

```
┌──────────────┐
│ 👥 Jakékoli  │  ← Modrý badge
└──────────────┘
```

**Význam:** Vyžaduje jakékoli aktivní členství, není vybrána konkrétní úroveň

---

### 3. Konkrétní úrovně

```
┌───────────────────────┐
│ [Basic] [Premium]     │  ← Fialové badges
└───────────────────────┘
```

**Význam:** Vyžaduje konkrétní úrovně členství

---

### 4. Více úrovní

```
┌─────────────────────────┐
│ [Level1] [Level2] +3    │  ← Badge s počtem
└─────────────────────────┘
```

**Význam:** Vyžaduje více než 2 úrovně, zobrazí se první 2 + počet zbylých

---

### 5. Chyba (⚠️ Chyba)

```
┌──────────────┐
│ ⚠️ Chyba     │  ← Červený badge
└──────────────┘
```

**Význam:** Ochrana zapnutá, ale úrovně neexistují (byly smazány)

---

## 🎯 Funkce sloupce

### 1. Sortování

**Klikněte na záhlaví "Úroveň":**

```
┌──────────────┐
│ 🛡️ Úroveň ▲  │  ← ASC: Veřejné → Chráněné
└──────────────┘

┌──────────────┐
│ 🛡️ Úroveň ▼  │  ← DESC: Chráněné → Veřejné
└──────────────┘
```

---

### 2. Filtrování

**Nad seznamem příspěvků:**

```
┌─────────────────────────────────┐
│ [Všechny úrovně ▼]              │
└─────────────────────────────────┘
```

**Možnosti:**
- Všechny úrovně
- Veřejné
- Chráněné
- Basic
- Premium
- VIP
- ... (všechny vaše úrovně)

---

### 3. Quick Edit

**Klikněte "Rychlá úprava":**

```
┌────────────────────────────────┐
│ Název: Můj příspěvek           │
├────────────────────────────────┤
│ ☑ Povolit ochranu              │
│                                │
│ Požadované úrovně:             │
│ ┌────────────────────────────┐ │
│ │ ☑ Basic                    │ │
│ │ ☑ Premium                  │ │
│ │ ☐ VIP                      │ │
│ └────────────────────────────┘ │
└────────────────────────────────┘
```

---

### 4. Bulk Edit

**Vyberte více příspěvků → Hromadné akce → Upravit:**

```
┌────────────────────────────────┐
│ Úrovně členství:               │
│ [Nastavit úrovně ▼]            │
│                                │
│ ☑ Basic                        │
│ ☑ Premium                      │
│ ☐ VIP                          │
└────────────────────────────────┘
```

**Možnosti:**
- Nastavit úrovně (nahradit)
- Přidat úrovně
- Odstranit ochranu

---

## 🎨 Barevné schéma

```css
Veřejný:
- Background: #f0fff4 (světle zelená)
- Text: #22543d (tmavě zelená)
- Icon: #38a169 (zelená)

Jakékoli:
- Background: #ebf8ff (světle modrá)
- Text: #2c5282 (tmavě modrá)
- Icon: #4299e1 (modrá)

Úrovně:
- Background: gradient(#667eea, #764ba2) (fialová)
- Text: white
- Border-radius: 12px

Více:
- Background: #e2e8f0 (šedá)
- Text: #4a5568 (tmavě šedá)

Chyba:
- Background: #fff5f5 (světle červená)
- Text: #742a2a (tmavě červená)
- Icon: #e53e3e (červená)
```

---

## 💡 Tips & Tricks

### Tip 1: Tooltip

Najeďte myší na badge pro zobrazení všech úrovní:

```
[Level1] [Level2] +3
         ↓
Tooltip: Level1, Level2, Level3, Level4, Level5
```

---

### Tip 2: Rychlé přiřazení

```
1. Klikněte "Rychlá úprava"
2. Zaškrtněte úrovně
3. Klikněte "Aktualizovat"
4. ✅ Hotovo za 5 sekund!
```

---

### Tip 3: Hromadná změna

```
1. Vyberte 10 příspěvků
2. Hromadné akce → Upravit
3. Nastavte úrovně
4. Aktualizovat
5. ✅ Všech 10 najednou!
```

---

### Tip 4: Filtrování

```
1. Vyberte filter "Premium"
2. Vidíte jen Premium příspěvky
3. Bulk edit → Přidat VIP
4. ✅ Všechny Premium mají i VIP!
```

---

## 📋 Checklist

**Zkontrolujte:**

1. ☐ Plugin verze 1.5.6+
2. ☐ "Možnosti obrazovky" → "Úroveň" zaškrtnuto
3. ☐ Sloupec viditelný v seznamu
4. ☐ Badges se zobrazují správně
5. ☐ Sortování funguje
6. ☐ Filtrování funguje
7. ☐ Quick Edit funguje
8. ☐ Bulk Edit funguje
9. ☐ Tooltips fungují
10. ☐ CSS načtený (F12 → Network)

---

## 🐛 Troubleshooting

### Problém: Sloupec není viditelný

**Řešení:**
```
1. Možnosti obrazovky → Zaškrtnout "Úroveň"
2. Hard refresh (Ctrl + F5)
3. Zkontrolovat CSS v Network tab
```

---

### Problém: Badges se nezobrazují správně

**Řešení:**
```
1. F12 → Console → Hledat chyby
2. F12 → Network → Zkontrolovat post-level-column.css
3. Zkontrolovat verzi pluginu
```

---

### Problém: Quick Edit nefunguje

**Řešení:**
```
1. F12 → Console → Hledat chyby
2. Zkontrolovat post-level-column.js načtený
3. Zkontrolovat AJAX endpoint
```

---

## 📸 Screenshots

### Jak vypadá sloupec:

```
Seznam příspěvků:
┌────────────────────────────────────────────────────┐
│ Název                    │ Úroveň      │ Datum     │
├──────────────────────────┼─────────────┼───────────┤
│ Veřejný článek           │ 🔓 Veřejný  │ 1.1.2025  │
├──────────────────────────┼─────────────┼───────────┤
│ Premium obsah            │ [Premium]   │ 2.1.2025  │
├──────────────────────────┼─────────────┼───────────┤
│ Členové                  │ 👥 Jakékoli │ 3.1.2025  │
├──────────────────────────┼─────────────┼───────────┤
│ Multi-level              │ [B][P] +2   │ 4.1.2025  │
└──────────────────────────┴─────────────┴───────────┘
```

---

## 🆘 Pomoc

**Pokud sloupec stále nevidíte:**

1. ✅ Deaktivujte a znovu aktivujte plugin
2. ✅ Smažte browser cache
3. ✅ Zkontrolujte wp-content/debug.log
4. ✅ Kontaktujte podporu

**Kontakt:**
- 📧 info@conexo.cz
- 💬 GitHub Issues

---

**Plugin obsahuje plně funkční sloupec "Úroveň"!**
**Stačí jen zaškrtnout v "Možnosti obrazovky"!** ✅
