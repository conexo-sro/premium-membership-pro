# Premium Membership Pro - WordPress Plugin

Kompletní systém pro správu členství, prémiový obsah, předplatné a prodej digitálních produktů pro WordPress.

## Funkce

### Základní funkce
- ✅ Neomezený počet úrovní členství
- ✅ Opakující se platby (denní, týdenní, měsíční, roční)
- ✅ Jednorázové platby a doživotní členství
- ✅ Zkušební období (trial)
- ✅ Ochrana obsahu (příspěvky, stránky, kategorie)
- ✅ Uživatelské účty a správa předplatného
- ✅ Automatické e-maily (uvítání, připomínky, ukončení)

### Platební brány
- 💳 Stripe (připraveno pro integraci)
- 💰 PayPal (připraveno pro integraci)
- 🏦 Bankovní převod
- ✨ Snadné rozšíření o další brány

### Pokročilé funkce
- 📊 Analytika a reporty
- 🎟️ Slevové kupóny
- 📦 Digitální produkty
- 🔒 Flexibilní přístupová pravidla
- 📈 Sledování přístupů k obsahu
- 💌 Šablony e-mailů
- 🎨 Přizpůsobitelné šablony

### Shortcody
```
[pmp_membership_levels] - Zobrazí všechny úrovně členství
[pmp_account] - Stránka uživatelského účtu
[pmp_login_form] - Přihlašovací formulář
[pmp_member_content] - Obsah pouze pro členy
[pmp_non_member_content] - Obsah pouze pro nečleny
[pmp_has_membership level="premium"] - Obsah pro konkrétní úroveň
```

## Instalace

1. **Nahrání pluginu:**
   - Zkopírujte složku `premium-membership-pro` do adresáře `/wp-content/plugins/`
   - Nebo nahrajte ZIP soubor přes WordPress admin (Pluginy > Přidat nový > Nahrát plugin)

2. **Aktivace:**
   - Přejděte do Pluginy > Nainstalované pluginy
   - Najděte "Premium Membership Pro" a klikněte na Aktivovat

3. **Základní nastavení:**
   - Přejděte do Membership > Nastavení
   - Nastavte měnu a platební brány
   - Vytvořte potřebné stránky (Ceník, Účet, Poděkování)

## Rychlý start

### 1. Vytvoření úrovní členství

1. Přejděte do Membership > Úrovně > Přidat novou
2. Vyplňte název a popis úrovně
3. Nastavte cenu a typ fakturace:
   - **Opakující se**: Pro měsíční/roční předplatné
   - **Doživotní**: Pro jednorázovou platbu bez expirace
   - **Pevné období**: Pro členství na určitou dobu

4. Nastavte přístupová pravidla:
   - **Přístup ke všemu obsahu**: Člen vidí veškerý obsah
   - **Pouze vybrané kategorie**: Omezení na konkrétní kategorie
   - **Pouze vybrané příspěvky**: Ruční výběr příspěvků

### 2. Ochrana obsahu

**Metoda 1: Pomocí meta boxu**
1. Otevřete příspěvek/stránku k úpravě
2. V postranním panelu najděte box "Ochrana obsahu"
3. Zaškrtněte "Chránit tento obsah"
4. Vyberte požadované úrovně členství
5. Volitelně přidejte náhledový text

**Metoda 2: Pomocí shortcodů**
```php
[pmp_member_content levels="basic,premium"]
Tento obsah uvidí pouze členové s úrovní Basic nebo Premium.
[/pmp_member_content]

[pmp_non_member_content]
Tento obsah uvidí pouze nečlenové.
[/pmp_non_member_content]
```

### 3. Vytvoření stránek

**Stránka s ceníkem:**
```
Název: Ceník
Obsah: [pmp_membership_levels layout="grid"]
```

**Stránka účtu:**
```
Název: Můj účet
Obsah: [pmp_account]
```

**Přihlašovací stránka:**
```
Název: Přihlášení
Obsah: [pmp_login_form]
```

### 4. Nastavení platebních bran

**Stripe:**
1. Zaregistrujte se na https://stripe.com
2. Získejte API klíče z Dashboard
3. V Membership > Nastavení přejděte na Platební brány
4. Povolte Stripe a zadejte klíče

**PayPal:**
1. Vytvořte si účet na https://paypal.com
2. Získejte Client ID a Secret
3. Zadejte je v nastavení pluginu

**Bankovní převod:**
1. Povolte v nastavení
2. Zadejte údaje o bankovním účtu
3. Členové obdrží pokyny emailem

## Použití v šablonách

### Kontrola členství v PHP

```php
// Kontrola, zda má uživatel aktivní členství
if (pmp_user_has_membership()) {
    echo 'Máte aktivní členství!';
}

// Získání údajů o členství
$membership = pmp_get_user_membership();
if ($membership) {
    echo 'Vaše úroveň: ' . get_the_title($membership->level_id);
}

// Kontrola přístupu k obsahu
if (pmp_user_can_access_content(get_the_ID())) {
    the_content();
} else {
    echo 'Tento obsah je pouze pro členy.';
}
```

### Podmíněné zobrazení v šablonách

```php
<?php if (pmp_user_has_membership()): ?>
    <div class="member-only-content">
        <!-- Obsah pouze pro členy -->
    </div>
<?php else: ?>
    <div class="subscribe-message">
        <p>Staňte se členem pro přístup k prémiový obsahu!</p>
        <a href="<?php echo home_url('/cenik'); ?>">Zobrazit plány</a>
    </div>
<?php endif; ?>
```

## Databázové tabulky

Plugin vytváří následující tabulky:

- `wp_pmp_memberships` - Aktivní členství uživatelů
- `wp_pmp_transactions` - Historie plateb
- `wp_pmp_access_logs` - Logy přístupů k obsahu
- `wp_pmp_email_logs` - Historie odeslaných emailů

## Hooky a filtry

### Akce (Actions)

```php
// Po vytvoření předplatného
add_action('pmp_subscription_created', function($subscription_id, $user_id, $level_id) {
    // Váš kód
}, 10, 3);

// Po zrušení předplatného
add_action('pmp_subscription_cancelled', function($subscription_id, $user_id, $reason) {
    // Váš kód
}, 10, 3);

// Po vypršení předplatného
add_action('pmp_subscription_expired', function($subscription_id, $user_id) {
    // Váš kód
}, 10, 2);
```

### Filtry (Filters)

```php
// Upravit formátování ceny
add_filter('pmp_format_price', function($formatted_price, $price, $currency) {
    return $formatted_price;
}, 10, 3);

// Upravit šablonu emailu
add_filter('pmp_email_template', function($template, $type, $vars) {
    return $template;
}, 10, 3);
```

## Často kladené otázky (FAQ)

**Q: Jak přidat novou platební bránu?**
A: Vytvořte novou třídu, která rozšiřuje `PMP_Payment_Gateway` a zaregistrujte ji pomocí filtru `pmp_payment_gateways`.

**Q: Mohu mít více aktivních členství pro jednoho uživatele?**
A: Ve výchozím nastavení ne, ale můžete to upravit v kódu v souboru `class-pmp-subscriptions.php`.

**Q: Jak změním šablony emailů?**
A: Vytvořte vlastní šablony v složce `/templates/emails/` ve vašem child theme.

**Q: Podporuje plugin recurring platby?**
A: Ano, ale vyžaduje integraci s Stripe nebo PayPal. Bankovní převody jsou pouze pro jednorázové platby.

## Technické požadavky

- WordPress 5.0 nebo novější
- PHP 7.4 nebo novější
- MySQL 5.6 nebo novější

## Podpora a dokumentace

Pro další informace a podporu:
- 📧 Email: support@example.com
- 🌐 Web: https://example.com/docs
- 💬 Forum: https://example.com/forum

## Changelog

### Verze 1.0.0
- Počáteční vydání
- Základní funkce členství
- Ochrana obsahu
- Platební brány (Stripe, PayPal, bankovní převod)
- E-mailové notifikace
- Analytika a reporty

## Licence

GPL v2 or later

## Autor

Tento plugin vytvořil Claude pro demonstrační účely.

## 👁️ Pokročilé náhledy chráněného obsahu

Plugin nabízí **3 typy náhledů** pro nečleny, které můžete nastavit pro každý článek zvlášť:

### 1. Rozostřený obsah (Blur Preview) - DOPORUČENO
```
✅ Nejefektivnější pro konverzi
🎯 Uživatel vidí strukturu článku, ale nemůže číst
💡 Ideální pro dlouhé články a tutoriály
```

**Jak to funguje:**
- Zobrazí prvních X% obsahu čitelně (výchozí 30%)
- Zbytek článku je viditelný, ale rozostřený (blur efekt)
- Přes rozostřený obsah se zobrazí přehledný overlay s výzvou k přihlášení
- Gradient efekt pro plynulý přechod

**Nastavení:**
1. Upravte příspěvek
2. V meta boxu "Ochrana obsahu" zaškrtněte "Chránit tento obsah"
3. Vyberte "Rozostřený obsah"
4. Nastavte procento zobrazitelného obsahu (10-75%)

### 2. Textový náhled (Teaser Preview)
```
✅ Klasický přístup
📄 Zobrazí jen začátek textu
💡 Ideální pro novinky a kratší články
```

**Jak to funguje:**
- Zobrazí prvních X slov (výchozí 30 slov nebo 30% délky)
- Pod textem fade-out efekt
- Výzva k přihlášení pod náhledem

**Nastavení:**
1. Vyberte "Textový náhled"
2. Nastavte počet slov nebo procent
3. Volitelně napište vlastní úvodní text

### 3. Úplně uzamčeno (Locked Preview)
```
🔒 Maximální tajemno
❌ Žádný obsah není viditelný
💡 Pro exkluzivní premium obsah
```

**Jak to funguje:**
- Nezobrazí žádný obsah článku
- Jen ikona zámku a výzva k členství
- Gradient pozadí pro atraktivní vzhled

### Vizuální ukázka rozdílů

**Rozostřený obsah:**
```
[Čitelný text prvních 30% článku...]

[🔒 ROZOSTŘENÝ TEXT - VIDITELNÝ ALE NEČITELNÝ]
      
      Odemkněte zbytek článku
      Pro pokračování ve čtení si aktivujte členství
      
      [Basic - 199 Kč/měsíc] [Premium - 990 Kč/rok]
      
      [Vybrat členství]
```

**Textový náhled:**
```
Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
Sed do eiusmod tempor incididunt ut labore et dolore magna...
[fade-out efekt]

━━━━━━━━━━━━━━━━━━━━━━━━
🔒 Pokračujte ve čtení s členstvím
[Přihlásit se] [Registrovat]
```

**Uzamčeno:**
```
━━━━━━━━━━━━━━━━━━━━━━━━
        🔒
   Tento obsah je uzamčen
   Pro zobrazení potřebujete členství
   
   [Získat přístup]
━━━━━━━━━━━━━━━━━━━━━━━━
```

### Nastavení rozostření v kódu

Pro pokročilé uživatele - můžete upravit vzhled v CSS:

```css
/* Síla rozostření */
.pmp-blurred-content {
    filter: blur(8px); /* Změňte hodnotu 8px */
}

/* Barva overlaye */
.pmp-blur-overlay {
    background: linear-gradient(
        to bottom,
        rgba(255,255,255,0) 0%,
        rgba(255,255,255,1) 70%
    );
}
```

### Nejlepší praxe

**Pro konverzi:**
- Použijte "Rozostřený obsah" s 30-40% zobrazení
- Umožní to čtenářům vidět kvalitu a délku článku

**Pro novinky:**
- Použijte "Textový náhled" s 20-30%
- Začátek příběhu naláká na pokračování

**Pro exkluzivní obsah:**
- Použijte "Úplně uzamčeno"
- Vytvoří pocit výjimečnosti

### FAQ - Náhledy

**Q: Mohu mít různé typy náhledů pro různé články?**
A: Ano! Každý článek má vlastní nastavení v meta boxu "Ochrana obsahu".

**Q: Vidí Google rozostřený obsah?**
A: Ano, vyhledávače vidí celý obsah pro SEO, rozostření je pouze vizuální CSS efekt.

**Q: Funguje to i na mobilech?**
A: Ano, všechny náhledy jsou plně responzivní a optimalizované pro mobily.

**Q: Mohu změnit procento zobrazení po publikování?**
A: Ano, kdykoli můžete upravit článek a změnit nastavení náhledu.

**Q: Mohu náhled úplně vypnout?**
A: Ano, použijte typ "Úplně uzamčeno" - nezobrazí se žádný obsah.


---

## 👨‍💻 Autor

**CONEXO s.r.o.**
- 🌐 Web: https://conexo.cz
- 📧 Email: info@conexo.cz
- 📍 Lokace: Litoměřice, Česká republika

---

## 📜 Licence

Tento projekt je licencován pod [GPL-2.0 License](LICENSE).

```
Premium Membership Pro - WordPress Membership Plugin
Copyright (C) 2024 CONEXO s.r.o.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
```

---

## 📞 Kontakt a podpora

- 📧 Email: info@conexo.cz
- 🌐 Web: https://conexo.cz
- 🐛 Issues: https://github.com/conexo/premium-membership-pro/issues

---

## ⭐ Líbí se vám plugin?

Pokud vám Premium Membership Pro pomohl:
- ⭐ Dejte hvězdu na GitHubu
- 📝 Sdílejte s ostatními
- 💬 Napište zpětnou vazbu

---

**Vytvořeno s ❤️ v České republice**

*CONEXO s.r.o. - Profesionální WordPress řešení*
