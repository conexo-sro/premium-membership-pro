<?php
/**
 * Plugin Name: Premium Membership Pro
 * Plugin URI: https://conexo.cz/premium-membership-pro
 * Description: Membership systém - v1.14.0 - Královské ikony pro úrovně členství 👑💎⭐
 * Version: 1.14.0
 * Author: CONEXO s.r.o.
 * Author URI: https://conexo.cz
 * License: GPL v2 or later
 * Text Domain: premium-membership-pro
 * Domain Path: /languages
 * Requires at least: 6.4
 * Tested up to: 6.9
 * Requires PHP: 8.0
 * Elementor tested up to: 3.25
 * Elementor Pro tested up to: 3.25
 * WC requires at least: 5.0
 * WC tested up to: 9.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('PMP_VERSION', '1.14.0');
define('PMP_MIN_WP_VERSION', '6.4');
define('PMP_TESTED_WP_VERSION', '6.9');
define('PMP_MIN_PHP_VERSION', '8.0');
define('PMP_PLUGIN_FILE', __FILE__);
define('PMP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('PMP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('PMP_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Include required files
// CRITICAL: Early init MUST be first!
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-early-init.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-preview-mode.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-roles.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-post-types.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-membership-levels.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-access-control.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-subscriptions.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-payments.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-user-management.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-content-protection.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-content-groups.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-bulk-actions.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-shortcodes.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-emails.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-analytics.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-elementor.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-update-checker.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-meta-boxes.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-auth-pages.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-help.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-upgrade.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-uninstall-dialog.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-content-lock.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-membership-assignment.php';
require_once PMP_PLUGIN_DIR . 'includes/class-pmp-post-level-column.php';
require_once PMP_PLUGIN_DIR . 'admin/class-pmp-admin.php';

class Premium_Membership_Pro {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // CRITICAL: Initialize early hooks FIRST!
        PMP_Early_Init::init();
        
        // Initialize preview mode
        PMP_Preview_Mode::init();
        
        // CRITICAL: Add capabilities IMMEDIATELY on plugin load
        $this->ensure_admin_capabilities();
        
        // CRITICAL: Register post types early in init hook
        // Priority 1 = before admin_menu
        add_action('init', array($this, 'register_post_types_early'), 1);
        
        // CRITICAL: Initialize admin IMMEDIATELY (before admin_menu hook)
        if (is_admin()) {
            // Admin class is already loaded via require at top of file
            // Initialize it immediately
            PMP_Admin::init();
        }
        
        $this->init_hooks();
    }
    
    /**
     * Register post types with priority 1 (very early)
     */
    public function register_post_types_early() {
        PMP_Post_Types::register_post_types();
        PMP_Post_Types::register_taxonomies();
    }
    
    /**
     * Ensure admin has all capabilities immediately
     * Runs IMMEDIATELY on plugin load
     */
    private function ensure_admin_capabilities() {
        // Only run in admin
        if (!is_admin()) {
            return;
        }
        
        $admin_role = get_role('administrator');
        if (!$admin_role) {
            return;
        }
        
        // Quick check - if admin already has main capability, skip
        if ($admin_role->has_cap('pmp_view_dashboard')) {
            return;
        }
        
        // Add all capabilities immediately
        $capabilities = array(
            'pmp_view_dashboard',
            'pmp_manage_levels',
            'pmp_edit_level',
            'pmp_delete_level',
            'pmp_view_levels',
            'pmp_manage_members',
            'pmp_edit_member',
            'pmp_delete_member',
            'pmp_view_members',
            'pmp_view_transactions',
            'pmp_manage_transactions',
            'pmp_view_reports',
            'pmp_export_data',
            'pmp_import_data',
            'pmp_manage_products',
            'pmp_edit_product',
            'pmp_delete_product',
            'pmp_manage_coupons',
            'pmp_edit_coupon',
            'pmp_delete_coupon',
            'pmp_manage_emails',
            'pmp_send_emails',
            'pmp_manage_protection',
            'pmp_view_logs',
            'pmp_manage_settings',
        );
        
        foreach ($capabilities as $cap) {
            $admin_role->add_cap($cap);
        }
    }
    
    private function init_hooks() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // CRITICAL: Check database tables on every load (before anything else)
        add_action('plugins_loaded', array($this, 'ensure_database_tables'), 1);
        
        // CRITICAL: Check capabilities BEFORE admin_menu hook (priority 5)
        add_action('plugins_loaded', array($this, 'early_capability_check'), 5);
        
        add_action('plugins_loaded', array($this, 'check_compatibility'));
        add_action('plugins_loaded', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('admin_notices', array($this, 'activation_notice'));
    }
    
    /**
     * Early capability check - runs before admin_menu
     */
    public function early_capability_check() {
        // Ensure admin has all capabilities BEFORE menu is registered
        $admin_role = get_role('administrator');
        if ($admin_role) {
            $capabilities = array(
                'pmp_view_dashboard',
                'pmp_manage_levels',
                'pmp_edit_level',
                'pmp_delete_level',
                'pmp_view_levels',
                'pmp_manage_members',
                'pmp_edit_member',
                'pmp_delete_member',
                'pmp_view_members',
                'pmp_view_transactions',
                'pmp_manage_transactions',
                'pmp_view_reports',
                'pmp_export_data',
                'pmp_import_data',
                'pmp_manage_products',
                'pmp_edit_product',
                'pmp_delete_product',
                'pmp_manage_coupons',
                'pmp_edit_coupon',
                'pmp_delete_coupon',
                'pmp_manage_emails',
                'pmp_send_emails',
                'pmp_manage_protection',
                'pmp_view_logs',
                'pmp_manage_settings',
            );
            
            foreach ($capabilities as $cap) {
                if (!$admin_role->has_cap($cap)) {
                    $admin_role->add_cap($cap);
                }
            }
        }
    }
    
    /**
     * Show notice after plugin activation
     */
    public function activation_notice() {
        if (get_transient('pmp_activated')) {
            delete_transient('pmp_activated');
            ?>
            <div class="notice notice-success is-dismissible">
                <h3><?php _e('Premium Membership Pro aktivováno!', 'premium-membership-pro'); ?></h3>
                <p>
                    <?php _e('Plugin byl úspěšně aktivován. Všechna oprávnění byla přidána Administrátorům.', 'premium-membership-pro'); ?>
                </p>
                <p>
                    <a href="<?php echo admin_url('admin.php?page=premium-membership-pro'); ?>" class="button button-primary">
                        <?php _e('Přejít na Dashboard', 'premium-membership-pro'); ?>
                    </a>
                    <a href="<?php echo admin_url('admin.php?page=pmp-settings'); ?>" class="button">
                        <?php _e('Nastavení pluginu', 'premium-membership-pro'); ?>
                    </a>
                </p>
            </div>
            <?php
        }
    }
    
    /**
     * Check WordPress and PHP version compatibility
     */
    public function check_compatibility() {
        global $wp_version;
        
        // Check WordPress version
        if (version_compare($wp_version, PMP_MIN_WP_VERSION, '<')) {
            add_action('admin_notices', function() use ($wp_version) {
                ?>
                <div class="notice notice-error">
                    <p>
                        <strong>Premium Membership Pro:</strong> 
                        Tento plugin vyžaduje WordPress <?php echo PMP_MIN_WP_VERSION; ?> nebo novější. 
                        Aktuálně používáte verzi <?php echo $wp_version; ?>.
                    </p>
                </div>
                <?php
            });
            return;
        }
        
        // Check PHP version
        if (version_compare(PHP_VERSION, PMP_MIN_PHP_VERSION, '<')) {
            add_action('admin_notices', function() {
                ?>
                <div class="notice notice-error">
                    <p>
                        <strong>Premium Membership Pro:</strong> 
                        Tento plugin vyžaduje PHP <?php echo PMP_MIN_PHP_VERSION; ?> nebo novější. 
                        Aktuálně používáte verzi <?php echo PHP_VERSION; ?>.
                    </p>
                </div>
                <?php
            });
            return;
        }
        
        // Show success message on plugin page
        if (isset($_GET['page']) && $_GET['page'] === 'premium-membership-pro') {
            add_action('admin_notices', function() use ($wp_version) {
                ?>
                <div class="notice notice-success is-dismissible">
                    <p>
                        <strong>✓ Premium Membership Pro:</strong> 
                        Plugin je kompatibilní s vaší verzí WordPress <?php echo $wp_version; ?> 
                        (testováno až do verze <?php echo PMP_TESTED_WP_VERSION; ?>)
                    </p>
                </div>
                <?php
            });
        }
    }
    
    public function init() {
        // Initialize components
        PMP_Roles::init();
        // PMP_Post_Types already initialized in constructor
        PMP_Membership_Levels::init();
        PMP_Access_Control::init();
        PMP_Subscriptions::init();
        PMP_Payments::init();
        PMP_User_Management::init();
        PMP_Content_Protection::init();
        PMP_Content_Groups::init();
        PMP_Bulk_Actions::init();
        PMP_Shortcodes::init();
        PMP_Emails::init();
        PMP_Analytics::init();
        PMP_Elementor::init();
        PMP_Meta_Boxes::init(); // Meta boxes for posts/pages
        PMP_Auth_Pages::init(); // Login and registration pages
        PMP_Help::init(); // Help and tooltips system
        PMP_Upgrade::init(); // Upgrade page
        PMP_Uninstall_Dialog::init(); // Uninstall dialog
        PMP_Content_Lock::init(); // Content lock functionality
        PMP_Membership_Assignment::init(); // Membership assignment
        
        // Initialize post level column on admin_init (later) with fallback
        add_action('admin_init', array('PMP_Post_Level_Column', 'init'), 5);
        
        // Add fallback column registration with ultra-high priority
        add_action('admin_init', function() {
            add_filter('manage_post_posts_columns', function($columns) {
                if (!isset($columns['pmp_levels'])) {
                    $new = array();
                    foreach ($columns as $key => $title) {
                        $new[$key] = $title;
                        if ($key === 'title') {
                            $new['pmp_levels'] = '<span class="dashicons dashicons-shield"></span> Úroveň';
                        }
                    }
                    return $new;
                }
                return $columns;
            }, 99999);
        }, 1);
        
        // PMP_Admin already initialized in constructor
        
        // Initialize update checker
        $this->init_update_checker();
        
        // WordPress 6.9 compatibility features
        $this->init_wp69_features();
        
        // Load text domain
        load_plugin_textdomain('premium-membership-pro', false, dirname(PMP_PLUGIN_BASENAME) . '/languages');
    }
    
    /**
     * Initialize update checker
     */
    private function init_update_checker() {
        global $pmp_update_checker;
        
        // Initialize with GitHub URL (can be changed to custom server)
        $pmp_update_checker = new PMP_Update_Checker(
            __FILE__,
            'https://api.github.com/repos/conexo-sro/premium-membership-pro/releases/latest'
        );
    }
    
    /**
     * Initialize WordPress 6.9 specific features
     */
    private function init_wp69_features() {
        global $wp_version;
        
        // Block theme support (WordPress 5.9+)
        if (version_compare($wp_version, '5.9', '>=')) {
            add_theme_support('block-templates');
            add_theme_support('block-template-parts');
        }
        
        // Full Site Editing support (WordPress 6.0+)
        if (version_compare($wp_version, '6.0', '>=')) {
            add_filter('theme_file_path', array($this, 'add_block_templates'), 10, 2);
            add_filter('theme_file_uri', array($this, 'add_block_templates'), 10, 2);
        }
        
        // WordPress 6.9 performance improvements
        if (version_compare($wp_version, '6.9', '>=')) {
            // Enable lazy loading for membership images
            add_filter('wp_lazy_loading_enabled', '__return_true');
            
            // Add async/defer to scripts
            add_filter('script_loader_tag', array($this, 'add_async_defer_attributes'), 10, 2);
        }
        
        // Add plugin action links
        add_filter('plugin_action_links_' . PMP_PLUGIN_BASENAME, array($this, 'add_plugin_action_links'));
        add_filter('plugin_row_meta', array($this, 'add_plugin_row_meta'), 10, 2);
    }
    
    /**
     * Add async/defer attributes to scripts for better performance
     */
    public function add_async_defer_attributes($tag, $handle) {
        // Add defer to PMP frontend scripts
        if (strpos($handle, 'pmp-') === 0 && !is_admin()) {
            return str_replace(' src', ' defer src', $tag);
        }
        return $tag;
    }
    
    /**
     * Add plugin action links (left side - after plugin name)
     */
    public function add_plugin_action_links($links) {
        $plugin_links = array(
            'settings' => '<a href="' . admin_url('admin.php?page=pmp-settings') . '">Settings</a>',
        );
        
        // Add links at the beginning (before Deactivate)
        return array_merge($plugin_links, $links);
    }
    
    /**
     * Add plugin row meta links (right side - after Version, Author, etc.)
     */
    public function add_plugin_row_meta($links, $file) {
        if ($file !== PMP_PLUGIN_BASENAME) {
            return $links;
        }
        
        $meta_links = array(
            'support' => '<a href="https://conexo.cz/podpora" target="_blank" style="color: #2271b1;">💬 Podpora</a>',
            'changelog' => '<a href="' . admin_url('admin.php?page=pmp-documentation&tab=changelog') . '" style="color: #50575e;">📋 Changelog</a>',
            'rate' => '<a href="https://wordpress.org/support/plugin/premium-membership-pro/reviews/#new-post" target="_blank" style="color: #ffb900;">⭐⭐⭐⭐⭐ Ohodnotit</a>',
        );
        
        return array_merge($links, $meta_links);
    }
    
    /**
     * Ensure database tables exist - runs on every plugin load
     * Creates tables if they don't exist (failsafe for activation issues)
     */
    public function ensure_database_tables() {
        global $wpdb;
        
        // Check if tables exist
        $tables = array(
            $wpdb->prefix . 'pmp_memberships',
            $wpdb->prefix . 'pmp_transactions',
            $wpdb->prefix . 'pmp_access_logs',
            $wpdb->prefix . 'pmp_email_logs'
        );
        
        $missing_tables = array();
        foreach ($tables as $table) {
            if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
                $missing_tables[] = $table;
            }
        }
        
        // If any tables are missing, create them all
        if (!empty($missing_tables)) {
            if (WP_DEBUG) {
                error_log('PMP: Missing tables detected: ' . implode(', ', $missing_tables));
                error_log('PMP: Creating database tables...');
            }
            
            $this->create_tables();
            
            // Verify creation
            $still_missing = array();
            foreach ($tables as $table) {
                if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
                    $still_missing[] = $table;
                }
            }
            
            if (!empty($still_missing)) {
                // Tables still missing - show admin notice
                add_action('admin_notices', function() use ($still_missing) {
                    echo '<div class="notice notice-error">';
                    echo '<p><strong>Premium Membership Pro:</strong> Nepodařilo se vytvořit databázové tabulky:</p>';
                    echo '<ul>';
                    foreach ($still_missing as $table) {
                        echo '<li>' . esc_html($table) . '</li>';
                    }
                    echo '</ul>';
                    echo '<p>Řešení: <a href="' . admin_url('plugins.php') . '">Deaktivuj a znovu aktivuj plugin</a> nebo použij manuální skript.</p>';
                    echo '</div>';
                });
                
                if (WP_DEBUG) {
                    error_log('PMP: FAILED to create tables: ' . implode(', ', $still_missing));
                }
            } else {
                if (WP_DEBUG) {
                    error_log('PMP: All tables created successfully');
                }
                
                // Show success notice (only once)
                if (!get_transient('pmp_tables_created_notice')) {
                    set_transient('pmp_tables_created_notice', true, 60);
                    add_action('admin_notices', function() {
                        echo '<div class="notice notice-success is-dismissible">';
                        echo '<p><strong>Premium Membership Pro:</strong> Databázové tabulky byly úspěšně vytvořeny!</p>';
                        echo '</div>';
                    });
                }
            }
        }
    }
    
    public function activate() {
        // Create database tables
        $this->create_tables();
        
        // Set default options
        $this->set_default_options();
        
        // Add capabilities to roles
        PMP_Roles::add_capabilities();
        
        // Set activation flag for admin notice
        set_transient('pmp_activated', true, 30);
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    public function deactivate() {
        // Remove capabilities
        PMP_Roles::remove_capabilities();
        
        flush_rewrite_rules();
    }
    
    public function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        // Memberships table
        $table_memberships = $wpdb->prefix . 'pmp_memberships';
        $sql_memberships = "CREATE TABLE $table_memberships (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            level_id bigint(20) unsigned NOT NULL,
            status varchar(50) NOT NULL DEFAULT 'active',
            start_date datetime NOT NULL,
            end_date datetime DEFAULT NULL,
            trial_end_date datetime DEFAULT NULL,
            payment_gateway varchar(50) DEFAULT NULL,
            subscription_id varchar(255) DEFAULT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY level_id (level_id),
            KEY status (status)
        ) $charset_collate;";
        
        dbDelta($sql_memberships);
        
        // Transactions table
        $table_transactions = $wpdb->prefix . 'pmp_transactions';
        $sql_transactions = "CREATE TABLE $table_transactions (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            membership_id bigint(20) unsigned DEFAULT NULL,
            amount decimal(10,2) NOT NULL,
            currency varchar(10) NOT NULL DEFAULT 'CZK',
            status varchar(50) NOT NULL DEFAULT 'pending',
            payment_gateway varchar(50) NOT NULL,
            transaction_id varchar(255) DEFAULT NULL,
            invoice_number varchar(100) DEFAULT NULL,
            description text,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY membership_id (membership_id),
            KEY status (status)
        ) $charset_collate;";
        
        dbDelta($sql_transactions);
        
        // Access logs table
        $table_logs = $wpdb->prefix . 'pmp_access_logs';
        $sql_logs = "CREATE TABLE $table_logs (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            post_id bigint(20) unsigned NOT NULL,
            membership_level_id bigint(20) unsigned NOT NULL,
            access_type varchar(50) NOT NULL,
            ip_address varchar(45) DEFAULT NULL,
            user_agent text,
            accessed_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY post_id (post_id),
            KEY accessed_at (accessed_at)
        ) $charset_collate;";
        
        dbDelta($sql_logs);
        
        // Email logs table
        $table_emails = $wpdb->prefix . 'pmp_email_logs';
        $sql_emails = "CREATE TABLE $table_emails (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            email_type varchar(100) NOT NULL,
            subject varchar(255) NOT NULL,
            status varchar(50) NOT NULL DEFAULT 'sent',
            sent_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY email_type (email_type)
        ) $charset_collate;";
        
        dbDelta($sql_emails);
        
        // Store database version
        update_option('pmp_db_version', PMP_VERSION);
        
        // Log success
        if (WP_DEBUG) {
            error_log('PMP: Database tables created successfully');
            error_log('PMP: ' . $table_memberships . ' - ' . ($wpdb->get_var("SHOW TABLES LIKE '$table_memberships'") ? 'EXISTS' : 'FAILED'));
            error_log('PMP: ' . $table_transactions . ' - ' . ($wpdb->get_var("SHOW TABLES LIKE '$table_transactions'") ? 'EXISTS' : 'FAILED'));
            error_log('PMP: ' . $table_logs . ' - ' . ($wpdb->get_var("SHOW TABLES LIKE '$table_logs'") ? 'EXISTS' : 'FAILED'));
            error_log('PMP: ' . $table_emails . ' - ' . ($wpdb->get_var("SHOW TABLES LIKE '$table_emails'") ? 'EXISTS' : 'FAILED'));
        }
    }
    
    private function set_default_options() {
        $default_options = array(
            'pmp_currency' => 'CZK',
            'pmp_currency_position' => 'after',
            'pmp_enable_trial' => '1',
            'pmp_trial_period' => '7',
            'pmp_enable_stripe' => '0',
            'pmp_enable_paypal' => '0',
            'pmp_enable_bank_transfer' => '1',
            'pmp_login_redirect' => '',
            'pmp_logout_redirect' => '',
            'pmp_account_page' => '',
            'pmp_pricing_page' => '',
            'pmp_thank_you_page' => '',
        );
        
        foreach ($default_options as $key => $value) {
            if (get_option($key) === false) {
                add_option($key, $value);
            }
        }
    }
    
    public function enqueue_scripts() {
        wp_enqueue_style('pmp-frontend', PMP_PLUGIN_URL . 'assets/css/frontend.css', array(), PMP_VERSION);
        wp_enqueue_script('pmp-frontend', PMP_PLUGIN_URL . 'assets/js/frontend.js', array('jquery'), PMP_VERSION, true);
        
        wp_localize_script('pmp-frontend', 'pmpData', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('pmp_nonce'),
            'strings' => array(
                'error' => __('Došlo k chybě. Zkuste to prosím znovu.', 'premium-membership-pro'),
                'loading' => __('Načítání...', 'premium-membership-pro'),
            )
        ));
    }
    
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'premium-membership-pro') !== false) {
            wp_enqueue_style('pmp-admin', PMP_PLUGIN_URL . 'assets/css/admin.css', array(), PMP_VERSION);
            wp_enqueue_script('pmp-admin', PMP_PLUGIN_URL . 'assets/js/admin.js', array('jquery', 'jquery-ui-datepicker'), PMP_VERSION, true);
            
            wp_localize_script('pmp-admin', 'pmpAdminData', array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('pmp_admin_nonce'),
            ));
        }
    }
}

// Initialize plugin
function pmp_init() {
    return Premium_Membership_Pro::get_instance();
}
add_action('plugins_loaded', 'pmp_init');

// Helper functions
function pmp_get_user_membership($user_id = null) {
    if (!$user_id) {
        $user_id = get_current_user_id();
    }
    return PMP_User_Management::get_user_membership($user_id);
}

function pmp_user_has_membership($user_id = null) {
    if (!$user_id) {
        $user_id = get_current_user_id();
    }
    return PMP_User_Management::user_has_active_membership($user_id);
}

function pmp_user_can_access_content($post_id, $user_id = null) {
    if (!$user_id) {
        $user_id = get_current_user_id();
    }
    return PMP_Access_Control::user_can_access($post_id, $user_id);
}

function pmp_format_price($price, $currency = null) {
    if (!$currency) {
        $currency = get_option('pmp_currency', 'CZK');
    }
    
    $position = get_option('pmp_currency_position', 'after');
    $formatted = number_format($price, 2, ',', ' ');
    
    if ($position === 'before') {
        return $currency . ' ' . $formatted;
    }
    return $formatted . ' ' . $currency;
}
