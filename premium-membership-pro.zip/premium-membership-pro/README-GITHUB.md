# Premium Membership Pro

<div align="center">

![Version](https://img.shields.io/badge/version-1.1.0-blue.svg)
![WordPress](https://img.shields.io/badge/WordPress-5.0%2B-blue.svg)
![PHP](https://img.shields.io/badge/PHP-7.4%2B-purple.svg)
![License](https://img.shields.io/badge/license-GPL--2.0-green.svg)

**Kompletní systém pro správu členství, prémiový obsah a předplatné pro WordPress**

[Demo](#-demo) • [Instalace](#-instalace) • [Dokumentace](#-dokumentace) • [Přispět](#-přispívání)

</div>

---

## 📖 O pluginu

Premium Membership Pro je profesionální WordPress plugin pro správu členství a monetizaci obsahu. Nabízí kompletní řešení podobné komerčním pluginům jako MemberPress, ale je **zcela zdarma a open-source**.

### ✨ Hlavní funkce

- 🔒 **Pokročilá ochrana obsahu** - Včetně rozostřených náhledů (blur effect)
- 👥 **Neomezené úrovně členství** - Vytvářejte libovolný počet plánů
- 💰 **Flexibilní ceny** - Měsíční, roční, doživotní předplatné
- 🎁 **Zkušební období** - 7, 14, 30 dní zdarma
- 💳 **Platební brány** - Stripe, PayPal, bankovní převod
- 📧 **Automatické e-maily** - Uvítání, připomínky, notifikace
- 📊 **Analytika** - Dashboard s přehledy a statistikami
- 🎟️ **Slevové kupóny** - Procenta, limity, expirace
- 🌍 **Český jazyk** - Plná lokalizace

### 🎨 Nové v verzi 1.1

**Profesionální náhledy chráněného obsahu:**

<table>
<tr>
<td width="33%">
<h4>🔒 Rozostřený obsah</h4>
<p>Nečlenové vidí strukturu článku, ale text je rozmazaný</p>
<ul>
<li>✅ Vyšší konverze</li>
<li>✅ SEO friendly</li>
<li>✅ Moderní vzhled</li>
</ul>
</td>
<td width="33%">
<h4>📄 Textový náhled</h4>
<p>Zobrazí jen začátek článku s fade efektem</p>
<ul>
<li>✅ Klasický přístup</li>
<li>✅ Jednoduché</li>
<li>✅ Efektivní</li>
</ul>
</td>
<td width="33%">
<h4>🚫 Úplně uzamčeno</h4>
<p>Jen ikona zámku, žádný obsah</p>
<ul>
<li>✅ Maximální tajemno</li>
<li>✅ Pro exkluzivní obsah</li>
<li>✅ Premium feel</li>
</ul>
</td>
</tr>
</table>

---

## 🚀 Rychlý start

### 1. Instalace

```bash
# Metoda A: Nahrát přes WordPress admin
1. Stáhněte nejnovější release
2. WordPress Admin → Pluginy → Přidat nový → Nahrát plugin
3. Vyberte ZIP soubor a aktivujte

# Metoda B: Přes FTP
1. Rozbalte ZIP
2. Nahrajte složku do /wp-content/plugins/
3. Aktivujte v WordPress admin
```

### 2. Základní nastavení

```bash
WordPress Admin → Membership → Nastavení
├─ Nastavte měnu (CZK, EUR, USD)
├─ Aktivujte platební brány
└─ Vytvořte stránky (Ceník, Účet)
```

### 3. První úroveň členství

```bash
WordPress Admin → Membership → Úrovně → Přidat novou
├─ Název: "Basic"
├─ Cena: 199 Kč
├─ Typ: Opakující se, 1 měsíc
└─ Publikovat
```

### 4. Ochrana článku

```bash
Upravit článek → Ochrana obsahu (pravý panel)
├─ ☑️ Chránit tento obsah
├─ Typ náhledu: Rozostřený obsah
├─ Zobrazit: 30%
└─ Aktualizovat
```

**🎉 Hotovo! Za 5 minut máte funkční membership systém.**

---

## 📸 Screenshots

### Dashboard
![Dashboard](https://via.placeholder.com/800x400/667eea/ffffff?text=Dashboard+s+analytikou)

### Rozostřený náhled
![Blur Preview](https://via.placeholder.com/800x400/764ba2/ffffff?text=Rozostřený+náhled+článku)

### Správa členství
![Members](https://via.placeholder.com/800x400/0073aa/ffffff?text=Správa+členů)

---

## 📚 Dokumentace

### Základní použití

#### Shortcody

```php
// Zobrazit všechny úrovně členství
[pmp_membership_levels]

// Stránka uživatelského účtu
[pmp_account]

// Přihlašovací formulář
[pmp_login_form]

// Obsah pouze pro členy
[pmp_member_content]
Tento text vidí pouze členové
[/pmp_member_content]

// Obsah pouze pro konkrétní úroveň
[pmp_has_membership level="premium"]
Exkluzivní obsah pro Premium členy
[/pmp_has_membership]
```

#### PHP funkce

```php
// Kontrola členství
if (pmp_user_has_membership()) {
    echo 'Uživatel je člen!';
}

// Získat data o členství
$membership = pmp_get_user_membership();
echo $membership->level_id;

// Kontrola přístupu k obsahu
if (pmp_user_can_access_content($post_id)) {
    the_content();
}

// Formátování ceny
echo pmp_format_price(199); // "199 Kč"
```

#### Hooky pro vývojáře

```php
// Po vytvoření členství
add_action('pmp_subscription_created', function($id, $user_id, $level_id) {
    // Váš kód
}, 10, 3);

// Po zrušení členství
add_action('pmp_subscription_cancelled', function($id, $user_id, $reason) {
    // Váš kód
}, 10, 3);

// Po vypršení členství
add_action('pmp_subscription_expired', function($id, $user_id) {
    // Váš kód
}, 10, 2);
```

### Pokročilé

- 📖 [Kompletní dokumentace](README.md)
- 🎨 [Přizpůsobení vzhledu](docs/customization.md)
- 🔌 [Vývoj rozšíření](docs/development.md)
- 🌐 [REST API](docs/api.md)

---

## 🛠️ Technické informace

### Požadavky

- WordPress 5.0+
- PHP 7.4+
- MySQL 5.6+
- HTTPS (doporučeno pro platby)

### Struktura

```
premium-membership-pro/
├── admin/                      # Admin panel
│   └── class-pmp-admin.php
├── assets/                     # CSS a JS
│   ├── css/
│   │   ├── frontend.css
│   │   └── admin.css
│   └── js/
│       ├── frontend.js
│       └── admin.js
├── includes/                   # Hlavní logika
│   ├── class-pmp-access-control.php
│   ├── class-pmp-analytics.php
│   ├── class-pmp-emails.php
│   ├── class-pmp-membership-levels.php
│   ├── class-pmp-payments.php
│   ├── class-pmp-post-types.php
│   ├── class-pmp-shortcodes.php
│   ├── class-pmp-subscriptions.php
│   └── class-pmp-user-management.php
├── templates/                  # Šablony
│   ├── account.php
│   └── membership-levels.php
├── premium-membership-pro.php  # Hlavní soubor
├── README.md                   # Dokumentace CZ
├── CHANGELOG.md                # Historie změn
├── CONTRIBUTING.md             # Průvodce přispíváním
└── LICENSE                     # GPL-2.0
```

### Databáze

Plugin vytváří 4 tabulky:

- `wp_pmp_memberships` - Členství uživatelů
- `wp_pmp_transactions` - Platební transakce
- `wp_pmp_access_logs` - Logy přístupů k obsahu
- `wp_pmp_email_logs` - Historie odeslaných emailů

---

## 🎯 Roadmap

### Verze 1.2 (Q1 2025)
- [ ] Hromadná úprava náhledů
- [ ] A/B testování
- [ ] Detailnější analytika
- [ ] Video náhledy s blur
- [ ] Export dat členů

### Verze 1.3 (Q2 2025)
- [ ] Časovaný odemyk
- [ ] Countdown timer
- [ ] Social login
- [ ] Apple Pay
- [ ] Webhook integrace

### Verze 2.0 (Q3 2025)
- [ ] Multisite podpora
- [ ] Affiliate systém
- [ ] Gamifikace
- [ ] Drip content
- [ ] REST API

[➡️ Zobrazit celý roadmap](ROADMAP.md)

---

## 🤝 Přispívání

Příspěvky jsou vítány! Prosím přečtěte si [průvodce pro přispěvatele](CONTRIBUTING.md).

### Jak pomoci

- 🐛 **Nahlaste chyby** - Vytvořte issue
- 💡 **Navrhněte funkce** - Sdílejte své nápady
- 🔧 **Pull requesty** - Opravte bug nebo přidejte funkci
- 📖 **Dokumentace** - Vylepšete návody
- 🌍 **Překlady** - Přeložte do dalších jazyků
- ⭐ **Dejte hvězdu** - Pokud se vám plugin líbí

### Top přispěvatelé

<a href="https://github.com/conexo-sro/premium-membership-pro/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=conexo-sro/premium-membership-pro" />
</a>

---

## 📊 Statistiky

![GitHub stars](https://img.shields.io/github/stars/conexo-sro/premium-membership-pro?style=social)
![GitHub forks](https://img.shields.io/github/forks/conexo-sro/premium-membership-pro?style=social)
![GitHub issues](https://img.shields.io/github/issues/conexo-sro/premium-membership-pro)
![GitHub pull requests](https://img.shields.io/github/issues-pr/conexo-sro/premium-membership-pro)
![Downloads](https://img.shields.io/github/downloads/conexo-sro/premium-membership-pro/total)

---

## 📜 Licence

Tento projekt je licencován pod [GPL-2.0 License](LICENSE).

```
Premium Membership Pro - WordPress Membership Plugin
Copyright (C) 2024 Your Name

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
```

---

## 🙏 Poděkování

- Inspirováno projektem [MemberPress](https://memberpress.com/)
- Děkujeme WordPress komunitě
- Všem přispěvatelům a uživatelům

---

## 📞 Kontakt

- 📧 Email: info@conexo.cz
- 💬 Discussions: [GitHub Discussions](https://github.com/conexo-sro/premium-membership-pro/discussions)
- 🐛 Issues: [GitHub Issues](https://github.com/conexo-sro/premium-membership-pro/issues)
- 🌐 Web: https://conexo.cz

---

## 📜 Licence

Tento projekt je licencován pod [GPL-2.0 License](LICENSE).

```
Premium Membership Pro - WordPress Membership Plugin
Copyright (C) 2024 CONEXO s.r.o.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
```

---

## ⭐ Líbí se vám projekt?

Pokud vám Premium Membership Pro pomohl, zvažte:

- ⭐ **Dejte hvězdu** na GitHubu
- 🐦 **Sdílejte** na sociálních sítích
- 📝 **Napište recenzi** na WordPress.org

---

<div align="center">

**Vytvořeno s ❤️ v České republice**

**CONEXO s.r.o. - Profesionální WordPress řešení**

[⬆ Zpět nahoru](#premium-membership-pro)

</div>
