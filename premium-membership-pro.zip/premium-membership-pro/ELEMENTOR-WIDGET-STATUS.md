# 🎨 Elementor Widget: Stav členství

## Nový widget pro zobrazení informací o členství uživatele

---

## 📦 Co widget dělá

Widget **"Stav členství"** zobrazuje informace o aktuálně přihlášeném uživateli a jeho členství:

- ✅ Avatar uživatele
- ✅ Jméno uživatele
- ✅ Aktuální úroveň členství
- ✅ Datum expirace
- ✅ Varování při blížící se expiraci
- ✅ Tlačítko pro upgrade
- ✅ Zpráva pro nepřihlášené uživatele

---

## 🎯 Kde najít widget

### V Elementor editoru:

```
Elementor Editor
    ↓
Levý panel → Widgety
    ↓
Sekce: "Premium Membership Pro"
    ↓
Widget: "Stav členství" (ikona user)
```

---

## 🎨 Nastavení widgetu

### OBSAH

#### Zobrazit avatar
- **Typ:** Přepínač (Ano/Ne)
- **Výchozí:** Ano
- **Popis:** Zobrazí avatar uživatele

#### Zobrazit jméno
- **Typ:** Přepínač (Ano/Ne)
- **Výchozí:** Ano
- **Popis:** Zobrazí jméno uživatele

#### Zobrazit úroveň
- **Typ:** Přepínač (Ano/Ne)
- **Výchozí:** Ano
- **Popis:** Zobrazí badge s názvem úrovně

#### Zobrazit expirace
- **Typ:** Přepínač (Ano/Ne)
- **Výchozí:** Ano
- **Popis:** Zobrazí datum expirace členství

#### Zobrazit tlačítko upgrade
- **Typ:** Přepínač (Ano/Ne)
- **Výchozí:** Ano
- **Popis:** Zobrazí tlačítko pro upgrade

#### Text tlačítka upgrade
- **Typ:** Text
- **Výchozí:** "Upgrade členství"
- **Popis:** Text na tlačítku

#### Zpráva pro nepřihlášené
- **Typ:** Textarea
- **Výchozí:** "Pro zobrazení stavu členství se prosím přihlaste."
- **Popis:** Zpráva zobrazená nepřihlášeným uživatelům

---

### STYL

#### Layout
- **Typ:** Select
- **Možnosti:**
  - **Karta** - Centrovaná karta (výchozí)
  - **Řádek** - Avatar vlevo, obsah vpravo
  - **Kompaktní** - Menší padding

#### Pozadí karty
- **Typ:** Color Picker
- **Výchozí:** #ffffff (bílá)

#### Barva textu
- **Typ:** Color Picker
- **Výchozí:** #2d3748 (tmavě šedá)

#### Ohraničení
- **Typ:** Border Control
- **Možnosti:** Typ, šířka, barva, radius

#### Zaoblení rohů
- **Typ:** Dimensions
- **Výchozí:** 8px všude

#### Vnitřní odsazení
- **Typ:** Dimensions
- **Výchozí:** 30px všude

#### Stín
- **Typ:** Box Shadow
- **Výchozí:** Lehký stín

---

### STYL TLAČÍTKA

#### Pozadí tlačítka
- **Typ:** Color Picker
- **Výchozí:** #667eea (fialová)

#### Barva textu tlačítka
- **Typ:** Color Picker
- **Výchozí:** #ffffff (bílá)

---

## 📸 Jak vypadá widget

### Layout: Karta

```
┌────────────────────────────────┐
│                                │
│         [Avatar 80x80]         │
│                                │
│       Jan Novák                │
│                                │
│      [Premium]                 │
│                                │
│   Vyprší: 15.01.2025           │
│                                │
│   [Upgrade členství]           │
│                                │
└────────────────────────────────┘
```

### Layout: Řádek

```
┌────────────────────────────────┐
│                                │
│  [Avatar]  Jan Novák           │
│            [Premium]           │
│            Vyprší: 15.01.2025  │
│            [Upgrade členství]  │
│                                │
└────────────────────────────────┘
```

### Layout: Kompaktní

```
┌──────────────────────┐
│  [Avatar] Jan Novák  │
│  [Premium]           │
│  Vyprší: 15.01.2025  │
│  [Upgrade]           │
└──────────────────────┘
```

---

## 🎯 Příklady použití

### Použití 1: Účetní stránka

```
[Header]
[Widget: Stav členství] ← Zobrazit kompletní info
[Obsah účtu...]
```

### Použití 2: Sidebar

```
[Widget: Stav členství - Kompaktní]
Layout: Kompaktní
Zobrazit: Avatar, Úroveň, Tlačítko
```

### Použití 3: Dashboard

```
[Widget: Stav členství - Řádek]
Layout: Řádek
Všechny informace viditelné
```

---

## 🔔 Speciální funkce

### Varování před expirací

Pokud členství vyprší do 7 dní, zobrazí se červené varování:

```
Vyprší: 15.01.2025 (zbývá 3 dny)
                    ↑ červeně
```

### Zpráva pro nepřihlášené

Pokud není uživatel přihlášen, zobrazí se:

```
┌──────────────────────────────────┐
│ Pro zobrazení stavu členství se  │
│ prosím přihlaste.                │
└──────────────────────────────────┘
```

### Žádné aktivní členství

Pokud uživatel nemá členství:

```
┌────────────────────────────────┐
│       Jan Novák                │
│   Žádné aktivní členství       │
│   [Upgrade členství]           │
└────────────────────────────────┘
```

---

## 💻 Technické detaily

### CSS třídy

```css
.pmp-membership-status-widget
.pmp-membership-status-card
.pmp-layout-card
.pmp-layout-inline
.pmp-layout-compact
.pmp-status-avatar
.pmp-status-name
.pmp-status-level
.pmp-level-badge
.pmp-no-membership
.pmp-status-expiry
.pmp-expiry-warning
.pmp-upgrade-button
.pmp-membership-status-logged-out
```

### Database query

Widget načítá aktivní členství z tabulky:

```sql
SELECT m.*, p.post_title as level_name
FROM wp_pmp_memberships m
LEFT JOIN wp_posts p ON m.level_id = p.ID
WHERE m.user_id = %d 
AND m.status = 'active'
AND (m.expires_at IS NULL OR m.expires_at > NOW())
ORDER BY m.created_at DESC
LIMIT 1
```

---

## 🎨 Přizpůsobení

### Custom CSS

```css
/* Změnit barvu badge */
.pmp-level-badge {
    background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%) !important;
}

/* Změnit styl tlačítka */
.pmp-upgrade-button {
    background: #48bb78 !important;
    border-radius: 30px !important;
}

/* Změnit pozadí karty */
.pmp-membership-status-card {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
    color: white !important;
}
```

---

## 📋 Checklist

**Po přidání widgetu:**

- ☐ Widget viditelný v seznamu
- ☐ Ikona zobrazena správně
- ☐ Všechna nastavení fungují
- ☐ Avatar se zobrazuje
- ☐ Jméno se zobrazuje
- ☐ Úroveň se zobrazuje
- ☐ Datum expirace správné
- ☐ Tlačítko funguje
- ☐ Layout přepínání funguje
- ☐ Responsive design OK

---

## 🐛 Troubleshooting

### Widget není viditelný

**Řešení:**
```
1. Zkontrolujte že Elementor je aktivní
2. Smažte Elementor cache
3. Deaktivujte + aktivujte PMP
4. Hard refresh editoru
```

### Avatar se nezobrazuje

**Řešení:**
```
1. Zkontrolujte že uživatel má Gravatar
2. Zkontrolujte nastavení "Zobrazit avatar"
3. Zkontrolujte WordPress nastavení avatarů
```

### Expirační datum nesprávné

**Řešení:**
```
1. Zkontrolujte timezone v WordPress
2. Zkontrolujte data v databázi
3. Zkontrolujte formát datetime
```

---

## 🎓 Video návod

```
1. Otevřete stránku v Elementoru
2. Vyhledejte "Stav členství"
3. Přetáhněte na stránku
4. Upravte nastavení
5. Změňte layout
6. Přizpůsobte barvy
7. Publikujte!
```

---

## 🌟 Best Practices

### Tip 1: Použijte kompaktní layout v sidebaru
```
→ Zabírá méně místa
→ Stále zobrazuje důležité info
```

### Tip 2: Přidejte na účetní stránku
```
→ Uživatel okamžitě vidí stav
→ Rychlý přístup k upgrade
```

### Tip 3: Kombinujte s dalšími widgety
```
[Stav členství]
[Member Content] ← Podmíněný obsah
[Pricing Table] ← Nabídka upgradů
```

---

**Widget je připraven k použití!** 🎉

**Přidejte ho na jakoukoli stránku v Elementoru!** ✨
