# 🔧 Debug Soubory - Návod k použití

## ⚠️ DŮLEŽITÉ

Debug soubory v pluginu **NEJSOU** automaticky aktivní!

```
❌ Neaktivují se sami
❌ Nevytvářejí samostatné pluginy
✅ Jsou pouze pomocné nástroje
✅ Použijte je jen když potřebujete
```

---

## 📁 Debug soubory v pluginu

### 1. `debug-elementor.php`

**Účel:** Diagnostika Elementor integrace

**Jak použít:**

**Varianta A: Do functions.php**
```php
// Zkopírujte celý obsah debug-elementor.php
// do functions.php vašeho motivu
```

**Varianta B: Jako plugin**
```php
1. Otevřete debug-elementor.php
2. Odkomentujte řádky s "Plugin Name:"
3. Uložte soubor
4. Aktivujte v Pluginech
```

---

### 2. `debug-metaboxes.php`

**Účel:** Diagnostika meta boxů

**Jak použít:**

```php
// Zkopírujte celý obsah do functions.php
```

---

## 🚀 Kdy použít debug soubory

### Použijte když:

- ❌ Meta boxy se nezobrazují
- ❌ Elementor sekce chybí
- ❌ Sloupec úrovní není viditelný
- ❌ Chcete vidět diagnostické info

### Nepoužívejte když:

- ✅ Vše funguje správně
- ✅ Na produkčním webu
- ✅ Nechcete debug info

---

## 📋 Návod krok za krokem

### Debug Elementor integrace:

```
1. Otevřete wp-content/themes/VÁŠ-MOTIV/functions.php
2. Na konec souboru přidejte:

<?php
// PMP Elementor Debug
include_once WP_PLUGIN_DIR . '/premium-membership-pro/debug-elementor.php';
?>

3. Uložte soubor
4. Otevřete stránku v Elementoru
5. Uvidíte debug panel
6. Po vyřešení problému odstraňte kód
```

### Debug Meta Boxů:

```
1. Otevřete wp-content/themes/VÁŠ-MOTIV/functions.php
2. Na konec souboru přidejte:

<?php
// PMP Meta Boxes Debug
include_once WP_PLUGIN_DIR . '/premium-membership-pro/debug-metaboxes.php';
?>

3. Uložte soubor
4. Otevřete editor příspěvku
5. Uvidíte debug info
6. Po vyřešení problému odstraňte kód
```

---

## ⚠️ Varování

**NIKDY nenechávejte debug soubory aktivní na produkci!**

```
❌ Zpomalují web
❌ Zobrazují interní info
❌ Můžou odhalit strukturu
❌ Jsou jen pro development
```

**Po vyřešení problému:**
```
1. Odstraňte kód z functions.php
2. Nebo deaktivujte debug plugin
3. ✅ Debug je vypnutý
```

---

## 🔍 Co zobrazují debug soubory

### debug-elementor.php

```
🔍 PMP Elementor Debug
├─ Post Info
│  ├─ Post ID: 123
│  ├─ Post Type: page
│  └─ Post Status: publish
├─ Classes Loaded
│  ├─ PMP_Meta_Boxes: ✅
│  ├─ PMP_Elementor: ✅
│  └─ Elementor\Plugin: ✅
├─ Elementor Status
│  ├─ Elementor loaded: ✅
│  └─ PMP enabled: ✅
├─ Hooks Registered
│  └─ register_controls: ✅
└─ Meta Values
   ├─ _pmp_enable_protection: 1
   └─ _pmp_required_levels: [1,2]
```

### debug-metaboxes.php

```
🔍 PMP Debug Info
├─ Current Screen: post
├─ Post Type: post
├─ Classes loaded
│  ├─ PMP_Meta_Boxes: ✅
│  ├─ PMP_Content_Lock: ✅
│  └─ PMP_Membership_Assignment: ✅
├─ Hooks registered
│  └─ add_meta_boxes: ✅ (15 callbacks)
└─ Registered meta boxes
   ├─ pmp-membership-settings
   ├─ pmp_content_lock
   └─ pmp_membership_assignment
```

---

## 💡 Alternativní debug metody

### 1. WP_DEBUG

```php
// wp-config.php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);

// Pak zkontrolujte: /wp-content/debug.log
```

### 2. Browser Console

```
F12 → Console
Hledejte:
- Red errors
- PMP messages
- AJAX errors
```

### 3. Network Tab

```
F12 → Network
Zkontrolujte:
- post-level-column.css načten?
- post-level-column.js načten?
- AJAX requesty OK?
```

---

## 🆘 Pomoc

**Pokud debug soubory nepomohly:**

1. ✅ Pošlete debug log
2. ✅ Screenshot debug panelu
3. ✅ Verze WordPress/PHP
4. ✅ Seznam pluginů

**Kontakt:**
- 📧 info@conexo.cz
- 💬 GitHub Issues

---

## ✅ Checklist

**Před kontaktováním podpory:**

- ☐ WP_DEBUG zapnutý
- ☐ debug.log zkontrolovaný
- ☐ Debug soubory použity
- ☐ Browser console zkontrolována
- ☐ Network tab zkontrolován
- ☐ Verze pluginu 1.5.7+
- ☐ Cache vymazána
- ☐ Plugin deaktivován/aktivován

---

**Debug soubory jsou nástroje - použijte je moudrě!** 🔧✨
