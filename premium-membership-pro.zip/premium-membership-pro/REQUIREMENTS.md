# Systémové požadavky

## ✅ Minimální požadavky

### Server
- **PHP:** 8.0 nebo novější
- **MySQL:** 5.7+ nebo MariaDB 10.2+
- **HTTPS:** Doporučeno (pro platební brány povinné)
- **Memory Limit:** 256MB doporučeno (128MB minimum)
- **Max Execution Time:** 300s doporučeno

### WordPress
- **Verze:** 6.4 nebo novější
- **Testováno až do:** 6.9
- **Multisite:** Ano, plně kompatibilní

### PHP Extensions (povinné)
- ✅ `mysqli` nebo `pdo_mysql`
- ✅ `json`
- ✅ `mbstring`
- ✅ `curl`
- ✅ `openssl`
- ✅ `zip`

### PHP Extensions (volitelné)
- 🔹 `imagick` nebo `gd` (pro manipulaci s obrázky)
- 🔹 `opcache` (pro lepší výkon)
- 🔹 `redis` nebo `memcached` (pro caching)

## 🎯 Doporučená konfigurace

### Pro optimální výkon:

```ini
; php.ini
memory_limit = 512M
max_execution_time = 300
post_max_size = 64M
upload_max_filesize = 64M
max_input_vars = 5000
```

### PHP 8.3 konfigurace:

```ini
; Optimalizace pro PHP 8.3
opcache.enable = 1
opcache.memory_consumption = 256
opcache.interned_strings_buffer = 16
opcache.max_accelerated_files = 10000
opcache.validate_timestamps = 0
opcache.jit = 1255
opcache.jit_buffer_size = 128M
```

## 🔌 Kompatibilita s pluginy

### Plně kompatibilní:
- ✅ **Elementor** 3.0+ (včetně vlastních widgetů)
- ✅ **WooCommerce** 5.0+
- ✅ **Yoast SEO**
- ✅ **Contact Form 7**
- ✅ **WP Mail SMTP**
- ✅ **Advanced Custom Fields (ACF)**
- ✅ **User Role Editor**
- ✅ **Members Plugin**

### Testováno s:
- ✅ W3 Total Cache
- ✅ WP Super Cache
- ✅ Autoptimize
- ✅ Wordfence Security
- ✅ All in One SEO

### Cache pluginy:
- ✅ Automatická invalidace cache při změnách
- ✅ Podpora page cache
- ✅ Podpora object cache

## 🎨 Kompatibilita s tématy

### Block Themes (FSE):
- ✅ Twenty Twenty-Four
- ✅ Twenty Twenty-Three
- ✅ Twenty Twenty-Two
- ✅ Všechna block-based témata

### Classic Themes:
- ✅ Astra
- ✅ GeneratePress
- ✅ OceanWP
- ✅ Neve
- ✅ Kadence
- ✅ Hello Elementor

## 🌐 Hosting kompatibilita

### Testováno na:
- ✅ **WP Engine** (doporučeno)
- ✅ **Kinsta**
- ✅ **SiteGround**
- ✅ **Bluehost**
- ✅ **Cloudways**
- ✅ **DigitalOcean**
- ✅ **AWS Lightsail**
- ✅ **Localhost** (XAMPP, MAMP, Local by Flywheel)

### Managed WordPress hosting:
- ✅ Plná kompatibilita
- ✅ Optimalizováno pro managed prostředí
- ✅ Respektuje hosting limity

## 📱 Browser kompatibilita

### Desktop:
- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+

### Mobile:
- ✅ iOS Safari 14+
- ✅ Chrome Mobile
- ✅ Firefox Mobile

## 🔒 Bezpečnost

### Požadované pro platby:
- ✅ **SSL certifikát** (HTTPS)
- ✅ **PCI DSS compliance** (pro ukládání kreditních karet)
- ✅ **Aktuální WordPress** (bezpečnostní aktualizace)
- ✅ **Aktuální PHP** (bezpečnostní aktualizace)

### Doporučené:
- 🔹 Two-factor authentication
- 🔹 Firewall (Wordfence, Sucuri)
- 🔹 Regular backups
- 🔹 Security monitoring

## 📊 Výkonnostní požadavky

### Pro 1000 členů:
- RAM: 512MB minimum
- CPU: 2 cores doporučeno
- Disk: 1GB volného místa

### Pro 10,000 členů:
- RAM: 1GB minimum
- CPU: 4 cores doporučeno
- Disk: 5GB volného místa
- Database: Optimalizovaná (indexy)

### Pro 100,000+ členů:
- RAM: 4GB+
- CPU: 8+ cores
- Disk: SSD doporučeno
- Database: Dedicated server
- Cache: Redis/Memcached povinné
- CDN: Doporučeno

## 🚀 PHP Verze

### Podporované:
| Verze | Status | Poznámka |
|-------|--------|----------|
| PHP 8.3 | ✅ Doporučeno | Nejnovější, nejrychlejší |
| PHP 8.2 | ✅ Plná podpora | Stabilní |
| PHP 8.1 | ✅ Plná podpora | Stabilní |
| PHP 8.0 | ✅ Plná podpora | Minimum |
| PHP 7.4 | ❌ Nepodporováno | EOL (End of Life) |

### Proč PHP 8.0+?

- ⚡ **Rychlost:** JIT compiler (až 3x rychlejší)
- 🔒 **Bezpečnost:** Aktivní security updates
- 🎯 **Moderní syntax:** Typed properties, match expressions
- 📦 **Lepší paměťová správa:** Snížená spotřeba RAM
- 🚀 **Named arguments:** Čitelnější kód

## 📋 Kontrolní seznam před instalací

```
□ PHP 8.0 nebo novější
□ WordPress 6.4 nebo novější
□ MySQL 5.7+ nebo MariaDB 10.2+
□ 256MB+ RAM
□ SSL certifikát (pro produkci)
□ Backup databáze
□ Backup souborů
□ Testovací prostředí (doporučeno)
```

## 🧪 Testování

### Development:
```bash
# Minimální požadavky pro development
PHP 8.0+
WordPress 6.4+
MySQL 5.7+
```

### Staging:
```bash
# Stejné jako produkce
PHP 8.3
WordPress 6.9
MySQL 8.0
SSL certifikát
```

### Production:
```bash
# Doporučená konfigurace
PHP 8.3
WordPress 6.9 (latest)
MySQL 8.0
HTTPS
Managed hosting
CDN
Backup systém
Monitoring
```

## 📞 Podpora

Pokud váš hosting nesplňuje požadavky:

📧 **E-mail:** info@conexo.cz  
🌐 **Web:** https://conexo.cz/podpora

---

**CONEXO s.r.o. | Litoměřice, Česká republika**

**Aktualizováno:** 8.12.2024  
**Plugin verze:** 1.4.4
