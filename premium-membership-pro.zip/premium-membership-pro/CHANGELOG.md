# Changelog

Všechny významné změny v tomto projektu budou zdokumentovány v tomto souboru.

Formát vychází z [Keep a Changelog](https://keepachangelog.com/cs/1.0.0/),
a tento projekt dodržuje [Semantic Versioning](https://semver.org/lang/cs/).

## [1.11.0] - 2024-12-10

### 🚨 ULTIMATE ŘEŠENÍ - SHUTDOWN HOOK!
- 💪 **Nový `shutdown` hook - běží na KONCI každého requestu**
- ✅ Zkontroluje VŠECHNY příspěvky upravené v posledních 5 minutách
- ✅ Najde ty s prázdným `_pmp_protected`
- ✅ OPRAVÍ JE automaticky (DELETE + INSERT + VERIFY)
- ✅ Běží s prioritou 999 (úplně poslední)
- ✅ Funguje pro nové posty i inline editor

### Jak To Funguje
```php
add_action('shutdown', 'ultimate_protection_check', 999);

Na konci KAŽDÉHO requestu:
1. SELECT ID FROM wp_posts WHERE post_modified >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)
2. Pro každý post:
   - SELECT meta_value WHERE meta_key = '_pmp_protected'
   - IF empty:
     * DELETE old
     * INSERT '1'
     * VERIFY
3. Log: Fixed X posts
```

### Proč Shutdown Hook
```
Všechny ostatní hooky můžou selhat nebo být přepsány
Shutdown hook běží POSLEDNÍ - po všech ostatních
Funguje jako "záchranná síť"
Opraví JAKÉKOLIV prázdné hodnoty
```

### Debug Výstup
```
=== PMP ULTIMATE PROTECTION CHECK (shutdown) ===
PMP: Checking 3 recently modified posts
PMP: Post 123 has empty _pmp_protected - FIXING NOW
PMP: ✅ FIXED post 123 → _pmp_protected = '1'
PMP: Post 456 has empty _pmp_protected - FIXING NOW
PMP: ✅ FIXED post 456 → _pmp_protected = '1'
PMP: Fixed 2 posts
=== PMP ULTIMATE CHECK END ===
```

### Kompletní Ochrana (6 Úrovní!)
1. `wp_insert_post` hook (nové posty)
2. `save_post` hook (uložení)
3. `transition_post_status` hook (změna statusu)
4. Inline editor SQL (AJAX)
5. `default_post_metadata` filter (čtení)
6. `shutdown` hook ← NOVÝ! (záchranná síť)

## [1.10.4] - 2024-12-10

### 🔥 MAXIMÁLNÍ AGRESIVITA - RAW SQL!
- 💪 **Přepsáno na raw SQL queries místo $wpdb->insert()**
- ✅ DELETE pomocí $wpdb->query() + prepared statement
- ✅ INSERT pomocí $wpdb->query() + prepared statement
- ✅ REPLACE INTO jako fallback (MySQL specific)
- ✅ Row count check - zjistí jestli VŮBEC existuje řádek
- ✅ Loguje KAŽDÝ SQL dotaz včetně chyb

### Změny
```php
// ❌ STARÉ (v1.10.3):
$wpdb->insert($wpdb->postmeta, array(...));

// ✅ NOVÉ (v1.10.4):
$sql = $wpdb->prepare("INSERT INTO wp_postmeta (post_id, meta_key, meta_value) VALUES (%d, %s, %s)", ...);
$result = $wpdb->query($sql);
error_log("Query: {$sql}");
error_log("Result: {$result}");

// REPLACE INTO fallback:
$wpdb->query("REPLACE INTO wp_postmeta ...");

// Row count check:
$count = $wpdb->get_var("SELECT COUNT(*) FROM wp_postmeta WHERE ...");
```

### Debug Výstup
```
=== PMP INLINE SAVE - SQL OPERATIONS ===
PMP: Target table: wp_postmeta
PMP: Will save _pmp_protected = '1'

Step 1 - DELETE query: DELETE FROM wp_postmeta WHERE post_id = 123 AND meta_key = '_pmp_protected'
Step 1 - DELETE result: 1

Step 2 - INSERT query: INSERT INTO wp_postmeta (post_id, meta_key, meta_value) VALUES (123, '_pmp_protected', '1')
Step 2 - INSERT result: 1

Step 3 - VERIFY query: SELECT meta_value FROM wp_postmeta WHERE post_id = 123 AND meta_key = '_pmp_protected'
Step 3 - VERIFY result: '1'

Step 5 - Row count: 1
✅ SUCCESS - Value is '1'
```

### Pokud Selže
```
Step 2 - INSERT result: 0  ← FAILED!
Step 2 - INSERT error: [MySQL error message]

Step 4 - VERIFICATION FAILED! Using REPLACE INTO...
Step 4 - REPLACE query: REPLACE INTO wp_postmeta ...
Step 4 - REPLACE result: 2
Step 4 - VERIFY after REPLACE: '1'

Step 5 - Row count: 1
✅ SUCCESS - Value is '1'
```

## [1.10.3] - 2024-12-10

### 🔍 DIAGNOSTICKÁ VERZE
- 🐛 **Ultra-verbose debug logging pro checkbox "Chránit obsah"**
- ✅ Loguje všechny možné varianty hodnoty enable_protection
- ✅ Kontroluje: true, 'true', '1', 1 (všechny varianty)
- ✅ Jasně řekne proč hodnota nebyla nastavena

### Debug Výstup
```
RAW POST data:
  enable_protection RAW: true
  enable_protection type: boolean
  enable_protection === true: YES
  enable_protection === 'true': NO
  enable_protection === '1': NO
  enable_protection === 1: NO

PMP: enable_protection SET TO TRUE from POST data
```

### Účel
Tato verze pomůže identifikovat:
- Jestli JavaScript posílá checkbox správně
- V jakém formátu (boolean/string/number)
- Proč PHP to možná nerozpoznává

Po diagnostice podle logu upravíme kód.

## [1.10.2] - 2024-12-10

### 🔥 KRITICKÁ OPRAVA - SELECTED LEVELS = PROTECTED!
- 💪 **GARANTOVANÁ logika: Pokud jsou vybrané úrovně → _pmp_protected = '1'**
- ✅ JavaScript opraveno: VŽDY sbírá selected_levels (ne pouze když checkbox)
- ✅ JavaScript auto-enable: Pokud selected_levels.length > 0 → enableProtection = true
- ✅ PHP zesíleno: Dvojitá kontrola selected_levels
- ✅ PHP GUARANTEE: `$protection_value = ($enable_protection || !empty($selected_levels)) ? '1' : '0'`

### Co Bylo Špatně
```javascript
// ❌ STARÉ (v1.10.1):
if (enableProtection) {
    // Sbírej selected_levels
}
// → Pokud checkbox nebyl zaškrtnutý, selected_levels se neposlaly!

// ✅ NOVÉ (v1.10.2):
// VŽDY sbírej selected_levels
if (selectedLevels.length > 0) {
    enableProtection = true;  // Auto-enable
}
```

### Co Je Opraveno v PHP
```php
// KRITICKÁ KONTROLA:
if (!empty($selected_levels)) {
    $enable_protection = true;  // FORCE
}

// DVOJITÁ GARANCE:
$protection_value = ($enable_protection || !empty($selected_levels)) ? '1' : '0';

// NEMŮŽE BÝT '0' POKUD JSOU ÚROVNĚ!
```

### Debug Výstup
```
PMP: FORCED enable_protection = TRUE because selected_levels is not empty
COMPUTED values:
  enable_protection: TRUE
  selected_levels: 5,7
  Will save _pmp_protected = 1
FINAL protection_value: 1
Reason: selected_levels not empty
```

## [1.10.1] - 2024-12-10

### 🔥 KRITICKÁ OPRAVA INLINE EDITORU
- 💪 **NUCLEAR OPTION pro inline editor**
- ✅ Třetí pokus o uložení pokud první dva selhaly
- ✅ Raw SQL bez prepared statements jako poslední záchrana
- ✅ WordPress cache clear (`wp_cache_delete` + `clean_post_cache`)
- ✅ Přímý SQL read pro display HTML (bypass cache)
- ✅ Absolutní finální verifikace před odesláním odpovědi

### Co Je Nového
```php
// Pokud hodnota STÁLE není správná po 2 pokusech:
if ($verify_sql !== $protection_value) {
    // NUCLEAR OPTION:
    $wpdb->query("DELETE FROM wp_postmeta WHERE post_id = X AND meta_key = '_pmp_protected'");
    $wpdb->query("INSERT INTO wp_postmeta (post_id, meta_key, meta_value) VALUES (X, '_pmp_protected', '1')");
    
    // Absolute final verification
}

// Clear WordPress cache
wp_cache_delete($post_id, 'post_meta');
clean_post_cache($post_id);

// Read directly from DB (bypass cache)
$is_protected = $wpdb->get_var("SELECT meta_value FROM wp_postmeta...");
```

### Debug Výstup Rozšířen
```
FINAL VERIFICATION:
  Direct SQL: '1'
  get_post_meta: '1'
  SUCCESS: YES ✅

POKUD NE:
CRITICAL: Value still not correct! FORCING FINAL TIME...
  ABSOLUTE FINAL VALUE: '1'
```

### Proč Cache Clear
- WordPress cache může vracet staré hodnoty
- `wp_cache_delete()` vymaže object cache
- `clean_post_cache()` vymaže post cache
- Přímý SQL read pro display HTML

## [1.10.0] - 2024-12-10

### 🎉 NOVÁ FUNKCE
- 🆕 **Automatické přidání nových uživatelů do členství**
- ✅ Hook `user_register` - spustí se při registraci KAŽDÉHO nového uživatele
- ✅ Automaticky přiřadí výchozí membership level
- ✅ Pokud neexistuje žádná úroveň → vytvoří "Registrovaný"
- ✅ Zapisuje do tabulky `wp_pmp_memberships`
- ✅ Status: 'active'
- ✅ Rozšířené debug logování

### Jak To Funguje
```php
add_action('user_register', 'auto_assign_membership_to_new_user');

Když se nový uživatel zaregistruje:
1. Najde výchozí membership level (první active)
2. Pokud žádný neexistuje → vytvoří "Registrovaný"
3. INSERT do wp_pmp_memberships:
   - user_id
   - level_id
   - status = 'active'
   - start_date = now
4. Verifikuje že se uložilo
```

### Debug Výstup
```
=== PMP AUTO-ASSIGN MEMBERSHIP ===
PMP: New user registered: user_id=456
PMP: Using existing default level: Registrovaný (ID=1)
PMP: ✅ SUCCESS - Membership assigned (membership_id=123)
=== PMP AUTO-ASSIGN END ===
```

### Kompletní Řešení
**Nové příspěvky:**
- ✅ _pmp_protected = '1' (4 hooky - v1.9.6)

**Noví uživatelé:**
- ✅ Automaticky přidáni do členství (v1.10.0)

## [1.9.6] - 2024-12-10

### 🚀 PŘELOMOVÁ OPRAVA
- 💪 **Přidán `transition_post_status` hook - NEMŮŽE SELHAT!**
- ✅ Zachytí KAŽDOU změnu statusu příspěvku (draft → publish, atd.)
- ✅ Kontroluje hodnotu pomocí přímého SQL
- ✅ Pokud chybí → SQL DELETE + INSERT
- ✅ Běží při KAŽDÉM uložení/publikování
- ✅ Rozšířené debug logování

### Nový Hook: transition_post_status
```php
add_action('transition_post_status', array(__CLASS__, 'ensure_protection_on_publish'), 10, 3);

// Volá se při KAŽDÉ změně statusu:
// - new → draft
// - draft → publish  ← HLAVNĚ TOTO!
// - publish → publish (update)
// - draft → draft (save)
```

### Proč Toto MUSÍ Fungovat
```
wp_insert_post může přeskočit některé případy
→ transition_post_status zachytí VŠE

Běží při:
✅ Vytvoření konceptu
✅ Publikování konceptu
✅ Aktualizaci příspěvku
✅ KAŽDÉ změně statusu
```

### Debug Výstup
```
=== PMP TRANSITION POST STATUS ===
PMP: post_id=123, title=Nový příspěvek
PMP: old_status=draft → new_status=publish
PMP: Current _pmp_protected value: NULL
PMP: VALUE MISSING! Forcing SQL insert...
PMP: INSERT result: 1
PMP: Verification: '1'
PMP: ✅ SUCCESS - _pmp_protected = '1'
=== PMP TRANSITION END ===
```

### Celkové Pokrytí (4 Hooky!)
1. `transition_post_status` ← NOVÝ! Zachytí vše
2. `wp_insert_post` (v1.9.5)
3. `save_post` (v1.9.0)
4. `default_post_metadata` filter (v1.9.0)

## [1.9.5] - 2024-12-10

### 🔥 KRITICKÁ OPRAVA
- 💪 **KAŽDÝ NOVÝ PŘÍSPĚVEK má _pmp_protected IHNED při vytvoření**
- ✅ `wp_insert_post` hook používá přímý SQL (ne update_post_meta)
- ✅ DELETE + INSERT při vytvoření každého příspěvku
- ✅ Okamžitá SQL verifikace
- ✅ Debug logging pro nové příspěvky

### Změněno v wp_insert_post Hook
```php
// ❌ STARÉ: update_post_meta (může selhat)
update_post_meta($post_id, '_pmp_protected', '1');

// ✅ NOVÉ: Přímý SQL (garantované uložení)
$wpdb->delete(...);  // Smaž staré
$wpdb->insert(...);  // Vlož nové
$verify = $wpdb->get_var(...);  // Ověř ihned
update_post_meta(...);  // Pro cache
```

### Debug Výstup Pro Nové Příspěvky
```
=== PMP NEW POST CREATED ===
PMP: post_id=123, title=Nový příspěvek, type=post
PMP: INSERT result: 1
PMP: SQL verification: '1'
PMP: SUCCESS - New post has _pmp_protected = '1' ✅
=== PMP NEW POST END ===
```

### Pokrytí
- ✅ Nové příspěvky: SQL při wp_insert_post
- ✅ Inline editor: SQL při uložení (v1.9.4)
- ✅ Existující příspěvky: default_post_metadata filter (v1.9.0)
- ✅ 100% pokrytí všech scénářů

## [1.9.4] - 2024-12-10

### 🔥 PŘELOMOVÁ ZMĚNA
- 💪 **FORCE IMMEDIATE SYNCHRONOUS SAVE**
- ✅ DELETE + INSERT HNED na začátku (ne až jako fallback)
- ✅ Žádné čekání na hooky nebo filtry
- ✅ 6-krokový proces pro garantované uložení
- ✅ Okamžitá SQL verifikace
- ✅ Retry mechanismus pokud hodnota nesedí
- ✅ Dvojitá kontrola: SQL + get_post_meta

### Technické - 6 Kroků Uložení
```
1. DELETE existing _pmp_protected (čistý start)
2. INSERT new value (přímý SQL zápis)
3. IMMEDIATE SQL verification (kontrola)
4. IF mismatch → INSERT ... ON DUPLICATE KEY UPDATE (retry)
5. update_post_meta (pro WordPress cache)
6. FINAL verification (SQL + get_post_meta)
```

### Proč Toto MUSÍ Fungovat
- 🚀 SQL jako PRIMÁRNÍ metoda (ne fallback)
- 🚀 Synchronní operace (ne asynchronní)
- 🚀 Žádné hooky před zápisem
- 🚀 Retry pokud první pokus selže
- 🚀 Dvojitá verifikace před odesláním odpovědi

## [1.9.3] - 2024-12-10

### Přidáno
- 🚀 **SQL FALLBACK pro garantované uložení**
- ✅ Pokud `update_post_meta()` selže → použije přímý SQL
- ✅ `DELETE` + `INSERT` pro čistý zápis
- ✅ Okamžitá verifikace po uložení
- ✅ Pokud hodnota není správná → SQL záchrana
- ✅ Dvojitá verifikace: get_post_meta() + přímý SQL dotaz

### Debug Výstup Rozšířen
```
=== PMP Inline Save START ===
RAW POST data: ...
COMPUTED values: ...
UPDATE RESULT: (bool) true/false
USING SQL FALLBACK! (pokud update selhal)
  SQL insert result: 1/false
FINAL VERIFICATION:
  _pmp_protected after save: '1'
  Direct SQL query result: '1'
=== PMP Inline Save END ===
```

### Technické
- 🔧 2-vrstvá záchrana:
  1. `update_post_meta()` (preferovaná metoda)
  2. Přímý SQL (pokud 1 selže)
- 🔧 SQL: `DELETE` + `INSERT` místo `UPDATE`
- 🔧 Ověření před odesláním odpovědi

## [1.9.2] - 2024-12-10

### Přidáno
- 🔍 **Rozšířené debug logování pro inline editor**
- ✅ Loguje RAW POST data (typ, hodnota)
- ✅ Loguje COMPUTED values (enable_protection, selected_levels)
- ✅ Loguje VERIFICATION (hodnota po uložení)
- ✅ Pomůže identifikovat proč se _pmp_protected neukládá

### Debug Výstup
```
PMP Inline Save - RAW POST data:
  post_id: 123
  enable_protection: true (boolean)
  selected_levels: array(5, 7)

PMP Inline Save - COMPUTED values:
  enable_protection: TRUE
  selected_levels: 5,7
  Will save _pmp_protected = 1

PMP Inline Save - VERIFICATION:
  _pmp_protected after save: '1'
```

## [1.9.1] - 2024-12-10

### Opraveno
- 🐛 **Inline editor nyní správně ukládá `_pmp_protected`**
- ✅ Opravena kontrola `enable_protection` v PHP
- ✅ JavaScript posílá boolean, PHP nyní rozpozná boolean i string
- ✅ Přidán debug logging pro diagnostiku

### Technické
- 🔧 PHP nyní akceptuje:
  - `$_POST['enable_protection'] === true` (boolean)
  - `$_POST['enable_protection'] === 'true'` (string)
  - `$_POST['enable_protection'] === '1'` (string)
- 🔧 Debug log: "PMP Inline Save: post_id=X, enable_protection=true/false"

## [1.9.0] - 2024-12-10

### 🔥 PŘELOMOVÁ ZMĚNA
- ✅ **Výchozí hodnota změněna z '0' na '1'**
- ✅ **Nové příspěvky jsou CHRÁNĚNÉ by default**
- ✅ **Uživatel musí explicitně zveřejnit příspěvek**

### Přidáno
- 🚀 **GARANTOVANÝ filter `default_post_metadata`**
- ✅ Vrací '1' když meta neexistuje v databázi
- ✅ Automaticky ukládá do databáze při prvním čtení
- ✅ Funguje i když hooky selžou
- ✅ 3 úrovně ochrany:
  1. `default_post_metadata` filter (VŽDY funguje)
  2. `wp_insert_post` hook
  3. `save_post` hook

### Opraveno
- 🐛 Konečně vyřešen problém s prázdnými hodnotami
- 🐛 Hodnota je GARANTOVANÁ i když hooky selžou
- 🐛 Filter zachytí každý případ

### Technické
- 🔧 Filter kontroluje databázi přímo pomocí SQL
- 🔧 Pokud meta neexistuje → vrátí '1' a uloží
- 🔧 Pokud meta je prázdné → vrátí '1' a aktualizuje
- 🔧 Nové příspěvky: force '1' v wp_insert_post

## [1.8.9] - 2024-12-10

### Opraveno
- 🐛 **Přidán agresivnější hook `wp_insert_post` pro nastavení výchozí hodnoty**
- ✅ Nové příspěvky URČITĚ dostanou `_pmp_protected = '0'`
- ✅ Hook `wp_insert_post` běží dříve než `save_post`

### Přidáno
- ✅ Nová metoda `set_default_protection_on_insert()`
- ✅ Rozlišuje mezi novými příspěvky ($update = false) a aktualizacemi
- ✅ Debug logging pro diagnostiku

### Technické
- 🔧 DVA hooky zajišťují nastavení hodnoty:
  1. `wp_insert_post` (priorita 10) - běží jako první
  2. `save_post` (priorita 5) - záložní řešení
- 🔧 Nové příspěvky ($update = false) mají prioritu
- 🔧 Existující příspěvky s prázdnou hodnotou se vyplní

## [1.8.8] - 2024-12-10

### Opraveno
- 🔄 **Výchozí hodnota `_pmp_protected` vrácena zpět na '0' (veřejný)**
- ✅ Nové příspěvky jsou defaultně **veřejné** (jako v1.8.6)
- ✅ Ale hodnota **nikdy není prázdná** - vždy je '0' nebo '1'

### Důvod Změny
- 📝 Uživatel preferuje veřejné příspěvky by default
- 🔓 Běžnější workflow: vytvoř veřejný → pak případně ochraň
- ✅ Ale stále platí: hodnota NIKDY není prázdná!

### Technické
- ✅ set_default_protection_value() nastavuje '0' (jako v1.8.6)
- ✅ Hook zajišťuje že hodnota nikdy není prázdná
- ✅ Meta box zobrazí odškrtnuté "Povolit ochranu"
- ✅ Sloupec "Úroveň" zobrazí "🔓 Veřejný"

## [1.8.7] - 2024-12-10

### Změněno
- 🔄 **Výchozí hodnota `_pmp_protected` změněna z '0' na '1'**
- 🔄 Nové příspěvky jsou nyní **defaultně chráněné** (protected by default)
- 🔄 Uživatel musí explicitně odškrtnout "Chránit obsah" aby byl příspěvek veřejný

### Důvod Změny
- 📝 Na základě požadavku klienta: nové příspěvky mají být automaticky chráněné
- 🔒 Bezpečnější přístup: obsah je chráněný dokud ho explicitně nezveřejníš

### Technické
- ✅ set_default_protection_value() nyní nastavuje '1' místo '0'
- ✅ Meta box zobrazí "Chránit obsah" jako zaškrtnuté
- ✅ Sloupec "Úroveň" zobrazí "🔒 Chráněný" (bez úrovní)

## [1.8.6] - 2024-12-10

### Přidáno
- ✅ **Automatické nastavení výchozí hodnoty `_pmp_protected = '0'` pro nové příspěvky**
- ✅ Hook `set_default_protection_value()` na `save_post` s prioritou 5
- ✅ Kontrola existence hodnoty před nastavením
- ✅ Debug logging při nastavení výchozí hodnoty

### Opraveno
- 🐛 Nové příspěvky už nikdy nemají prázdnou hodnotu `_pmp_protected`
- 🐛 Sloupec "Úroveň" vždy zobrazuje správný stav (Veřejný/Chráněný)
- 🐛 Ochrana obsahu správně počítá procento i pro nové příspěvky

### Technické
- 🔄 Hook běží s prioritou 5 (před save_meta_boxes s prioritou 10)
- 🔄 Přeskakuje auto-drafts, revisions a autosave
- 🔄 Pouze pro post_type 'post' a 'page'

## [1.8.5] - 2024-12-10

### Přidáno
- ✅ **Automatické zapnutí ochrany při výběru úrovně v inline editoru**
- ✅ JavaScript automaticky zaškrtne "Chránit obsah" když vyber eš úroveň
- ✅ PHP backend automaticky zapne ochranu když jsou vybrané úrovně

### Opraveno
- 🐛 Meta box nyní načítá z `_pmp_protected` místo `_pmp_enable_protection`
- 🐛 Ochrana se nyní zapne i když uživatel zapomene zaškrtnout checkbox

### Vylepšeno
- 🔄 Intuitivnější UX - stačí vybrat úroveň a ochrana se zapne automaticky
- 🔄 Méně kroků pro uživatele

## [1.8.4] - 2024-12-10

### Opraveno
- 🐛 **KRITICKÉ: Sjednocen meta key pro ochranu obsahu na `_pmp_protected`**
- 🐛 Meta boxy nyní ukládají do `_pmp_protected` místo `_pmp_enable_protection`
- 🐛 Inline editace ukládá do správného meta key
- 🐛 Zobrazení sloupce "Úroveň" načítá správný meta key
- 🐛 Ochrana obsahu nyní správně počítá chráněný obsah
- 🐛 Admin bar menu používá správný meta key
- 🐛 SQL dotaz v ochraně obsahu používá INNER JOIN místo LEFT JOIN

### Vylepšeno
- 🔄 Konzistence napříč celým pluginem
- 🔄 Všechny komponenty nyní používají stejný meta key

## [1.8.3] - 2024-12-10

### Přidáno
- ✅ **Tlačítko "Vytvořit / Opravit Tabulky" v Nastavení**
- ✅ Přehled databázových tabulek se statusem
- ✅ Počet záznamů v každé tabulce
- ✅ Vizuální indikátory (✅/❌) pro každou tabulku
- ✅ Automatické zobrazení výsledku po vytvoření tabulek
- ✅ Potvrzovací dialog před vytvořením
- ✅ Bezpečné použití - zachová existující data

### Vylepšeno
- 🔄 Uživatelsky přívětivé rozhraní pro správu databáze
- 🔄 Jasné informace o stavu každé tabulky
- 🔄 Možnost manuálního vytvoření/opravy kdykoliv

## [1.8.2] - 2024-12-10

### Přidáno
- ✅ **Automatická kontrola databázových tabulek při každém načtení pluginu**
- ✅ Metoda `ensure_database_tables()` - kontroluje existenci tabulek
- ✅ Automatické vytvoření chybějících tabulek
- ✅ Admin notice při vytvoření tabulek
- ✅ Admin notice s řešením pokud vytvoření selže
- ✅ Debug logging pro diagnostiku

### Opraveno
- 🐛 **KRITICKÉ: Problém s chybějícími tabulkami po aktivaci**
- 🐛 Tabulky se nyní vytvoří i když aktivace selhala
- 🐛 Plugin je nyní plně funkční i bez manuálního zásahu

### Technické
- 🔄 Hook `plugins_loaded` s prioritou 1 pro kontrolu tabulek
- 🔄 Kontrola existence každé tabulky samostatně
- 🔄 Verifikace po vytvoření tabulek
- 🔄 Transient pro zobrazení notice pouze jednou

## [1.8.1] - 2024-12-10

### Opraveno
- 🐛 Opravena dbDelta syntaxe pro WordPress standardy
- 🐛 unsigned atribut pro všechny ID sloupce
- 🐛 PRIMARY KEY s dvojitou mezerou

### Přidáno
- ✅ create-tables-manual.php - manuální skript
- ✅ DATABASE-TROUBLESHOOTING.md - kompletní návod

## [1.8.0] - 2024-12-09

### Přidáno
- ✅ Fallback column registration (priorita 99999)
- ✅ PHP 8.0+ optimalizace

## [1.4.2] - 2024-12-08

### Opraveno
- 🐛 **KRITICKÉ: Menu se nyní vždy zobrazí Administrátorům**
- 🐛 Menu používá `manage_options` pro adminy místo vlastních capabilities
- 🐛 Capabilities se přidávají PŘED registrací menu (priority 5)
- 🐛 Early capability check v `plugins_loaded`

### Přidáno
- ✅ `early_capability_check()` metoda v main plugin file
- ✅ Capabilities se přidají před `admin_menu` hookem
- ✅ Fallback na `manage_options` pro všechny admin menu položky

### Vylepšeno
- 🔄 Menu registration používá `current_user_can('manage_options')`
- 🔄 14 submenu stránek s fallback capabilities
- 🔄 Jednodušší a spolehlivější menu system

## [1.4.1] - 2024-12-07

### Přidáno
- ✅ Vylepšené přidávání oprávnění pro Administrátory
- ✅ Automatická kontrola capabilities při admin_init
- ✅ Admin notice po aktivaci
- ✅ Tlačítko "Obnovit všechna oprávnění"

## [1.4.0] - 2024-12-07

### Přidáno
- ✅ Vyčištění dat při odinstalaci
- ✅ uninstall.php soubor
- ✅ Možnost zachovat data

## [1.3.1] - 2024-12-07

### Přidáno
- ✅ Admin nastavení pro Elementor

### Opraveno
- 🐛 Fatal errors při aktivaci

## [1.3.0] - 2024-12-07

### Přidáno
- ✅ Plná integrace s Elementorem
- ✅ 6 vlastních widgetů

## [1.2.0] - 2024-12-07

### Přidáno
- ✅ WordPress 6.9 kompatibilita

## [1.1.0] - 2024-12-06

### Přidáno
- ✨ Rozostřené náhledy článků
- 🎨 Tři typy náhledů

## [1.0.0] - 2024-12-06

### Přidáno
- ⭐ Iniciální release
- 💳 Membership systém
- 🔒 Ochrana obsahu
- 🇨🇿 Český překlad

---

[1.4.2]: https://github.com/conexo/premium-membership-pro/compare/v1.4.1...v1.4.2
[1.4.1]: https://github.com/conexo/premium-membership-pro/compare/v1.4.0...v1.4.1
[1.4.0]: https://github.com/conexo/premium-membership-pro/compare/v1.3.1...v1.4.0
[1.3.1]: https://github.com/conexo/premium-membership-pro/compare/v1.3.0...v1.3.1
[1.3.0]: https://github.com/conexo/premium-membership-pro/compare/v1.2.0...v1.3.0
[1.2.0]: https://github.com/conexo/premium-membership-pro/compare/v1.1.0...v1.2.0
[1.1.0]: https://github.com/conexo/premium-membership-pro/compare/v1.0.0...v1.1.0
[1.0.0]: https://github.com/conexo/premium-membership-pro/releases/tag/v1.0.0
